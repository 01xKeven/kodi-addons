import sys
import re
import xbmc
import xbmcgui
import xbmcaddon
import requests

# Configuración del Addon
_addon_name = "Control Parental IMDb"
ADDON = xbmcaddon.Addon()

# Diccionario para los colores y símbolos de severidad
SEVERITY_VISUALS = {
    "noneVotes":     {'color': 'white',  'char': '[COLOR white]█[/COLOR]'},
    "mildVotes":     {'color': 'green',  'char': '[COLOR green]█[/COLOR]'},
    "moderateVotes": {'color': 'yellow', 'char': '[COLOR yellow]█[/COLOR]'},
    "severeVotes":   {'color': 'red',    'char': '[COLOR red]█[/COLOR]'},
    "naVotes":       {'color': 'grey',   'char': '[COLOR grey]█[/COLOR]'},
}

# Orden de aparición en pantalla
CATEGORY_ORDER = ["SEXUAL_CONTENT", "VIOLENCE", "PROFANITY", "ALCOHOL_DRUGS", "FRIGHTENING_INTENSE_SCENES"]

# Textos según el idioma utilizando strings.po de Kodi
STRING_MAPPING = {
    'SEXUAL_CONTENT': 30000,
    'VIOLENCE': 30001,
    'PROFANITY': 30002,
    'ALCOHOL_DRUGS': 30003,
    'FRIGHTENING_INTENSE_SCENES': 30004,
    'none': 30005,
    'mild': 30006,
    'moderate': 30007,
    'severe': 30008,
    'title': 30009,
    'connecting': 30010,
    'processing': 30011,
    'finalizing': 30012,
    'no_results_title': 30013,
    'no_results_body': 30014,
    'error_title': 30015,
    'error_format': 30016,
    'error_connect': 30017,
    'keyboard_prompt': 30018,
    'post_credits': 30021,
    'audio_only': 30022,
    'na': 30023,
    'rating': 30024,
    'rated': 30025,
    'votes': 30026,
}

FALLBACK_STRINGS = {
    'es': {
        'SEXUAL_CONTENT': "Desnudos",
        'VIOLENCE': "Violencia",
        'PROFANITY': "Groserias",
        'ALCOHOL_DRUGS': "Alcohol y Drogas",
        'FRIGHTENING_INTENSE_SCENES': "Escenas intensas",
        'none': "Ninguno",
        'mild': "Leve",
        'moderate': "Moderada",
        'severe': "Severa",
        'title': "Control Parental IMDb",
        'connecting': "Conectando con IMDb...",
        'processing': "Procesando clasificaciones...",
        'finalizing': "Finalizando...",
        'no_results_title': "Sin Resultados",
        'no_results_body': 'No se encontró guía parental para "{title}".',
        'error_title': "Error",
        'error_format': "El formato del ID de IMDb es incorrecto.",
        'error_connect': "No se pudo obtener la guía parental: {error}",
        'keyboard_prompt': "Introduce el ID de IMDb (ttxxxxxxx)",
        'post_credits': "Post-Créditos",
        'audio_only': "Solo audio",
        'na': "N/A",
        'rating': "Valoración",
        'rated': "Clasificación",
        'votes': "votos",
    },
    'en': {
        'SEXUAL_CONTENT': "Nudity",
        'VIOLENCE': "Violence",
        'PROFANITY': "Profanity",
        'ALCOHOL_DRUGS': "Alcohol & Drugs",
        'FRIGHTENING_INTENSE_SCENES': "Intense Scenes",
        'none': "None",
        'mild': "Mild",
        'moderate': "Moderate",
        'severe': "Severe",
        'title': "IMDb Parental Guide",
        'connecting': "Connecting to IMDb...",
        'processing': "Processing ratings...",
        'finalizing': "Finalizing...",
        'no_results_title': "No Results",
        'no_results_body': 'No parental guide found for "{title}".',
        'error_title': "Error",
        'error_format': "The format of the IMDb ID is incorrect.",
        'error_connect': "Could not retrieve parental guide: {error}",
        'keyboard_prompt': "Enter IMDb ID (ttxxxxxxx)",
        'post_credits': "Post-Credits",
        'audio_only': "Audio only",
        'na': "N/A",
        'rating': "Rating",
        'rated': "Rated",
        'votes': "votes",
    }
}

def get_language():
    try:
        lang = xbmc.getLanguage(xbmc.ISO_639_1)
        if lang:
            return 'es' if lang.lower().startswith('es') else 'en'
    except Exception:
        pass
    try:
        lang_name = xbmc.getLanguage()
        if lang_name:
            if 'spanish' in lang_name.lower() or 'espanol' in lang_name.lower():
                return 'es'
            return 'en'
    except Exception:
        pass
    return 'en'

def get_string(key):
    string_id = STRING_MAPPING.get(key, key)
    if isinstance(string_id, int):
        try:
            val = ADDON.getLocalizedString(string_id)
            if val:
                return val
        except Exception:
            pass
    lang = get_language()
    result = FALLBACK_STRINGS[lang].get(key, FALLBACK_STRINGS['en'].get(key, str(key)))
    return result

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{_addon_name}] {msg}", level=level)

def severity_to_class(level):
    mapping = {
        "none":     (get_string("none"),  "noneVotes"),
        "mild":     (get_string("mild"),  "mildVotes"),
        "moderate": (get_string("moderate"), "moderateVotes"),
        "severe":   (get_string("severe"),   "severeVotes"),
    }
    return mapping.get(level, (get_string("na"), "naVotes"))

def format_vote_count(count):
    try:
        n = int(count)
    except (TypeError, ValueError):
        return None
    if n >= 1000000:
        value = n / 1000000.0
        text = f"{value:.1f}M" if value < 10 else f"{value:.0f}M"
        return text.replace(".0M", "M")
    if n >= 1000:
        value = n / 1000.0
        if value >= 100:
            text = f"{value:.0f}k"
        else:
            text = f"{value:.1f}k"
        return text.replace(".0k", "k")
    return str(n)


def normalize_imdb_id(value):
    """Acepta tt1234567 o solo 1234567."""
    if not value:
        return None
    value = str(value).strip()
    match = re.search(r'(tt\d{7,8})', value, flags=re.IGNORECASE)
    if match:
        return match.group(1).lower()
    if re.fullmatch(r'\d{7,8}', value):
        return 'tt' + value
    return None


def _title_tokens(value):
    stop = {
        'the', 'a', 'an', 'and', 'or', 'of', 'part', 'pts', 'pt',
        'season', 'episode', 'series', 'movie', 'film'
    }
    cleaned = re.sub(r'[^a-z0-9]+', ' ', (value or '').lower())
    return [t for t in cleaned.split() if t and t not in stop and not t.isdigit()]


def titles_look_related(left, right):
    """True si los títulos parecen el mismo contenido."""
    a = set(_title_tokens(left))
    b = set(_title_tokens(right))
    if not a or not b:
        return False
    if a <= b or b <= a:
        return True
    overlap = len(a & b)
    return overlap >= 2 and (overlap / float(min(len(a), len(b))) >= 0.5)


def search_imdb_suggestions(query, year=None):
    """Busca títulos en el endpoint público de sugerencias de IMDb."""
    query = (query or '').strip()
    if not query:
        return []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
        'Accept': 'application/json',
        'Referer': 'https://www.imdb.com/',
        'Origin': 'https://www.imdb.com',
    }
    results = []
    seen = set()
    attempts = [query]
    if year:
        attempts.append(f"{query} {year}")
    for term in attempts:
        try:
            url = 'https://v3.sg.media-imdb.com/suggestion/h/' + requests.utils.quote(term) + '.json'
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code != 200:
                log(f"Sugerencias IMDb HTTP {r.status_code} para '{term}'", level=xbmc.LOGWARNING)
                continue
            for item in (r.json().get('d') or []):
                iid = normalize_imdb_id(item.get('id'))
                if not iid or iid in seen:
                    continue
                seen.add(iid)
                results.append({
                    'id': iid,
                    'title': item.get('l') or '',
                    'year': item.get('y'),
                    'type': (item.get('qid') or '').lower(),
                })
        except Exception as e:
            log(f"Error buscando sugerencias IMDb: {e}", level=xbmc.LOGWARNING)
    return results


def pick_best_search_result(results, hint_title, hint_year=None, prefer_movie=True):
    if not results:
        return None
    scored = []
    for item in results:
        score = 0
        if titles_look_related(hint_title, item.get('title')):
            score += 8
        if hint_year and str(item.get('year') or '') == str(hint_year):
            score += 4
        itype = item.get('type') or ''
        if prefer_movie and itype == 'movie':
            score += 3
        if itype in ('tvepisode', 'podcastepisode', 'video'):
            score -= 2
        scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    best_score, best = scored[0]
    if best_score <= 0:
        return None
    return best


def format_rating_line(rating, votes):
    if rating is None and votes is None:
        return get_string("na")
    parts = []
    if rating is not None:
        try:
            parts.append(f"{float(rating):.1f}")
        except (TypeError, ValueError):
            parts.append(str(rating))
    vote_text = format_vote_count(votes)
    if vote_text:
        parts.append(f"{vote_text} {get_string('votes')}")
    return " / ".join(parts) if parts else get_string("na")

def get_episode_imdb_id(series_id, season, episode):
    try:
        url = 'https://api.graphql.imdb.com/'
        query = """
        query {
          title(id: "%s") {
            episodes {
              episodes(filter: {includeSeasons: ["%s"]}, first: 250) {
                edges {
                  node {
                    id
                    series {
                      displayableEpisodeNumber {
                        episodeNumber {
                          episodeNumber
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        """ % (series_id, season)

        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
            'Referer': 'https://www.imdb.com/',
            'Origin': 'https://www.imdb.com',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9,es;q=0.8'
        }
        r = requests.post(url, json={'query': query}, headers=headers, timeout=12)
        if r.status_code != 200:
            log(f"IMDb GraphQL devolvió código {r.status_code} al buscar episodios", level=xbmc.LOGWARNING)
            return None

        data = r.json()
        edges = data.get('data', {}).get('title', {}).get('episodes', {}).get('episodes', {}).get('edges', [])

        for edge in edges:
            node = edge.get('node', {})
            ep_num_str = node.get('series', {}).get('displayableEpisodeNumber', {}).get('episodeNumber', {}).get('episodeNumber')
            if ep_num_str and int(ep_num_str) == int(episode):
                ep_id = node.get('id', '')
                if ep_id.startswith('tt'):
                    return ep_id

        log(f"Episodio S{season:02d}E{episode:02d} no encontrado en la respuesta de GraphQL", level=xbmc.LOGWARNING)
    except Exception as e:
        log(f"Error buscando ID de episodio en GraphQL: {e}", level=xbmc.LOGWARNING)
    return None

def parse_crazy_credits(crazy_credits_edges):
    if not crazy_credits_edges:
        return {
            'has_stinger': False,
            'stinger_text': get_string("none"),
            'stinger_color': "FF7F8C8D"
        }

    def clean_stinger_text(t):
        t = re.sub(r'<[^>]+>', ' ', t)
        t = t.replace('&#39;', "'").replace('&quot;', '"').replace('&amp;', '&')
        t = re.sub(r'^(spoiler\s*:\s*|in\s+a\s+|there\s+is\s+a\s+)', '', t, flags=re.IGNORECASE)
        return t.strip()

    def are_duplicate_scenes(t1, t2):
        w1 = set(re.findall(r'\b[a-z]{4,}\b', t1.lower()))
        w2 = set(re.findall(r'\b[a-z]{4,}\b', t2.lower()))
        stop_words = {
            'credits', 'scene', 'after', 'during', 'closing', 'ending', 'appears',
            'there', 'shows', 'movie', 'scenes', 'credit', 'beginning', 'first',
            'another', 'extra', 'final', 'mid-credit', 'post-credit', 'leads',
            'spoilers', 'spoiler'
        }
        w1 -= stop_words
        w2 -= stop_words
        if w1 and w2:
            overlap = len(w1 & w2)
            jaccard = overlap / len(w1 | w2)
            if overlap >= 3:
                return True
            if overlap >= 2 and jaccard > 0.25:
                return True
        return False

    mid_scenes = []
    after_scenes = []
    audio_only = 0

    for edge in crazy_credits_edges:
        raw_text = edge.get('node', {}).get('text', {}).get('plaidHtml', '')
        text = raw_text.lower()

        if re.search(r'\b(only\s+\d+\s+episodes|episodes\s+have\s+post|episodes\s+got|there\s+are\s+\w+\s+extra\s+scenes|two\s+extra\s+scenes|last\s+episode,\s+there\s+are)\b', text):
            continue

        if any(x in text for x in ['animated sequence featuring', 'illustrated drawings', 'drawings of', 'disclaimer in the closing', 'logo in the opening', 'costume designers', 'statement at the start', 'style and font of', 'concept art paintings']):
            continue

        if any(x in text for x in ['dedicated to', 'in memory of', 'aspect ratio', 'soundtrack', 'tribute', 'filmed in', 'special thanks']):
            if not any(x in text for x in ['scene', 'dialogue', 'audio', 'appears after', 'after the closing credits', 'hammer hitting']):
                continue

        if '<ul>' in raw_text:
            li_items = re.findall(r'<li>(.*?)</li>', raw_text, flags=re.IGNORECASE)
            if len(li_items) >= 2:
                for li in li_items:
                    c_li = clean_stinger_text(li)
                    if not any(are_duplicate_scenes(c_li, s) for s in after_scenes):
                        after_scenes.append(c_li)
                continue

        is_audio = any(x in text for x in ['sound of a hammer', 'sound of', 'voice of', 'heard after', 'hammering']) and not any(x in text for x in ['scene', 'video', 'footage', 'epilogue', 'post-credit'])
        is_scene = any(x in text for x in ['scene', 'epilogue', 'post-credits epilogue', 'mid-credits', 'post-credits', 'after the credits', 'after the closing credits', 'trailer for'])

        if is_audio and not is_scene:
            audio_only += 1
            continue

        if 'does not have a scene' in text or 'no scene' in text:
            continue

        if 'walks off with the music' in text or 'picks up his walkman' in text:
            continue

        is_mid = any(x in text for x in ['mid-credit', 'mid credit', 'during the credit', 'during the closing credit', 'during the end credit', 'throughout the credit', 'beginning of the credits'])
        is_after = any(x in text for x in ['after the credit', 'after the closing credit', 'after the end credit', 'at the end of the closing credit', 'end of the credits', 'after the main credits', 'scene in the closing credits', 'scene at the end of the closing credits', 'post-credits epilogue', 'trailer for'])

        cleaned = clean_stinger_text(raw_text)

        if not is_mid and not is_after and is_scene:
            is_after = True

        if is_mid and not is_after:
            if not any(are_duplicate_scenes(cleaned, s) for s in mid_scenes):
                mid_scenes.append(cleaned)
        elif is_after and not is_mid:
            if not any(are_duplicate_scenes(cleaned, s) for s in after_scenes):
                after_scenes.append(cleaned)
        elif is_mid and is_after:
            if not any(are_duplicate_scenes(cleaned, s) for s in mid_scenes) and not any(are_duplicate_scenes(cleaned, s) for s in after_scenes):
                after_scenes.append(cleaned)

    total_scenes = len(mid_scenes) + len(after_scenes)

    if total_scenes == 0 and audio_only > 0:
        return {
            'has_stinger': True,
            'stinger_text': get_string("audio_only"),
            'stinger_color': "FFF1C40F"
        }

    if total_scenes == 0:
        return {
            'has_stinger': False,
            'stinger_text': get_string("none"),
            'stinger_color': "FF7F8C8D"
        }

    return {
        'has_stinger': True,
        'stinger_text': str(total_scenes),
        'stinger_color': "FF00E5FF"
    }

def _pick_certificate(certificates_payload):
    """Elige una clasificación: US/MPA primero, luego cualquier rating usable."""
    edges = (certificates_payload or {}).get('edges') or []
    ratings = []
    for edge in edges:
        node = (edge or {}).get('node') or {}
        rating = (node.get('rating') or '').strip()
        if not rating:
            continue
        country = ((node.get('country') or {}).get('id') or '').upper()
        ratings.append((country, rating))
    for preferred in ('US', 'GB', 'CA', 'AU'):
        for country, rating in ratings:
            if country == preferred:
                return rating
    return ratings[0][1] if ratings else None


def _empty_extra_info():
    return {
        'has_stinger': False,
        'stinger_text': get_string("none"),
        'stinger_color': "FF7F8C8D",
        'imdb_rating': None,
        'vote_count': None,
        'certificate': None,
        'rating_text': get_string("na"),
    }

def get_parental_guide(imdb_id, progress_dialog=None, silent=False, media_type=None, hint_title=None, hint_year=None):
    """
    Obtiene la guía parental directamente de IMDb usando la API de GraphQL.
    Devuelve (title, parental_guide_list, extra_info) o (None, None, None) en caso de error.
    """
    extra_info = _empty_extra_info()
    imdb_id = normalize_imdb_id(imdb_id)

    if not imdb_id or not imdb_id.startswith('tt') or not imdb_id[2:].isdigit():
        log(f"ID de IMDb inválido: {imdb_id}", level=xbmc.LOGERROR)
        if not silent:
            xbmcgui.Dialog().ok(get_string("error_title"), get_string("error_format"))
        return None, None, None

    if progress_dialog:
        progress_dialog.update(20, get_string("connecting"))

    try:
        url = 'https://api.graphql.imdb.com/'
        query = """
        query {
          title(id: "%s") {
            id
            titleText {
              text
            }
            ratingsSummary {
              aggregateRating
              voteCount
            }
            certificate {
              rating
            }
            certificates(first: 15) {
              edges {
                node {
                  rating
                  country {
                    id
                    text
                  }
                }
              }
            }
            parentsGuide {
              categories {
                category {
                  id
                  text
                }
                severity {
                  id
                }
              }
            }
            crazyCredits(first: 10) {
              edges {
                node {
                  text {
                    plaidHtml
                  }
                }
              }
            }
          }
        }
        """ % imdb_id

        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
            'Referer': 'https://www.imdb.com/',
            'Origin': 'https://www.imdb.com',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9,es;q=0.8'
        }

        log(f"Consultando IMDb GraphQL para la guía parental y metadatos: {imdb_id}")
        r = requests.post(url, json={'query': query}, headers=headers, timeout=12)

        if r.status_code != 200:
            log(f"IMDb GraphQL respondió con código {r.status_code}", level=xbmc.LOGWARNING)
            return imdb_id, None, extra_info

        data = r.json()
        title_data = data.get("data", {}).get("title")
        if not title_data:
            log(f"No hay datos de título en GraphQL para ID: {imdb_id}")
            return imdb_id, None, extra_info

        movie_title = title_data.get("titleText", {}).get("text", imdb_id)
        parents_guide = title_data.get("parentsGuide")

        ratings_summary = title_data.get("ratingsSummary") or {}
        extra_info['imdb_rating'] = ratings_summary.get('aggregateRating')
        extra_info['vote_count'] = ratings_summary.get('voteCount')
        extra_info['rating_text'] = format_rating_line(extra_info['imdb_rating'], extra_info['vote_count'])

        cert = title_data.get("certificate") or {}
        extra_info['certificate'] = cert.get("rating") or None
        if not extra_info['certificate']:
            extra_info['certificate'] = _pick_certificate(title_data.get("certificates"))

        crazy_credits_edges = title_data.get("crazyCredits", {}).get("edges", [])
        extra_info.update(parse_crazy_credits(crazy_credits_edges))

        if not parents_guide:
            log(f"No hay guía parental en GraphQL para ID: {imdb_id}")
            return movie_title, {}, extra_info

        categories = parents_guide.get("categories", [])
        if not categories:
            log(f"No hay categorías de guía parental en GraphQL para ID: {imdb_id}")
            return movie_title, {}, extra_info

    except Exception as err:
        log(f"Error al conectar con IMDb GraphQL: {err}", level=xbmc.LOGERROR)
        if not silent:
            xbmcgui.Dialog().ok(get_string("error_title"), get_string("error_connect").format(error=err))
        return None, None, None

    if progress_dialog:
        progress_dialog.update(70, get_string("processing"))

    graphql_cat_map = {
        "NUDITY": "SEXUAL_CONTENT",
        "VIOLENCE": "VIOLENCE",
        "PROFANITY": "PROFANITY",
        "ALCOHOL": "ALCOHOL_DRUGS",
        "FRIGHTENING": "FRIGHTENING_INTENSE_SCENES"
    }

    entries_by_cat = {}
    for cat_item in categories:
        g_cat_id = cat_item.get("category", {}).get("id")
        internal_key = graphql_cat_map.get(g_cat_id)
        if internal_key:
            entries_by_cat[internal_key] = cat_item

    parental_guide = []
    for cat_key in CATEGORY_ORDER:
        cat_label = get_string(cat_key)
        entry = entries_by_cat.get(cat_key)

        if entry and entry.get("severity") and entry["severity"].get("id"):
            sev_id = entry["severity"].get("id", "noneVotes")
            level = sev_id.replace("Votes", "")
            sev_text, sev_class = severity_to_class(level)
            missing = False
        else:
            sev_text, sev_class = get_string("na"), "naVotes"
            missing = True

        parental_guide.append({
            'category':       cat_label,
            'raw_category':   cat_key,
            'severity_text':  sev_text,
            'severity_class': sev_class,
            'missing':        missing,
            'item_list':      []
        })

    if progress_dialog:
        progress_dialog.update(95, get_string("finalizing"))

    extra_info['resolved_id'] = imdb_id
    extra_info['resolved_title'] = movie_title

    needs_retry = False
    if hint_title and movie_title and not titles_look_related(hint_title, movie_title):
        log(f"El ID {imdb_id} ('{movie_title}') no coincide con el título en reproducción ('{hint_title}'). Buscando de nuevo.")
        needs_retry = True
    if not parental_guide or all(item.get('missing') for item in parental_guide):
        if hint_title:
            log(f"Guía parental vacía para {imdb_id}. Intentando resolver por título: {hint_title}")
            needs_retry = True

    if needs_retry and hint_title and not getattr(get_parental_guide, '_retrying', False):
        prefer_movie = (media_type != 'show')
        results = search_imdb_suggestions(hint_title, hint_year)
        best = pick_best_search_result(results, hint_title, hint_year, prefer_movie=prefer_movie)
        if best and best['id'] != imdb_id:
            log(f"ID corregido por búsqueda: {imdb_id} -> {best['id']} ({best.get('title')})")
            get_parental_guide._retrying = True
            try:
                return get_parental_guide(
                    best['id'],
                    progress_dialog=progress_dialog,
                    silent=silent,
                    media_type=media_type,
                    hint_title=None,
                    hint_year=hint_year,
                )
            finally:
                get_parental_guide._retrying = False

    return movie_title, parental_guide, extra_info


def process_id(imdb_id):
    log(f"Procesando ID manualmente: {imdb_id}")

    pDialog = xbmcgui.DialogProgress()
    pDialog.create(get_string("title"), get_string("connecting"))

    res = get_parental_guide(imdb_id, pDialog)
    if res and len(res) == 3:
        movie_title, guide, extra_info = res
    elif res and len(res) == 2:
        movie_title, guide = res
        extra_info = _empty_extra_info()
    else:
        movie_title, guide, extra_info = None, None, None

    if not pDialog.iscanceled():
        pDialog.update(100, get_string("finalizing"))
        pDialog.close()

    if movie_title is not None and guide is not None:
        if guide:
            text = ""
            extra_info = extra_info or _empty_extra_info()
            text += f"[B]{get_string('rating')}:[/B] {extra_info.get('rating_text') or get_string('na')}\n"
            text += f"[B]{get_string('rated')}:[/B] {extra_info.get('certificate') or get_string('na')}\n\n"
            for item in guide:
                visual_info = SEVERITY_VISUALS.get(item['severity_class'], {'color': 'white', 'char': ' '})
                color = visual_info['color']
                text += f"{visual_info['char']} [B]{item['category']}:[/B] [COLOR={color}]{item['severity_text']}[/COLOR]\n\n"

            if extra_info and extra_info.get('stinger_text'):
                color_map = {
                    "FF00E5FF": "cyan",
                    "FFF1C40F": "yellow",
                    "FF7F8C8D": "grey"
                }
                c_name = color_map.get(extra_info.get('stinger_color', ''), 'white')
                text += f"🎬 [B]{get_string('post_credits')}:[/B] [COLOR={c_name}]{extra_info['stinger_text']}[/COLOR]\n"

            xbmcgui.Dialog().textviewer(f"{get_string('title')}: {movie_title}", text)
        else:
            xbmcgui.Dialog().ok(get_string("no_results_title"), get_string("no_results_body").format(title=movie_title))


def main():
    while True:
        kb = xbmc.Keyboard('', get_string("keyboard_prompt"))
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            process_id(kb.getText().strip())
            break
        else:
            break


if __name__ == '__main__':
    main()
