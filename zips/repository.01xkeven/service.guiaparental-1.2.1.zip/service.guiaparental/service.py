import sys
import os
import time
import threading
import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')

sys.path.append(ADDON_PATH)
import main

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} Service] {msg}", level=level)

def get_overlay_settings():
    """Lee duración y modo persistente desde settings del addon."""
    keep_visible = False
    duration = 8
    try:
        keep_visible = ADDON.getSettingBool('keep_visible')
    except Exception:
        try:
            keep_visible = ADDON.getSetting('keep_visible').lower() == 'true'
        except Exception:
            keep_visible = False
    try:
        duration = ADDON.getSettingInt('display_duration')
    except Exception:
        try:
            duration = int(float(ADDON.getSetting('display_duration') or 8))
        except Exception:
            duration = 8
    if duration < 3:
        duration = 3
    if duration > 60:
        duration = 60
    return keep_visible, duration


class LabelData:
    """Almacena los datos de cada etiqueta para poder regenerar el texto con alpha variable."""
    def __init__(self, cat_name, sev_text, color_hex, separator="  –  "):
        self.cat_name  = cat_name
        self.sev_text  = sev_text
        self.color_hex = color_hex
        self.separator = separator

    def make_text(self, alpha):
        rgb = self.color_hex[2:]
        a   = f"{alpha:02X}"
        name = f"[B][COLOR={a}FFFFFF]{self.cat_name}[/COLOR][/B]"
        sep  = f"[COLOR={a}AAAAAA]{self.separator}[/COLOR]"
        sev  = f"[COLOR={a}{rgb}]{self.sev_text}[/COLOR]"
        return f"{name}{sep}{sev}"


_FADE_IN  = [0x00, 0x20, 0x45, 0x70, 0xA0, 0xCF, 0xFF]
_FADE_OUT = [0xFF, 0xCF, 0xA0, 0x70, 0x45, 0x20, 0x00]
_STEP_S   = 0.035


class ParentalGuideOverlay(object):
    """HUD no intrusivo inyectado en la ventana de reproducción, con fade suave."""

    def __init__(self):
        self.window     = xbmcgui.Window(12005)
        self.bar        = None
        self.separators = []
        self.labels     = []

    def _add_separator(self, texture, y, width=230):
        try:
            sep = xbmcgui.ControlImage(-1000, y, width, 1, texture)
            self.window.addControl(sep)
            sep.setColorDiffuse("00FFFFFF")
            sep.setPosition(70, y)
            self.separators.append(sep)
        except Exception as e:
            log(f"Error separador: {e}", level=xbmc.LOGWARNING)

    def _add_label(self, ld, y, width=420):
        try:
            lbl = xbmcgui.ControlLabel(70, y, width, 30, ld.make_text(0x00),
                                       font='font12', textColor='0x00000000')
            self.window.addControl(lbl)
            self.labels.append((lbl, ld))
        except Exception as e:
            log(f"Error etiqueta {ld.cat_name}: {e}", level=xbmc.LOGWARNING)

    def show_guide(self, ratings, extra_info=None):
        log("Construyendo HUD con fade suave...")
        extra_info = extra_info or {}

        severity_colors = {
            "none":     "FF7F8C8D",
            "mild":     "FF2ECC71",
            "moderate": "FFF39C12",
            "severe":   "FFE74C3C",
            "na":       "FF95A5A6",
        }

        def normalize_category(cat_name):
            c = cat_name.lower().strip()
            if "desnud" in c or "nudity" in c or "sex" in c:      return "Desnudos"
            if "violenc" in c or "sangr" in c:                     return "Violencia"
            if "obscen" in c or "groser" in c or "profan" in c or "languag" in c:
                                                                    return "Groserias"
            if "alcohol" in c or "drog" in c or "drink" in c:     return "Alcohol/Drogas"
            if "intens" in c or "terror" in c or "fright" in c:   return "Escenas intensas"
            return cat_name

        normalized = {}
        for item in (ratings or []):
            raw = item.get('raw_category')
            if raw:
                normalized[raw] = item
            else:
                normalized[normalize_category(item.get('category', ''))] = item

        categories_keys = ["SEXUAL_CONTENT", "VIOLENCE", "PROFANITY", "ALCOHOL_DRUGS", "FRIGHTENING_INTENSE_SCENES"]
        texture = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', '720p', 'rounded_bar.png')

        has_stinger_line = bool(extra_info)
        header_lines = 2
        category_lines = len(categories_keys)
        extra_lines = 1 if has_stinger_line else 0
        separators_count = 1 + (1 if extra_lines else 0)
        bar_height = 20 + (header_lines * 32) + (category_lines * 35) + (extra_lines * 35) + (separators_count * 16)

        try:
            self.bar = xbmcgui.ControlImage(-1000, 48, 4, bar_height, texture)
            self.window.addControl(self.bar)
            self.bar.setColorDiffuse("00FFFFFF")
            self.bar.setPosition(50, 48)
        except Exception as e:
            log(f"Error barra: {e}", level=xbmc.LOGWARNING)

        y = 48

        rating_text = extra_info.get('rating_text') or main.get_string("na")
        certificate = extra_info.get('certificate') or main.get_string("na")
        self._add_label(LabelData(main.get_string("rating"), rating_text, "FFF1C40F"), y)
        y += 32
        self._add_label(LabelData(main.get_string("rated"), certificate, "FF3498DB"), y)
        y += 38

        self._add_separator(texture, y)
        y += 12

        for cat_key in categories_keys:
            data = normalized.get(cat_key)
            if not data:
                spanish_fallback = {
                    "SEXUAL_CONTENT": "Desnudos",
                    "VIOLENCE": "Violencia",
                    "PROFANITY": "Groserias",
                    "ALCOHOL_DRUGS": "Alcohol y Drogas",
                    "FRIGHTENING_INTENSE_SCENES": "Escenas intensas"
                }.get(cat_key)
                data = normalized.get(spanish_fallback)

            cat_label = main.get_string(cat_key)
            sev_t     = main.get_string("na")
            col_h     = severity_colors["na"]

            if data:
                missing = data.get('missing')
                if missing:
                    sev_t = data.get('severity_text', main.get_string('na'))
                    col_h = severity_colors["na"]
                else:
                    sev_t = data.get('severity_text', main.get_string('none'))
                    sc    = data.get('severity_class', '') or ''
                    sc_l  = sc.lower()
                    if   'na'       in sc_l: col_h = severity_colors["na"]
                    elif 'none'     in sc_l: col_h = severity_colors["none"]
                    elif 'mild'     in sc_l: col_h = severity_colors["mild"]
                    elif 'moderate' in sc_l: col_h = severity_colors["moderate"]
                    elif 'severe'   in sc_l: col_h = severity_colors["severe"]
                    else:
                        lt = (sev_t or '').lower()
                        if   lt in ['n/a', 'na']: col_h = severity_colors["na"]
                        elif lt in ['leve', 'mild']: col_h = severity_colors["mild"]
                        elif lt in ['moderada', 'moderate']: col_h = severity_colors["moderate"]
                        elif lt in ['severa', 'severe']: col_h = severity_colors["severe"]
                        elif lt in ['ninguno', 'none']: col_h = severity_colors["none"]

            self._add_label(LabelData(cat_label, sev_t, col_h), y)
            y += 35

        if extra_info:
            y_sep = y + 7
            y_lbl = y + 15
            self._add_separator(texture, y_sep)

            st_label = main.get_string("post_credits")
            st_text  = extra_info.get("stinger_text", main.get_string("none"))
            st_color = extra_info.get("stinger_color", "FF00E5FF")
            self._add_label(LabelData(st_label, st_text, st_color), y_lbl)

        if self.bar:
            for alpha in _FADE_IN:
                self.bar.setColorDiffuse(f"{alpha:02X}FFFFFF")
                time.sleep(_STEP_S)

        last_idx = len(self.labels) - 1
        for i, (lbl, ld) in enumerate(self.labels):
            fade_seps = (i == 1) or (i == last_idx and len(self.separators) > 1)
            for alpha in _FADE_IN:
                try:
                    lbl.setLabel(ld.make_text(alpha))
                    if fade_seps:
                        sep_a = int(alpha * 0.25)
                        for sep in self.separators:
                            sep.setColorDiffuse(f"{sep_a:02X}FFFFFF")
                except Exception:
                    pass
                time.sleep(_STEP_S)

    def close(self):
        log("Cerrando HUD con fade-out...")

        for i, (lbl, ld) in enumerate(reversed(self.labels)):
            fade_seps = (i == 0) or (i == len(self.labels) - 2)
            for alpha in _FADE_OUT:
                try:
                    lbl.setLabel(ld.make_text(alpha))
                    if fade_seps:
                        sep_a = int(alpha * 0.25)
                        for sep in self.separators:
                            sep.setColorDiffuse(f"{sep_a:02X}FFFFFF")
                except Exception:
                    pass
                time.sleep(_STEP_S)

        if self.bar:
            for alpha in _FADE_OUT:
                try:
                    self.bar.setColorDiffuse(f"{alpha:02X}FFFFFF")
                except Exception:
                    pass
                time.sleep(_STEP_S)

        for lbl, _ in self.labels:
            try:
                self.window.removeControl(lbl)
            except Exception:
                pass
        for sep in self.separators:
            try:
                self.window.removeControl(sep)
            except Exception:
                pass
        if self.bar:
            try:
                self.window.removeControl(self.bar)
            except Exception:
                pass
        self.labels     = []
        self.separators = []
        self.bar        = None


class ParentalPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self.active_overlay = None
        self.playback_thread = None
        self.stop_event = threading.Event()
        self.playback_lock = threading.Lock()
        self.thread_active = False

    def onPlayBackStarted(self):
        log("Evento de reproducción iniciado (onPlayBackStarted) recibido.")
        self._trigger_start("onPlayBackStarted")

    def onAVStarted(self):
        log("Evento de audio/video iniciado (onAVStarted) recibido.")
        self._trigger_start("onAVStarted")

    def _trigger_start(self, event_name):
        with self.playback_lock:
            if self.thread_active:
                log(f"El proceso de overlay ya está activo, ignorando evento: {event_name}")
                return
            self.thread_active = True

        log(f"Iniciando hilo de procesamiento gatillado por: {event_name}")
        self.stop_event.set()
        if self.playback_thread and self.playback_thread.is_alive():
            self.playback_thread.join()

        self.stop_event.clear()
        self.playback_thread = threading.Thread(target=self._process_playback)
        self.playback_thread.daemon = True
        self.playback_thread.start()

    def onPlayBackStopped(self):
        log("Reproducción detenida por el usuario.")
        with self.playback_lock:
            self.thread_active = False
        self.stop_event.set()
        self.close_overlay()

    def onPlayBackEnded(self):
        log("Reproducción finalizada.")
        with self.playback_lock:
            self.thread_active = False
        self.stop_event.set()
        self.close_overlay()

    def close_overlay(self):
        if self.active_overlay:
            try:
                self.active_overlay.close()
                log("Overlay de control parental cerrado.")
            except Exception as e:
                log(f"Error cerrando el overlay: {e}", level=xbmc.LOGWARNING)
            self.active_overlay = None

    def _should_dismiss_overlay(self):
        if self.stop_event.is_set() or not self.isPlayingVideo():
            return True
        try:
            if xbmc.getCondVisibility('Window.IsVisible(fullscreeninfo) | Window.IsVisible(videoosd) | Window.IsVisible(osdvideosettings) | Window.IsVisible(osdaudiosettings)'):
                log("OSD del reproductor abierto; cerrando overlay.")
                return True
        except Exception:
            pass
        return False

    def _process_playback(self):
        try:
            for _ in range(10):
                if self.stop_event.is_set() or not self.isPlayingVideo():
                    return
                time.sleep(0.1)

            playing_title, playing_year = self._get_playing_title_year()
            imdb_id = self._get_imdb_id()
            if not imdb_id and playing_title:
                log(f"Sin ID de IMDb en metadatos. Buscando por título: {playing_title}")
                results = main.search_imdb_suggestions(playing_title, playing_year)
                best = main.pick_best_search_result(results, playing_title, playing_year, prefer_movie=True)
                if best:
                    imdb_id = best['id']
                    log(f"ID encontrado por título: {imdb_id} ({best.get('title')})")
            if not imdb_id:
                log("No se pudo extraer un ID de IMDb válido para el contenido en reproducción.")
                return

            log(f"ID de IMDb extraído: {imdb_id}. Título local: {playing_title or '?'}. Buscando guía de contenido...")

            media_type  = 'movie'
            season_num  = None
            episode_num = None
            try:
                info_tag = self.getVideoInfoTag()
                m_type   = info_tag.getMediaType()

                if m_type == 'episode':
                    media_type  = 'show'
                    season_num  = info_tag.getSeason()
                    episode_num = info_tag.getEpisode()
                elif m_type == 'movie':
                    media_type = 'movie'
                else:
                    content = xbmc.getInfoLabel('VideoPlayer.Content')
                    tvshow  = xbmc.getInfoLabel('VideoPlayer.TVShowTitle')
                    if 'episode' in content or 'show' in content or tvshow:
                        media_type  = 'show'
                        season_num  = int(xbmc.getInfoLabel('VideoPlayer.Season')  or 0) or None
                        episode_num = int(xbmc.getInfoLabel('VideoPlayer.Episode') or 0) or None
            except Exception as ex:
                log(f"Error detectando tipo de medio: {ex}", level=xbmc.LOGWARNING)
                content = xbmc.getInfoLabel('VideoPlayer.Content')
                if 'episode' in content or 'show' in content:
                    media_type = 'show'

            show_imdb_id = imdb_id
            if media_type == 'show' and self._looks_like_feature(playing_title):
                log(f"El título parece un largometraje ('{playing_title}'); no se resolverá como episodio.")
                media_type = 'movie'
            if media_type == 'show' and season_num and episode_num:
                ep_id = self._get_episode_imdb_id(imdb_id, season_num, episode_num)
                if ep_id:
                    log(f"ID específico del episodio S{season_num:02d}E{episode_num:02d}: {ep_id}")
                    imdb_id = ep_id
                else:
                    log(f"No se encontró ID de episodio, usando ID de serie: {imdb_id}", level=xbmc.LOGWARNING)

            try:
                res = main.get_parental_guide(
                    imdb_id,
                    progress_dialog=None,
                    silent=True,
                    media_type=media_type,
                    hint_title=playing_title,
                    hint_year=playing_year,
                )
                extra_info = None
                if res and len(res) == 3:
                    movie_title, guide, extra_info = res
                elif res and len(res) == 2:
                    movie_title, guide = res
                    extra_info = None
                else:
                    movie_title, guide, extra_info = None, None, None

                if media_type == 'show' and not guide and show_imdb_id and show_imdb_id != imdb_id:
                    log(f"El episodio no tiene guía propia en IMDb, obteniendo guía de la serie: {show_imdb_id}")
                    s_res = main.get_parental_guide(show_imdb_id, progress_dialog=None, silent=True, media_type='show')
                    if s_res and len(s_res) >= 2 and s_res[1]:
                        guide = s_res[1]
                        if not movie_title:
                            movie_title = s_res[0]
                        if (not extra_info or not extra_info.get('certificate')) and len(s_res) == 3 and s_res[2]:
                            inherited = s_res[2]
                            extra_info = extra_info or {}
                            extra_info['certificate'] = extra_info.get('certificate') or inherited.get('certificate')
                            if not extra_info.get('rating_text') or extra_info.get('rating_text') == main.get_string("na"):
                                extra_info['rating_text'] = inherited.get('rating_text')
                                extra_info['imdb_rating'] = inherited.get('imdb_rating')
                                extra_info['vote_count'] = inherited.get('vote_count')
            except Exception as e:
                log(f"Error al descargar la guía parental: {e}", level=xbmc.LOGERROR)
                return

            if not guide and not extra_info:
                log(f"No se encontró información para el ID: {imdb_id}.")
                return

            if self.stop_event.is_set() or not self.isPlayingVideo():
                return

            log(f"Mostrando overlay inyectado para: {movie_title}")
            try:
                self.active_overlay = ParentalGuideOverlay()
                self.active_overlay.show_guide(guide, extra_info=extra_info)

                keep_visible, duration = get_overlay_settings()
                if keep_visible:
                    log("Overlay persistente activo hasta que se cierre el OSD o termine la reproducción.")
                    while not self._should_dismiss_overlay():
                        time.sleep(0.2)
                else:
                    log(f"Manteniendo overlay visible {duration} segundos.")
                    steps = max(1, int(duration * 10))
                    for _ in range(steps):
                        if self._should_dismiss_overlay():
                            break
                        time.sleep(0.1)

                self.close_overlay()

            except Exception as e:
                log(f"Excepción al inicializar/mostrar el overlay XML: {e}", level=xbmc.LOGERROR)
        finally:
            with self.playback_lock:
                self.thread_active = False

    def _get_playing_title_year(self):
        title = ''
        year = None
        try:
            info_tag = self.getVideoInfoTag()
            if info_tag:
                title = info_tag.getTitle() or info_tag.getTVShowTitle() or ''
                try:
                    year = info_tag.getYear() or None
                except Exception:
                    year = None
        except Exception:
            pass
        if not title:
            title = xbmc.getInfoLabel('VideoPlayer.Title') or xbmc.getInfoLabel('Player.Title') or ''
        if not year:
            raw_year = xbmc.getInfoLabel('VideoPlayer.Year') or ''
            if raw_year.isdigit():
                year = int(raw_year)
        show = xbmc.getInfoLabel('VideoPlayer.TVShowTitle') or ''
        # Prefer the more specific on-screen name when both exist
        if show and title and show.lower() not in title.lower() and len(title) < 8:
            title = f"{show} {title}".strip()
        elif not title and show:
            title = show
        return title.strip(), year

    def _looks_like_feature(self, title):
        t = (title or '').lower()
        if any(x in t for x in ('part 1', 'part 2', 'part 3', 'part one', 'part two', 'part i', 'part ii')):
            return True
        if 's0' in t and 'e0' in t.replace(' ', ''):
            return False
        return False

    def _get_imdb_id(self):
        candidates = []
        try:
            info_tag = self.getVideoInfoTag()
            if info_tag:
                for getter in (
                    lambda: info_tag.getUniqueID('imdb'),
                    lambda: info_tag.getUniqueID('imdb_id'),
                    lambda: info_tag.getIMDBNumber(),
                ):
                    try:
                        value = getter()
                    except Exception:
                        value = ''
                    if value:
                        candidates.append(value)

            for label in (
                'VideoPlayer.UniqueID(imdb)',
                'Player.UniqueID(imdb)',
                'ListItem.UniqueID(imdb)',
                'ListItem.IMDBNumber',
                'Player.IMDBNumber',
                'VideoPlayer.IMDBNumber',
            ):
                value = xbmc.getInfoLabel(label)
                if value:
                    candidates.append(value)

            try:
                playing_file = self.getPlayingFile()
            except Exception:
                playing_file = ''
            if playing_file:
                candidates.append(playing_file)
            title, _year = self._get_playing_title_year()
            if title:
                candidates.append(title)
        except Exception as e:
            log(f"Error extrayendo el ID de IMDb: {e}", level=xbmc.LOGWARNING)

        for raw in candidates:
            parsed = main.normalize_imdb_id(raw)
            if parsed:
                return parsed
        return None

    def _get_episode_imdb_id(self, series_id, season, episode):
        return main.get_episode_imdb_id(series_id, season, episode)


def main_loop():
    monitor = xbmc.Monitor()
    player = ParentalPlayer()

    log("Servicio de Control Parental IMDb iniciado.")

    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

    player.close_overlay()
    log("Servicio de Control Parental IMDb detenido.")

if __name__ == '__main__':
    main_loop()
