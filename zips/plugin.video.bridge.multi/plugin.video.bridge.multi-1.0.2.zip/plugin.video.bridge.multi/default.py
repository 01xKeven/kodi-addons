import sqlite3
# -*- coding: utf-8 -*-
import sys
import os
import re
import json
import base64
import threading
import time
import datetime
import socket
import builtins
import types

builtins.sys = sys
builtins.basestring = str
builtins.unicode = str
socket.setdefaulttimeout(30)

import urllib
import urllib.parse as uparse
import urllib.request as urequest
import urllib.response as uresponse
import urllib.error as uerror
import html, html.parser, html.entities
import http.cookiejar
from contextlib import contextmanager

urllib.quote = uparse.quote
urllib.quote_plus = uparse.quote_plus
urllib.unquote = uparse.unquote
urllib.unquote_plus = uparse.unquote_plus
urllib.urlencode = uparse.urlencode
urllib.addinfourl = uresponse.addinfourl
urllib.request = urequest
urllib.response = uresponse

urequest.HTTPError = uerror.HTTPError
urequest.URLError = uerror.URLError
sys.modules['urllib2'] = urequest

html.parser.HTMLParser.unescape = staticmethod(html.unescape)
html_parser_mod = types.ModuleType('HTMLParser')
html_parser_mod.HTMLParser = html.parser.HTMLParser
sys.modules['HTMLParser'] = html_parser_mod
sys.modules['htmlentitydefs'] = html.entities
sys.modules['urlparse'] = uparse
sys.modules['cookielib'] = http.cookiejar

handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1] else -1
original_argv = list(sys.argv)

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcplugin
import xbmcgui

if not hasattr(xbmc, 'translatePath'):
    xbmc.translatePath = xbmcvfs.translatePath

_bridge_addon = xbmcaddon.Addon('plugin.video.bridge.multi')

# Auto-load all script.module dependencies from Kodi addons directory
addons_root = xbmcvfs.translatePath('special://home/addons/')
alfa_path = os.path.join(addons_root, 'plugin.video.alfa')
_alfa_lib = os.path.join(alfa_path, 'lib')
balandro_path = os.path.join(addons_root, 'plugin.video.balandro')
_balandro_lib = os.path.join(balandro_path, 'lib')

if os.path.exists(addons_root):
    for _ad in os.listdir(addons_root):
        if _ad.startswith('script.module.'):
            _mod_lib = os.path.join(addons_root, _ad, 'lib')
            if os.path.isdir(_mod_lib):
                if _mod_lib not in sys.path: sys.path.append(_mod_lib)
            else:
                _ad_path = os.path.join(addons_root, _ad)
                if os.path.isdir(_ad_path) and _ad_path not in sys.path: sys.path.append(_ad_path)

TMDB_PLAYERS_PATH = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/players/')
BRIDGE_DATA_PATH = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.bridge.multi/')
if not os.path.exists(BRIDGE_DATA_PATH):
    try: os.makedirs(BRIDGE_DATA_PATH)
    except: pass
if not os.path.exists(TMDB_PLAYERS_PATH):
    try: os.makedirs(TMDB_PLAYERS_PATH)
    except: pass

SEARCH_CACHE_FILE = os.path.join(BRIDGE_DATA_PATH, 'bridge_multi_search_cache.json')
BOOKMARKS_FILE = os.path.join(BRIDGE_DATA_PATH, 'bridge_multi_bookmarks.json')
CLOUD_SYNC_FILE = os.path.join(BRIDGE_DATA_PATH, 'cloud_sync_info.json')

def _get_media_key(meta, item=None):
    if not meta: meta = {}
    s_val = meta.get('season') if meta.get('season') is not None else _safe_get_item_attr(item, 'season')
    e_val = meta.get('episode') if meta.get('episode') is not None else _safe_get_item_attr(item, 'episode')
    has_se = (s_val is not None and str(s_val).strip() != '') and (e_val is not None and str(e_val).strip() != '')
    is_series = bool(has_se or _safe_get_item_attr(item, 'contentType') == 'episode' or _safe_get_item_attr(item, 'contentSeason'))
    tmdb = meta.get('tmdb') or _safe_get_item_attr(item, 'tmdb_id') or _safe_get_item_attr(item, 'tmdb') or ''
    imdb = meta.get('imdb') or _safe_get_item_attr(item, 'imdb_id') or _safe_get_item_attr(item, 'imdb') or ''
    season = meta.get('season') or _safe_get_item_attr(item, 'season') or _safe_get_item_attr(item, 'contentSeason') or ''
    episode = meta.get('episode') or _safe_get_item_attr(item, 'episode') or _safe_get_item_attr(item, 'contentEpisodeNumber') or ''
    title = meta.get('title') or _safe_get_item_attr(item, 'contentTitle') or _safe_get_item_attr(item, 'title') or ''
    show = meta.get('showname') or _safe_get_item_attr(item, 'contentSerieName') or _safe_get_item_attr(item, 'show') or ''

    if is_series:
        s_str = '%02d' % int(season) if str(season).isdigit() else str(season)
        e_str = '%02d' % int(episode) if str(episode).isdigit() else str(episode)
        if tmdb: return 'tv_%s_s%s_e%s' % (tmdb, s_str, e_str)
        if imdb: return 'tv_%s_s%s_e%s' % (imdb, s_str, e_str)
        clean_s = clean_title(show or title)
        return 'tv_%s_s%s_e%s' % (clean_s, s_str, e_str)
    else:
        if tmdb: return 'movie_%s' % tmdb
        if imdb: return 'movie_%s' % imdb
        year = meta.get('year') or _safe_get_item_attr(item, 'year') or ''
        clean_t = clean_title(title)
        return 'movie_%s_%s' % (clean_t, year)

def _is_same_media_item(cached_meta, cur_meta):
    """Verifica si dos diccionarios meta corresponden exactamente al mismo contenido.
    Para series: comprueba que season y episode coincidan numéricamente y que
    sea la misma serie (mismo tmdb, imdb, tvdb o título/showname).
    Para películas: comprueba tmdb, imdb o título + año.
    """
    if not cached_meta or not cur_meta:
        return False

    c_s = cached_meta.get('season')
    c_e = cached_meta.get('episode')
    cur_s = cur_meta.get('season')
    cur_e = cur_meta.get('episode')

    c_is_series = bool(c_s is not None and str(c_s).strip() != '' and c_e is not None and str(c_e).strip() != '')
    cur_is_series = bool(cur_s is not None and str(cur_s).strip() != '' and cur_e is not None and str(cur_e).strip() != '')

    # Uno es serie y el otro película -> No es el mismo contenido
    if c_is_series != cur_is_series:
        return False

    if cur_is_series:
        # En series: temporada y episodio DEBEN coincidir numéricamente
        try:
            if int(c_s) != int(cur_s) or int(c_e) != int(cur_e):
                return False
        except (ValueError, TypeError):
            if str(c_s).strip() != str(cur_s).strip() or str(c_e).strip() != str(cur_e).strip():
                return False

        # Verificar que sea la misma serie (tmdb, imdb, tvdb o título)
        c_tmdb = str(cached_meta.get('tmdb') or '')
        cur_tmdb = str(cur_meta.get('tmdb') or '')
        if c_tmdb and cur_tmdb:
            return c_tmdb == cur_tmdb

        c_imdb = str(cached_meta.get('imdb') or '')
        cur_imdb = str(cur_meta.get('imdb') or '')
        if c_imdb and cur_imdb:
            return c_imdb == cur_imdb

        c_tvdb = str(cached_meta.get('tvdb') or '')
        cur_tvdb = str(cur_meta.get('tvdb') or '')
        if c_tvdb and cur_tvdb:
            return c_tvdb == cur_tvdb

        # Comparar por nombre de serie si no hay IDs
        c_name = clean_title(cached_meta.get('showname') or cached_meta.get('title') or '')
        cur_name = clean_title(cur_meta.get('showname') or cur_meta.get('title') or '')
        return bool(c_name and cur_name and c_name == cur_name)
    else:
        # En películas: Comprobar tmdb, imdb o título + año
        c_tmdb = str(cached_meta.get('tmdb') or '')
        cur_tmdb = str(cur_meta.get('tmdb') or '')
        if c_tmdb and cur_tmdb:
            return c_tmdb == cur_tmdb

        c_imdb = str(cached_meta.get('imdb') or '')
        cur_imdb = str(cur_meta.get('imdb') or '')
        if c_imdb and cur_imdb:
            return c_imdb == cur_imdb

        c_title = clean_title(cached_meta.get('title') or '')
        cur_title = clean_title(cur_meta.get('title') or '')
        c_year = str(cached_meta.get('year') or '')
        cur_year = str(cur_meta.get('year') or '')
        if c_title and cur_title and c_title == cur_title:
            if c_year and cur_year:
                return c_year == cur_year
            return True
        return False


def get_bookmark(media_key, tmdb_id=None, is_series=False, season=None, episode=None):
    # 1. Local bookmark database
    if media_key and os.path.exists(BOOKMARKS_FILE):
        try:
            with open(BOOKMARKS_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
            bm = data.get(media_key)
            if bm and isinstance(bm, dict):
                r_time = float(bm.get('resume_time', 0))
                t_time = float(bm.get('total_time', 0))
                if r_time > 20 and (t_time == 0 or (r_time / t_time < 0.93)):
                    return bm
        except Exception: pass

    # 2. Sync from TMDb Helper's Trakt cache (ItemDetails.db)
    if tmdb_id:
        try:
            tmdb_base = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/')
            db_files = []
            if os.path.exists(tmdb_base):
                for root, _, files in os.walk(tmdb_base):
                    for fn in files:
                        if fn.lower() == 'itemdetails.db':
                            db_files.append(os.path.join(root, fn))

            for db_path in db_files:
                try:
                    conn = sqlite3.connect(db_path)
                    c = conn.cursor()
                    if is_series and season is not None and episode is not None:
                        c.execute("SELECT playback_progress, runtime, title FROM simplecache WHERE tmdb_id = ? AND season_number = ? AND episode_number = ? AND item_type = 'episode' AND playback_progress > 0;", (int(tmdb_id), int(season), int(episode)))
                    else:
                        c.execute("SELECT playback_progress, runtime, title FROM simplecache WHERE tmdb_id = ? AND item_type = 'movie' AND playback_progress > 0;", (int(tmdb_id),))
                    row = c.fetchone()
                    conn.close()
                    if row:
                        progress_pct, runtime_mins, title = row[0], row[1], row[2]
                        if progress_pct and runtime_mins and float(progress_pct) > 0.2:
                            pct = float(progress_pct)
                            if pct <= 1.0 and pct > 0: pct = pct * 100.0
                            tot_sec = float(runtime_mins) * 60.0
                            res_sec = (pct / 100.0) * tot_sec
                            if res_sec > 20 and (res_sec / tot_sec < 0.93):
                                return {'resume_time': res_sec, 'total_time': tot_sec, 'title': title, 'source': 'trakt'}
                except Exception: pass
        except Exception: pass

    return None

def save_bookmark(media_key, resume_time, total_time, title=""):
    if not media_key: return
    try:
        data = {}
        if os.path.exists(BOOKMARKS_FILE):
            try:
                with open(BOOKMARKS_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
            except: data = {}
        
        if total_time > 0 and (resume_time / float(total_time) >= 0.92):
            if media_key in data: del data[media_key]
        elif resume_time > 30:
            data[media_key] = {
                'resume_time': float(resume_time),
                'total_time': float(total_time),
                'title': title,
                'updated': time.time()
            }
        elif resume_time <= 30 and media_key in data:
            del data[media_key]

        with open(BOOKMARKS_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except: pass

def start_playback_monitor(media_key, title_str="", seek_to_time=0):
    if not media_key: return
    def _monitor_loop():
        p = xbmc.Player()
        mon = xbmc.Monitor()
        for _ in range(120):
            if mon.abortRequested(): return
            if p.isPlayingVideo(): break
            if mon.waitForAbort(0.25): return

        if not p.isPlayingVideo(): return

        if seek_to_time > 10:
            if mon.waitForAbort(0.6): return
            try: p.seekTime(float(seek_to_time))
            except: pass

        last_saved_time = 0
        tot_time = 0
        while p.isPlayingVideo() and not mon.abortRequested():
            try:
                cur_time = p.getTime()
                tot = p.getTotalTime()
                if tot > 0: tot_time = tot
                if abs(cur_time - last_saved_time) >= 5:
                    save_bookmark(media_key, cur_time, tot_time, title=title_str)
                    last_saved_time = cur_time
            except: pass
            if mon.waitForAbort(3.0): break

        if last_saved_time > 0 or tot_time > 0:
            save_bookmark(media_key, last_saved_time, tot_time, title=title_str)

    threading.Thread(target=_monitor_loop, daemon=True).start()

alfa_icon = 'DefaultVideo.png'

def _safe_str(val):
    if val is None: return ""
    if isinstance(val, bytes):
        try: return val.decode('utf-8', errors='ignore')
        except: return str(val)
    return str(val)

def _safe_get_item_attr(item, attr_name, default=''):
    if not item: return default
    if hasattr(item, '__dict__') and attr_name in item.__dict__:
        val = item.__dict__[attr_name]
        if val is not None and val != '': return val
    if hasattr(item, '__dict__') and 'infoLabels' in item.__dict__:
        il = item.__dict__['infoLabels']
        if isinstance(il, dict) and attr_name in il:
            val = il[attr_name]
            if val is not None and val != '': return val
    return default

# ---------------------------------------------------------
# Dynamic Module Switcher for Clean Alfa / Balandro Execution
# ---------------------------------------------------------
_current_engine_env = None
_engine_lock = threading.RLock()

def _switch_engine_environment(target_engine):
    global _current_engine_env
    if _current_engine_env == target_engine:
        return
    with _engine_lock:
        if _current_engine_env == target_engine:
            return
        for m in list(sys.modules.keys()):
            if any(m == sm or m.startswith(sm + '.') for sm in ['platformcode', 'core', 'channels', 'servers', 'modules', 'lib']):
                del sys.modules[m]
        sys.path = [p for p in sys.path if p not in (alfa_path, _alfa_lib, balandro_path, _balandro_lib)]
        if target_engine == 'alfa':
            sys.argv[0] = 'plugin://plugin.video.alfa/'
            if alfa_path not in sys.path: sys.path.insert(0, alfa_path)
            if os.path.exists(_alfa_lib) and _alfa_lib not in sys.path: sys.path.append(_alfa_lib)
        else:
            sys.argv[0] = 'plugin://plugin.video.balandro/'
            if balandro_path not in sys.path: sys.path.insert(0, balandro_path)
            if os.path.exists(_balandro_lib) and _balandro_lib not in sys.path: sys.path.append(_balandro_lib)
        _current_engine_env = target_engine

def _get_alfa_modules():
    try:
        _switch_engine_environment('alfa')
        from platformcode import config, platformtools
        from core.item import Item, InfoLabels
        from core import servertools, httptools, scrapertools
        config.get_runtime_path = lambda: alfa_path
        try:
            from core import tmdb as _a_tmdb
            _a_tmdb.set_infoLabels = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
            _a_tmdb.set_infoLabels_itemlist = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
        except Exception: pass
        return {
            'path': alfa_path, 'config': config, 'platformtools': platformtools,
            'Item': Item, 'InfoLabels': InfoLabels, 'servertools': servertools,
            'httptools': httptools, 'scrapertools': scrapertools
        }
    except Exception as e:
        xbmc.log("Bridge Multi: Error cargando Alfa: " + str(e), xbmc.LOGWARNING)
        return None

def _get_balandro_modules():
    try:
        _switch_engine_environment('balandro')
        from platformcode import config, platformtools
        from core.item import Item, InfoLabels
        from core import servertools, httptools, scrapertools
        config.get_runtime_path = lambda: balandro_path
        try:
            from core import tmdb as _b_tmdb
            _b_tmdb.set_infoLabels = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
            _b_tmdb.set_infoLabels_itemlist = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
            _b_tmdb.set_infoLabels_item = lambda *args, **kwargs: 0
        except Exception: pass

        orig_set_infolabels = platformtools.set_infolabels
        def _enhanced_balandro_set_infolabels(listitem, item, player=False):
            tmdb_id = str(_safe_get_item_attr(item, 'tmdb_id') or _safe_get_item_attr(item, 'tmdb') or _safe_get_item_attr(item, 'code') or '')
            imdb_id = str(_safe_get_item_attr(item, 'imdb_id') or _safe_get_item_attr(item, 'imdb') or _safe_get_item_attr(item, 'imdbnumber') or '')
            tvdb_id = str(_safe_get_item_attr(item, 'tvdb_id') or _safe_get_item_attr(item, 'tvdb') or '')
            trakt_id = str(_safe_get_item_attr(item, 'trakt_id') or _safe_get_item_attr(item, 'trakt') or '')

            title_str = str(_safe_get_item_attr(item, 'title') or _safe_get_item_attr(item, 'contentTitle') or '')
            showname_str = str(_safe_get_item_attr(item, 'tvshowtitle') or _safe_get_item_attr(item, 'contentSerieName') or _safe_get_item_attr(item, 'show') or '')
            season_num = _safe_get_item_attr(item, 'season', None)
            if season_num is None: season_num = _safe_get_item_attr(item, 'contentSeason', None)
            episode_num = _safe_get_item_attr(item, 'episode', None)
            if episode_num is None: episode_num = _safe_get_item_attr(item, 'contentEpisodeNumber', None)
            year_num = _safe_get_item_attr(item, 'year', None)
            plot_str = str(_safe_get_item_attr(item, 'plot') or _safe_get_item_attr(item, 'sinopsis') or '')
            tagline_str = str(_safe_get_item_attr(item, 'tagline') or _safe_get_item_attr(item, 'slogan') or '')

            try: orig_set_infolabels(listitem, item, player=player)
            except Exception: pass

            try:
                is_ep = bool(season_num is not None and episode_num is not None and str(season_num) != '' and str(episode_num) != '')
                unique_dict = {}
                if tmdb_id: unique_dict['tmdb'] = tmdb_id
                if imdb_id: unique_dict['imdb'] = imdb_id
                if tvdb_id: unique_dict['tvdb'] = tvdb_id
                if trakt_id: unique_dict['trakt'] = trakt_id

                if unique_dict:
                    try: listitem.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else 'imdb')
                    except: pass

                if tmdb_id: listitem.setProperty('tmdb_id', tmdb_id)
                if imdb_id: listitem.setProperty('imdb_id', imdb_id)
                if tvdb_id: listitem.setProperty('tvdb_id', tvdb_id)

                trakt_payload = {}
                if tmdb_id: trakt_payload['tmdb'] = int(tmdb_id) if tmdb_id.isdigit() else tmdb_id
                if imdb_id: trakt_payload['imdb'] = imdb_id
                if tvdb_id: trakt_payload['tvdb'] = int(tvdb_id) if tvdb_id.isdigit() else tvdb_id
                if trakt_payload:
                    listitem.setProperty('script.trakt.ids', json.dumps(trakt_payload))

                try:
                    vt = listitem.getVideoInfoTag()
                    if vt:
                        if unique_dict:
                            try: vt.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else ('imdb' if imdb_id else ''))
                            except: pass
                        if imdb_id:
                            try: vt.setIMDbNumber(imdb_id)
                            except: pass
                        if is_ep:
                            vt.setMediaType('episode')
                            if showname_str: vt.setTvShowTitle(showname_str)
                            if season_num: vt.setSeason(int(season_num))
                            if episode_num: vt.setEpisode(int(episode_num))
                            if title_str: vt.setTitle(title_str)
                        else:
                            vt.setMediaType('movie')
                            if title_str: vt.setTitle(title_str)
                        if year_num:
                            try: vt.setYear(int(year_num))
                            except: pass
                        if plot_str: vt.setPlot(plot_str)
                        if tagline_str:
                            try: vt.setTagLine(tagline_str)
                            except: pass
                except: pass
            except Exception: pass

        platformtools.set_infolabels = _enhanced_balandro_set_infolabels

        return {
            'path': balandro_path, 'config': config, 'platformtools': platformtools,
            'Item': Item, 'InfoLabels': InfoLabels, 'servertools': servertools,
            'httptools': httptools, 'scrapertools': scrapertools
        }
    except Exception as e:
        xbmc.log("Bridge Multi: Error cargando Balandro: " + str(e), xbmc.LOGWARNING)
        return None

@contextmanager
def silenced_dialogs():
    pt_mod = sys.modules.get('platformcode.platformtools')
    orig_ok = getattr(pt_mod, 'dialog_ok', None) if pt_mod else None
    orig_notif = getattr(pt_mod, 'dialog_notification', None) if pt_mod else None
    orig_yesno = getattr(pt_mod, 'dialog_yesno', None) if pt_mod else None
    orig_select = getattr(pt_mod, 'dialog_select', None) if pt_mod else None
    orig_multiselect = getattr(pt_mod, 'dialog_multiselect', None) if pt_mod else None

    tmdb_mod = sys.modules.get('core.tmdb')
    orig_sil = getattr(tmdb_mod, 'set_infoLabels', None) if tmdb_mod else None
    orig_sill = getattr(tmdb_mod, 'set_infoLabels_itemlist', None) if tmdb_mod else None
    orig_sili = getattr(tmdb_mod, 'set_infoLabels_item', None) if tmdb_mod else None
    _dummy_sil = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])

    try:
        if pt_mod:
            pt_mod.dialog_ok = lambda *args, **kwargs: None
            pt_mod.dialog_notification = lambda *args, **kwargs: None
            pt_mod.dialog_yesno = lambda *args, **kwargs: True
            pt_mod.dialog_select = lambda *args, **kwargs: -1
            pt_mod.dialog_multiselect = lambda *args, **kwargs: []
        if tmdb_mod:
            tmdb_mod.set_infoLabels = _dummy_sil
            tmdb_mod.set_infoLabels_itemlist = _dummy_sil
            if hasattr(tmdb_mod, 'set_infoLabels_item'):
                tmdb_mod.set_infoLabels_item = lambda *args, **kwargs: 0
        yield
    finally:
        if pt_mod:
            if orig_ok: pt_mod.dialog_ok = orig_ok
            if orig_notif: pt_mod.dialog_notification = orig_notif
            if orig_yesno: pt_mod.dialog_yesno = orig_yesno
            if orig_select: pt_mod.dialog_select = orig_select
            if orig_multiselect: pt_mod.dialog_multiselect = orig_multiselect
        if tmdb_mod:
            if orig_sil: tmdb_mod.set_infoLabels = orig_sil
            if orig_sill: tmdb_mod.set_infoLabels_itemlist = orig_sill
            if orig_sili: tmdb_mod.set_infoLabels_item = orig_sili

def _prepare_playable_link(link, engine='alfa'):
    """Prepara un enlace decodificando URLs protegidas (ej. data_url base64 en Cinecalidad)
    y ejecutando canal.play(item) si el canal implementa resolutor propio."""
    if not link:
        return None

    item = link.clone() if hasattr(link, 'clone') else link

    # 1. Base64 data_url decode si url esta vacia o 'None'
    data_url = _safe_str(getattr(item, 'data_url', '') or '')
    cur_url = _safe_str(getattr(item, 'url', '') or '')
    if (not cur_url or cur_url.lower() == 'none') and data_url:
        try:
            item.url = base64.b64decode(data_url).decode('utf-8')
        except Exception as e:
            xbmc.log(f"Bridge Multi: error decodificando data_url: {e}", xbmc.LOGINFO)

    # 2. Si el canal tiene metodo play(), ejecutarlo para resolver wrappers/protectores
    ch_name = _safe_str(getattr(item, 'channel', '') or '').strip()
    srv = _safe_str(getattr(item, 'server', '') or '').strip().lower()
    cur_u = _safe_str(getattr(item, 'url', '') or '').lower()
    needs_channel_play = bool(not srv or srv in ('', 'directo', 'local') or (ch_name and ch_name in cur_u))
    if ch_name and needs_channel_play:
        if engine == 'balandro':
            try:
                _switch_engine_environment('balandro')
                ch_mod = __import__('channels.' + ch_name, fromlist=[''])
                if hasattr(ch_mod, 'play'):
                    with silenced_dialogs():
                        p_res = ch_mod.play(item)
                        if p_res:
                            if isinstance(p_res, list) and len(p_res) > 0:
                                if isinstance(p_res[0], list):
                                    item.video_urls = p_res
                                elif hasattr(p_res[0], 'url') or hasattr(p_res[0], 'server'):
                                    item = p_res[0]
                            elif hasattr(p_res, 'url'):
                                item = p_res
                            elif isinstance(p_res, str) and p_res.startswith('http'):
                                item.url = p_res
            except Exception as e:
                xbmc.log(f"Bridge Multi: balandro canal {ch_name}.play error: {e}", xbmc.LOGINFO)
        else:  # alfa
            try:
                _switch_engine_environment('alfa')
                ch_mod = __import__('channels.' + ch_name, fromlist=[''])
                if hasattr(ch_mod, 'play'):
                    with silenced_dialogs():
                        p_res = ch_mod.play(item)
                        if p_res:
                            if isinstance(p_res, list) and len(p_res) > 0:
                                if isinstance(p_res[0], list):
                                    item.video_urls = p_res
                                elif hasattr(p_res[0], 'url') or hasattr(p_res[0], 'server'):
                                    item = p_res[0]
                            elif hasattr(p_res, 'url'):
                                item = p_res
                            elif isinstance(p_res, str) and p_res.startswith('http'):
                                item.url = p_res
            except Exception as e:
                xbmc.log(f"Bridge Multi: alfa canal {ch_name}.play error: {e}", xbmc.LOGINFO)

    # 3. Comprobacion secundaria de data_url si url sigue vacia
    if (not getattr(item, 'url', '') or str(getattr(item, 'url', '')).lower() == 'none') and getattr(item, 'data_url', ''):
        try:
            item.url = base64.b64decode(item.data_url).decode('utf-8')
        except Exception:
            pass

    return item

# ---------------------------------------------------------
# Request URL Parameter Parsing (Supports Nested URLs)
# ---------------------------------------------------------
def get_param(name):
    if len(sys.argv) > 2 and sys.argv[2]:
        params = sys.argv[2]
        if params.startswith('?'): params = params[1:]
        for pair in params.split('&'):
            if '=' in pair:
                k, v = pair.split('=', 1)
                if k == name and v:
                    val = uparse.unquote(v).strip()
                    if val.lower() in ('none', 'null', 'undefined', '_', ''):
                        return ''
                    return val
        if 'url=' in params:
            nested_part = params.split('url=', 1)[1]
            unq_nested = uparse.unquote(nested_part)
            if '?' in unq_nested:
                inner_q = unq_nested.split('?', 1)[1]
                for pair in inner_q.split('&'):
                    if '=' in pair:
                        k, v = pair.split('=', 1)
                        if k == name and v:
                            val = uparse.unquote(v).strip()
                            if val.lower() in ('none', 'null', 'undefined', '_', ''):
                                return ''
                            return val
    return ''

url = get_param('url')
action = get_param('action')
view = get_param('view')
engine_param = get_param('engine')
title = get_param('title')
year = get_param('year')
season = get_param('season')
episode = get_param('episode')
showname = get_param('showname')
showyear = get_param('showyear')
title_es = get_param('title_es')
title_lat = get_param('title_lat')
title_en = get_param('title_en')
title_orig = get_param('title_orig')
tmdb_id = get_param('tmdb')
imdb_id = get_param('imdb')
tvdb_id = get_param('tvdb')
trakt_id = get_param('trakt')
plot = get_param('plot')
plot_lat = get_param('plot_lat')
plot_es = get_param('plot_es')
director = get_param('director')
tagline = get_param('tagline')
tagline_lat = get_param('tagline_lat')
tagline_es = get_param('tagline_es')
poster = get_param('poster')
fanart = get_param('fanart')
thumbnail = get_param('thumbnail')

def decode_base64_item(b64_str, ItemClass):
    try:
        decoded_bytes = base64.b64decode(b64_str)
        decoded_str = decoded_bytes.decode('utf-8', errors='ignore')
        data = json.loads(decoded_str)
        it = ItemClass()
        it.__dict__.update(data)
        for k, v in data.items():
            try: setattr(it, k, v)
            except: pass
        return it
    except Exception:
        try: return ItemClass().fromurl('plugin://plugin.video.alfa/?' + b64_str)
        except: return ItemClass()

# ---------------------------------------------------------
# Title Matching and Normalization
# ---------------------------------------------------------

# ── Leading-article stripping (The/El/La/etc.) ──────────────────────────────
_LEADING_ARTICLES = frozenset([
    'the', 'el', 'la', 'los', 'las', 'a', 'an', 'un', 'una',
    'le', 'les', 'der', 'die', 'das', 'de', 'het',
])

def _strip_leading_article(s):
    """Remove leading article from a *cleaned* title string for comparison.
    'the office' → 'office', 'la casa de papel' stays (only drops first word)."""
    words = s.split()
    if len(words) > 1 and words[0] in _LEADING_ARTICLES:
        return ' '.join(words[1:])
    return s

# ── Roman-numeral → Arabic normalization ────────────────────────────────────
_ROMAN_PATTERNS = [
    (re.compile(r'\bxx\b'),   '20'), (re.compile(r'\bxix\b'),  '19'),
    (re.compile(r'\bxviii\b'),'18'), (re.compile(r'\bxvii\b'), '17'),
    (re.compile(r'\bxvi\b'),  '16'), (re.compile(r'\bxv\b'),   '15'),
    (re.compile(r'\bxiv\b'),  '14'), (re.compile(r'\bxiii\b'), '13'),
    (re.compile(r'\bxii\b'),  '12'), (re.compile(r'\bxi\b'),   '11'),
    (re.compile(r'\bx\b'),    '10'), (re.compile(r'\bix\b'),    '9'),
    (re.compile(r'\bviii\b'),  '8'), (re.compile(r'\bvii\b'),   '7'),
    (re.compile(r'\bvi\b'),    '6'), (re.compile(r'\biv\b'),    '4'),
    (re.compile(r'\bv\b'),     '5'), (re.compile(r'\biii\b'),   '3'),
    (re.compile(r'\bii\b'),    '2'),
]

def _normalize_numerals(s):
    """Convert roman numerals to arabic digits: 'rocky ii' → 'rocky 2'.
    Only standalone words, not inside larger tokens."""
    if not s: return ''
    for pat, num in _ROMAN_PATTERNS:
        s = pat.sub(num, s)
    return s

_WORD_NUMBERS = [
    (re.compile(r'\bse7en\b', re.IGNORECASE), '7'),
    (re.compile(r'\bscre4m\b', re.IGNORECASE), 'scream 4'),
    (re.compile(r'\bfant4stic\b', re.IGNORECASE), 'fantastic 4'),
    (re.compile(r'\bzero\b|\bcero\b', re.IGNORECASE), '0'),
    (re.compile(r'\bone\b|\buno\b', re.IGNORECASE), '1'),
    (re.compile(r'\btwo\b|\bdos\b', re.IGNORECASE), '2'),
    (re.compile(r'\bthree\b|\btres\b', re.IGNORECASE), '3'),
    (re.compile(r'\bfour\b|\bcuatro\b', re.IGNORECASE), '4'),
    (re.compile(r'\bfive\b|\bcinco\b', re.IGNORECASE), '5'),
    (re.compile(r'\bsix\b|\bseis\b', re.IGNORECASE), '6'),
    (re.compile(r'\bseven\b|\bsiete\b', re.IGNORECASE), '7'),
    (re.compile(r'\beight\b|\bocho\b', re.IGNORECASE), '8'),
    (re.compile(r'\bnine\b|\bnueve\b', re.IGNORECASE), '9'),
    (re.compile(r'\bten\b|\bdiez\b', re.IGNORECASE), '10'),
    (re.compile(r'\beleven\b|\bonce\b', re.IGNORECASE), '11'),
    (re.compile(r'\btwelve\b|\bdoce\b', re.IGNORECASE), '12'),
    (re.compile(r'\bthirteen\b|\btrece\b', re.IGNORECASE), '13'),
    (re.compile(r'\bfourteen\b|\bcatorce\b', re.IGNORECASE), '14'),
    (re.compile(r'\bfifteen\b|\bquince\b', re.IGNORECASE), '15'),
    (re.compile(r'\bsixteen\b|\bdieciseis\b', re.IGNORECASE), '16'),
    (re.compile(r'\bseventeen\b|\bdiecisiete\b', re.IGNORECASE), '17'),
    (re.compile(r'\beighteen\b|\bdieciocho\b', re.IGNORECASE), '18'),
    (re.compile(r'\bnineteen\b|\bdiecinueve\b', re.IGNORECASE), '19'),
    (re.compile(r'\btwenty\b|\bveinte\b', re.IGNORECASE), '20'),
    (re.compile(r'\bthirty\b|\btreinta\b', re.IGNORECASE), '30'),
    (re.compile(r'\bforty\b|\bcuarenta\b', re.IGNORECASE), '40'),
    (re.compile(r'\bfifty\b|\bcincuenta\b', re.IGNORECASE), '50'),
    (re.compile(r'\bhundred\b|\bcien\b|\bciento\b', re.IGNORECASE), '100'),
    (re.compile(r'\bthousand\b|\bmil\b', re.IGNORECASE), '1000'),
]

def _normalize_number_words(s):
    if not s: return ''
    for pat, rep in _WORD_NUMBERS:
        s = pat.sub(rep, s)
    return s

_SPECIAL_CHAR_MAP = {
    'ß': 'ss', 'ẞ': 'ss',
    'æ': 'ae', 'Æ': 'ae',
    'œ': 'oe', 'Œ': 'oe',
    'ø': 'o',  'Ø': 'o',
    'ł': 'l',  'Ł': 'l',
    'đ': 'd',  'Đ': 'd',
    'ð': 'd',  'Ð': 'd',
    'þ': 'th', 'Þ': 'th',
    'ı': 'i',  'İ': 'i',
}

_ALL_ARTICLES = frozenset([
    'the', 'a', 'an', 'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas',
    'le', 'les', 'der', 'die', 'das', 'de', 'del', 'of',
])

def _strip_all_articles(s):
    return ' '.join(w for w in s.split() if w not in _ALL_ARTICLES)

def clean_title(title_str):
    """Normalize a title for fuzzy comparison.

    Handles: Kodi tags, brackets/parens, quality flags, & and + → and,
    Foreign ligatures/characters (ß, æ, ø, ł, etc.),
    Unicode accents (all scripts via NFD), possessives, roman numerals.
    Result is lowercase ASCII alphanumeric words joined by single spaces.
    """
    title_str = _safe_str(title_str)
    if not title_str: return ''
    # 1. Strip Kodi markup tags
    c = re.sub(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|LIGHT|CR)\]', '', title_str, flags=re.IGNORECASE)
    # 2. Strip content inside brackets / parens / braces (year, quality, etc.)
    c = re.sub(r'[\(\[\{][^\)\]\}]{0,80}[\)\]\}]', '', c)
    # 3. Strip quality / language / codec keywords
    c = re.sub(
        r'(?i)\b(4k|uhd|2160p|1080p|720p|480p|360p|'
        r'bluray|blu-ray|bdrip|brrip|hdrip|hdtv|dvdrip|dvdscr|'
        r'web-dl|webdl|webrip|web-rip|'
        r'x264|x265|h264|h265|hevc|avc|xvid|divx|'
        r'latino|castellano|espa[ñn]ol|subtitulado|dual|audio|'
        r'hdr|sdr|dts|aac|ac3|mp3|'
        r'extended|remastered|unrated|theatrical|directors.cut)\b',
        '', c)
    # 4. Normalize & and + to and
    c = re.sub(r'\s*[&+]\s*', ' and ', c)
    # 5. Map special ligatures / foreign letters that NFKD does not decompose
    for ch, repl in _SPECIAL_CHAR_MAP.items():
        if ch in c:
            c = c.replace(ch, repl)
    # 6. Unicode NFKD decomposition (handles European/Latin accents)
    try:
        import unicodedata as _ud
        nfkd = _ud.normalize('NFKD', c)
        c = ''.join(ch for ch in nfkd if not _ud.combining(ch))
    except Exception:
        pass
    c = c.lower()
    # 7. Possessives and apostrophes: "Pan's" → "pans", "it's" → "its"
    c = re.sub(r"[\u2019\u2018\u0027\u0060\u00b4]s\b", 's', c)
    c = re.sub(r"[\u2019\u2018\u0027\u0060\u00b4]", '', c)
    # 8. Keep only ASCII alphanumeric; everything else → space
    c = re.sub(r'[^a-z0-9]', ' ', c)
    return ' '.join(c.split())

def _extract_year_from_val(val):
    if not val: return None
    s = str(val).strip()
    m = re.search(r'\b(19\d\d|20\d\d)\b', s)
    if m:
        try:
            y = int(m.group(1))
            if 1900 <= y <= 2099:
                return y
        except:
            pass
    return None

def _extract_title_embedded_years(target_titles):
    """Finds 4-digit numbers that are part of target titles (e.g. 1917, 1984 in Wonder Woman 1984)."""
    embedded = set()
    for t in (target_titles or []):
        if t:
            for y in re.findall(r'\b(19\d\d|20\d\d)\b', str(t)):
                embedded.add(int(y))
    return embedded

def _get_item_year(item=None, title_str=None, embedded_title_years=None):
    """Extract a 4-digit year (1900-2099) as integer, or None, avoiding title embedded numbers."""
    embedded = embedded_title_years or set()
    # 1. From item.infoLabels
    if item:
        _il = getattr(item, 'infoLabels', {}) if hasattr(item, 'infoLabels') else {}
        if isinstance(_il, dict):
            for k in ('year', 'release_date', 'premiered', 'aired'):
                y = _extract_year_from_val(_il.get(k))
                if y and y not in embedded:
                    return y
        for attr in ('year', 'contentYear'):
            y = _extract_year_from_val(getattr(item, attr, None))
            if y and y not in embedded:
                return y
    # 2. From explicit year tags in title: (YYYY) or [YYYY]
    for t in (title_str, getattr(item, 'title', None) if item else None, getattr(item, 'contentTitle', None) if item else None):
        if t:
            m = re.search(r'[\(\[]\s*(19\d\d|20\d\d)\s*[\)\]]', str(t))
            if m:
                return int(m.group(1))
    # 3. From trailing year in title: ONLY if not an embedded title year
    for t in (title_str, getattr(item, 'title', None) if item else None, getattr(item, 'contentTitle', None) if item else None):
        if t:
            m = re.search(r'(?:\s*-\s*|\s+)(19\d\d|20\d\d)\s*$', str(t))
            if m:
                y = int(m.group(1))
                if y not in embedded:
                    return y
    # 4. From URL: ONLY if not an embedded title year
    if item:
        url = _safe_str(getattr(item, 'url', ''))
        if url:
            for m in re.finditer(r'[-_/(](19\d\d|20\d\d)(?:[-_/.)]|$)', url):
                y = int(m.group(1))
                if y not in embedded:
                    return y
    return None

def _get_item_tmdb(item):
    if not item: return None
    _il = getattr(item, 'infoLabels', {}) if hasattr(item, 'infoLabels') else {}
    if isinstance(_il, dict):
        for k in ('tmdb_id', 'tmdb'):
            val = _safe_str(_il.get(k))
            if val.isdigit() and int(val) > 0:
                return val
    for attr in ('tmdb_id', 'tmdb'):
        val = _safe_str(getattr(item, attr, ''))
        if val.isdigit() and int(val) > 0:
            return val
    url = _safe_str(getattr(item, 'url', ''))
    if url:
        m = re.search(r'[?&](?:tmdb_id|tmdb)=(\d+)', url)
        if m and int(m.group(1)) > 0:
            return m.group(1)
        ch = _safe_str(getattr(item, 'channel', '')).lower()
        if any(x in ch for x in ('poseidon', 'cuevana', 'pelisplus', 'estrenosgo', 'pelisforte')):
            m = re.search(r'/(?:pelicula|serie|series|tv|movie)/(\d{2,9})(?:/|[-_]|$)', url)
            if m and int(m.group(1)) > 0:
                return m.group(1)
        else:
            m = re.search(r'/(?:pelicula|serie|series|tv|movie)/(\d{2,9})/(?:[^/?#]+)', url)
            if m and int(m.group(1)) > 0:
                return m.group(1)
    return None

def _get_item_imdb(item):
    if not item: return None
    _il = getattr(item, 'infoLabels', {}) if hasattr(item, 'infoLabels') else {}
    if isinstance(_il, dict):
        for k in ('imdb_id', 'imdb', 'IMDBNumber'):
            val = _safe_str(_il.get(k)).lower()
            if val.startswith('tt'): return val
    for attr in ('imdb_id', 'imdb'):
        val = _safe_str(getattr(item, attr, '')).lower()
        if val.startswith('tt'): return val
    url = _safe_str(getattr(item, 'url', '')).lower()
    if url:
        m = re.search(r'(tt\d{6,10})', url)
        if m: return m.group(1)
    return None

def _clean_search_term(term):
    term = _safe_str(term)
    if not term: return ""
    term = re.sub(r'\s*\(\d{4}\)', '', term)
    term = re.sub(r'[\:\-\_]', ' ', term)
    term = re.sub(r'\s+', ' ', term)
    return term.strip().lower()

def get_core_title(t):
    t = _safe_str(t)
    if not t: return ''
    core = re.sub(r'\s*\(\d{4}\)', '', t)
    core = re.split(r'[:\-–—]', core)[0]
    return core.strip()

def _extract_title_number(title_str):
    title_str = _safe_str(title_str)
    if not title_str: return None
    s = _normalize_number_words(title_str.lower())
    m = re.search(r'\b(?:volumen|vol\.?|parte|part)\s*(\d+)\b', s)
    if m: return int(m.group(1))
    m = re.search(r'\b(?:volumen|vol\.?|parte|part)\s*(iv|v|vi|vii|viii|ix|x|iii|ii|i)\b', s)
    if m:
        romans = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
        return romans.get(m.group(1))
    m = re.search(r'\b(\d+)\b', s)
    if m: return int(m.group(1))
    m = re.search(r'\b(iv|v|vi|vii|viii|ix|x|iii|ii)\b', s)
    if m:
        romans = {'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
        return romans.get(m.group(1))
    return None

def is_slug_or_raw_consistent(raw_title, target_title, target_year, item=None, embedded_years=None):
    raw_title = _safe_str(raw_title)
    target_title = _safe_str(target_title)
    if not raw_title or not target_title: return True
    raw_sub = re.sub(r'\s*\(\d{4}\)', '', raw_title)
    tgt_sub = re.sub(r'\s*\(\d{4}\)', '', target_title)
    raw_has_colon = ':' in raw_sub or ' - ' in raw_sub or '–' in raw_sub
    tgt_has_colon = ':' in tgt_sub or ' - ' in tgt_sub or '–' in tgt_sub
    if tgt_has_colon and not raw_has_colon:
        tgt_parts = re.split(r'[:\-–—]', tgt_sub)
        if len(tgt_parts) > 1:
            subtitle = clean_title(tgt_parts[1])
            if subtitle and len(subtitle) >= 3:
                raw_c = clean_title(raw_sub)
                if subtitle not in raw_c:
                    raw_y_match = _get_item_year(item, raw_title, embedded_title_years=embedded_years)
                    if raw_y_match and target_year:
                        if abs(int(raw_y_match) - int(target_year)) > 1: return False
    raw_num = _extract_title_number(raw_sub)
    tgt_num = _extract_title_number(tgt_sub)
    if raw_num is not None or tgt_num is not None:
        if raw_num != tgt_num: return False
    return True

def score_match(result_title, target_year, all_names, target_tmdb=None, item=None, target_imdb=None, is_series=None):
    """Calculates a match confidence score (integer > 0) or returns 0 if rejected.

    Higher score indicates greater precision and relevance.
    Scoring components:
      - TMDb match: +10000 (mismatch: REJECT)
      - IMDb match: +8000  (mismatch: REJECT)
      - Exact Year match: +3000
      - Off-by-1 Year: +2000
      - Year mismatch (>1): REJECT (0)
      - Exact Clean Title match: +1000
      - Compact de-spaced match (hyphens/dots/acronyms): +950
      - Number words & Roman numerals normalized match: +900
      - All articles stripped match: +880
      - Article/Numeral normalized match: +800
      - Subtitle prefix match: +800
      - Substring match: +300
      - Media type compatibility (movie vs show): +500
    """
    result_title = _safe_str(result_title)
    if not result_title: return 0

    # 1. Media Type Guard
    url_str = _safe_str(getattr(item, 'url', '')).lower() if item else ''
    content_type = _safe_str(getattr(item, 'contentType', '')).lower() if item else ''
    low_title = result_title.lower()

    if is_series is False:
        # Searching for movie
        if content_type in ('tvshow', 'season', 'episode'):
            return 0
        if '/serie/' in url_str or '/series/' in url_str or '/temporada/' in url_str:
            return 0
        if re.search(r'\b(?:temporada\s*\d+|capitulo\s*\d+|season\s*\d+|episodio\s*\d+)\b', low_title):
            return 0
    elif is_series is True:
        # Searching for series
        if content_type == 'movie' and not getattr(item, 'contentSerieName', ''):
            return 0
        if '/pelicula/' in url_str and not ('/serie/' in url_str or '/temporada/' in url_str):
            return 0

    # 2. TMDb Check
    item_tmdb = _get_item_tmdb(item)
    tmdb_score = 0
    if target_tmdb and item_tmdb:
        if str(target_tmdb) == str(item_tmdb):
            tmdb_score = 10000
        else:
            # Explicit TMDb conflict!
            return 0

    # 3. IMDb Check
    item_imdb = _get_item_imdb(item)
    imdb_score = 0
    if target_imdb and item_imdb:
        if str(target_imdb).lower() == str(item_imdb).lower():
            imdb_score = 8000
        else:
            return 0

    # 4. Year Check (avoid treating title embedded numbers like 1917, 1984 as release years)
    embedded_years = _extract_title_embedded_years(all_names)
    item_year = _get_item_year(item, result_title, embedded_title_years=embedded_years)
    year_score = 0
    if item_year and target_year:
        try:
            y_diff = abs(int(item_year) - int(target_year))
            if y_diff == 0:
                year_score = 3000
            elif y_diff == 1:
                year_score = 2000
            else:
                # Strong rejection for year mismatch (e.g. 1984 vs 2026)
                return 0
        except:
            pass

    clean_res = clean_title(result_title)
    if not clean_res: return 0

    _cr_na       = _strip_leading_article(clean_res)
    _cr_nr       = _normalize_numerals(clean_res)
    _cr_nw       = _normalize_number_words(clean_res)
    _cr_nw_nr    = _normalize_numerals(_cr_nw)
    _cr_compact  = clean_res.replace(' ', '')
    _cr_nw_comp  = _cr_nw_nr.replace(' ', '')
    _cr_all_art  = _strip_all_articles(clean_res)
    _cr_art_comp = _cr_all_art.replace(' ', '')

    best_title_score = 0

    for name in (all_names or []):
        name = _safe_str(name)
        if not name: continue
        clean_target = clean_title(name)
        if not clean_target: continue

        if not is_slug_or_raw_consistent(result_title, name, target_year, item=item, embedded_years=embedded_years):
            continue

        _ct_na       = _strip_leading_article(clean_target)
        _ct_nr       = _normalize_numerals(clean_target)
        _ct_nw       = _normalize_number_words(clean_target)
        _ct_nw_nr    = _normalize_numerals(_ct_nw)
        _ct_compact  = clean_target.replace(' ', '')
        _ct_nw_comp  = _ct_nw_nr.replace(' ', '')
        _ct_all_art  = _strip_all_articles(clean_target)
        _ct_art_comp = _ct_all_art.replace(' ', '')

        # 1. Exact clean match
        if clean_res == clean_target:
            best_title_score = max(best_title_score, 1000)
            continue

        # 2. Compact match (handles hyphens, dots, spaces: Spider-Man/Spiderman, S.W.A.T./SWAT, Kick-Ass/Kickass, WALL·E/Wall-E)
        if _cr_compact == _ct_compact and len(_cr_compact) >= 3:
            best_title_score = max(best_title_score, 950)
            continue

        # 3. Number words / Roman numerals normalized (12 Monkeys/Twelve Monkeys, Ocean's 11/Ocean's Eleven, Rocky II/Rocky 2)
        if _cr_nw_nr == _ct_nw_nr or _cr_nr == _ct_nr:
            best_title_score = max(best_title_score, 900)
            continue

        # 4. All articles stripped match (e.g. 2001: Una odisea del espacio vs 2001: Odisea del espacio)
        if _cr_all_art and _ct_all_art and (_cr_all_art == _ct_all_art or (_cr_art_comp == _ct_art_comp and len(_cr_art_comp) >= 3)):
            best_title_score = max(best_title_score, 880)
            continue

        # 5. Compact + Number words normalized
        if _cr_nw_comp == _ct_nw_comp and len(_cr_nw_comp) >= 3:
            best_title_score = max(best_title_score, 850)
            continue

        # 6. Article-stripped match
        if (_cr_na == _ct_na and _cr_na) or (_cr_na.replace(' ', '') == _ct_na.replace(' ', '') and len(_cr_na) >= 3):
            best_title_score = max(best_title_score, 800)
            continue

        # 7. Subtitle split handling: "Supergirl: Woman of Tomorrow" vs "Supergirl", "Dr. Strangelove or:..." vs "Dr. Strangelove"
        if ':' in name or ' - ' in name or '–' in name:
            parts = re.split(r'[:\-–—]', name)
            if len(parts) > 1:
                prefix = clean_title(parts[0])
                prefix_comp = prefix.replace(' ', '')
                if (prefix and clean_res == prefix) or (prefix_comp and _cr_compact == prefix_comp):
                    if tmdb_score > 0:
                        best_title_score = max(best_title_score, 1000)
                    elif year_score > 0:
                        best_title_score = max(best_title_score, 800)
                    elif target_year is None:
                        best_title_score = max(best_title_score, 500)
                    continue

        if ':' in result_title or ' - ' in result_title or '–' in result_title:
            res_parts = re.split(r'[:\-–—]', result_title)
            if len(res_parts) > 1:
                res_prefix = clean_title(res_parts[0])
                res_pref_comp = res_prefix.replace(' ', '')
                if (res_prefix and res_prefix == clean_target) or (res_pref_comp and res_pref_comp == _ct_compact):
                    if tmdb_score > 0:
                        best_title_score = max(best_title_score, 1000)
                    elif year_score > 0:
                        best_title_score = max(best_title_score, 800)
                    elif target_year is None:
                        best_title_score = max(best_title_score, 500)
                    continue

        # 8. Substring match
        for _rv, _tv in [(clean_res, clean_target), (_cr_na, _ct_na)]:
            if not _rv or not _tv or _rv == _tv: continue
            _sub_fwd = _tv in _rv
            _sub_rev = _rv in _tv
            if not _sub_fwd and not _sub_rev: continue

            _wc_res = len(_rv.split())
            _wc_tgt = len(_tv.split())
            _same_wc = _wc_res == _wc_tgt

            if _sub_fwd and not _same_wc:
                _pos = _rv.find(_tv)
                _extra = (_rv[:_pos].strip() + ' ' + _rv[_pos + len(_tv):].strip()).strip()
                if _extra and any(ch.isalpha() for ch in _extra):
                    break

            if year_score > 0 or tmdb_score > 0 or _same_wc:
                best_title_score = max(best_title_score, 300)
            break

    if best_title_score == 0 and tmdb_score == 0 and imdb_score == 0:
        return 0

    total_score = tmdb_score + imdb_score + year_score + best_title_score
    if is_series is False and ('/pelicula/' in url_str or content_type == 'movie'):
        total_score += 500
    elif is_series is True and ('/serie/' in url_str or content_type == 'tvshow'):
        total_score += 500

    return total_score

def match_title(result_title, target_year, all_names, target_tmdb=None, item=None, target_imdb=None, is_series=None):
    """Return True if result_title matches any name in all_names, considering year and IDs."""
    return score_match(result_title, target_year, all_names, target_tmdb=target_tmdb, item=item, target_imdb=target_imdb, is_series=is_series) > 0


# ---------------------------------------------------------
# Item Formatting & Quality / Server / Language Helpers
# ---------------------------------------------------------
def _is_torrent_link(link):
    if not link: return False

    # 1. Server check
    srv = _safe_str(getattr(link, 'server', '')).lower().strip()
    if srv:
        if srv in ('torrent', 'magnet', 'torrents', 'bittorrent', 'utorrent', 'elementum'):
            return True
        if 'torrent' in srv or 'magnet' in srv:
            return True

    # 2. URL check
    url_str = _safe_str(getattr(link, 'url', '')).lower().strip()
    if url_str:
        if url_str.startswith('magnet:') or 'magnet:?' in url_str or 'xt=urn:btih' in url_str or 'urn:btih:' in url_str:
            return True
        if '.torrent' in url_str:
            return True

    # 3. Action check
    act = _safe_str(getattr(link, 'action', '')).lower().strip()
    if act in ('play_torrent', 'torrent', 'download_torrent'):
        return True

    # 4. Extra / Stream type / Format / Type check
    extra = _safe_str(getattr(link, 'extra', '')).lower()
    if 'torrent' in extra:
        return True
    st_type = _safe_str(getattr(link, 'stream_type', '')).lower()
    if 'torrent' in st_type:
        return True
    l_type = _safe_str(getattr(link, 'type', '')).lower()
    if 'torrent' in l_type:
        return True

    # 5. Channel check (canales torrent conocidos en Balandro y Alfa)
    ch = _safe_str(getattr(link, 'channel', '')).lower().strip()
    if ch:
        if 'torrent' in ch or 'divx' in ch:
            return True
        torrent_channels = (
            'dontorrent', 'dontorrents', 'dontorrentsin', 'dontorrent21',
            'elitetorrent', 'elitetorrentnz', 'grantorrent', 'hacktorrent',
            'mejortorrent', 'mejortorrentapp', 'mejortorrentin', 'mitorrent',
            'pasateatorrent', 'pediatorrent', 'subtorrents', 'todotorrents',
            'torrentgalaxy', 'vivatorrents', 'divxtotal', 'divxatope',
            'tomadivx', 'eztv', 'yts', 'pelitorrent', 'yestorrent',
            'wolfmax4k', 'moviesdvdr', 'reinventorrent'
        )
        if ch in torrent_channels:
            return True

    # 6. video_urls check
    video_urls = getattr(link, 'video_urls', None)
    if video_urls and isinstance(video_urls, list):
        for v in video_urls:
            v_str = str(v).lower()
            if 'magnet:' in v_str or '.torrent' in v_str or '[torrent]' in v_str:
                return True

    # 7. other / title check
    other = _safe_str(getattr(link, 'other', '')).lower()
    if '[torrent]' in other or '(torrent)' in other or other.startswith('torrent'):
        return True

    return False


def _get_torrent_client():
    """Lee el ajuste 'cliente_torrent' de Balandro y devuelve (addon_id, url_template).

    url_template usa %s como placeholder para la URL/magnet codificada.
    Retorna (None, None) si no hay cliente configurado o no está instalado.
    """
    try:
        bal_addon = xbmcaddon.Addon('plugin.video.balandro')
        cliente = (bal_addon.getSetting('cliente_torrent') or '').strip().lower()
        if not cliente or cliente in ('ninguno', 'seleccionar', ''):
            return None, None

        # Leer torrent.json de Balandro para obtener la URL template
        bal_path = bal_addon.getAddonInfo('path')
        torrent_json_path = os.path.join(bal_path, 'servers', 'torrent.json')
        if not os.path.exists(torrent_json_path):
            return None, None

        import json as _json
        with open(torrent_json_path, 'r', encoding='utf-8') as _f:
            _data = _json.load(_f)

        for client in _data.get('clients', []):
            if client.get('name', '').lower() == cliente:
                addon_id = client.get('id', '')
                if addon_id and xbmc.getCondVisibility('System.HasAddon("%s")' % addon_id):
                    return addon_id, client.get('url', '')
                else:
                    xbmc.log('Bridge Multi: cliente torrent "%s" (%s) no instalado' % (cliente, addon_id), xbmc.LOGINFO)
                    return None, None

        xbmc.log('Bridge Multi: cliente torrent "%s" no encontrado en torrent.json' % cliente, xbmc.LOGINFO)
        return None, None

    except Exception as _e:
        xbmc.log('Bridge Multi: _get_torrent_client error: ' + str(_e), xbmc.LOGINFO)
        return None, None


def _play_torrent_link(torrent_url, matched_item=None, meta=None):
    """Reproduce un link torrent usando el cliente configurado en Balandro.

    Enriquece la URL con datos TMDb (tmdb_id, type, season, episode, show)
    para que Elementum/Quasar puedan identificar el contenido correctamente.

    Returns True si se lanzó la reproducción, False si no hay cliente configurado.
    """
    if not torrent_url:
        return False

    _tor_id, _tor_tpl = _get_torrent_client()
    if not (_tor_id and _tor_tpl):
        xbmcgui.Dialog().notification(
            'Bridge Multi',
            'Configura un cliente torrent en Ajustes → Balandro → Torrents',
            '', 5000)
        return False

    # Elegir url o url_magnet según tipo de enlace
    _is_magnet = torrent_url.startswith('magnet:')

    # Si el template no acepta magnets y tenemos magnet, intentar url_magnet
    # (ya resuelto: _tor_tpl viene del json y tiene la URL correcta para el tipo)
    encoded = uparse.quote_plus(torrent_url)
    play_url = _tor_tpl % encoded

    # ── Enriquecimiento TMDb para Elementum / Quasar ───────────────────────
    _tor_name = _tor_id.rsplit('.', 1)[-1].lower()   # 'elementum', 'quasar', ...
    if _tor_name in ('elementum', 'quasar'):
        _tmdb   = ''
        _ctype  = 'movie'
        _season = ''
        _epnum  = ''
        _show   = ''

        # Fuente 1: matched_item (Item de Balandro)
        if matched_item:
            _info  = getattr(matched_item, 'infoLabels', {}) or {}
            _tmdb  = str(_info.get('tmdb_id', '') or '')
            _ctype = str(getattr(matched_item, 'contentType', '') or 'movie')
            _season= str(getattr(matched_item, 'contentSeason', '')
                         or _info.get('season', '') or '')
            _epnum = str(getattr(matched_item, 'contentEpisode', '')
                         or _info.get('episode', '') or '')
            _show  = str(getattr(matched_item, 'contentSerieName', '')
                         or _info.get('tvshowtitle', '') or '')

        # Fuente 2: meta dict (del handler principal)
        if not _tmdb and meta:
            _tmdb  = str(meta.get('tmdb', '') or '')
        if not _ctype or _ctype == 'movie':
            if meta and meta.get('season') and meta.get('episode'):
                _ctype = 'episode'
        if meta and not _season:
            _season = str(meta.get('season', '') or '')
        if meta and not _epnum:
            _epnum  = str(meta.get('episode', '') or '')

        if _tmdb:
            if _ctype == 'episode' and _season and _epnum:
                play_url += ('&episode=%s&library=&season=%s&show=%s&tmdb=%s&type=episode'
                             % (_epnum, _season, uparse.quote_plus(_show), _tmdb))
                xbmc.log('Bridge Multi: torrent enriquecido [serie] tmdb=%s S%sE%s' % (
                    _tmdb, _season, _epnum), xbmc.LOGINFO)
            else:
                play_url += '&library=&tmdb=%s&type=movie' % _tmdb
                xbmc.log('Bridge Multi: torrent enriquecido [peli] tmdb=%s' % _tmdb, xbmc.LOGINFO)

    xbmc.log('Bridge Multi: torrent → %s' % _tor_id, xbmc.LOGINFO)
    sync_tmdbhelper_playerstring(meta)
    xbmc.executebuiltin('PlayMedia(%s)' % play_url)
    return True



def _offer_elementum_search(meta):
    """Si elementum_fallback está activo, pregunta si buscar en Elementum.

    Se ejecuta después de que el handle del plugin ha sido descartado y TMDb Helper
    ha finalizado, evitando cualquier interferencia o espera de player.
    """
    if _bridge_addon.getSetting('elementum_fallback') != 'true':
        return
    if not xbmc.getCondVisibility('System.HasAddon("plugin.video.elementum")'):
        return

    tmdb_id = str(meta.get('tmdb', '') or '')
    if not tmdb_id:
        return

    is_episode = bool(meta.get('season') and meta.get('episode'))
    title = str(meta.get('title') or meta.get('showname') or '')
    label = '[B]%s[/B]' % title if title else 'este contenido'

    ans = xbmcgui.Dialog().yesno(
        'Bridge Multi — Sin enlaces',
        'No se encontraron enlaces para %s.\n¿Buscar en [B]Elementum[/B]?' % label,
        nolabel='No',
        yeslabel='Sí')

    if not ans:
        return

    # URL de Elementum para buscar y mostrar la lista modal de torrents por TMDb ID
    if is_episode:
        _s = str(meta.get('season', '') or '')
        _e = str(meta.get('episode', '') or '')
        elem_url = 'plugin://plugin.video.elementum/show/%s/season/%s/episode/%s/links' % (tmdb_id, _s, _e)
    else:
        elem_url = 'plugin://plugin.video.elementum/movie/%s/links' % tmdb_id

    xbmc.log('Bridge Multi: lanzando Elementum via PlayMedia → %s' % elem_url, xbmc.LOGINFO)

    # PlayMedia asigna a Elementum un handle de reproductor real para que al elegir el torrent
    # Elementum pueda resolver e iniciar la reproducción en Kodi. Bridge Multi termina aquí su ejecución.
    sync_tmdbhelper_playerstring(meta)
    xbmc.executebuiltin('PlayMedia("%s")' % elem_url)
    return






def _get_link_server_name(link):


    if not link: return 'Directo'
    srv = _safe_str(getattr(link, 'server', '')).strip()
    other = _safe_str(getattr(link, 'other', '')).strip()
    url_str = _safe_str(getattr(link, 'url', '')).strip().lower()

    clean_other = re.sub(r'[\(\)\[\]]', '', other).strip()
    clean_other = re.sub(r'\s+D$', '', clean_other, flags=re.IGNORECASE).strip()

    domain_map = [
        ('fastream', 'Fastream'), ('streamwish', 'Streamwish'), ('strwish', 'Streamwish'),
        ('swish', 'Streamwish'), ('audinifer', 'Streamwish'), ('hanerix', 'Streamwish'),
        ('vidhide', 'Vidhide'), ('vidhideplus', 'Vidhide'), ('vidhidepro', 'Vidhide'),
        ('voe', 'Voe'), ('voesx', 'Voe'), ('vidmoly', 'Vidmoly'), ('dood', 'Doodstream'),
        ('ds2play', 'Doodstream'), ('mixdrop', 'Mixdrop'), ('uqload', 'Uqload'),
        ('vudeo', 'Vudeo'), ('turbovid', 'Turboviplay'), ('emturbovid', 'Turboviplay'),
        ('turboviplay', 'Turboviplay'), ('filelions', 'Filelions'), ('lion', 'Filelions'),
        ('luluvdo', 'Lulustream'), ('lulustream', 'Lulustream'), ('waaw', 'Waaw'),
        ('netu', 'Waaw'), ('gamovideo', 'Gamovideo'), ('streamtape', 'Streamtape'),
        ('streamlare', 'Streamlare'), ('supervideo', 'Supervideo'), ('dropload', 'Dropload'),
        ('userload', 'Userload'), ('upstream', 'Upstream'), ('wolfstream', 'Wolfstream'),
        ('hexupload', 'Hexupload'), ('mega', 'Mega'), ('1fichier', '1fichier'),
        ('okru', 'Okru'), ('ok.ru', 'Okru'), ('kinoger', 'Kinoger')
    ]

    if not srv or srv.lower() in ('various', 'directo', 'none', ''):
        if clean_other and clean_other.lower() not in ('various', 'directo', 'none', ''):
            for d_key, d_name in domain_map:
                if d_key in clean_other.lower(): return d_name
            return clean_other.capitalize()
        for d_key, d_name in domain_map:
            if d_key in url_str: return d_name
        if _is_torrent_link(link): return 'Torrent'
        return 'Directo'

    for d_key, d_name in domain_map:
        if d_key == srv.lower() or d_key in srv.lower():
            return d_name

    if clean_other and clean_other.lower() not in ('various', 'directo', 'none', ''):
        for d_key, d_name in domain_map:
            if d_key in clean_other.lower(): return d_name

    return srv.capitalize()

def _format_language(link):
    lang = getattr(link, 'language', '')
    if isinstance(lang, list): lang = ' / '.join([_safe_str(l) for l in lang])
    lang = _safe_str(lang).strip()
    title_str = _safe_str(getattr(link, 'title', ''))
    combined = (lang + ' ' + title_str).lower()
    if 'lat' in combined or 'latino' in combined or 'dual' in combined: return 'LATINO'
    if 'cast' in combined or 'esp' in combined or 'castellano' in combined or 'español' in combined: return 'CASTELLANO'
    if 'vose' in combined or 'sub' in combined or 'vos' in combined: return 'VOSE'
    if 'eng' in combined or 'ingles' in combined: return 'INGLES'
    return 'LATINO' if not lang else lang.upper()

def _get_link_language_group(link):
    f_lang = _format_language(link)
    if 'LAT' in f_lang: return 'LAT'
    if 'CAST' in f_lang or 'ESP' in f_lang: return 'ESP'
    if 'VOSE' in f_lang or 'SUB' in f_lang: return 'VOSE'
    return 'OTHER'

def _format_quality(link):
    qual = _safe_str(getattr(link, 'quality', '')).strip()
    title_str = _safe_str(getattr(link, 'title', '')).strip()
    url_str = _safe_str(getattr(link, 'url', '')).strip()
    combined = (qual + ' ' + title_str + ' ' + url_str).upper()
    if '4K' in combined or '2160P' in combined or 'UHD' in combined: return '4K'
    if '1080P' in combined or 'FULLHD' in combined or 'FHD' in combined or '1080' in combined: return '1080p'
    if '720P' in combined or 'HD' in combined: return '720p'
    if 'RIP' in combined or 'DVD' in combined or 'WEBRIP' in combined or 'DVDRIP' in combined: return 'SD'
    if 'CAM' in combined or 'TS' in combined or 'TELESYNC' in combined: return 'CAM'
    return 'N/D'

def _get_link_quality_score(link):
    q = _format_quality(link)
    scores = {'4K': 500, '1080p': 400, '720p': 300, 'SD': 200, 'CAM': 100, 'N/D': 50}
    return scores.get(q, 50)

def _format_channel(link):
    ch = _safe_str(getattr(link, 'channel', ''))
    if ch: return ch.capitalize()
    return 'General'

def _get_int_setting(key, default_val):
    try:
        val = _bridge_addon.getSetting(key)
        if val is None or val == '': return default_val
        return int(float(val))
    except Exception:
        return default_val

def _parse_csv_setting(val):
    if not val: return []
    return [_safe_str(s).strip().lower() for s in str(val).split(',') if s.strip()]

def _get_filter_prefs():
    def _bi(key, def_val):
        try:
            val = _bridge_addon.getSetting(key)
            if val is None or val == '': return def_val
            return int(float(val))
        except:
            return def_val

    def _bcsv(key, def_val):
        try:
            val = _bridge_addon.getSetting(key)
            if not val: return def_val
            return [s.strip().lower() for s in str(val).split(',') if s.strip()]
        except:
            return def_val

    lang_on = _bridge_addon.getSetting('filter_lang_enabled') != 'false'
    qual_on = _bridge_addon.getSetting('filter_quality_enabled') != 'false'
    srv_on  = _bridge_addon.getSetting('filter_servers_enabled') != 'false'

    return {
        'preferencia_idioma_lat': _bi('preferencia_idioma_lat', 1) if lang_on else 1,
        'preferencia_idioma_esp': _bi('preferencia_idioma_esp', 2) if lang_on else 1,
        'preferencia_idioma_vos': _bi('preferencia_idioma_vos', 3) if lang_on else 1,
        'servers_sort_quality': _bi('servers_sort_quality', 1) if qual_on else 0,
        'servers_preferred': _bcsv('servers_preferred', ['voe', 'doodstream', 'vidmoly']) if srv_on else [],
        'servers_unfavored': _bcsv('servers_unfavored', ['uqload', 'torrent']) if srv_on else [],
        'servers_discarded': _bcsv('servers_discarded', ['rapidgator', 'directo', 'waaw']) if srv_on else [],
    }

def _filter_and_sort_links(links):
    if not links: return []

    safe_links = []
    for l in links:
        try:
            _u = _safe_str(getattr(l, 'url', ''))
            if _u and len(_u) > 1500:
                continue
            safe_links.append(l)
        except:
            safe_links.append(l)

    b_prefs = _get_filter_prefs()

    # PASO 1 de Balandro: filter_and_sort_by_quality
    # 0: Orden Web, 1: Calidad Alta (descendente), 2: Calidad Baja (ascendente)
    sort_q = b_prefs.get('servers_sort_quality', 1)
    if sort_q == 1:
        safe_links = sorted(safe_links, key=_get_link_quality_score, reverse=True)
    elif sort_q == 2:
        safe_links = sorted(safe_links, key=_get_link_quality_score)

    # PASO 2 de Balandro: filter_and_sort_by_server
    # 2a. Descartar servidores descartados por el usuario
    disc_list = b_prefs.get('servers_discarded', [])
    if disc_list:
        def _is_not_discarded(it):
            if _is_torrent_link(it) and 'torrent' not in disc_list:
                return True
            srv = (_get_link_server_name(it) or getattr(it, 'server', '') or '').lower()
            if not srv:
                return 'indeterminado' not in disc_list
            return srv not in disc_list
        safe_links = [it for it in safe_links if _is_not_discarded(it)]

    # 2b. Ordenar preferidos, normales (99) y última opción (999 - index)
    pref_list = b_prefs.get('servers_preferred', [])
    unfav_list = b_prefs.get('servers_unfavored', [])
    if pref_list or unfav_list:
        def numera_server(it):
            if _is_torrent_link(it):
                srv = 'torrent'
            else:
                srv = (_get_link_server_name(it) or getattr(it, 'server', '') or '').lower()
            if not srv:
                srv = 'indeterminado'
            if srv in pref_list:
                return pref_list.index(srv)
            elif srv in unfav_list:
                return 999 - unfav_list.index(srv)
            else:
                return 99
        safe_links = sorted(safe_links, key=numera_server)

    # PASO 3 de Balandro: filter_and_sort_by_language
    # 3a. Quitar idiomas con valor 0 (Descartar)
    # 3b. Ordenar según orden de preferencia (1: Primero, 2: Segundo, 3: Tercero)
    p_lat = b_prefs.get('preferencia_idioma_lat', 1)
    p_esp = b_prefs.get('preferencia_idioma_esp', 2)
    p_vos = b_prefs.get('preferencia_idioma_vos', 3)
    prefs_lang = {'Lat': p_lat, 'Esp': p_esp, 'VO': p_vos, '?': 4}

    def _get_lang_grp(it):
        l_str = (_safe_str(getattr(it, 'language', '')) + ' ' + _get_link_language_group(it)).upper()
        if 'LAT' in l_str: return 'Lat'
        if 'ESP' in l_str or 'CAST' in l_str: return 'Esp'
        if 'VOS' in l_str or 'VO' in l_str or 'SUB' in l_str or 'ENG' in l_str: return 'VO'
        return '?'

    # Descartar idiomas con valor 0 (Descartar)
    safe_links = [it for it in safe_links if _is_torrent_link(it) or prefs_lang.get(_get_lang_grp(it), 4) != 0]

    # Ordenar por preferencia de idioma
    def _lang_sort_key(it):
        if _is_torrent_link(it):
            grp = _get_lang_grp(it)
            return prefs_lang.get(grp, 4) if grp != '?' else 99
        return prefs_lang.get(_get_lang_grp(it), 4)

    safe_links = sorted(safe_links, key=_lang_sort_key)

    return safe_links

# ---------------------------------------------------------
# Headless Link Verification System
# ---------------------------------------------------------
def _extract_valid_streams(video_urls):
    if not video_urls: return None
    res = []
    if isinstance(video_urls, list):
        for entry in video_urls:
            if isinstance(entry, list) and len(entry) >= 2:
                stream_url = _safe_str(entry[1])
                if stream_url.startswith('http') or stream_url.startswith('rtmp'):
                    res.append(entry)
            elif isinstance(entry, str) and (entry.startswith('http') or entry.startswith('rtmp')):
                res.append(['', entry])
    return res if res else None

def _verify_links_headless(links, engine='alfa', p_dialog=None):
    if not links: return []

    # Separar enlaces torrent de enlaces directos.
    # Los enlaces torrent NUNCA se verifican (no son streaming directo ni usan hosters/resolvers HTTP).
    # Se conservan automáticamente en su posición original como disponibles.
    verified_results = {}
    direct_items_to_test = []

    for idx, lnk in enumerate(links):
        if _is_torrent_link(lnk):
            verified_results[idx] = lnk
        else:
            direct_items_to_test.append((idx, lnk))

    if not direct_items_to_test:
        xbmc.log("Bridge Multi: _verify_links_headless - todos los enlaces son torrents (%d), ninguno a verificar" % len(links), xbmc.LOGINFO)
        return [verified_results[idx] for idx in sorted(verified_results.keys())]

    mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
    if not mods: return links

    servertools = mods['servertools']
    total_to_check = len(direct_items_to_test)
    checked_count = [0]
    finished_indices = set()
    lock = threading.Lock()

    max_workers = _get_int_setting('verify_threads_max', 8)
    verify_timeout = _get_int_setting('verify_timeout', 30)
    if max_workers < 1: max_workers = 1
    if verify_timeout < 3: verify_timeout = 3

    orig_timeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(verify_timeout)

    def _test_worker(orig_idx, lnk):
        # Doble salvaguarda: si es torrent, jamás verificar por red
        if _is_torrent_link(lnk):
            with lock:
                if orig_idx not in finished_indices:
                    finished_indices.add(orig_idx)
                    verified_results[orig_idx] = lnk
                checked_count[0] += 1
            return

        test_item = lnk.clone() if hasattr(lnk, 'clone') else lnk
        video_urls = None
        puedes = False
        try:
            prep = _prepare_playable_link(test_item, engine=engine)
            if not prep: return
            if _is_torrent_link(prep):
                with lock:
                    if orig_idx not in finished_indices:
                        finished_indices.add(orig_idx)
                        verified_results[orig_idx] = prep
                return

            actual_srv = (getattr(prep, 'server', '') or _get_link_server_name(prep)).lower().strip()
            raw_srv = (getattr(prep, 'server', '') or '').lower().strip()
            url = getattr(prep, 'url', '')
            pwd = getattr(prep, 'password', '')

            if not url and not getattr(prep, 'video_urls', None):
                return

            servers_to_try = []
            if actual_srv and actual_srv not in ('directo', 'none', ''): servers_to_try.append(actual_srv)
            if raw_srv and raw_srv not in servers_to_try and raw_srv not in ('directo', 'none', ''): servers_to_try.append(raw_srv)
            if 'various' not in servers_to_try: servers_to_try.append('various')

            if getattr(prep, 'video_urls', None):
                video_urls = prep.video_urls
                puedes = True
            else:
                with silenced_dialogs():
                    for srv_try in servers_to_try:
                        if engine == 'balandro':
                            try:
                                video_urls, puedes, _ = servertools.resolve_video_urls_for_playing(srv_try, url)
                                if puedes and video_urls: break
                            except Exception: pass
                        else:
                            try:
                                video_urls, puedes, _ = servertools.resolve_video_urls_for_playing(srv_try, url, pwd, False)
                                if puedes and video_urls: break
                            except Exception: pass

            if puedes and video_urls:
                valid_streams = _extract_valid_streams(video_urls)
                if valid_streams:
                    prep.video_urls = valid_streams
                    with lock:
                        if orig_idx not in finished_indices:
                            finished_indices.add(orig_idx)
                            verified_results[orig_idx] = prep
        except Exception: pass
        finally:
            with lock:
                if orig_idx not in finished_indices:
                    finished_indices.add(orig_idx)
                checked_count[0] += 1

    threads = []
    for orig_idx, lnk in direct_items_to_test:
        threads.append((orig_idx, threading.Thread(target=_test_worker, args=(orig_idx, lnk), daemon=True)))

    running = []
    i = 0
    try:
        while (i < len(threads) or running) and not xbmc.Monitor().abortRequested():
            if p_dialog and p_dialog.iscanceled(): break
            now = time.time()
            running = [(orig_idx, t, st) for (orig_idx, t, st) in running if t.is_alive() and (now - st < verify_timeout)]

            while i < len(threads) and len(running) < max_workers:
                orig_idx, t = threads[i]
                t.start()
                running.append((orig_idx, t, time.time()))
                i += 1

            with lock: done = checked_count[0]
            if p_dialog:
                pct = int((done / float(total_to_check)) * 100) if total_to_check else 100
                p_dialog.update(pct, 'Verificando servidores... (%d/%d comprobados)' % (done, total_to_check))

            if not running and i >= len(threads): break
            time.sleep(0.1)
    finally:
        socket.setdefaulttimeout(orig_timeout)

    return [verified_results[orig_idx] for orig_idx in sorted(verified_results.keys()) if orig_idx in verified_results]

def _build_bridge_terms(target_title, alt_terms, all_names):
    candidates = []
    seen_raw = set()
    def add_cand(t):
        if not t:
            return
        t_str = _safe_str(t).strip()
        if not t_str:
            return
        low = t_str.lower()
        if low in seen_raw:
            return
        seen_raw.add(low)
        candidates.append(t_str)
    add_cand(target_title)
    if alt_terms:
        for t in alt_terms:
            add_cand(t)
    if all_names:
        for t in all_names:
            add_cand(t)
    terms = []
    seen_clean = set()
    for raw in candidates:
        cleaned = _clean_search_term(raw)
        if cleaned and cleaned.lower() not in seen_clean:
            seen_clean.add(cleaned.lower())
            terms.append(cleaned)
        core_raw = get_core_title(raw)
        if core_raw and core_raw != raw:
            core_clean = _clean_search_term(core_raw)
            if core_clean and core_clean.lower() not in seen_clean:
                seen_clean.add(core_clean.lower())
                terms.append(core_clean)
    return terms[:8]


_tmdb_translations_cache = {}

def _resolve_localized_metadata(tmdb_id=None, is_series=False, season=None, episode=None,
                                 plot_lat='', plot_es='', plot_param='',
                                 tagline_lat='', tagline_es='', tagline_param='',
                                 title_lat='', title_es='', title_param=''):
    """Resuelve de forma independiente la traducción del contenido usando TMDb API /translations.
    Prioridad:
      1. Español (México) (es-MX)
      2. Si no hay es-MX, usar Español (España) (es-ES) para sinopsis, slogan y título
      3. Si no hay es-MX ni es-ES (solo inglés u otro idioma), sinopsis = 'Sinopsis sin traducción'
    """
    tmdb_id_str = str(tmdb_id or '').strip()
    s_val = str(season or '').strip()
    e_val = str(episode or '').strip()
    is_ep = bool(is_series and s_val and e_val and s_val.isdigit() and e_val.isdigit())

    cache_key = f"{tmdb_id_str}_{s_val}_{e_val}" if is_ep else f"{tmdb_id_str}_{1 if is_series else 0}"

    cur_plot = str(plot_param or '').strip()
    cur_tagline = str(tagline_param or '').strip()
    cur_title = str(title_param or '').strip()

    if tmdb_id_str.isdigit() and cache_key in _tmdb_translations_cache:
        return dict(_tmdb_translations_cache[cache_key])

    tmdb_mx_plot = ''
    tmdb_mx_tagline = ''
    tmdb_mx_title = ''
    tmdb_es_plot = ''
    tmdb_es_tagline = ''
    tmdb_es_title = ''
    tmdb_oth_plot = ''
    tmdb_oth_tagline = ''
    tmdb_oth_title = ''
    has_tmdb_data = False

    if tmdb_id_str.isdigit():
        api_key = "a1ab8b8669da03637a4b98fa39c39228"
        import urllib.request as _ureq
        import ssl as _ssl
        import json as _json

        ctx = None
        try:
            ctx = _ssl._create_unverified_context()
        except Exception:
            pass

        urls_to_try = []
        if is_ep:
            urls_to_try.append(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}/season/{s_val}/episode/{e_val}/translations?api_key={api_key}")
            urls_to_try.append(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}/translations?api_key={api_key}")
        elif is_series:
            urls_to_try.append(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}/translations?api_key={api_key}")
        else:
            urls_to_try.append(f"https://api.themoviedb.org/3/movie/{tmdb_id_str}/translations?api_key={api_key}")

        for u in urls_to_try:
            try:
                req = _ureq.Request(u, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
                kw = {'timeout': 3.5}
                if ctx:
                    kw['context'] = ctx
                with _ureq.urlopen(req, **kw) as resp:
                    raw = resp.read().decode('utf-8', errors='ignore')
                    data = _json.loads(raw)
                    translations = data.get('translations', [])
                    if translations:
                        has_tmdb_data = True
                        for t in translations:
                            iso_639 = (t.get('iso_639_1') or '').lower()
                            iso_3166 = (t.get('iso_3166_1') or '').upper()
                            d = t.get('data', {})
                            if iso_639 == 'es':
                                p = (d.get('overview') or '').strip()
                                tg = (d.get('tagline') or '').strip()
                                tt = (d.get('title') or d.get('name') or '').strip()
                                if iso_3166 == 'MX':
                                    if p and not tmdb_mx_plot: tmdb_mx_plot = p
                                    if tg and not tmdb_mx_tagline: tmdb_mx_tagline = tg
                                    if tt and not tmdb_mx_title: tmdb_mx_title = tt
                                elif iso_3166 == 'ES':
                                    if p and not tmdb_es_plot: tmdb_es_plot = p
                                    if tg and not tmdb_es_tagline: tmdb_es_tagline = tg
                                    if tt and not tmdb_es_title: tmdb_es_title = tt
                                else:
                                    if p and not tmdb_oth_plot: tmdb_oth_plot = p
                                    if tg and not tmdb_oth_tagline: tmdb_oth_tagline = tg
                                    if tt and not tmdb_oth_title: tmdb_oth_title = tt
                        # Complementar títulos en _tmdb_titles_cache para búsquedas paralelas
                        all_t = [x for x in [tmdb_mx_title, tmdb_es_title, tmdb_oth_title] if x]
                        if all_t:
                            ck = f"{tmdb_id_str}_{1 if is_series else 0}"
                            if ck not in _tmdb_titles_cache:
                                _tmdb_titles_cache[ck] = []
                            for cand in all_t:
                                if cand not in _tmdb_titles_cache[ck]:
                                    _tmdb_titles_cache[ck].append(cand)
                    if tmdb_mx_plot or tmdb_es_plot:
                        break
            except Exception as e:
                pass

    # Resolver SINOPSIS (plot):
    if tmdb_mx_plot:
        final_plot = tmdb_mx_plot
    elif tmdb_es_plot:
        final_plot = tmdb_es_plot
    elif tmdb_oth_plot:
        final_plot = tmdb_oth_plot
    elif has_tmdb_data:
        final_plot = "Sinopsis sin traducción"
    elif plot_lat and plot_lat.strip():
        final_plot = plot_lat.strip()
    elif plot_es and plot_es.strip():
        final_plot = plot_es.strip()
    elif cur_plot:
        final_plot = cur_plot
    else:
        final_plot = "Sinopsis sin traducción"

    # Resolver SLOGAN (tagline):
    if tmdb_mx_tagline:
        final_tagline = tmdb_mx_tagline
    elif tmdb_es_tagline:
        final_tagline = tmdb_es_tagline
    elif tmdb_oth_tagline:
        final_tagline = tmdb_oth_tagline
    elif has_tmdb_data:
        final_tagline = ''
    elif tagline_lat and tagline_lat.strip():
        final_tagline = tagline_lat.strip()
    elif tagline_es and tagline_es.strip():
        final_tagline = tagline_es.strip()
    elif cur_tagline:
        final_tagline = cur_tagline
    else:
        final_tagline = ''

    # Resolver TÍTULO:
    final_title = cur_title
    if tmdb_mx_title:
        final_title = tmdb_mx_title
    elif tmdb_es_title:
        final_title = tmdb_es_title
    elif tmdb_oth_title:
        final_title = tmdb_oth_title
    elif title_lat and title_lat.strip():
        final_title = title_lat.strip()
    elif title_es and title_es.strip():
        final_title = title_es.strip()

    res = {
        'plot': final_plot,
        'tagline': final_tagline,
        'title': final_title,
        'has_spanish': bool(tmdb_mx_plot or tmdb_es_plot or tmdb_oth_plot)
    }
    if tmdb_id_str.isdigit():
        _tmdb_translations_cache[cache_key] = res

    try:
        xbmc.log(f"Bridge Multi: traducción resuelta (tmdb={tmdb_id_str}): plot={final_plot[:50]}... tagline={final_tagline} title={final_title}", xbmc.LOGINFO)
    except Exception:
        pass

    return res


_tmdb_titles_cache = {}

def _fetch_tmdb_titles(tmdb_id, is_series=False):
    # Cache + 2 idiomas + paralelo + timeout corto (3s) para no retrasar inicio
    titles = []
    if not tmdb_id:
        return titles
    tmdb_id_str = str(tmdb_id).strip()
    if not tmdb_id_str.isdigit():
        return titles
    cache_key = f"{tmdb_id_str}_{1 if is_series else 0}"
    if cache_key in _tmdb_titles_cache:
        return list(_tmdb_titles_cache[cache_key])
    try:
        api_key = "a1ab8b8669da03637a4b98fa39c39228"
        tmdb_type = "tv" if is_series else "movie"
        import json as _json
        import urllib.request as _ureq
        langs = ["es-MX", "es-ES"]  # 2 requests paralelos son suficientes (en ya viene como original_title)
        results = {}
        def _fetch_lang(lang):
            try:
                url = f"https://api.themoviedb.org/3/{tmdb_type}/{tmdb_id_str}?api_key={api_key}&language={lang}"
                # Intento rapido con urllib (3s) sin pasar por httptools para no bloquear lock
                try:
                    with _ureq.urlopen(url, timeout=3) as resp2:
                        raw = resp2.read().decode('utf-8', errors='ignore')
                        data = _json.loads(raw)
                        if data:
                            t = data.get('title') or data.get('name') or ""
                            o = data.get('original_title') or data.get('original_name') or ""
                            results[lang] = [x for x in [t, o] if x]
                except Exception as e:
                    results[lang] = []
            except Exception as e:
                results[lang] = []
        # Paralelo
        import threading
        threads = []
        for lang in langs:
            th = threading.Thread(target=_fetch_lang, args=(lang,), daemon=True)
            th.start()
            threads.append(th)
        for th in threads:
            th.join(timeout=3.5)
        for lang in langs:
            for cand in results.get(lang, []):
                if cand and cand not in titles:
                    titles.append(cand)
        # Fallback: si no hay nada, intentar en si el original_title ya esta en otro idioma via una sola peticion extra en
        # pero con lo anterior es suficiente
        if not titles:
            # Intento unico con en por si es pelicula sin traduccion es
            try:
                url = f"https://api.themoviedb.org/3/{tmdb_type}/{tmdb_id_str}?api_key={api_key}&language=en"
                with _ureq.urlopen(url, timeout=3) as resp2:
                    raw = resp2.read().decode('utf-8', errors='ignore')
                    data = _json.loads(raw)
                    if data:
                        t = data.get('title') or data.get('name') or ""
                        if t and t not in titles:
                            titles.append(t)
            except:
                pass
        # Cache
        uniq = []
        seen = set()
        for t in titles:
            if not t:
                continue
            low = t.lower().strip()
            if low in seen:
                continue
            seen.add(low)
            uniq.append(t)
        _tmdb_titles_cache[cache_key] = list(uniq)
        return uniq
    except Exception as e:
        try:
            xbmc.log(f"Bridge Multi: _fetch_tmdb_titles error: {e}", xbmc.LOGINFO)
        except:
            pass
        return []
        return []


def _enrich_with_tmdb(results, engine):
    # Desactivado intencionalmente: busquedas a ciegas en TMDb sobre resultados de canales
    # sin contexto de destino sobreescriben items con metadatos de peliculas equivocadas
    # (ej. 'El Origen' -> TMDb ID 8355 'Ice Age 3: El origen de los dinosaurios'),
    # generan alta latencia y contaminan la lista.
    # Los metadatos canonicos de TMDb Helper (meta) se aplican de forma fidedigna.
    return

# ---------------------------------------------------------
# ---------------------------------------------------------
# Search Implementation: Alfa Engine & Balandro Engine
# ---------------------------------------------------------
def _search_planb(target_title, target_year, is_series, s_num, e_num, all_names, target_tmdb=None, target_imdb=None):
    # PlanB: intentar con cada variante de titulo (por si vitaminar depende del titulo) y con tmdb/imdb
    try:
        mods = _get_alfa_modules()
        if not mods:
            return None, None
        Item = mods['Item']
        planb = None
        with _engine_lock:
            _switch_engine_environment('alfa')
            try:
                from lib import planb_py3 as planb
            except Exception:
                try:
                    from lib import planb
                except Exception:
                    planb = None
        if not planb:
            return None, None
        try:
            alt_for_planb = [t for t in (all_names or []) if t and t != target_title]
            terms_for_planb = _build_bridge_terms(target_title, alt_for_planb, all_names)
            if not terms_for_planb:
                terms_for_planb = [_clean_search_term(target_title) or target_title]
        except:
            terms_for_planb = [target_title]
        for try_title in terms_for_planb:
            it_vit = Item(
                channel='PlanB',
                action='vitaminar',
                contentType='episode' if is_series else 'movie',
                contentTitle=try_title,
                infoLabels={
                    'tmdb_id': str(target_tmdb or ''),
                    'imdb_id': str(target_imdb or ''),
                    'year': str(target_year or ''),
                    'title': try_title,
                    'mediatype': 'episode' if is_series else 'movie'
                }
            )
            if is_series:
                try:
                    it_vit.contentSeason = int(s_num or 1)
                except:
                    pass
                try:
                    it_vit.contentEpisodeNumber = int(e_num or 1)
                except:
                    pass
                try:
                    it_vit.infoLabels['season'] = int(s_num or 1)
                except:
                    pass
                try:
                    it_vit.infoLabels['episode'] = int(e_num or 1)
                except:
                    pass
                it_vit.infoLabels['tvshowtitle'] = try_title
            raw_links = []
            with silenced_dialogs():
                if hasattr(planb, 'vitaminar'):
                    try:
                        raw_links = planb.vitaminar(it_vit) or []
                    except Exception as e:
                        xbmc.log("Bridge Multi: PlanB vitaminar error title '%s': %s" % (try_title, str(e)), xbmc.LOGINFO)
                if not raw_links and hasattr(planb, 'findvideos'):
                    try:
                        raw_links = planb.findvideos(it_vit) or []
                    except Exception as e:
                        xbmc.log("Bridge Multi: PlanB findvideos error title '%s': %s" % (try_title, str(e)), xbmc.LOGINFO)
            if raw_links and isinstance(raw_links, list):
                valid_links = []
                for l in raw_links:
                    if getattr(l, 'action', '') == 'play' or getattr(l, 'server', '') or getattr(l, 'url', ''):
                        l.channel = 'PlanB'
                        l.is_vitamina = True
                        l.bridge_engine = 'alfa'
                        valid_links.append(l)
                if valid_links:
                    xbmc.log("Bridge Multi: PlanB encontro %d enlaces para '%s' (try_title='%s')" % (len(valid_links), target_title, try_title), xbmc.LOGINFO)
                    return it_vit, valid_links
            xbmc.log("Bridge Multi: PlanB sin enlaces para try_title='%s'" % try_title, xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("Bridge Multi: PlanB search error: " + str(e), xbmc.LOGWARNING)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGINFO)
    return None, None

def _search_channel_alfa(channel_id, target_title, target_year, is_series, s_num, e_num, all_names, base_item=None, alt_terms=None, target_tmdb=None, target_imdb=None):
    if str(channel_id).lower() in ('planb', 'plan_b'):
        return _search_planb(target_title, target_year, is_series, s_num, e_num, all_names, target_tmdb=target_tmdb, target_imdb=target_imdb)
    mods = _get_alfa_modules()
    if not mods:
        return None, None
    Item = mods['Item']
    terms_to_try = _build_bridge_terms(target_title, alt_terms, all_names)
    if not terms_to_try:
        cleaned = _clean_search_term(target_title)
        if cleaned:
            terms_to_try = [cleaned]
        else:
            return None, None
    xbmc.log("Bridge Multi: %s terms_to_try=%s" % (channel_id, terms_to_try), xbmc.LOGINFO)
    for cur_term in terms_to_try:
        if xbmc.Monitor().abortRequested():
            break
        results = []
        canal = None
        search_actions = []
        with _engine_lock:
            try:
                _switch_engine_environment('alfa')
                canal = __import__('channels.' + channel_id, fromlist=[''])
                try:
                    if hasattr(canal, 'canonical') and isinstance(canal.canonical, dict):
                        canal.canonical['global_search_active'] = True
                except:
                    pass
                try:
                    with silenced_dialogs():
                        mainlist_items = canal.mainlist(Item(channel=channel_id)) if hasattr(canal, 'mainlist') else []
                        search_actions = [elem for elem in (mainlist_items or []) if getattr(elem, 'action', '') == 'search']
                except Exception as e:
                    xbmc.log("Bridge Multi: %s mainlist error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    search_actions = []
            except Exception as e:
                xbmc.log("Bridge Multi: %s import error term '%s': %s" % (channel_id, cur_term, str(e)), xbmc.LOGINFO)
                continue
        with silenced_dialogs():
            if search_actions:
                for s_act in search_actions:
                    try:
                        res = canal.search(s_act, cur_term)
                        if isinstance(res, list) and res:
                            results.extend(res)
                    except TypeError:
                        try:
                            res = canal.search(s_act, cur_term, 'tvshow' if is_series else 'movie')
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e2:
                            xbmc.log("Bridge Multi: %s search(s_act) TypeError fallback failed: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log("Bridge Multi: %s search(s_act) error term '%s': %s" % (channel_id, cur_term, str(e)), xbmc.LOGINFO)
            else:
                try:
                    if base_item and hasattr(base_item, 'clone'):
                        try:
                            it_search = base_item.clone()
                        except:
                            it_search = Item(channel=channel_id)
                    else:
                        it_search = Item(channel=channel_id)
                    it_search.channel = channel_id
                    it_search.buscando = cur_term
                    it_search.text = cur_term
                    it_search.terms = cur_term
                    it_search.term = cur_term
                    it_search.c_type = 'search'
                    it_search.search_type = 'tvshow' if is_series else 'movie'
                    if not hasattr(it_search, 'infoLabels') or not isinstance(getattr(it_search, 'infoLabels', None), dict):
                        it_search.infoLabels = {}
                    if target_tmdb:
                        it_search.infoLabels['tmdb_id'] = str(target_tmdb)
                    if target_imdb:
                        it_search.infoLabels['imdb_id'] = str(target_imdb)
                    if target_year:
                        it_search.infoLabels['year'] = str(target_year)
                    if is_series:
                        it_search.contentSerieName = cur_term
                        it_search.contentType = 'tvshow'
                    else:
                        it_search.contentTitle = cur_term
                        it_search.contentType = 'movie'
                    ch_host = None
                    try:
                        if hasattr(canal, 'canonical') and isinstance(canal.canonical, dict):
                            alt = canal.canonical.get('host_alt', [])
                            if alt and isinstance(alt, list) and alt and alt[0].startswith('http'):
                                ch_host = alt[0]
                        if not ch_host and hasattr(canal, 'host') and getattr(canal, 'host', '') and str(canal.host).startswith('http'):
                            ch_host = str(canal.host)
                    except:
                        pass
                    if not getattr(it_search, 'url', '') or not str(it_search.url).startswith('http'):
                        if ch_host:
                            it_search.url = ch_host
                    if hasattr(canal, 'search'):
                        try:
                            res = canal.search(it_search, cur_term)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except TypeError:
                            try:
                                res = canal.search(it_search, cur_term, 'tvshow' if is_series else 'movie')
                                if isinstance(res, list) and res:
                                    results.extend(res)
                            except Exception as e2:
                                xbmc.log("Bridge Multi: %s fallback TypeError2: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log("Bridge Multi: %s fallback search error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    elif hasattr(canal, 'list_all'):
                        try:
                            res = canal.list_all(it_search)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e:
                            xbmc.log("Bridge Multi: %s list_all fallback error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Bridge Multi: %s fallback construction error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
        if not results:
            xbmc.log("Bridge Multi: %s sin resultados para '%s'" % (channel_id, cur_term), xbmc.LOGINFO)
            continue
        xbmc.log("Bridge Multi: %s obtuvo %d resultados para '%s'" % (channel_id, len(results), cur_term), xbmc.LOGINFO)
        _enrich_with_tmdb(results, 'alfa')
        candidates = []
        for it in results:
            title_check = getattr(it, 'title', '') or getattr(it, 'contentTitle', '') or getattr(it, 'contentSerieName', '')
            if not title_check:
                continue
            # Filtrar items de paginacion / siguiente pagina que contaminan resultados (ej. CineCalidad)
            _low_title = _safe_str(title_check).lower()
            if 'pagina siguiente' in _low_title or ('siguiente' in _low_title and '>>' in _low_title) or _low_title.strip().startswith('>>'):
                xbmc.log(f"Bridge Multi: {channel_id} skip pagination '{title_check}'", xbmc.LOGINFO)
                continue
            score = score_match(title_check, target_year, all_names, target_tmdb=target_tmdb, item=it, target_imdb=target_imdb, is_series=is_series)
            if score <= 0:
                continue
            candidates.append((score, it, title_check))

        candidates.sort(key=lambda c: c[0], reverse=True)

        for score, it, title_check in candidates:
            xbmc.log("Bridge Multi: %s MATCH (score=%d) '%s' para term '%s' (target_year=%s tmdb=%s)" % (channel_id, score, title_check, cur_term, target_year, target_tmdb), xbmc.LOGINFO)
            if is_series and hasattr(canal, 'episodios'):
                try:
                    ep_list = canal.episodios(it)
                    if not ep_list:
                        xbmc.log("Bridge Multi: %s episodios vacio para '%s'" % (channel_id, title_check), xbmc.LOGINFO)
                    for ep in (ep_list or []):
                        ep_season = int(getattr(ep, 'contentSeason', 0) or getattr(ep, 'infoLabels', {}).get('season', 0) or getattr(ep, 'season', 0) or 0)
                        ep_episode = int(getattr(ep, 'contentEpisodeNumber', 0) or getattr(ep, 'infoLabels', {}).get('episode', 0) or getattr(ep, 'episode', 0) or 0)
                        if ep_season == int(s_num or 1) and ep_episode == int(e_num or 1):
                            links = None
                            try:
                                links = canal.findvideos(ep) if hasattr(canal, 'findvideos') else None
                            except Exception as e:
                                xbmc.log("Bridge Multi: %s findvideos(ep) error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                            if links and isinstance(links, list) and len(links) > 0:
                                valid = [l for l in links if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                                if valid:
                                    for l in valid:
                                        l.channel = channel_id
                                        l.bridge_engine = 'alfa'
                                    xbmc.log("Bridge Multi: %s OK serie %dx%d %d enlaces" % (channel_id, ep_season, ep_episode, len(valid)), xbmc.LOGINFO)
                                    return ep, valid
                                else:
                                    xbmc.log("Bridge Multi: %s findvideos(ep) sin enlaces validos" % channel_id, xbmc.LOGINFO)
                            else:
                                xbmc.log("Bridge Multi: %s findvideos(ep) vacio" % channel_id, xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Bridge Multi: %s episodios exception: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    import traceback
                    xbmc.log(traceback.format_exc(), xbmc.LOGINFO)
            elif hasattr(canal, 'findvideos'):
                try:
                    links = canal.findvideos(it)
                    if links and isinstance(links, list) and len(links) > 0:
                        valid = [l for l in links if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                        if valid:
                            for l in valid:
                                l.channel = channel_id
                                l.bridge_engine = 'alfa'
                            xbmc.log("Bridge Multi: %s OK peli %d enlaces para '%s'" % (channel_id, len(valid), title_check), xbmc.LOGINFO)
                            return it, valid
                        else:
                            xbmc.log("Bridge Multi: %s findvideos sin enlaces validos para '%s'" % (channel_id, title_check), xbmc.LOGINFO)
                    else:
                        xbmc.log("Bridge Multi: %s findvideos vacio para '%s'" % (channel_id, title_check), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Bridge Multi: %s findvideos error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    import traceback
                    xbmc.log(traceback.format_exc(), xbmc.LOGINFO)
    return None, None

def _search_channel_balandro(channel_id, target_title, target_year, is_series, s_num, e_num, all_names, base_item=None, alt_terms=None, target_tmdb=None, target_imdb=None):
    mods = _get_balandro_modules()
    if not mods:
        return None, None
    Item = mods['Item']
    terms_to_try = _build_bridge_terms(target_title, alt_terms, all_names)
    if not terms_to_try:
        cleaned = _clean_search_term(target_title)
        if cleaned:
            terms_to_try = [cleaned]
        else:
            return None, None
    xbmc.log("Bridge Multi [Balandro]: %s terms_to_try=%s" % (channel_id, terms_to_try), xbmc.LOGINFO)
    for cur_term in terms_to_try:
        if xbmc.Monitor().abortRequested():
            break
        results = []
        canal = None
        search_actions = []
        with _engine_lock:
            try:
                _switch_engine_environment('balandro')
                canal = __import__('channels.' + channel_id, fromlist=[''])
                try:
                    if hasattr(canal, 'canonical') and isinstance(canal.canonical, dict):
                        canal.canonical['global_search_active'] = True
                except:
                    pass
                try:
                    with silenced_dialogs():
                        mainlist_items = canal.mainlist(Item(channel=channel_id)) if hasattr(canal, 'mainlist') else []
                        search_actions = [elem for elem in (mainlist_items or []) if getattr(elem, 'action', '') == 'search']
                except Exception as e:
                    xbmc.log("Bridge Multi [Balandro]: %s mainlist error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    search_actions = []
            except Exception as e:
                xbmc.log("Bridge Multi [Balandro]: %s import error term '%s': %s" % (channel_id, cur_term, str(e)), xbmc.LOGINFO)
                continue
        with silenced_dialogs():
            if search_actions:
                for s_act in search_actions:
                    try:
                        res = canal.search(s_act, cur_term)
                        if isinstance(res, list) and res:
                            results.extend(res)
                    except TypeError:
                        try:
                            res = canal.search(s_act, cur_term, 'tvshow' if is_series else 'movie')
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e2:
                            xbmc.log("Bridge Multi [Balandro]: %s search TypeError fallback: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log("Bridge Multi [Balandro]: %s search error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
            else:
                try:
                    if base_item and hasattr(base_item, 'clone'):
                        try:
                            it_search = base_item.clone()
                        except:
                            it_search = Item(channel=channel_id)
                    else:
                        it_search = Item(channel=channel_id)
                    it_search.channel = channel_id
                    it_search.buscando = cur_term
                    it_search.text = cur_term
                    it_search.terms = cur_term
                    it_search.term = cur_term
                    it_search.c_type = 'search'
                    it_search.search_type = 'tvshow' if is_series else 'movie'
                    if not hasattr(it_search, 'infoLabels') or not isinstance(getattr(it_search, 'infoLabels', None), dict):
                        it_search.infoLabels = {}
                    if target_tmdb:
                        it_search.infoLabels['tmdb_id'] = str(target_tmdb)
                    if target_imdb:
                        it_search.infoLabels['imdb_id'] = str(target_imdb)
                    if target_year:
                        it_search.infoLabels['year'] = str(target_year)
                    if is_series:
                        it_search.contentSerieName = cur_term
                        it_search.contentType = 'tvshow'
                    else:
                        it_search.contentTitle = cur_term
                        it_search.contentType = 'movie'
                    ch_host = None
                    try:
                        if hasattr(canal, 'host') and getattr(canal, 'host', '') and str(canal.host).startswith('http'):
                            ch_host = str(canal.host)
                    except:
                        pass
                    if not getattr(it_search, 'url', '') or not str(it_search.url).startswith('http'):
                        if ch_host:
                            it_search.url = ch_host
                    if hasattr(canal, 'search'):
                        try:
                            res = canal.search(it_search, cur_term)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except TypeError:
                            try:
                                res = canal.search(it_search, cur_term, 'tvshow' if is_series else 'movie')
                                if isinstance(res, list) and res:
                                    results.extend(res)
                            except Exception as e2:
                                xbmc.log("Bridge Multi [Balandro]: %s fallback TypeError2: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log("Bridge Multi [Balandro]: %s fallback error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    elif hasattr(canal, 'list_all'):
                        try:
                            res = canal.list_all(it_search)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e:
                            xbmc.log("Bridge Multi [Balandro]: %s list_all error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Bridge Multi [Balandro]: %s fallback construction error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
        if not results:
            xbmc.log("Bridge Multi [Balandro]: %s sin resultados para '%s'" % (channel_id, cur_term), xbmc.LOGINFO)
            continue
        xbmc.log("Bridge Multi [Balandro]: %s obtuvo %d resultados para '%s'" % (channel_id, len(results), cur_term), xbmc.LOGINFO)
        _debug_nomatch_count = 0
        _enrich_with_tmdb(results, 'balandro')
        candidates = []
        for it in results:
            title_check = getattr(it, 'title', '') or getattr(it, 'contentTitle', '') or getattr(it, 'contentSerieName', '')
            if not title_check:
                continue
            # Filtrar items de paginacion / siguiente pagina que contaminan resultados (ej. CineCalidad)
            _low_title = _safe_str(title_check).lower()
            if 'pagina siguiente' in _low_title or ('siguiente' in _low_title and '>>' in _low_title) or _low_title.strip().startswith('>>'):
                xbmc.log(f"Bridge Multi: {channel_id} skip pagination '{title_check}'", xbmc.LOGINFO)
                continue
            score = score_match(title_check, target_year, all_names, target_tmdb=target_tmdb, item=it, target_imdb=target_imdb, is_series=is_series)
            if score <= 0:
                if _debug_nomatch_count < 5:
                    _item_yr = _get_item_year(it, title_check)
                    _item_tmdb = _get_item_tmdb(it)
                    xbmc.log("Bridge Multi [Balandro]: %s NO match '%s' yr=%s tmdb=%s" % (channel_id, title_check, _item_yr, _item_tmdb), xbmc.LOGINFO)
                    _debug_nomatch_count += 1
                continue
            candidates.append((score, it, title_check))

        candidates.sort(key=lambda c: c[0], reverse=True)

        for score, it, title_check in candidates:
            xbmc.log("Bridge Multi [Balandro]: %s MATCH (score=%d) '%s' para term '%s'" % (channel_id, score, title_check, cur_term), xbmc.LOGINFO)
            if is_series:
                _target_s = int(s_num or 1)
                _target_e = int(e_num or 1)
                _found_ep = False

                def _ep_nums(ep):
                    """Extrae (season, episode) de un item episodio de Balandro."""
                    s = int(getattr(ep, 'contentSeason', 0) or
                            getattr(ep, 'infoLabels', {}).get('season', 0) or 0)
                    e = int(getattr(ep, 'contentEpisodeNumber', 0) or
                            getattr(ep, 'infoLabels', {}).get('episode', 0) or 0)
                    return s, e

                def _try_ep_list(ep_list):
                    """Busca TODOS los items del episodio correcto (distintos idiomas) y devuelve todos sus links."""
                    _all_valid = []
                    _any_ep = None
                    for ep in (ep_list or []):
                        ep_s, ep_e = _ep_nums(ep)
                        if ep_s == _target_s and ep_e == _target_e:
                            _lk = None
                            try:
                                with silenced_dialogs():
                                    _lk = canal.findvideos(ep) if hasattr(canal, 'findvideos') else None
                            except Exception as _fe:
                                xbmc.log('Bridge Multi [Balandro]: %s findvideos error: %s' % (channel_id, _fe), xbmc.LOGINFO)
                            if _lk and isinstance(_lk, list):
                                valid = [l for l in _lk if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                                if valid:
                                    for l in valid: l.channel = channel_id; l.bridge_engine = 'balandro'
                                    _all_valid.extend(valid)
                                    if _any_ep is None:
                                        _any_ep = ep
                    if _all_valid:
                        xbmc.log('Bridge Multi [Balandro]: %s OK serie %sx%s %d enlaces' % (channel_id, _target_s, _target_e, len(_all_valid)), xbmc.LOGINFO)
                        return _any_ep, _all_valid
                    return None, None

                # Patrón estándar Balandro: temporadas() → episodios(season_item)
                if hasattr(canal, 'temporadas') and hasattr(canal, 'episodios'):
                    try:
                        xbmc.log('Bridge Multi [Balandro]: %s show_url=%s' % (channel_id, getattr(it, 'url', '?')[:80]), xbmc.LOGINFO)
                        with silenced_dialogs():
                            seasons = canal.temporadas(it)

                        xbmc.log('Bridge Multi [Balandro]: %s temporadas() -> %d items' % (channel_id, len(seasons) if seasons else 0), xbmc.LOGINFO)
                        if not seasons:
                            pass
                        else:
                            # Detectar si temporadas() ya devolvio episodios directamente
                            # (ocurre en series de 1 sola temporada en hdfull y otros canales)
                            _first = seasons[0]
                            _is_ep_list = (
                                int(getattr(_first, 'contentEpisodeNumber', 0) or 0) > 0 or
                                getattr(_first, 'contentType', '') == 'episode' or
                                getattr(_first, 'action', '') not in ('episodios', 'temporadas', '')
                            )

                            if _is_ep_list:
                                # temporadas() devolvio episodios directamente (1 temporada)
                                xbmc.log('Bridge Multi [Balandro]: %s temporadas devolvio %d eps directo' % (channel_id, len(seasons)), xbmc.LOGINFO)
                                _rep_ep, _rep_lk = _try_ep_list(seasons)
                                if _rep_lk:
                                    return _rep_ep, _rep_lk
                                _found_ep = True
                            else:
                                # Lista de temporadas — buscar la correcta
                                sea_item = None
                                for sea in seasons:
                                    sea_num = int(getattr(sea, 'contentSeason', 0) or
                                                  getattr(sea, 'infoLabels', {}).get('season', 0) or 0)
                                    if sea_num == _target_s:
                                        sea_item = sea
                                        break
                                if sea_item is None:
                                    sea_item = seasons[0]  # fallback a primera temporada
                                xbmc.log('Bridge Multi [Balandro]: %s usando temporada %s' % (channel_id, getattr(sea_item, 'contentSeason', '?')), xbmc.LOGINFO)
                                if target_tmdb:
                                    sea_item.tmdb_id = str(target_tmdb)
                                    if not hasattr(sea_item, 'infoLabels') or not isinstance(sea_item.infoLabels, dict):
                                        sea_item.infoLabels = {}
                                    sea_item.infoLabels['tmdb_id'] = str(target_tmdb)
                                with silenced_dialogs():
                                    ep_list = canal.episodios(sea_item)
                                _rep_ep, _rep_lk = _try_ep_list(ep_list)
                                if _rep_lk:
                                    return _rep_ep, _rep_lk
                                if ep_list:
                                    _found_ep = True
                    except Exception as e:
                        xbmc.log('Bridge Multi [Balandro]: %s temporadas/episodios error: %s' % (channel_id, str(e)), xbmc.LOGINFO)

                # Fallback: intentar episodios() directo en el show (algunos canales lo soportan)
                if not _found_ep and hasattr(canal, 'episodios'):
                    try:
                        _it_fallback = it.clone() if hasattr(it, 'clone') else it
                        _it_fallback.contentSeason = _target_s  # inyectar temporada para canales como homecine
                        if target_tmdb:
                            _it_fallback.tmdb_id = str(target_tmdb)
                            if not hasattr(_it_fallback, 'infoLabels') or not isinstance(_it_fallback.infoLabels, dict):
                                _it_fallback.infoLabels = {}
                            _it_fallback.infoLabels['tmdb_id'] = str(target_tmdb)
                        with silenced_dialogs():
                            ep_list = canal.episodios(_it_fallback)
                        xbmc.log('Bridge Multi [Balandro]: %s episodios fallback(s=%s) -> %d items' % (channel_id, _target_s, len(ep_list) if ep_list else 0), xbmc.LOGINFO)
                        _rep_ep, _rep_lk = _try_ep_list(ep_list)
                        if _rep_lk:
                            return _rep_ep, _rep_lk
                    except Exception as e:
                        xbmc.log('Bridge Multi [Balandro]: %s episodios directo error: %s' % (channel_id, str(e)), xbmc.LOGINFO)

            elif hasattr(canal, 'findvideos'):
                try:
                    links = canal.findvideos(it)
                    if links and isinstance(links, list) and len(links) > 0:
                        valid = [l for l in links if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                        if valid:
                            for l in valid:
                                l.channel = channel_id
                                l.bridge_engine = 'balandro'
                            return it, valid
                except Exception as e:
                    xbmc.log("Bridge Multi [Balandro]: %s findvideos error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
    return None, None

def _search_on_player(player_file, engine, is_series, target_title, target_year, s_num, e_num, all_names, alt_terms=None, target_tmdb=None, target_imdb=None):
    fpath = os.path.join(TMDB_PLAYERS_PATH, player_file)
    try:
        with open(fpath, 'r', encoding='utf-8') as f: data = json.load(f)
        key = 'play_episode' if is_series else 'play_movie'
        url_list = data.get(key, [])
        if not url_list or not isinstance(url_list, list): return None, None
        url_str = url_list[0]
        mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
        if not mods: return None, None
        ItemClass = mods['Item']
        search_item = None
        target_channel = ''
        if 'plugin://plugin.video.alfa/?' in url_str:
            raw_b64 = url_str.split('plugin://plugin.video.alfa/?')[1].split('&')[0]
            raw_b64 = uparse.unquote(raw_b64)
            search_item = decode_base64_item(raw_b64, ItemClass)
            target_channel = getattr(search_item, 'channel', '')
        elif 'plugin://plugin.video.balandro/?' in url_str:
            raw_b64 = url_str.split('plugin://plugin.video.balandro/?')[1].split('&')[0]
            raw_b64 = uparse.unquote(raw_b64)
            search_item = decode_base64_item(raw_b64, ItemClass)
            target_channel = getattr(search_item, 'channel', '')
        else:
            clean_fn = player_file.replace('.json', '')
            clean_fn = re.sub(r'^(Alfa|Balandro)-', '', clean_fn, flags=re.IGNORECASE)
            target_channel = re.sub(r'-(Series|Movies?)$', '', clean_fn, flags=re.IGNORECASE).lower()

        if not target_channel or target_channel == 'search': return None, None

        p_engine = 'alfa' if player_file.lower().startswith('alfa-') else ('balandro' if player_file.lower().startswith('balandro-') else engine)
        if p_engine == 'alfa':
            res_it, res_links = _search_channel_alfa(target_channel, target_title, target_year, is_series, s_num, e_num, all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
            if res_links:
                for l in res_links: l.bridge_engine = 'alfa'
            return res_it, res_links
        else:
            res_it, res_links = _search_channel_balandro(target_channel, target_title, target_year, is_series, s_num, e_num, all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
            if res_links:
                for l in res_links: l.bridge_engine = 'balandro'
            return res_it, res_links
    except Exception:
        return None, None

# ---------------------------------------------------------
# Master Parallel Search Execution
# ---------------------------------------------------------
def run_parallel_search(engine='alfa'):
    p_title = title or get_param('title') or get_param('title_es') or get_param('title_lat') or get_param('title_orig') or get_param('title_en') or ''
    p_showname = showname or get_param('showname') or ''
    p_year = year or get_param('year') or ''
    p_showyear = showyear or get_param('showyear') or ''
    p_season = season or get_param('season') or ''
    p_episode = episode or get_param('episode') or ''
    p_tmdb = tmdb_id or get_param('tmdb') or ''
    p_imdb = imdb_id or get_param('imdb') or ''

    is_series = bool(p_season and p_episode)
    if is_series and engine == 'alfa':
        xbmc.log("Bridge Multi: Alfa solo soporta películas. Cambiando motor a Balandro para series.", xbmc.LOGINFO)
        engine = 'balandro'
    target_title = (p_showname if is_series else p_title) or ''
    target_year = p_showyear if is_series else p_year
    target_tmdb = p_tmdb
    target_imdb = p_imdb
    all_names = [t for t in [target_title, p_title, title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_en or get_param('title_en'), title_orig or get_param('title_orig'), p_showname] if t]
    alt_terms = [t for t in [title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_orig or get_param('title_orig'), title_en or get_param('title_en'), p_showname, p_title] if t and t != target_title]

    enabled_players = []
    prefix = 'Alfa-' if engine == 'alfa' else 'Balandro-'
    if os.path.exists(TMDB_PLAYERS_PATH):
        for fname in sorted(os.listdir(TMDB_PLAYERS_PATH)):
            if not fname.endswith('.json') or fname.startswith('(1)MultiBusqueda') or fname.startswith('(1)AlfaMulti') or fname.startswith('(1)BalandroMulti'):
                continue
            if not fname.lower().startswith(prefix.lower()):
                continue
            fpath = os.path.join(TMDB_PLAYERS_PATH, fname)
            try:
                with open(fpath, 'r', encoding='utf-8') as f: data = json.load(f)
                if str(data.get('disabled', '')).lower() in ('true', '1') or data.get('disabled') is True:
                    continue
                if is_series and 'play_episode' not in data: continue
                if not is_series and 'play_movie' not in data: continue
                enabled_players.append(fname)
            except: pass

    if not enabled_players: return [], None

    timeout_secs = max(10, _get_int_setting('search_timeout', 40))
    # Series requieren navegar temporada->episodio->links: toman el doble de tiempo que pelicula
    if is_series:
        timeout_secs = timeout_secs * 2
        xbmc.log('Bridge Multi: modo serie, timeout extendido a %ds' % timeout_secs, xbmc.LOGINFO)
    max_search_workers = max(1, _get_int_setting('search_threads_max', 25))

    total_channels = len(enabled_players)
    engine_name = 'Alfa' if engine == 'alfa' else 'Balandro'
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('Bridge Multi (%s)' % engine_name, 'Preparando busqueda en %d canales...' % total_channels)
    # Complementar titulos solo si faltan variantes (cache + 2 peticiones paralelas 3s) - ya con dialogo visible
    try:
        _distinct = len(set([_safe_str(x).lower().strip() for x in all_names if x]))
        if target_tmdb and _distinct < 3:
            p_dialog.update(5, 'Obteniendo titulos TMDB...')
            fetched = _fetch_tmdb_titles(target_tmdb, is_series)
            xbmc.log(f"Bridge Multi: fetched TMDB titles for {target_tmdb}: {fetched}", xbmc.LOGINFO)
            for ft in fetched:
                if ft and ft not in all_names:
                    all_names.append(ft)
                if ft and ft != target_title and ft not in alt_terms:
                    alt_terms.append(ft)
            xbmc.log(f"Bridge Multi: run_parallel_search target_title='{target_title}' all_names={all_names} alt_terms={alt_terms}", xbmc.LOGINFO)
        else:
            xbmc.log(f"Bridge Multi: run_parallel_search (sin fetch) target_title='{target_title}' all_names={all_names} alt_terms={alt_terms}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Bridge Multi: fetch titles error: {e}", xbmc.LOGINFO)
    p_dialog.update(0, 'Buscando en tus %d canales de %s...' % (total_channels, engine_name))

    # Pre-importar canales secuencialmente para evitar contencion de lock al inicio (acelera arranque)
    try:
        p_dialog.update(2, 'Preparando canales...')
        for _pf in enabled_players:
            try:
                _ch = re.sub(r'^(Alfa|Balandro)-', '', _pf.replace('.json',''), flags=re.IGNORECASE)
                _ch = re.sub(r'-(Series|Movies?)$', '', _ch, flags=re.IGNORECASE).lower()
                if not _ch or _ch == 'search':
                    continue
                with _engine_lock:
                    _switch_engine_environment(engine)
                    __import__('channels.' + _ch, fromlist=[''])
            except:
                pass
            if xbmc.Monitor().abortRequested() or p_dialog.iscanceled():
                break
        xbmc.log(f"Bridge Multi: pre-import completado para {len(enabled_players)} canales", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Bridge Multi: pre-import error: {e}", xbmc.LOGINFO)

    results_dict = {}
    threads = []
    def _worker(pf):
        try:
            it, links = _search_on_player(pf, engine, is_series, target_title, target_year, p_season, p_episode, all_names, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
            if it and links: results_dict[pf] = (it, links)
        except Exception: pass

    for pf in enabled_players:
        threads.append(threading.Thread(target=_worker, args=(pf,), daemon=True))

    started_indices = set()
    completed_indices = set()
    finished_channels = []

    def clean_name(pf):
        n = pf.replace('.json', '')
        n = re.sub(r'^(Alfa|Balandro)-', '', n, flags=re.IGNORECASE)
        return re.sub(r'-(Series|Movies?)$', '', n, flags=re.IGNORECASE).strip()

    start_time = time.time()
    thread_start_times = {}
    channel_timeout = timeout_secs
    i = 0
    while not xbmc.Monitor().abortRequested():
        now = time.time()
        active_cnt = len([idx for idx in started_indices if idx not in completed_indices and threads[idx].is_alive()])
        while i < len(threads) and active_cnt < max_search_workers:
            threads[i].start()
            started_indices.add(i)
            thread_start_times[i] = now
            active_cnt += 1
            i += 1

        for idx, pf in enumerate(enabled_players):
            if idx in started_indices and idx not in completed_indices:
                st = thread_start_times.get(idx, start_time)
                is_alive = threads[idx].is_alive()
                if not is_alive or (now - st > channel_timeout):
                    completed_indices.add(idx)
                    found = pf in results_dict
                    finished_channels.append((clean_name(pf), found))

        completed = len(completed_indices)
        pct = int((completed / float(total_channels)) * 100) if total_channels else 100
        lines = []
        recent = finished_channels[-4:]
        for ch_name, found in recent:
            if found: lines.append('[COLOR lime][OK] %s[/COLOR]' % ch_name)
            else: lines.append('[COLOR grey][--] %s[/COLOR]' % ch_name)
        while len(lines) < 4: lines.append('')

        active_names = [clean_name(enabled_players[idx]) for idx in started_indices if idx not in completed_indices and threads[idx].is_alive()][:3]
        active_str = ', '.join(active_names) if active_names else 'Finalizando...'
        p_dialog.update(pct, '%s (%d/%d canales)\n%s\n%s\nBuscando: %s' % (target_title, completed, total_channels, lines[0], lines[1], active_str))

        elapsed = now - start_time
        if completed >= total_channels or elapsed > timeout_secs: break
        if p_dialog.iscanceled():
            if elapsed > 5 or len(results_dict) > 0: break
        time.sleep(0.1)

    try:
        p_dialog.close()
    except: pass
    # Esperar animacion de cierre del Progress antes de procesar resultados (evita hang)
    try:
        xbmc.sleep(300)
    except:
        time.sleep(0.3)

    all_links = []
    matched_item = None
    for pf in enabled_players:
        if pf in results_dict:
            it, links = results_dict[pf]
            if not matched_item and it: matched_item = it
            for lnk in links: all_links.append(lnk)

    all_links = _filter_and_sort_links(all_links)
    return all_links, matched_item

# ---------------------------------------------------------
# Serialization and UI List Directory Display
# ---------------------------------------------------------
def _serialize_item(it):
    if not it: return None
    d = {}
    dict_to_use = it.__dict__ if hasattr(it, '__dict__') else {}
    for k in dict_to_use:
        try:
            val = dict_to_use[k]
            if isinstance(val, (str, int, float, bool, list, dict, tuple)) or val is None: d[k] = val
        except: pass
    return d

def _deserialize_item(d, engine='alfa'):
    if not d: return None
    mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
    if not mods: return None
    Item = mods['Item']
    InfoLabels = mods['InfoLabels']
    it = Item()
    it.__dict__.update(d)
    for k, v in d.items():
        try: setattr(it, k, v)
        except: pass
    if 'infoLabels' in it.__dict__ and not isinstance(it.__dict__['infoLabels'], InfoLabels):
        it.__dict__['infoLabels'] = InfoLabels(it.__dict__['infoLabels'])
    return it

def _enrich_link_metadata(link, meta, matched_item=None):
    if not meta: meta = {}
    t_id = meta.get('tmdb') or _safe_get_item_attr(matched_item, 'tmdb_id') or ''
    i_id = meta.get('imdb') or _safe_get_item_attr(matched_item, 'imdb_id') or ''
    tv_id = meta.get('tvdb') or _safe_get_item_attr(matched_item, 'tvdb_id') or ''
    tr_id = meta.get('trakt') or _safe_get_item_attr(matched_item, 'trakt_id') or ''
    is_series = bool(meta.get('season') and meta.get('episode'))
    title_val = meta.get('title') or _safe_get_item_attr(matched_item, 'contentTitle') or _safe_get_item_attr(matched_item, 'title') or ''
    showname_val = meta.get('showname') or _safe_get_item_attr(matched_item, 'contentSerieName') or _safe_get_item_attr(matched_item, 'show') or ''
    year_val = meta.get('showyear' if is_series else 'year') or _safe_get_item_attr(matched_item, 'year') or ''
    plot_val = meta.get('plot') or _safe_get_item_attr(matched_item, 'plot') or ''
    tagline_val = meta.get('tagline') or _safe_get_item_attr(matched_item, 'tagline') or ''
    poster_val = meta.get('poster') or meta.get('thumbnail') or _safe_get_item_attr(matched_item, 'thumbnail') or ''
    fanart_val = meta.get('fanart') or _safe_get_item_attr(matched_item, 'fanart') or ''

    targets = []
    if link: targets.append(link)
    if matched_item and hasattr(matched_item, '__dict__'): targets.append(matched_item)
    if not targets: return

    for target in targets:
        if not hasattr(target, 'infoLabels') or not isinstance(getattr(target, 'infoLabels', None), dict):
            target.infoLabels = {}
        if is_series:
            target.contentType = 'episode'
            target.contentSerieName = showname_val
            target.show = showname_val
            try: target.contentSeason = int(meta.get('season'))
            except: pass
            try: target.contentEpisodeNumber = int(meta.get('episode'))
            except: pass
            target.contentTitle = title_val or showname_val
            target.infoLabels['mediatype'] = 'episode'
            target.infoLabels['tvshowtitle'] = showname_val
            try: target.infoLabels['season'] = int(meta.get('season'))
            except: pass
            try: target.infoLabels['episode'] = int(meta.get('episode'))
            except: pass
            target.infoLabels['title'] = '%s %sx%02d' % (showname_val, str(meta.get('season')), int(meta.get('episode')))
        else:
            target.contentType = 'movie'
            target.contentTitle = title_val
            target.infoLabels['mediatype'] = 'movie'
            target.infoLabels['title'] = title_val
        if t_id: target.infoLabels['tmdb_id'] = str(t_id); target.infoLabels['tmdb'] = str(t_id); target.infoLabels['code'] = str(t_id); target.tmdb_id = str(t_id)
        if i_id: target.infoLabels['imdb_id'] = str(i_id); target.infoLabels['imdbnumber'] = str(i_id); target.imdb_id = str(i_id)
        if tv_id: target.infoLabels['tvdb_id'] = str(tv_id); target.infoLabels['tvdb'] = str(tv_id); target.tvdb_id = str(tv_id)
        if tr_id: target.infoLabels['trakt_id'] = str(tr_id); target.infoLabels['trakt'] = str(tr_id); target.trakt_id = str(tr_id)
        if year_val:
            try: target.infoLabels['year'] = int(year_val); target.year = int(year_val)
            except: pass
        if plot_val: target.infoLabels['plot'] = plot_val; target.plot = plot_val
        if tagline_val: target.infoLabels['tagline'] = tagline_val; target.tagline = tagline_val
        if poster_val:
            target.thumbnail = poster_val
            target.infoLabels['poster'] = poster_val
            target.infoLabels['thumbnail'] = poster_val
        if fanart_val:
            target.fanart = fanart_val
            target.infoLabels['fanart'] = fanart_val

def sync_tmdbhelper_playerstring(meta=None):
    """Sincroniza la propiedad de ventana TMDbHelper.PlayerInfoString para que
    el servicio de TMDb Helper y el scrobbler de Trakt reconozcan la reproducción,
    incluso cuando el reproductor en TMDb Helper tiene 'is_resolvable': 'false'."""
    if not meta:
        meta = {}
    t_id = str(meta.get('tmdb') or '')
    i_id = str(meta.get('imdb') or '')
    tv_id = str(meta.get('tvdb') or '')
    s_val = meta.get('season')
    e_val = meta.get('episode')
    is_series = bool(s_val and e_val)

    if not t_id and not i_id:
        return

    try:
        p_dict = {
            'tmdb_type': 'episode' if is_series else 'movie',
            'tmdb_id': t_id,
        }
        if i_id:
            p_dict['imdb_id'] = i_id
        if tv_id:
            p_dict['tvdb_id'] = tv_id
        if is_series:
            try: p_dict['season'] = int(s_val)
            except: p_dict['season'] = str(s_val)
            try: p_dict['episode'] = int(e_val)
            except: p_dict['episode'] = str(e_val)

        p_str = json.dumps(p_dict)
        xbmcgui.Window(10000).setProperty('TMDbHelper.PlayerInfoString', p_str)
        xbmc.log(f"Bridge Multi: TMDbHelper.PlayerInfoString sincronizado -> {p_str}", xbmc.LOGINFO)
    except Exception as ex:
        xbmc.log(f"Bridge Multi: error sincronizando TMDbHelper.PlayerInfoString: {ex}", xbmc.LOGINFO)

def set_listitem_info(listitem, info=None, meta=None):
    if info is None: info = {}
    if meta is None: meta = {}

    tmdb_id = str(info.get('tmdb_id') or info.get('tmdb') or meta.get('tmdb') or '')
    imdb_id = str(info.get('imdb_id') or info.get('imdb') or meta.get('imdb') or '')
    tvdb_id = str(info.get('tvdb_id') or info.get('tvdb') or meta.get('tvdb') or '')
    trakt_id = str(info.get('trakt_id') or info.get('trakt') or meta.get('trakt') or '')

    s_val = info.get('season') or meta.get('season')
    e_val = info.get('episode') or meta.get('episode')
    is_series = bool(s_val and e_val)

    title_val = str(info.get('title') or meta.get('title') or '')
    showname_val = str(info.get('tvshowtitle') or meta.get('showname') or '')
    year_val = info.get('year') or meta.get('showyear' if is_series else 'year') or meta.get('year')
    plot_val = str(info.get('plot') or meta.get('plot') or '')
    tagline_val = str(info.get('tagline') or meta.get('tagline') or '')
    poster_val = str(info.get('poster') or info.get('thumbnail') or meta.get('poster') or meta.get('thumbnail') or '')
    fanart_val = str(info.get('fanart') or meta.get('fanart') or '')

    unique_dict = {}
    if tmdb_id:
        unique_dict['tmdb'] = str(tmdb_id)
        if is_series:
            unique_dict['tvshow.tmdb'] = str(tmdb_id)
    if imdb_id:
        unique_dict['imdb'] = str(imdb_id)
        if is_series:
            unique_dict['tvshow.imdb'] = str(imdb_id)
    if tvdb_id:
        unique_dict['tvdb'] = str(tvdb_id)
        if is_series:
            unique_dict['tvshow.tvdb'] = str(tvdb_id)
    if trakt_id:
        unique_dict['trakt'] = str(trakt_id)

    if tmdb_id: listitem.setProperty('tmdb_id', str(tmdb_id))
    if imdb_id: listitem.setProperty('imdb_id', str(imdb_id))
    if tvdb_id: listitem.setProperty('tvdb_id', str(tvdb_id))
    listitem.setProperty('tmdb_type', 'episode' if is_series else 'movie')

    trakt_payload = {}
    if tmdb_id: trakt_payload['tmdb'] = int(tmdb_id) if str(tmdb_id).isdigit() else tmdb_id
    if imdb_id: trakt_payload['imdb'] = imdb_id
    if tvdb_id: trakt_payload['tvdb'] = int(tvdb_id) if str(tvdb_id).isdigit() else tvdb_id
    if trakt_payload:
        listitem.setProperty('script.trakt.ids', json.dumps(trakt_payload))

    art_dict = {}
    if poster_val:
        art_dict['poster'] = poster_val
        art_dict['thumb'] = poster_val
        art_dict['icon'] = poster_val
    if fanart_val:
        art_dict['fanart'] = fanart_val
    if art_dict:
        try: listitem.setArt(art_dict)
        except: pass

    media_type = info.get('mediatype') or ('episode' if is_series else 'movie')
    try:
        vt = listitem.getVideoInfoTag()
        if vt:
            if unique_dict:
                try: vt.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else ('imdb' if imdb_id else ''))
                except: pass
            if imdb_id:
                try: vt.setIMDbNumber(imdb_id)
                except: pass
            vt.setMediaType(media_type)
            if is_series and media_type == 'episode':
                if showname_val: vt.setTvShowTitle(showname_val)
                if title_val: vt.setTitle(title_val)
                elif showname_val and s_val and e_val:
                    try: vt.setTitle(f"{showname_val} {int(s_val)}x{int(e_val):02d}")
                    except: vt.setTitle(f"{showname_val} {s_val}x{e_val}")
                if s_val:
                    try: vt.setSeason(int(s_val))
                    except: pass
                if e_val:
                    try: vt.setEpisode(int(e_val))
                    except: pass
            else:
                if title_val: vt.setTitle(title_val)
            if plot_val: vt.setPlot(plot_val)
            if tagline_val:
                try: vt.setTagLine(tagline_val)
                except: pass
            if year_val:
                try: vt.setYear(int(year_val))
                except: pass
            return
    except: pass

    if unique_dict:
        try: listitem.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else 'imdb')
        except: pass
    legacy_info = dict(info)
    if 'mediatype' not in legacy_info:
        legacy_info['mediatype'] = media_type
    if title_val and 'title' not in legacy_info:
        legacy_info['title'] = title_val
    if is_series and media_type == 'episode' and showname_val and 'tvshowtitle' not in legacy_info:
        legacy_info['tvshowtitle'] = showname_val
    if s_val and 'season' not in legacy_info:
        try: legacy_info['season'] = int(s_val)
        except: pass
    if e_val and 'episode' not in legacy_info:
        try: legacy_info['episode'] = int(e_val)
        except: pass
    if year_val and 'year' not in legacy_info:
        try: legacy_info['year'] = int(year_val)
        except: pass
    if plot_val and 'plot' not in legacy_info:
        legacy_info['plot'] = plot_val
    if tagline_val and 'tagline' not in legacy_info:
        legacy_info['tagline'] = tagline_val
    try: listitem.setInfo('video', legacy_info)
    except: pass

def _force_list_view():
    """Fuerza la visualización en vista de Lista (List) independientemente del skin activo en Kodi."""
    skin_id = ''
    try:
        skin_id = str(xbmc.getSkinDir() or '').lower()
    except Exception:
        pass

    # Mapeo de IDs de vista Lista para skins populares de Kodi (50 es el estándar universal de Kodi)
    skin_view_map = {
        'skin.estuary': 50,
        'skin.estouchy': 50,
        'skin.confluence': 50,
        'skin.aeon.nox.silvo': 50,
        'skin.aeon.tajo': 50,
        'skin.amber': 50,
        'skin.apptv': 50,
        'skin.bello.7': 50,
        'skin.bello.8': 50,
        'skin.box': 50,
        'skin.arctic.horizon': 50,
        'skin.arctic.horizon.2': 50,
        'skin.arctic.fuse': 50,
        'skin.arctic.zephyr.reloaded': 50,
        'skin.titan': 50,
        'skin.titan.bingie.mod': 50,
        'skin.aura': 50,
        'skin.auramod': 50,
        'skin.embuary': 50,
        'skin.phenomenal': 50,
        'skin.ftv': 50,
        'skin.mimic.lr': 50,
        'skin.pellucid': 50
    }
    view_id = skin_view_map.get(skin_id, 50)

    try:
        xbmc.executebuiltin("Container.SetViewMode(%d)" % view_id)
    except Exception:
        pass

    def _apply_delayed():
        # Re-aplicar tras breves momentos para asegurar que Kodi haya montado el contenedor
        for delay in (50, 150, 300, 600, 1000):
            xbmc.sleep(delay)
            try:
                xbmc.executebuiltin("Container.SetViewMode(%d)" % view_id)
            except Exception:
                pass

    try:
        t = threading.Thread(target=_apply_delayed)
        t.daemon = True
        t.start()
    except Exception:
        pass

def show_links_as_directory():
    xbmc.log("Bridge Multi: show_links_as_directory llamado", xbmc.LOGINFO)
    links = []
    matched_item = None
    meta = {}
    engine = 'alfa'
    try:
        _req_tmdb = get_param('tmdb') or tmdb_id or ''
        _req_s = get_param('season') or season
        _req_e = get_param('episode') or episode
        if os.path.exists(SEARCH_CACHE_FILE):
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as _f:
                _c2 = json.load(_f)
                _c2_meta = _c2.get('meta', {}) or {}
                _c2_s = _c2_meta.get('season')
                _c2_e = _c2_meta.get('episode')
                _cached_tmdb2 = str(_c2_meta.get('tmdb') or '')
                if _cached_tmdb2 and _req_tmdb and _cached_tmdb2 != str(_req_tmdb):
                    xbmc.log(f"Bridge Multi: cache tmdb {_cached_tmdb2} != pedido {_req_tmdb}", xbmc.LOGWARNING)
                if _req_s and _req_e and (_c2_s is not None) and (_c2_e is not None):
                    try:
                        if int(_c2_s) != int(_req_s) or int(_c2_e) != int(_req_e):
                            xbmc.log(f"Bridge Multi: cache episode S{_c2_s}E{_c2_e} != pedido S{_req_s}E{_req_e}", xbmc.LOGWARNING)
                    except: pass
    except Exception as e:
        xbmc.log(f"Bridge Multi: check cache tmdb error: {e}", xbmc.LOGINFO)
    if os.path.exists(SEARCH_CACHE_FILE):
        try:
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as f: cache = json.load(f)
            engine = cache.get('engine', 'alfa')
            links = [_deserialize_item(lnk, engine) for lnk in cache.get('links', [])]
            matched_item = _deserialize_item(cache.get('item'), engine)
            meta = cache.get('meta', {})
        except: pass

    if not links:
        xbmcgui.Dialog().notification('Bridge Multi', 'No hay enlaces en cache', '', 3000)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    # Datos para menu contextual de cada enlace
    _other_engine = 'balandro' if engine == 'alfa' else 'alfa'
    _other_name   = 'Balandro' if engine == 'alfa' else 'Alfa'
    _rs_url  = 'plugin://plugin.video.bridge.multi/?action=search_other_engine&engine=%s' % _other_engine
    _v_url   = 'plugin://plugin.video.bridge.multi/?action=verify_links'

    # Etiqueta de estado de verificacion (solo informativa, no es boton clicable)
    verified_only = meta.get('verified_only', False)
    if verified_only:
        v_label = '[B][COLOR lime]>> [OK] [ENLACES VERIFICADOS Y DISPONIBLES][/COLOR][/B]'
        v_li = xbmcgui.ListItem(label=v_label)
        v_li.setArt({'thumb': 'OverlayUnwatched.png', 'icon': 'OverlayUnwatched.png'})
        set_listitem_info(v_li, {'title': v_label, 'plot': 'Lista filtrada con enlaces comprobados y funcionales.', 'mediatype': 'video'})
        v_li.setLabel(v_label)
        try:
            vt = v_li.getVideoInfoTag()
            if vt: vt.setTitle(v_label)
        except Exception: pass
        try: v_li.setInfo('video', {'title': v_label})
        except Exception: pass
        v_li.setProperty('title', v_label)
        v_li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle, '', v_li, False)

    media_key_main = _get_media_key(meta, matched_item)
    is_s = bool(meta.get('season') and meta.get('episode'))
    saved_bm = get_bookmark(media_key_main, tmdb_id=meta.get('tmdb'), is_series=is_s, season=meta.get('season'), episode=meta.get('episode'))
    bm_str = ''
    if saved_bm:
        r_sec = float(saved_bm.get('resume_time', 0))
        m_mins = int(r_sec // 60); m_secs = int(r_sec % 60); m_hrs = m_mins // 60; m_mins = m_mins % 60
        bm_str = (' [COLOR orange][Reanudar: %d:%02d:%02d][/COLOR]' % (m_hrs, m_mins, m_secs)) if m_hrs else (' [COLOR orange][Reanudar: %d:%02d][/COLOR]' % (m_mins, m_secs))

    # Limitar a 40 enlaces para evitar crash en equipos modestos (Celeron) y filtrar URLs anormalmente largas
    if len(links) > 40:
        xbmc.log(f"Bridge Multi: truncando de {len(links)} a 40 enlaces para estabilidad", xbmc.LOGINFO)
        links = links[:40]
    for idx, lnk in enumerate(links):
        try:
            # Filtrar URLs absurdamente largas que pueden crashear Kodi (ej. mitorrent 1963 chars)
            _url = _safe_str(getattr(lnk, 'url', ''))
            if len(_url) > 1500:
                xbmc.log(f"Bridge Multi: skip link idx {idx} url muy larga {len(_url)} {getattr(lnk, 'channel','')}", xbmc.LOGINFO)
                continue
            srv = _get_link_server_name(lnk)
            lang = _format_language(lnk)
            qual = _format_quality(lnk)
            ch = _format_channel(lnk)

            lbl = '[B][COLOR deepskyblue]%s[/COLOR][/B] | [COLOR lime]%s[/COLOR] | [COLOR gold]%s[/COLOR] | [COLOR grey](%s)[/COLOR]%s' % (srv, lang, qual, ch, bm_str)
            play_url = 'plugin://plugin.video.bridge.multi/?action=play_single_link&index=%d&engine=%s' % (idx, engine)
            li = xbmcgui.ListItem(label=lbl)
            li.setPath(play_url)
            poster = meta.get('poster') or meta.get('thumbnail') or getattr(matched_item, 'thumbnail', '') or alfa_icon
            fanart = meta.get('fanart') or getattr(matched_item, 'fanart', '') or ''
            thumb = meta.get('thumbnail') or meta.get('poster') or getattr(lnk, 'thumbnail', '') or getattr(matched_item, 'thumbnail', '') or alfa_icon
            if thumb and len(_safe_str(thumb)) > 1000:
                thumb = alfa_icon
            if poster and len(_safe_str(poster)) > 1000:
                poster = alfa_icon
            if fanart and len(_safe_str(fanart)) > 1000:
                fanart = ''
            try:
                li.setArt({'thumb': thumb, 'icon': thumb, 'poster': poster, 'fanart': fanart})
            except:
                try: li.setArt({'thumb': alfa_icon, 'icon': alfa_icon})
                except: pass
            plot_text = meta.get('plot') or _safe_str(getattr(matched_item, 'plot', '') or '')
            info = {'title': lbl, 'plot': _safe_str(plot_text)[:2000], 'mediatype': 'video'}
            if meta.get('tagline'):
                info['tagline'] = meta['tagline']
            try:
                set_listitem_info(li, info, meta)
            except Exception as e:
                xbmc.log(f"Bridge Multi: set_listitem_info error idx {idx}: {e}", xbmc.LOGINFO)

            # Reforzar de forma explícita e inequívoca el título y etiqueta del enlace
            li.setLabel(lbl)
            li.setLabel2(ch)
            try:
                vt = li.getVideoInfoTag()
                if vt:
                    vt.setTitle(lbl)
            except Exception:
                pass
            try:
                li.setInfo('video', {'title': lbl})
            except Exception:
                pass
            li.setProperty('title', lbl)

            # Menu contextual (boton C o clic largo): acciones sin ocupar espacio en la lista
            _ctx_items = []
            if not (is_s and engine == 'balandro'):
                _ctx_items.append(
                    ('[COLOR orange]Buscar con %s[/COLOR]' % _other_name,
                     'RunPlugin(%s)' % _rs_url)
                )
            if not verified_only:
                _ctx_items.append(
                    ('[COLOR deepskyblue]Verificar disponibilidad[/COLOR]',
                     'RunPlugin(%s)' % _v_url)
                )
            li.addContextMenuItems(_ctx_items)

            li.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(handle, play_url, li, False)
        except Exception as e:
            xbmc.log(f"Bridge Multi: show_links skip idx {idx} error: {e}", xbmc.LOGINFO)
            import traceback
            xbmc.log(traceback.format_exc(), xbmc.LOGINFO)
            continue


    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.setContent(handle, 'movies')
    _force_list_view()
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
    _force_list_view()

# ---------------------------------------------------------
# Playback Handler (Native Delegates for Alfa & Balandro)
# ---------------------------------------------------------

def _resolve_link_to_listitem(link, engine, matched_item=None):
    """Resolve *link* to a playable ListItem by intercepting the engine's setResolvedUrl.

    Does NOT consume the real Kodi plugin handle — the interception captures the
    ListItem (with the direct stream URL) and returns it to the caller.

    Returns (True, listitem) on success, (False, None) on failure.
    """
    if not link: return False, None

    prep = _prepare_playable_link(link, engine=engine)
    if not prep:
        return False, None

    if not getattr(prep, 'url', '') and not getattr(prep, 'video_urls', None):
        return False, None

    _resolved_li = [None]
    _result       = [False]

    import xbmcplugin as _xp
    _orig = getattr(_xp, 'setResolvedUrl', None)

    def _capture(h, succeeded, listitem):
        if succeeded and listitem:
            _resolved_li[0] = listitem
            _result[0]      = True
        else:
            _result[0]      = False

    try:    _xp.setResolvedUrl = _capture
    except: pass

    try:
        with silenced_dialogs():
            if engine == 'balandro':
                mods = _get_balandro_modules()
                if not mods: return False, None
                pt     = mods['platformtools']
                parent = matched_item or prep
                pt.play_video(prep, parent, autoplay=True)
            else:  # alfa
                mods = _get_alfa_modules()
                if not mods: return False, None
                pt = mods['platformtools']
                pt.play_video(prep, autoplay=True)
    except Exception as _ex:
        xbmc.log('Bridge Multi _resolve_link error: ' + str(_ex), xbmc.LOGINFO)
        _result[0] = False
    finally:
        if _orig is not None:
            try:    _xp.setResolvedUrl = _orig
            except: pass

    if _result[0] and _resolved_li[0] is not None:
        return True, _resolved_li[0]
    return False, None


def _autoplay_with_fallback(links, handle, engine, matched_item=None,
                            monitor_secs=60, max_attempts=999, tmdb_for_list=None,
                            meta=None):
    """Try non-torrent links in order until one verifiably plays.

    While autoplay runs, list_links is opened in the background (if tmdb_for_list
    is provided) so the user can choose a different link (e.g. a torrent) after
    stopping the current playback.

    Torrents are filtered out of the autoplay queue — they only appear in list_links.
    The Kodi plugin handle is dismissed with setResolvedUrl(False) at the start.
    Actual playback uses xbmc.Player().play() independently of the handle.
    """
    if not meta and os.path.exists(SEARCH_CACHE_FILE):
        try:
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as _cf:
                meta = json.load(_cf).get('meta', {})
        except: pass

    if not links:
        _absorb = xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(handle, False, _absorb)
        return False

    # ── Filter torrents ────────────────────────────────────────────────────
    normal_links = [l for l in links if not _is_torrent_link(l)]
    if not normal_links:
        _absorb = xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(handle, False, _absorb)
        return False

    # ── Dismiss handle early (suppress Kodi error dialog via guardian) ─────
    _guard_stop = [False]
    def _suppress():
        for _ in range(30):
            if _guard_stop[0]: break
            try:
                xbmc.executebuiltin('Dialog.Close(okdialog,true)')
                xbmc.executebuiltin('Dialog.Close(error,true)')
            except: pass
            time.sleep(0.1)
    _gt = threading.Thread(target=_suppress, daemon=True)
    _gt.start()

    _absorb = xbmcgui.ListItem()
    try:    xbmcplugin.setResolvedUrl(handle, False, _absorb)
    except: pass
    xbmc.sleep(300)
    _guard_stop[0] = True
    try: _gt.join(timeout=0.5)
    except: pass

    # ── Abrir list_links en segundo plano ──────────────────────────────────
    # Se carga detrás del reproductor; cuando el usuario detiene el video
    # list_links se abrirá en el momento correcto: cuando el usuario diga "No"
    # o cuando se agoten todos los enlaces (ver más abajo).

    player    = xbmc.Player()
    total_att = min(len(normal_links), max_attempts)



    # Mapa de idioma interno → nombre legible para el usuario
    _LANG_NAMES = {
        'lat': 'Latino', 'latino': 'Latino',
        'esp': 'Castellano', 'castellano': 'Castellano', 'es': 'Castellano',
        'vose': 'VOSE', 'sub': 'VOSE', 'subtitulado': 'VOSE',
        'eng': 'Inglés', 'en': 'Inglés',
        'por': 'Portugués', 'pt': 'Portugués',
    }

    for idx, link in enumerate(normal_links[:total_att]):
        server   = _safe_str(getattr(link, 'server',   '') or '').capitalize() or 'servidor'
        lang_raw = _safe_str(getattr(link, 'language', '') or '').strip()
        lang_lbl = _LANG_NAMES.get(lang_raw.lower(), lang_raw) if lang_raw else ''
        qual     = _safe_str(getattr(link, 'quality',  '') or '').strip()
        ch       = _safe_str(getattr(link, 'channel',  '') or '')

        # Etiqueta: "Voe [Latino] · HD"
        _lang_part = (' [%s]' % lang_lbl) if lang_lbl else ''
        _qual_part = (' · %s' % qual) if qual else ''
        _label = '%s%s%s' % (server, _lang_part, _qual_part)

        xbmc.log('Bridge Multi autoplay [%d/%d] → %s %s (%s)' % (
            idx+1, total_att, server, lang_lbl, ch), xbmc.LOGINFO)


        # ── Step 1: Resolve ────────────────────────────────────────────────
        _prog = xbmcgui.DialogProgress()
        _prog.create('Bridge Multi',
                     '[%d/%d] Conectando a [B]%s[/B]...' % (idx+1, total_att, _label))
        _prog.update(10)

        _res_done  = [None]
        _res_li    = [None]
        def _do_resolve(lnk=link):
            ok, li = _resolve_link_to_listitem(lnk, engine, matched_item)
            _res_done[0] = ok
            _res_li[0]   = li

        _rt = threading.Thread(target=_do_resolve, daemon=True)
        _rt.start()

        cancelled = False
        for _s in range(250):   # 25 s max resolution
            if _prog.iscanceled():
                cancelled = True
                break
            if _res_done[0] is not None:
                break
            xbmc.sleep(100)
            _prog.update(min(10 + _s, 80))

        _rt.join(timeout=1)

        if cancelled:
            try: _prog.close()
            except: pass
            xbmc.log('Bridge Multi autoplay: usuario canceló resolución', xbmc.LOGINFO)
            break

        if not _res_done[0] or _res_li[0] is None:
            try: _prog.close()
            except: pass
            xbmc.log('Bridge Multi autoplay [%d/%d] %s no resolvió, siguiente...' % (
                idx+1, total_att, server), xbmc.LOGINFO)
            continue

        # Extract media URL
        _media_url = ''
        try:    _media_url = _res_li[0].getPath()
        except: pass
        if not _media_url:
            try: _prog.close()
            except: pass
            xbmc.log('Bridge Multi autoplay [%d/%d] %s URL vacía, siguiente...' % (
                idx+1, total_att, server), xbmc.LOGINFO)
            continue

        # ── Step 2: Start playback ─────────────────────────────────────────
        _prog.update(90, '[%d/%d] Iniciando [B]%s[/B]...' % (idx+1, total_att, _label))
        try:
            sync_tmdbhelper_playerstring(meta)
            if _res_li[0] is not None:
                set_listitem_info(_res_li[0], meta=meta)
            player.play(_media_url, _res_li[0])
        except Exception as _pe:
            try: _prog.close()
            except: pass
            xbmc.log('Bridge Multi autoplay Player.play error: ' + str(_pe), xbmc.LOGINFO)
            continue

        try: _prog.close()
        except: pass

        # ── Step 3: Monitor 60 s reales de reloj ─────────────────────────────
        # Esperar hasta 15 s a que el reproductor arranque
        started = False
        for _ in range(150):
            if player.isPlaying():
                started = True
                break
            xbmc.sleep(100)

        if not started:
            xbmc.log('Bridge Multi autoplay [%d/%d] %s nunca arrancó (15s), intentando siguiente sin preguntar...' % (
                idx+1, total_att, server), xbmc.LOGINFO)
            try: player.stop()
            except: pass
            xbmc.sleep(500)
            continue   # fallo técnico silencioso → siguiente automático

        xbmc.log('Bridge Multi autoplay [%d/%d] %s arrancó, monitoreando 60s reales...' % (
            idx+1, total_att, server), xbmc.LOGINFO)

        mon_start       = time.time()
        user_declined   = False   # usuario dijo "no" en el diálogo
        link_failed     = False   # reproducción se detuvo → pedir confirmación

        while time.time() - mon_start < monitor_secs:
            xbmc.sleep(1000)   # verificar cada segundo (tiempo real)

            if not player.isPlaying():
                elapsed = time.time() - mon_start
                xbmc.log('Bridge Multi autoplay [%d/%d] %s se detuvo a %.1fs reales' % (
                    idx+1, total_att, server, elapsed), xbmc.LOGINFO)

                # ¿Hay otro enlace disponible?
                remaining = total_att - (idx + 1)
                # Etiqueta simplificada: solo servidor + idioma (sin calidad)
                _srv_lang = server + ((' [%s]' % lang_lbl) if lang_lbl else '')
                if remaining > 0:
                    ans = xbmcgui.Dialog().yesno(
                        'Bridge Multi — Autoplay',
                        '[B]%s[/B] se detuvo. ¿Siguiente enlace?' % _srv_lang,
                        nolabel='No',
                        yeslabel='Sí')
                    if ans:
                        link_failed = True   # continuar con siguiente
                    else:
                        user_declined = True  # el usuario decidió parar
                else:
                    # No quedan más enlaces
                    user_declined = True
                break   # salir del while en ambos casos

        if user_declined:
            # Abrir list_links ahora que el usuario lo puede ver
            if tmdb_for_list:
                _ts = int(time.time())
                _lu = ('plugin://plugin.video.bridge.multi/?view=list_links'
                       '&tmdb=%s&t=%s' % (str(tmdb_for_list), _ts))
                if meta and meta.get('season') and meta.get('episode'):
                    _lu += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
                xbmc.log('Bridge Multi autoplay: usuario detuvo → abriendo list_links', xbmc.LOGINFO)
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.sleep(200)
                xbmc.executebuiltin('ActivateWindow(10025,"%s",return)' % _lu)
            break   # salir del for

        if link_failed:
            try: player.stop()
            except: pass
            xbmc.sleep(500)
            continue   # → siguiente enlace

        # ── 60 s reales transcurridos con reproducción activa → ÉXITO ────────
        xbmc.log('Bridge Multi autoplay [%d/%d] %s verificado OK tras 60s reales' % (
            idx+1, total_att, server), xbmc.LOGINFO)
        return True


    # ── Todos los intentos agotados ────────────────────────────────────────
    if not player.isPlaying():
        if tmdb_for_list:
            _ts = int(time.time())
            _lu = ('plugin://plugin.video.bridge.multi/?view=list_links'
                   '&tmdb=%s&t=%s' % (str(tmdb_for_list), _ts))
            if meta and meta.get('season') and meta.get('episode'):
                _lu += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
            xbmc.log('Bridge Multi autoplay: enlaces agotados → abriendo list_links', xbmc.LOGINFO)
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.sleep(200)
            xbmc.executebuiltin('ActivateWindow(10025,"%s",return)' % _lu)
        else:
            xbmcgui.Dialog().notification(
                'Bridge Multi',
                'Ningún enlace pudo reproducirse (%d intentos)' % total_att,
                '', 5000)
    return False



def _autoplay_link(link, handle, engine, matched_item=None):
    """Resolve *link* and tell Kodi to play it via setResolvedUrl(handle, True, ...).

    This is the CORRECT approach for autoplay: we hold the Kodi plugin handle open,
    resolve the server URL in the background, then hand the resolved ListItem back to
    Kodi.  No setResolvedUrl(False) / xbmc.Player().play() hack needed.

    Returns True if playback was handed off to Kodi, False on failure.
    """
    if not link: return False

    # ── Torrent → cliente configurado en Balandro (con enriquecimiento TMDb) ─
    if _is_torrent_link(link):
        torrent_url = _safe_str(getattr(link, 'url', '') or '')
        _absorb = xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(handle, False, _absorb)
        return _play_torrent_link(torrent_url, matched_item=matched_item)


    server_name = (_safe_str(getattr(link, 'server', '') or '').strip().capitalize()
                   or 'servidor')

    # ── Balandro engine ────────────────────────────────────────────────────
    if engine == 'balandro':
        mods = _get_balandro_modules()
        if not mods:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            return False

        platformtools = mods['platformtools']
        parent = matched_item if matched_item else link

        _prog = xbmcgui.DialogProgress()
        _prog.create('Bridge Multi', 'Reproduciendo via [B]%s[/B]...' % server_name)
        _prog.update(5)

        _resolved_li = [None]
        _result      = [None]   # True=ok, False=fail, 'cancel'=user cancelled

        def _do_resolve():
            import xbmcplugin as _xp
            _orig = getattr(_xp, 'setResolvedUrl', None)

            def _capture(h, succeeded, listitem):
                if succeeded:
                    _resolved_li[0] = listitem
                    _result[0] = True
                else:
                    _result[0] = False

            try:    _xp.setResolvedUrl = _capture
            except: pass

            try:
                sys.argv[1] = str(handle)
                # autoplay=True → skip Balandro's internal player-selector dialog
                platformtools.play_video(link, parent, autoplay=True)
                if _result[0] is None:
                    _result[0] = False
            except Exception as _ex:
                xbmc.log('Bridge Multi _autoplay_link Balandro error: ' + str(_ex), xbmc.LOGINFO)
                _result[0] = False
            finally:
                if _orig is not None:
                    try:    _xp.setResolvedUrl = _orig
                    except: pass

        _t = threading.Thread(target=_do_resolve, daemon=True)
        _t.start()

        # Wait for resolution with animated progress (max 30 s)
        for _step in range(300):
            if _prog.iscanceled():
                _result[0] = 'cancel'
                break
            if _result[0] is not None:
                break
            xbmc.sleep(100)
            _prog.update(min(5 + _step * 3, 90),
                         'Reproduciendo via [B]%s[/B]...' % server_name)

        try:    _prog.close()
        except: pass
        _t.join(timeout=2)

        if _result[0] is True and _resolved_li[0] is not None:
            xbmc.log('Bridge Multi _autoplay_link: setResolvedUrl True via %s' % server_name,
                     xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(handle, True, _resolved_li[0])
            return True
        else:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            if _result[0] != 'cancel':
                xbmcgui.Dialog().notification(
                    'Bridge Multi',
                    '[B]%s[/B] no pudo reproducirse' % server_name,
                    '', 4000)
            return False

    # ── Alfa engine ────────────────────────────────────────────────────────
    else:
        mods = _get_alfa_modules()
        if not mods:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            return False
        platformtools = mods['platformtools']
        try:
            sys.argv[1] = str(handle)
            # Alfa's play_video calls setResolvedUrl(handle, True, ...) internally
            platformtools.play_video(link)
            return True
        except Exception as _e:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            xbmcgui.Dialog().notification(
                'Bridge Multi', 'Error al reproducir: ' + str(_e)[:60], '', 3500)
            return False


def _clean_dialog_text(text):
    """Limpia etiquetas Kodi y HTML para mostrar texto legible en diálogos."""
    if not text:
        return ""
    t = str(text).replace('<br/>', '\n').replace('<br>', '\n')
    t = re.sub(r'\[/?COLOR.*?\]', '', t)
    t = re.sub(r'\[/?B\]', '', t)
    t = re.sub(r'\[/?I\]', '', t)
    t = re.sub(r'<[^>]+>', '', t)
    return t.strip()


def _play_link_safely(link, engine='alfa', matched_item=None, meta=None):

    if not link: return False

    if not meta and os.path.exists(SEARCH_CACHE_FILE):
        try:
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as _cf:
                meta = json.load(_cf).get('meta', {})
        except: pass

    # 1. Enlace Torrent → cliente configurado en Balandro (con enriquecimiento TMDb)
    if _is_torrent_link(link):
        torrent_url = _safe_str(getattr(link, 'url', '') or '')
        _play_torrent_link(torrent_url, matched_item=matched_item, meta=meta)
        return True

    # 2. Preparar enlace (resolver canal.play y data_url)
    prepared = _prepare_playable_link(link, engine=engine)
    if not prepared:
        xbmcgui.Dialog().notification('Bridge Multi', 'No se pudo preparar el enlace', '', 3000)
        return False

    server_name = (_safe_str(getattr(prepared, 'server', '') or getattr(link, 'server', '') or '').strip().capitalize()
                   or 'Servidor')

    has_url = bool(getattr(prepared, 'url', None))
    has_video_urls = bool(getattr(prepared, 'video_urls', None))

    if not has_url and not has_video_urls:
        xbmc.log(f"Bridge Multi: enlace sin URL para {server_name}", xbmc.LOGINFO)
        xbmcgui.Dialog().notification('Bridge Multi', f'{server_name} — No se encontró URL reproducible', '', 3500)
        return False

    # 3. Reproductor según el motor
    # ── Balandro: ventana de progreso de conexión, timeout (25s) y aviso de fallo ──
    if engine == 'balandro':
        mods = _get_balandro_modules()
        if not mods: return False

        platformtools = mods['platformtools']
        parent = matched_item if matched_item else prepared

        # Ventana de progreso visual exclusiva para Balandro
        prog = xbmcgui.DialogProgress()
        prog.create('Bridge Multi', 'Conectando a [B]%s[/B]...' % server_name)
        prog.update(5, 'Conectando a [B]%s[/B]...' % server_name)

        import xbmcplugin as _xp
        _resolved_li = [None]
        _result = [None]   # True=éxito, False=fallo, 'cancel'=cancelado por usuario
        _fail_reason = ['']

        def _cap_sru(h, succeeded, listitem):
            if succeeded and listitem:
                _resolved_li[0] = listitem
                _result[0] = True
            else:
                if _result[0] is None:
                    _result[0] = False

        def _cap_ok(heading="", message="", *args):
            txt = str(message or heading or '')
            if txt and not _fail_reason[0]:
                _fail_reason[0] = txt
            return True

        def _cap_notif(heading="", message="", *args, **kwargs):
            txt = str(message or heading or '')
            if txt and not _fail_reason[0]:
                _fail_reason[0] = txt
            return True

        def _cap_sel(heading="", options=None, *args, **kwargs):
            if options and isinstance(options, (list, tuple)):
                return len(options) - 1
            return 0

        def _do_resolve():
            _orig_sru = getattr(_xp, 'setResolvedUrl', None)
            _orig_ok = getattr(platformtools, 'dialog_ok', None)
            _orig_notif = getattr(platformtools, 'dialog_notification', None)
            _orig_sel = getattr(platformtools, 'dialog_select', None)

            try:
                _xp.setResolvedUrl = _cap_sru
                platformtools.dialog_ok = _cap_ok
                platformtools.dialog_notification = _cap_notif
                platformtools.dialog_select = _cap_sel
                sys.argv[1] = str(handle)
                xbmc.log(f"Bridge Multi: conectando a {server_name} en Balandro (url={str(getattr(prepared, 'url', ''))[:60]})", xbmc.LOGINFO)
                res = platformtools.play_video(prepared, parent, autoplay=False)
                if res is True and _resolved_li[0] is not None:
                    _result[0] = True
                elif res is False:
                    _result[0] = False
                elif _result[0] is None:
                    _result[0] = False
            except Exception as _ex:
                xbmc.log(f"Bridge Multi: error en play_video Balandro: {_ex}", xbmc.LOGINFO)
                if not _fail_reason[0]:
                    _fail_reason[0] = str(_ex)
                _result[0] = False
            finally:
                if _orig_sru is not None:
                    try: _xp.setResolvedUrl = _orig_sru
                    except: pass
                if _orig_ok is not None:
                    try: platformtools.dialog_ok = _orig_ok
                    except: pass
                if _orig_notif is not None:
                    try: platformtools.dialog_notification = _orig_notif
                    except: pass
                if _orig_sel is not None:
                    try: platformtools.dialog_select = _orig_sel
                    except: pass

        _t = threading.Thread(target=_do_resolve, daemon=True)
        _t.start()

        _timeout_steps = 150  # 15s
        for _step in range(_timeout_steps):
            if prog.iscanceled():
                _result[0] = 'cancel'
                break
            if _result[0] is not None:
                break
            xbmc.sleep(100)
            _elapsed = (_step + 1) * 0.1
            _pct = min(15 + int((_step / float(_timeout_steps)) * 80), 95)
            prog.update(
                _pct,
                'Conectando a [B]%s[/B]...\n[COLOR grey]Espere por favor (%.1fs / 15s)[/COLOR]' % (server_name, _elapsed)
            )

        try:
            prog.close()
        except:
            pass
        _t.join(timeout=1.0)

        if _result[0] == 'cancel':
            xbmc.log(f"Bridge Multi: conexión a {server_name} cancelada", xbmc.LOGINFO)
            return False

        if _result[0] is True and _resolved_li[0] is not None:
            media_url = ''
            try: media_url = _resolved_li[0].getPath()
            except: pass
            if media_url:
                xbmc.log(f"Bridge Multi: reproduciendo {server_name} con éxito (url={media_url[:60]})", xbmc.LOGINFO)
                sync_tmdbhelper_playerstring(meta)
                if _resolved_li[0] is not None:
                    set_listitem_info(_resolved_li[0], meta=meta)
                xbmc.Player().play(media_url, _resolved_li[0])
                return True
            else:
                xbmcgui.Dialog().ok(
                    'Bridge Multi — Error de Reproducción',
                    f'El servidor [B][COLOR gold]{server_name}[/COLOR][/B] resolvió pero no proporcionó la ruta final del vídeo.'
                )
                return False

        if _result[0] is None:
            xbmc.log(f"Bridge Multi: timeout conectando a {server_name} tras 15s", xbmc.LOGINFO)
            xbmcgui.Dialog().ok(
                'Bridge Multi — Tiempo de Espera Agotado',
                f'El servidor [B][COLOR gold]{server_name}[/COLOR][/B] no respondió a tiempo (15 segundos).\n\n'
                f'[COLOR red][B]Causa:[/B][/COLOR] Tiempo de espera agotado.\n'
                f'El servidor puede estar caído, saturado o bloqueando la conexión.'
            )
            return False

        raw_reason = _fail_reason[0].strip()
        clean_reason = _clean_dialog_text(raw_reason)
        if not clean_reason:
            clean_reason = 'El vídeo ya no existe, el enlace está caído o el servidor no responde.'

        xbmc.log(f"Bridge Multi: fallo reproduciendo {server_name}: {clean_reason}", xbmc.LOGINFO)
        xbmcgui.Dialog().ok(
            'Bridge Multi — Fallo del Servidor',
            f'No se pudo reproducir en el servidor [B][COLOR gold]{server_name}[/COLOR][/B].\n\n'
            f'[COLOR red][B]Motivo:[/B][/COLOR] {clean_reason}'
        )
        return False

    # ── Alfa: reproducción 100% nativa sin ventanas personalizadas ────────
    # Alfa gestiona su propia ventana nativa de progreso "Conectando con [Servidor]..."
    # y sus propios diálogos de fallo de forma independiente.
    else:
        mods = _get_alfa_modules()
        if not mods: return False
        platformtools = mods['platformtools']
        try:
            sys.argv[1] = str(handle)
            _enrich_link_metadata(prepared, meta, matched_item)
            sync_tmdbhelper_playerstring(meta)

            # Limpiar video_urls para que Alfa resuelva de forma fresca con su ventana nativa de progreso
            prepared.video_urls = []

            xbmc.log(f"Bridge Multi: reproduciendo {server_name} en Alfa (url={str(getattr(prepared, 'url', ''))[:60]})", xbmc.LOGINFO)

            orig_select = getattr(platformtools, 'dialog_select', None)
            def _smart_alfa_select(heading="", options=None, *args, **kwargs):
                if options and isinstance(options, (list, tuple)):
                    # Contar opciones de vídeo ("Ver el vídeo ...")
                    video_opts = []
                    for i, opt in enumerate(options):
                        opt_str = str(opt).lower()
                        if 'ver el video' in opt_str or 'ver el vídeo' in opt_str or 'reproducir' in opt_str:
                            video_opts.append(i)

                    # Si hay varias resoluciones, mostrar la ventana nativa de Alfa
                    if len(video_opts) > 1:
                        if orig_select:
                            return orig_select(heading, options, *args, **kwargs)
                        return xbmcgui.Dialog().select(heading, options)

                    # Si solo hay una resolución, iniciar directamente
                    if len(video_opts) == 1:
                        return video_opts[0]
                    return 0

                if orig_select:
                    return orig_select(heading, options, *args, **kwargs)
                return 0

            try:
                platformtools.dialog_select = _smart_alfa_select
                platformtools.play_video(prepared, force_direct=True)
            finally:
                if orig_select:
                    platformtools.dialog_select = orig_select

            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            if pl.size() > 0 or xbmc.Player().isPlaying() or xbmc.getCondVisibility("Player.HasMedia"):
                return True

            for _ in range(20):
                if xbmc.Player().isPlaying() or xbmc.getCondVisibility("Player.HasMedia") or pl.size() > 0:
                    return True
                xbmc.sleep(100)

            return True
        except Exception as e:
            xbmc.log(f"Bridge Multi: error en play_video Alfa: {e}", xbmc.LOGINFO)
            xbmcgui.Dialog().notification('Bridge Multi', f'{server_name} — Error: {str(e)[:60]}', '', 3500)
            return False

def verify_and_filter_links():
    links = []
    matched_item = None
    meta = {}
    engine = 'alfa'
    if os.path.exists(SEARCH_CACHE_FILE):
        try:
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as f: cache = json.load(f)
            engine = cache.get('engine', 'alfa')
            links = [_deserialize_item(lnk, engine) for lnk in cache.get('links', [])]
            matched_item = _deserialize_item(cache.get('item'), engine)
            meta = cache.get('meta', {})
        except: pass

    if not links: return
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('Bridge Multi', 'Verificando disponibilidad de enlaces...')
    verified_links = _verify_links_headless(links, engine=engine, p_dialog=p_dialog)
    try: p_dialog.close()
    except: pass

    if not verified_links:
        xbmcgui.Dialog().ok('Bridge Multi', 'No se encontraron enlaces funcionales.')
        return

    verified_links = _filter_and_sort_links(verified_links)
    meta['verified_only'] = True
    try:
        with open(SEARCH_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump({'item': _serialize_item(matched_item), 'links': [_serialize_item(l) for l in verified_links], 'meta': meta, 'engine': engine}, f)
    except: pass
    xbmc.executebuiltin('Container.Refresh')

# ---------------------------------------------------------
# Player Manager & Migration / Cloud Update Tools
# ---------------------------------------------------------
def check_and_run_migration():
    if not os.path.exists(TMDB_PLAYERS_PATH):
        try: os.makedirs(TMDB_PLAYERS_PATH)
        except: pass

    master_file = os.path.join(TMDB_PLAYERS_PATH, '(1)MultiBusqueda.json')
    master_movie_url = 'executebuiltin://RunPlugin("plugin://plugin.video.bridge.multi/?action=play&title={es-MX_title}&year={year}&title_es={es-ES_title}&title_lat={es-MX_title}&tmdb={tmdb}&imdb={imdb}&tvdb={tvdb}&trakt={trakt}&plot={plot}&plot_lat={es-MX_plot}&plot_es={es-ES_plot}&tagline={tagline}&tagline_lat={es-MX_tagline}&tagline_es={es-ES_tagline}&director={director}&title_en={en_title}&title_orig={originaltitle}&poster={poster}&fanart={fanart}&thumbnail={thumbnail}")'
    master_ep_url = 'executebuiltin://RunPlugin("plugin://plugin.video.bridge.multi/?action=play&title={es-MX_showname}&season={season}&episode={episode}&showname={showname}&showyear={showyear}&title_es={es-ES_showname}&title_lat={es-MX_showname}&tmdb={tmdb}&imdb={imdb}&tvdb={tvdb}&trakt={trakt}&plot={plot}&plot_lat={es-MX_plot}&plot_es={es-ES_plot}&tagline={tagline}&tagline_lat={es-MX_tagline}&tagline_es={es-ES_tagline}&director={director}&title_en={en_showname}&title_orig={original_name}&poster={poster}&fanart={fanart}&thumbnail={thumbnail}")'

    master_data = {
        "name": "(1) Multi-Busqueda (Alfa / Balandro)",
        "plugin": "plugin.video.bridge.multi",
        "priority": 100,
        "is_resolvable": "false",
        "assert": {
            "play_movie": ["title", "year"],
            "play_episode": ["showname", "season", "episode"]
        },
        "play_movie": master_movie_url,
        "play_episode": master_ep_url,
        "is_folder": "false"
    }

    with open(master_file, 'w', encoding='utf-8') as f:
        json.dump(master_data, f, indent=4, ensure_ascii=False)

    for fname in os.listdir(TMDB_PLAYERS_PATH):
        if not fname.endswith('.json') or fname.startswith('(1)MultiBusqueda'): continue
        fpath = os.path.join(TMDB_PLAYERS_PATH, fname)
        try:
            with open(fpath, 'r', encoding='utf-8') as f: p_data = json.load(f)
            p_data['plugin'] = 'plugin.video.bridge.multi'
            is_alfa = 'alfa' in fname.lower() or 'alfa' in str(p_data.get('play_movie', '')).lower() or 'alfa' in str(p_data.get('play_episode', '')).lower()
            is_series = 'play_episode' in p_data or fname.lower().endswith('-series.json')
            clean_ch = fname.replace('.json', '')
            clean_ch = re.sub(r'^\(\d+\)', '', clean_ch)
            clean_ch = re.sub(r'^(Alfa|Balandro)[\-_]?', '', clean_ch, flags=re.IGNORECASE)
            clean_ch = re.sub(r'-(Series|Movies?)$', '', clean_ch, flags=re.IGNORECASE).strip()

            if is_alfa:
                # ALFA ES EXCLUSIVAMENTE PARA PELICULAS: eliminar cualquier player de series
                if is_series or fname.lower().endswith('-series.json'):
                    try:
                        if os.path.exists(fpath): os.remove(fpath)
                    except: pass
                    continue
                # Limpiar cualquier residuo de play_episode si existiera
                if 'play_episode' in p_data:
                    del p_data['play_episode']
                if 'assert' in p_data and isinstance(p_data['assert'], dict) and 'play_episode' in p_data['assert']:
                    del p_data['assert']['play_episode']
                new_fn = 'Alfa-%s.json' % clean_ch
                p_data['name'] = 'Alfa-%s' % clean_ch
            else:
                new_fn = 'Balandro-%s-Series.json' % clean_ch if is_series else 'Balandro-%s.json' % clean_ch
                p_data['name'] = 'Balandro-%s%s' % (clean_ch, ' (Series)' if is_series else '')

            with open(fpath, 'w', encoding='utf-8') as f:
                json.dump(p_data, f, indent=4, ensure_ascii=False)

            new_path = os.path.join(TMDB_PLAYERS_PATH, new_fn)
            if new_path != fpath:
                if os.path.exists(new_path): os.remove(new_path)
                os.rename(fpath, new_path)
        except Exception: pass

# ---------------------------------------------------------
# Player Management Menus
# ---------------------------------------------------------
def _format_regional_datetime(dt):
    """Formatea fecha y hora respetando estrictamente la configuración regional de Kodi
    (fecha corta y reloj de 12h AM/PM o 24h).
    """
    if not dt:
        return ''

    # 1. Formato de fecha según región de Kodi
    date_str = ''
    try:
        dfmt = xbmc.getRegion('dateshort')
        if dfmt:
            if '%' in dfmt:
                date_str = dt.strftime(dfmt)
            else:
                conv = dfmt.replace('YYYY', '%Y').replace('yyyy', '%Y').replace('MM', '%m').replace('mm', '%m').replace('DD', '%d').replace('dd', '%d')
                date_str = dt.strftime(conv)
    except Exception:
        pass
    if not date_str:
        date_str = dt.strftime('%d/%m/%Y')

    # 2. Formato de hora según región de Kodi (12h AM/PM o 24h)
    time_str = ''
    try:
        tfmt = xbmc.getRegion('time')
        if tfmt:
            if '%' in tfmt:
                clean_tf = tfmt.replace(':%S', '').replace(':%s', '').replace('%H%H', '%H')
                time_str = dt.strftime(clean_tf).strip()
            else:
                conv = tfmt.replace(':ss', '').replace(':SS', '').replace('ss', '').replace('SS', '')
                conv = conv.replace('HH', '%H').replace('hh', '%I').replace('h', '%I').replace('mm', '%M').replace('xx', '%p').replace('XX', '%p')
                time_str = dt.strftime(conv).strip()
    except Exception:
        pass

    if not time_str:
        try:
            tf = str(xbmc.getRegion('timeformat')).lower()
            if '12' in tf:
                time_str = dt.strftime('%I:%M %p').lstrip('0')
            elif '24' in tf:
                time_str = dt.strftime('%H:%M')
        except Exception:
            pass

    if not time_str:
        time_str = dt.strftime('%H:%M')

    return '%s a las %s' % (date_str, time_str)

def _get_last_cloud_import_datetime():
    """Devuelve (datetime_obj, total_count) de la última importación desde la nube.
    Lee CLOUD_SYNC_FILE si existe, o busca el mtime de (1)MultiBusqueda.json en TMDB_PLAYERS_PATH.
    """
    if os.path.exists(CLOUD_SYNC_FILE):
        try:
            with open(CLOUD_SYNC_FILE, 'r', encoding='utf-8') as f:
                d = json.load(f)
            ts = d.get('timestamp')
            tot = d.get('total', 0)
            if ts:
                return datetime.datetime.fromtimestamp(ts), tot
        except Exception:
            pass

    # Fallback automático: fecha de modificación de los players en TMDB_PLAYERS_PATH
    mb_file = os.path.join(TMDB_PLAYERS_PATH, '(1)MultiBusqueda.json')
    if os.path.exists(mb_file):
        try:
            mtime = os.path.getmtime(mb_file)
            tot = len([f for f in os.listdir(TMDB_PLAYERS_PATH) if f.endswith('.json')])
            return datetime.datetime.fromtimestamp(mtime), tot
        except Exception:
            pass

    return None, 0

def show_player_manager_home():
    if handle < 0: return
    alfa_icon = os.path.join(alfa_path, 'resources', 'icon.png')
    if not os.path.exists(alfa_icon): alfa_icon = 'DefaultFolder.png'

    balandro_icon = os.path.join(balandro_path, 'icon.png')
    if not os.path.exists(balandro_icon): balandro_icon = 'DefaultFolder.png'

    last_dt, tot_players = _get_last_cloud_import_datetime()
    if last_dt:
        dt_formatted = _format_regional_datetime(last_dt)
        cloud_plot = (
            'Descargar y sincronizar todos los reproductores de Alfa y Balandro desde GitHub.\n\n'
            '[COLOR lime][B]Última importación:[/B][/COLOR] %s' % dt_formatted
        )
        if tot_players > 0:
            cloud_plot += '\n[COLOR grey]Reproductores actualmente activos: %d[/COLOR]' % tot_players
    else:
        cloud_plot = (
            'Descargar y sincronizar todos los reproductores de Alfa y Balandro desde GitHub.\n\n'
            '[COLOR orange][B]Última importación:[/B] Aún no se ha realizado ninguna importación.[/COLOR]'
        )

    items = [
        ('Alfa', 'Gestor de Players de Alfa (Películas)', 'plugin://plugin.video.bridge.multi/?view=list_players&engine=alfa', alfa_icon, True,
         'Administrar, activar o desactivar reproductores de TMDb Helper para los canales de Alfa.'),
        ('Balandro', 'Gestor de Players de Balandro', 'plugin://plugin.video.bridge.multi/?view=list_players&engine=balandro', balandro_icon, True,
         'Administrar, activar o desactivar reproductores de TMDb Helper para los canales de Balandro (Películas y Series).'),
        ('Crear', 'Crear nuevo Player (Asistente)', 'plugin://plugin.video.bridge.multi/?view=create_player', 'DefaultAddSource.png', False,
         'Asistente guiado paso a paso para generar nuevos reproductores TMDb Helper a partir de canales disponibles.'),
        ('Nube', 'Importar / Actualizar Players desde la Nube', 'plugin://plugin.video.bridge.multi/?view=update_cloud', 'DefaultNetwork.png', False,
         cloud_plot),
        ('Ajustes', 'Ajustes del Addon', 'plugin://plugin.video.bridge.multi/?view=settings', 'DefaultAddonProgram.png', False,
         'Configurar opciones del addon, orden de servidores, calidades, idiomas y repositorio de GitHub.'),
    ]
    for tag, title_str, item_url, icon, is_f, plot_str in items:
        li = xbmcgui.ListItem(label='[B][COLOR deepskyblue][%s][/COLOR] [COLOR white]%s[/COLOR][/B]' % (tag, title_str))
        li.setArt({'thumb': icon, 'icon': icon, 'poster': icon, 'banner': icon})
        try:
            vt = li.getVideoInfoTag()
            if vt:
                vt.setTitle(title_str)
                vt.setPlot(plot_str)
                vt.setMediaType('video')
        except Exception:
            pass
        try:
            li.setInfo('video', {'title': title_str, 'plot': plot_str})
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle, item_url, li, isFolder=is_f)
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)

def _get_counterpart_filename(player_filename):
    """Devuelve el nombre del archivo contraparte (película <-> series) si existe en TMDB_PLAYERS_PATH."""
    if not player_filename or not player_filename.endswith('.json'):
        return None
    base = player_filename[:-5]
    if base.lower().endswith('-series'):
        target = re.sub(r'-series$', '', base, flags=re.IGNORECASE) + '.json'
    else:
        target = base + '-Series.json'

    if os.path.exists(TMDB_PLAYERS_PATH):
        for f in os.listdir(TMDB_PLAYERS_PATH):
            if f.lower() == target.lower():
                return f
    return None

def _get_channel_group_data(engine='alfa'):
    prefix = 'Alfa-' if engine == 'alfa' else 'Balandro-'
    channels = {}
    if not os.path.exists(TMDB_PLAYERS_PATH):
        return channels
    for fname in sorted(os.listdir(TMDB_PLAYERS_PATH)):
        if fname.lower().startswith(prefix.lower()) and fname.endswith('.json'):
            fpath = os.path.join(TMDB_PLAYERS_PATH, fname)
            clean = fname[:-5]
            if clean.lower().startswith(prefix.lower()):
                clean = clean[len(prefix):]
            is_series = False
            if clean.lower().endswith('-series'):
                clean = re.sub(r'-series$', '', clean, flags=re.IGNORECASE)
                is_series = True
            norm_key = clean.lower().strip()
            if norm_key not in channels:
                channels[norm_key] = {
                    'name': clean.strip(),
                    'movie_file': None,
                    'series_file': None,
                    'movie_disabled': False,
                    'series_disabled': False
                }
            data = {}
            try:
                with open(fpath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                dis = str(data.get('disabled', '')).lower() in ('true', '1') or data.get('disabled') is True
            except:
                dis = False
            if is_series or 'play_episode' in data:
                channels[norm_key]['series_file'] = fname
                channels[norm_key]['series_disabled'] = dis
            else:
                channels[norm_key]['movie_file'] = fname
                channels[norm_key]['movie_disabled'] = dis
    return channels

def _set_player_disabled(filename, dis_str):
    if not filename: return
    fpath = os.path.join(TMDB_PLAYERS_PATH, filename)
    if not os.path.exists(fpath): return
    try:
        with open(fpath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        data['disabled'] = dis_str
        with open(fpath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except: pass

def _get_channel_icon_and_info(channel_id, engine='alfa', player_file=None):
    """Obtiene el icono original y la información de un canal directamente desde la ruta de su addon
    (Alfa o Balandro), sin descargar ni almacenar ninguna imagen en Bridge Multi.
    Soporta URLs remotas y rutas locales de forma nativa.
    """
    addon_path = alfa_path if engine == 'alfa' else balandro_path
    ch_dir = os.path.join(addon_path, 'channels')

    ch_json = os.path.join(ch_dir, channel_id + '.json')
    if not os.path.exists(ch_json) and os.path.exists(ch_dir):
        for f in os.listdir(ch_dir):
            if f.lower() == (channel_id + '.json').lower():
                ch_json = os.path.join(ch_dir, f)
                break

    # Si no existe por nombre directo, intentar extraer el canal incrustado en el archivo player
    if not os.path.exists(ch_json) and player_file:
        pf_path = os.path.join(TMDB_PLAYERS_PATH, player_file)
        if os.path.exists(pf_path):
            try:
                with open(pf_path, 'r', encoding='utf-8') as f:
                    pdata = json.load(f)
                pm = pdata.get('play_movie') or pdata.get('play_episode') or []
                url = pm[0] if isinstance(pm, list) and pm else (pm if isinstance(pm, str) else '')
                emb = None
                if 'channel=' in url:
                    m = re.search(r'channel=([^&]+)', url)
                    if m: emb = m.group(1)
                elif 'url=plugin://' in url:
                    sub = url.split('url=plugin://')[1].split('&')[0]
                    if '?' in sub:
                        q = sub.split('?', 1)[1]
                        dec = json.loads(urllib.parse.unquote(base64.b64decode(urllib.parse.unquote(q)).decode('utf-8')))
                        emb = dec.get('channel')
                if emb:
                    cand = os.path.join(ch_dir, emb + '.json')
                    if os.path.exists(cand):
                        ch_json = cand
            except:
                pass

    # Si aún no existe, buscar por coincidencia parcial en channels
    if not os.path.exists(ch_json) and os.path.exists(ch_dir):
        for f in os.listdir(ch_dir):
            if f.endswith('.json') and (f.lower().startswith(channel_id.lower()) or channel_id.lower().startswith(f[:-5].lower())):
                ch_json = os.path.join(ch_dir, f)
                break

    icon = None
    title = ''
    plot = ''

    if os.path.exists(ch_json):
        try:
            with open(ch_json, 'r', encoding='utf-8', errors='ignore') as f:
                ch_data = json.load(f)
            title = ch_data.get('name') or ''
            plot = ch_data.get('notes') or ''

            thumb = ch_data.get('thumbnail') or ch_data.get('banner') or ''
            if thumb:
                if thumb.startswith('http://') or thumb.startswith('https://'):
                    icon = thumb
                else:
                    local_thumb = os.path.join(addon_path, 'resources', 'media', 'channels', 'thumb', thumb)
                    if os.path.exists(local_thumb):
                        icon = local_thumb
                    else:
                        local_thumb2 = os.path.join(addon_path, 'resources', 'media', 'channels', thumb)
                        if os.path.exists(local_thumb2):
                            icon = local_thumb2

            if not plot:
                langs = [str(l).upper() for l in ch_data.get('language', [])]
                cats = [str(c).capitalize() for c in ch_data.get('categories', [])]
                parts = []
                if langs: parts.append('Idiomas: ' + ', '.join(langs))
                if cats: parts.append('Categorías: ' + ', '.join(cats))
                if parts: plot = ' | '.join(parts)
        except:
            pass

    if not icon:
        for ext in ('.jpg', '.png', '.jpeg'):
            cand_thumb = os.path.join(addon_path, 'resources', 'media', 'channels', 'thumb', channel_id + ext)
            if os.path.exists(cand_thumb):
                icon = cand_thumb
                break

    if not icon:
        for cand_icon in (os.path.join(addon_path, 'resources', 'icon.png'), os.path.join(addon_path, 'icon.png')):
            if os.path.exists(cand_icon):
                icon = cand_icon
                break

    if not icon:
        icon = 'DefaultFolder.png'

    return icon, title, plot

def show_players_list(engine='alfa'):
    if handle < 0: return
    if not os.path.exists(TMDB_PLAYERS_PATH):
        xbmcplugin.endOfDirectory(handle); return

    channels = _get_channel_group_data(engine=engine)
    if not channels:
        xbmcplugin.endOfDirectory(handle); return

    for norm_key in sorted(channels.keys(), key=lambda x: channels[x]['name'].lower()):
        info = channels[norm_key]
        name = info['name']
        m_file = info['movie_file']
        s_file = info['series_file']
        m_dis = info['movie_disabled']
        s_dis = info['series_disabled']

        has_both = bool(m_file and s_file)
        has_movie = bool(m_file)
        has_series = bool(s_file)

        if has_both:
            if not m_dis and not s_dis:
                status_icon = '[COLOR lime]●[/COLOR]'
                type_str = '[COLOR deepskyblue]Películas[/COLOR] + [COLOR gold]Series[/COLOR]'
            elif m_dis and s_dis:
                status_icon = '[COLOR red]●[/COLOR]'
                type_str = '[COLOR gray]Desactivado[/COLOR]'
            elif not m_dis and s_dis:
                status_icon = '[COLOR orange]●[/COLOR]'
                type_str = '[COLOR deepskyblue]Películas[/COLOR] [COLOR gray]| Series Desactivadas[/COLOR]'
            else:
                status_icon = '[COLOR orange]●[/COLOR]'
                type_str = '[COLOR gold]Series[/COLOR] [COLOR gray]| Películas Desactivadas[/COLOR]'
        elif has_movie:
            if not m_dis:
                status_icon = '[COLOR lime]●[/COLOR]'
                type_str = '[COLOR deepskyblue]Solo Películas[/COLOR]'
            else:
                status_icon = '[COLOR red]●[/COLOR]'
                type_str = '[COLOR gray]Desactivado (Películas)[/COLOR]'
        else:
            if not s_dis:
                status_icon = '[COLOR lime]●[/COLOR]'
                type_str = '[COLOR gold]Solo Series[/COLOR]'
            else:
                status_icon = '[COLOR red]●[/COLOR]'
                type_str = '[COLOR gray]Desactivado (Series)[/COLOR]'

        lbl = '%s  [B]%s[/B]   [%s]' % (status_icon, name, type_str)
        opt_url = 'plugin://plugin.video.bridge.multi/?view=player_options&channel=%s&engine=%s' % (norm_key, engine)
        li = xbmcgui.ListItem(label=lbl)

        sample_file = m_file or s_file
        icon, ch_title, ch_plot = _get_channel_icon_and_info(norm_key, engine=engine, player_file=sample_file)

        li.setArt({
            'thumb': icon,
            'icon': icon,
            'poster': icon,
            'banner': icon
        })

        display_title = ch_title if ch_title else name
        desc_plot = ch_plot if ch_plot else ('Canal de %s' % engine.capitalize())

        try:
            vt = li.getVideoInfoTag()
            if vt:
                vt.setTitle(display_title)
                vt.setPlot(desc_plot)
                vt.setMediaType('video')
        except Exception:
            pass
        try:
            li.setInfo('video', {'title': display_title, 'plot': desc_plot})
        except Exception:
            pass

        xbmcplugin.addDirectoryItem(handle, opt_url, li, isFolder=False)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)

def show_player_options(player_filename, engine='alfa'):
    if not player_filename: return
    dialog = xbmcgui.Dialog()

    channels = _get_channel_group_data(engine=engine)
    clean_key = player_filename.lower().replace('.json', '')
    prefix = 'alfa-' if engine == 'alfa' else 'balandro-'
    if clean_key.startswith(prefix):
        clean_key = clean_key[len(prefix):]
    clean_key = re.sub(r'-series$', '', clean_key, flags=re.IGNORECASE).strip()

    info = channels.get(clean_key)
    if not info:
        for k, v in channels.items():
            if v['name'].lower() == clean_key:
                info = v
                break

    if not info:
        fpath = os.path.join(TMDB_PLAYERS_PATH, player_filename)
        if not os.path.exists(fpath): return
        try:
            with open(fpath, 'r', encoding='utf-8') as f: data = json.load(f)
            dis = str(data.get('disabled', '')).lower() in ('true', '1') or data.get('disabled') is True
            new_dis = 'false' if dis else 'true'
            data['disabled'] = new_dis
            with open(fpath, 'w', encoding='utf-8') as f: json.dump(data, f, indent=4, ensure_ascii=False)
            dialog.notification('Bridge Multi', 'Player actualizado', '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        except: pass
        return

    name = info['name']
    m_file = info['movie_file']
    s_file = info['series_file']
    m_dis = info['movie_disabled']
    s_dis = info['series_disabled']

    has_both = bool(m_file and s_file)

    if has_both:
        opt_movie = ('[COLOR red]Desactivar[/COLOR] Películas' if not m_dis else '[COLOR lime]Activar[/COLOR] Películas')
        opt_series = ('[COLOR red]Desactivar[/COLOR] Series' if not s_dis else '[COLOR lime]Activar[/COLOR] Series')
        both_active = (not m_dis and not s_dis)
        opt_all = ('[COLOR red]Desactivar Todo[/COLOR] (Películas y Series)' if both_active else '[COLOR lime]Activar Todo[/COLOR] (Películas y Series)')
        opt_delete = '[COLOR red]Eliminar Canal[/COLOR] (ambos reproductores)'
        opt_back = 'Volver'

        options = [opt_movie, opt_series, opt_all, opt_delete, opt_back]
        sel = dialog.select('Canal: %s' % name, options)

        if sel == 0:
            new_val = 'true' if not m_dis else 'false'
            _set_player_disabled(m_file, new_val)
            dialog.notification('Bridge Multi', 'Películas de %s %s' % (name, 'desactivadas' if new_val == 'true' else 'activadas'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 1:
            new_val = 'true' if not s_dis else 'false'
            _set_player_disabled(s_file, new_val)
            dialog.notification('Bridge Multi', 'Series de %s %s' % (name, 'desactivadas' if new_val == 'true' else 'activadas'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 2:
            new_val = 'true' if both_active else 'false'
            _set_player_disabled(m_file, new_val)
            _set_player_disabled(s_file, new_val)
            dialog.notification('Bridge Multi', '%s %s' % (name, 'desactivado' if new_val == 'true' else 'activado'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 3:
            if dialog.yesno('Eliminar Canal', '¿Seguro que deseas eliminar el canal %s y todos sus reproductores?' % name):
                if m_file:
                    try: os.remove(os.path.join(TMDB_PLAYERS_PATH, m_file))
                    except: pass
                if s_file:
                    try: os.remove(os.path.join(TMDB_PLAYERS_PATH, s_file))
                    except: pass
                dialog.notification('Bridge Multi', '%s eliminado' % name, '', 2000)
                xbmc.executebuiltin('Container.Refresh')

    else:
        target_file = m_file or s_file
        target_type = 'Películas' if m_file else 'Series'
        is_dis = m_dis if m_file else s_dis

        opt_toggle = ('[COLOR red]Desactivar[/COLOR] %s' % target_type if not is_dis else '[COLOR lime]Activar[/COLOR] %s' % target_type)
        opt_delete = '[COLOR red]Eliminar Canal[/COLOR]'
        opt_back = 'Volver'

        options = [opt_toggle, opt_delete, opt_back]
        sel = dialog.select('Canal: %s (%s)' % (name, target_type), options)

        if sel == 0:
            new_val = 'true' if not is_dis else 'false'
            _set_player_disabled(target_file, new_val)
            dialog.notification('Bridge Multi', '%s (%s) %s' % (name, target_type, 'desactivado' if new_val == 'true' else 'activado'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 1:
            if dialog.yesno('Eliminar Canal', '¿Seguro que deseas eliminar el canal %s?' % name):
                try: os.remove(os.path.join(TMDB_PLAYERS_PATH, target_file))
                except: pass
                dialog.notification('Bridge Multi', '%s eliminado' % name, '', 2000)
                xbmc.executebuiltin('Container.Refresh')

def _detect_channel_capabilities(engine, channel_id, mods_path):
    ch_json = os.path.join(mods_path, 'channels', channel_id + '.json')
    supports_movies = True
    supports_series = False
    if os.path.exists(ch_json):
        try:
            with open(ch_json, 'r', encoding='utf-8') as f:
                d = json.load(f)
            cats = [str(c).lower() for c in d.get('categories', [])]
            stypes = [str(s).lower() for s in d.get('search_types', [])]
            if cats or stypes:
                supports_movies = ('movie' in cats or 'movie' in stypes or 'all' in stypes)
                supports_series = ('tvshow' in cats or 'tvshow' in stypes or 'series' in cats)
        except: pass
    if not supports_series:
        ch_py = os.path.join(mods_path, 'channels', channel_id + '.py')
        if os.path.exists(ch_py):
            try:
                with open(ch_py, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                supports_series = bool('episodios' in content or 'temporadas' in content or 'search_type == "tvshow"' in content)
            except: pass
    return supports_movies, supports_series

def _write_single_player(engine, channel_id, is_series):
    ch_clean = channel_id.capitalize()
    fn = '%s-%s-Series.json' % (engine.capitalize(), ch_clean) if is_series else '%s-%s.json' % (engine.capitalize(), ch_clean)
    p_name = '%s-%s%s' % (engine.capitalize(), ch_clean, ' (Series)' if is_series else '')

    match_regex = '(?i)^({es-ES_title}|{es-MX_title}|{en_title}|{originaltitle}|.+)'
    ep_regex = '(?i)^({es-ES_showname}|{es-MX_showname}|{en_showname}|{original_name}|.+)'
    play_url = 'plugin://plugin.video.bridge.multi/?url=plugin://plugin.video.%s/?channel=%s' % (engine, channel_id)
    play_url += '&title={title}&title_es={es-ES_title}&title_lat={es-MX_title}&title_en={en_title}&title_orig={originaltitle}&tmdb={tmdb}&imdb={imdb}&year={year}'
    play_ep_url = 'plugin://plugin.video.bridge.multi/?url=plugin://plugin.video.%s/?channel=%s' % (engine, channel_id)
    play_ep_url += '&showname={showname}&showyear={showyear}&season={season}&episode={episode}&title={showname}&tmdb={tmdb}&imdb={imdb}'

    player_data = {
        "name": p_name,
        "plugin": "plugin.video.bridge.multi",
        "priority": 200,
        "is_resolvable": "true",
        "assert": {"play_episode": ["showname", "season", "episode"]} if is_series else {"play_movie": ["title", "year"]},
        "play_episode" if is_series else "play_movie": [
            play_ep_url if is_series else play_url,
            {"title": ep_regex, "season": "{season}", "episode": "{episode}"} if is_series else {"title": match_regex, "year": "{year}"}
        ],
        "is_folder": "false"
    }

    dest = os.path.join(TMDB_PLAYERS_PATH, fn)
    with open(dest, 'w', encoding='utf-8') as f:
        json.dump(player_data, f, indent=4, ensure_ascii=False)
    return fn

def create_player_wizard():
    dialog = xbmcgui.Dialog()
    engine_choice = dialog.select('¿Para qué addon deseas crear el player?', ['Alfa (Solo Películas)', 'Balandro'])
    if engine_choice < 0: return
    engine = 'alfa' if engine_choice == 0 else 'balandro'

    mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
    if not mods:
        dialog.ok('Bridge Multi', 'El addon %s no está instalado o disponible.' % engine.capitalize())
        return

    channels_dir = os.path.join(mods['path'], 'channels')
    if not os.path.exists(channels_dir): return
    available = []
    for f in sorted(os.listdir(channels_dir)):
        if f.endswith('.py') and not f.startswith('__'):
            ch_id = f.replace('.py', '')
            available.append(ch_id)

    sel_ch = dialog.select('Selecciona Canal de %s' % engine.capitalize(), [c.capitalize() for c in available])
    if sel_ch < 0: return
    chosen_id = available[sel_ch]
    ch_clean = chosen_id.capitalize()

    supports_movies, supports_series = _detect_channel_capabilities(engine, chosen_id, mods['path'])

    created_files = []
    if engine == 'balandro' and supports_series:
        if supports_movies:
            opts = [
                'Crear Ambos (Películas y Series)',
                'Solo Películas',
                'Solo Series',
                'Cancelar'
            ]
            choice = dialog.select('El canal %s también soporta Series' % ch_clean, opts)
            if choice == 0:
                created_files.append(_write_single_player(engine, chosen_id, is_series=False))
                created_files.append(_write_single_player(engine, chosen_id, is_series=True))
            elif choice == 1:
                created_files.append(_write_single_player(engine, chosen_id, is_series=False))
            elif choice == 2:
                created_files.append(_write_single_player(engine, chosen_id, is_series=True))
            else:
                return
        else:
            created_files.append(_write_single_player(engine, chosen_id, is_series=True))
    else:
        created_files.append(_write_single_player(engine, chosen_id, is_series=False))

    if created_files:
        files_str = '\n'.join(['• %s' % fn for fn in created_files])
        dialog.ok('Bridge Multi', '¡Player(s) creado(s) con éxito!\n\n%s' % files_str)

def update_players_from_cloud():
    """Descarga e importa todos los players desde el repositorio de GitHub (01xKeven/Players-Multi),
    extrayendo los archivos JSON de las carpetas 'players alfa' y 'players balandro', y reemplazando
    siempre de forma limpia y completa todos los players correspondientes en la carpeta de TMDb Helper.
    """
    import zipfile
    import io

    dialog = xbmcgui.Dialog()
    repo_url = _bridge_addon.getSetting('cloud_repo_url') if _bridge_addon else ''
    if not repo_url or not repo_url.strip():
        repo_url = 'https://github.com/01xKeven/Players-Multi'

    confirm = dialog.yesno(
        'Bridge Multi — Nube',
        '¿Deseas descargar y reemplazar todos los players de TMDb Helper con la versión más reciente de la Nube (GitHub)?\n\n'
        '[COLOR deepskyblue]Repositorio:[/COLOR] %s\n'
        '[COLOR gold]Aviso:[/COLOR] Se reemplazarán todos los reproductores de Alfa y Balandro.' % repo_url
    )
    if not confirm:
        return

    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('Bridge Multi — Nube', 'Conectando con GitHub...')
    p_dialog.update(10, 'Descargando repositorio de players desde GitHub...')

    # Limpiar URL del repo para formar URLs de descarga
    clean_repo = repo_url.strip().rstrip('/')
    if clean_repo.startswith('https://github.com/'):
        clean_repo = clean_repo[len('https://github.com/'):]
    elif clean_repo.startswith('http://github.com/'):
        clean_repo = clean_repo[len('http://github.com/'):]

    token = _bridge_addon.getSetting('github_token').strip() if _bridge_addon else ''

    zip_candidates = [
        'https://github.com/%s/archive/refs/heads/master.zip' % clean_repo,
        'https://github.com/%s/archive/refs/heads/main.zip' % clean_repo,
        'https://codeload.github.com/%s/zip/refs/heads/master' % clean_repo,
        'https://codeload.github.com/%s/zip/refs/heads/main' % clean_repo
    ]

    zip_data = None
    headers = {'User-Agent': 'Mozilla/5.0'}
    if token:
        headers['Authorization'] = 'token %s' % token

    download_error = ''
    for u in zip_candidates:
        if p_dialog.iscanceled():
            p_dialog.close()
            return
        try:
            xbmc.log('Bridge Multi Nube: intentando descargar ' + u, xbmc.LOGINFO)
            req = urllib.request.Request(u, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as resp:
                if resp.status == 200:
                    zip_data = resp.read()
                    break
        except Exception as e:
            download_error = str(e)
            xbmc.log('Bridge Multi Nube: error descargando ' + u + ': ' + str(e), xbmc.LOGWARNING)

    if not zip_data:
        try: p_dialog.close()
        except: pass
        dialog.ok(
            'Bridge Multi — Error en Nube',
            'No se pudo descargar el archivo ZIP desde GitHub.\n\n'
            '[COLOR red]Detalle:[/COLOR] %s\n'
            'Verifica tu conexión a internet o el repositorio: %s' % (download_error or 'Descarga fallida', repo_url)
        )
        return

    p_dialog.update(50, 'Procesando archivo ZIP descargado...')

    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_data))
    except Exception as e:
        try: p_dialog.close()
        except: pass
        dialog.ok('Bridge Multi — Error', 'El archivo descargado no es un archivo ZIP válido: ' + str(e))
        return

    if not os.path.exists(TMDB_PLAYERS_PATH):
        try: os.makedirs(TMDB_PLAYERS_PATH)
        except: pass

    p_dialog.update(70, 'Limpiando y reemplazando reproductores en TMDb Helper...')

    # Eliminar players anteriores de Alfa, Balandro y MultiBusqueda para reemplazo completo
    try:
        for existing_fn in os.listdir(TMDB_PLAYERS_PATH):
            if not existing_fn.endswith('.json'): continue
            fn_low = existing_fn.lower()
            if fn_low.startswith('alfa-') or fn_low.startswith('balandro-') or fn_low.startswith('(1)multibusqueda'):
                try: os.remove(os.path.join(TMDB_PLAYERS_PATH, existing_fn))
                except: pass
    except Exception as e:
        xbmc.log('Bridge Multi Nube: error limpiando players anteriores: ' + str(e), xbmc.LOGWARNING)

    p_dialog.update(80, 'Extrayendo nuevos players de Alfa y Balandro...')

    alfa_count = 0
    balandro_count = 0
    other_count = 0

    try:
        for item in zf.infolist():
            if item.is_dir(): continue
            fname = os.path.basename(item.filename)
            if not fname.endswith('.json'): continue

            norm_path = item.filename.replace('\\', '/').lower()
            is_alfa = '/players alfa/' in norm_path or norm_path.startswith('players alfa/') or norm_path.startswith('alfa/')
            is_balandro = '/players balandro/' in norm_path or norm_path.startswith('players balandro/') or norm_path.startswith('balandro/')

            if is_alfa or is_balandro:
                dest_path = os.path.join(TMDB_PLAYERS_PATH, fname)
                content = zf.read(item.filename)
                with open(dest_path, 'wb') as out_f:
                    out_f.write(content)

                if is_alfa:
                    alfa_count += 1
                elif is_balandro:
                    balandro_count += 1
                else:
                    other_count += 1
    except Exception as e:
        try: p_dialog.close()
        except: pass
        dialog.ok('Bridge Multi — Error', 'Error al extraer players del archivo ZIP: ' + str(e))
        return

    p_dialog.update(95, 'Finalizando sincronización y verificando...')
    try:
        check_and_run_migration()
    except Exception:
        pass

    try: p_dialog.close()
    except: pass

    total_count = alfa_count + balandro_count + other_count

    try:
        sync_payload = {
            'timestamp': int(datetime.datetime.now().timestamp()),
            'iso': datetime.datetime.now().isoformat(),
            'total_alfa': alfa_count,
            'total_balandro': balandro_count,
            'total': total_count
        }
        with open(CLOUD_SYNC_FILE, 'w', encoding='utf-8') as _cf:
            json.dump(sync_payload, _cf, indent=4)
    except Exception as e:
        xbmc.log('Bridge Multi Nube: error guardando sync_info: ' + str(e), xbmc.LOGWARNING)

    dialog.ok(
        'Bridge Multi — Nube',
        '¡Sincronización de la Nube completada!\n\n'
        '• [B][COLOR deepskyblue]Players Alfa:[/COLOR][/B] %d importados\n'
        '• [B][COLOR gold]Players Balandro:[/COLOR][/B] %d importados\n'
        '• [B][COLOR lime]Total actualizados:[/COLOR][/B] %d reproductores\n\n'
        'Todos los players de TMDb Helper han sido reemplazados y actualizados con éxito.' % (alfa_count, balandro_count, total_count)
    )

# ---------------------------------------------------------
# Custom Engine Picker Dialog (ventana personalizada)
# ---------------------------------------------------------
class _EnginePickerDialog(xbmcgui.WindowDialog):
    ACTION_MOVE_LEFT   = 1
    ACTION_MOVE_RIGHT  = 2
    ACTION_SELECT_ITEM = 7
    ACTION_PREVIOUS_MENU = 10
    ACTION_NAV_BACK    = 92
    ACTION_MOUSE_MOVE  = 107

    def __init__(self, alfa_icon_path, balandro_icon_path):
        super().__init__()
        self.selected = -1          # -1 = cancelado
        self.current  = 0           # 0=Alfa 1=Balandro
        self._alfa_icon  = alfa_icon_path
        self._bal_icon   = balandro_icon_path
        self._alfa_hls   = []
        self._bal_hls    = []
        self._alfa_img_id = -1
        self._bal_img_id  = -1
        try:
            self._build()
        except Exception as e:
            xbmc.log('BridgeMulti EnginePickerDialog build error: ' + str(e), xbmc.LOGWARNING)

    @staticmethod
    def _white():
        # Textura blanca integrada del skin Estuary de Kodi (no requiere archivo propio)
        import xbmcvfs
        candidates = [
            'special://xbmc/addons/skin.estuary/media/white-diffuse.png',
            'special://xbmc/addons/skin.estuary/media/Colours/white.png',
            'special://xbmcbin/addons/skin.estuary/media/white-diffuse.png',
        ]
        for c in candidates:
            if xbmcvfs.exists(c):
                return c
        # Fallback: crear un PNG blanco 1x1 en memoria temporal
        import tempfile, struct, zlib
        _png = (b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01'
                b'\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc\xf8\xff\xff'
                b'\x3f\x00\x05\xfe\x02\xfe\xdc\xccY\xe7\x00\x00\x00\x00IEND\xaeB`\x82')
        _tmp = os.path.join(tempfile.gettempdir(), 'bm_white.png')
        try:
            if not os.path.exists(_tmp):
                with open(_tmp, 'wb') as _f: _f.write(_png)
        except: pass
        return _tmp


    def _build(self):
        W = self.getWidth()
        H = self.getHeight()

        # ----- dimensiones del dialogo -----
        dw, dh = 660, 340
        dx = (W - dw) // 2
        dy = (H - dh) // 2
        border = 4
        white  = self._white()

        # Borde dorado exterior
        self.addControl(xbmcgui.ControlImage(
            dx, dy, dw, dh, white, colorDiffuse='0xFFCFA82C'))

        # Fondo oscuro interior (negro puro)
        self.addControl(xbmcgui.ControlImage(
            dx+border, dy+border, dw-border*2, dh-border*2,
            white, colorDiffuse='0xFF000000'))

        # Titulo
        self.addControl(xbmcgui.ControlLabel(
            dx, dy+14, dw, 36,
            '[B]¿Con qué addon deseas buscar?[/B]',
            font='font13', textColor='0xFFCFA82C', alignment=6))

        # Línea separadora dorada
        self.addControl(xbmcgui.ControlImage(
            dx+30, dy+56, dw-60, 2, white, colorDiffuse='0x55CFA82C'))

        # ----- opciones: iconos centrados horizontalmente -----
        icon_sz  = 148
        gap      = 100
        total_w  = icon_sz*2 + gap
        opt1_x   = dx + (dw - total_w) // 2
        opt2_x   = opt1_x + icon_sz + gap
        icon_y   = dy + 76

        # --- Alfa ---
        alfa_img = xbmcgui.ControlImage(opt1_x, icon_y, icon_sz, icon_sz, self._alfa_icon)
        self.addControl(alfa_img)
        self._alfa_img_id = alfa_img.getId()

        self.addControl(xbmcgui.ControlLabel(
            opt1_x, icon_y+icon_sz+6, icon_sz, 32,
            '[B]Alfa[/B]', font='font13',
            textColor='0xFFFFFFFF', alignment=6))

        # --- Balandro ---
        bal_img = xbmcgui.ControlImage(opt2_x, icon_y, icon_sz, icon_sz, self._bal_icon)
        self.addControl(bal_img)
        self._bal_img_id = bal_img.getId()

        self.addControl(xbmcgui.ControlLabel(
            opt2_x, icon_y+icon_sz+6, icon_sz, 32,
            '[B]Balandro[/B]', font='font13',
            textColor='0xFFFFFFFF', alignment=6))

        # ----- highlight dorado (4 lados como borde) -----
        hl_mg  = 8
        hl_sz  = icon_sz + hl_mg*2
        thick  = 3
        GOLD   = '0xFFCFA82C'

        def make_hl(ox, oy):
            return [
                xbmcgui.ControlImage(ox-hl_mg,           oy-hl_mg,           hl_sz,  thick, white, colorDiffuse=GOLD),
                xbmcgui.ControlImage(ox-hl_mg,           oy+icon_sz+hl_mg-thick, hl_sz,  thick, white, colorDiffuse=GOLD),
                xbmcgui.ControlImage(ox-hl_mg,           oy-hl_mg,           thick, hl_sz, white, colorDiffuse=GOLD),
                xbmcgui.ControlImage(ox+icon_sz+hl_mg-thick, oy-hl_mg,       thick, hl_sz, white, colorDiffuse=GOLD),
            ]

        self._alfa_hls = make_hl(opt1_x, icon_y)
        self._bal_hls  = make_hl(opt2_x, icon_y)

        for c in self._alfa_hls + self._bal_hls:
            self.addControl(c)

        # Hint
        self.addControl(xbmcgui.ControlLabel(
            dx, dy+dh-34, dw, 28,
            '[COLOR=888888][← →] Navegar    [OK] Confirmar    [Atrás] Cancelar[/COLOR]',
            font='font12', textColor='0xFF888888', alignment=6))

        self._update_highlight()

    def _update_highlight(self):
        for c in self._alfa_hls:
            c.setVisible(self.current == 0)
        for c in self._bal_hls:
            c.setVisible(self.current == 1)

    def onAction(self, action):
        aid = action.getId()
        if aid in (self.ACTION_PREVIOUS_MENU, self.ACTION_NAV_BACK):
            self.selected = -1
            self.close()
        elif aid == self.ACTION_MOVE_LEFT:
            self.current = 0
            self._update_highlight()
        elif aid == self.ACTION_MOVE_RIGHT:
            self.current = 1
            self._update_highlight()
        elif aid == self.ACTION_SELECT_ITEM:
            self.selected = self.current
            self.close()

    def onClick(self, control_id):
        if control_id == self._alfa_img_id:
            self.selected = 0
            self.close()
        elif control_id == self._bal_img_id:
            self.selected = 1
            self.close()


def _show_engine_picker():
    """Muestra la ventana personalizada de seleccion de motor.
    Devuelve 'alfa', 'balandro' o None si se cancela."""
    try:
        alfa_addon = xbmcaddon.Addon('plugin.video.alfa')
        alfa_icon  = os.path.join(alfa_addon.getAddonInfo('path'), 'resources', 'icon.png')
        if not os.path.exists(alfa_icon):
            alfa_icon = alfa_addon.getAddonInfo('icon') or ''
    except Exception:
        alfa_icon = ''

    try:
        bal_addon  = xbmcaddon.Addon('plugin.video.balandro')
        bal_icon   = os.path.join(bal_addon.getAddonInfo('path'), 'icon.png')
        if not os.path.exists(bal_icon):
            bal_icon = bal_addon.getAddonInfo('icon') or ''
    except Exception:
        bal_icon = ''

    try:
        dlg = _EnginePickerDialog(alfa_icon, bal_icon)
        dlg.doModal()
        sel = dlg.selected
        del dlg
    except Exception as e:
        xbmc.log('BridgeMulti _show_engine_picker error: ' + str(e), xbmc.LOGWARNING)
        # Fallback al dialogo nativo de Kodi si algo falla
        fb = xbmcgui.Dialog().select(
            '¿Dónde deseas buscar?',
            ['[B][COLOR gold]Alfa[/COLOR][/B]', '[B][COLOR deepskyblue]Balandro[/COLOR][/B]'])
        return ('alfa' if fb == 0 else 'balandro') if fb >= 0 else None

    if sel < 0:
        return None
    return 'alfa' if sel == 0 else 'balandro'


# ---------------------------------------------------------
# Main Execution Entry Point
# ---------------------------------------------------------
def main():
    global plot, plot_lat, plot_es, tagline, tagline_lat, tagline_es
    global title, title_es, title_lat, title_en, title_orig
    global showname, year, showyear, season, episode
    global tmdb_id, imdb_id, tvdb_id, trakt_id
    global poster, fanart, thumbnail, director

    check_and_run_migration()

    if not action and not url:
        if not view or view == 'home': show_player_manager_home()
        elif view == 'list_players': show_players_list(engine_param or 'alfa')
        elif view in ('player_options', 'channel_options'): show_player_options(get_param('channel') or get_param('player'), engine_param or 'alfa')
        elif view == 'create_player': create_player_wizard()
        elif view == 'update_cloud': update_players_from_cloud()
        elif view == 'settings': _bridge_addon.openSettings(); (show_player_manager_home() if handle >= 0 else None)
        elif view == 'list_links': show_links_as_directory()
        else: show_player_manager_home()
        return

    if action == 'search_other_engine':

        _se_engine = get_param('engine') or 'alfa'

        # Cargar el cache e inyectar metadata
        _se_meta = {}
        _se_item = None
        try:
            if os.path.exists(SEARCH_CACHE_FILE):
                with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as _f:
                    _sc = json.load(_f)
                    _se_meta = _sc.get('meta', {})
                    _se_item = _deserialize_item(_sc.get('item'), _se_engine)
        except: pass

        _se_is_series = bool(season or get_param('season') or (_se_meta.get('season') and _se_meta.get('episode')))
        if _se_is_series and _se_engine == 'alfa':
            xbmcgui.Dialog().notification('Bridge Multi', 'Alfa solo está disponible para películas', '', 3500)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        def _g(k): return _se_meta.get(k) or ''

        title      = _g('title')      or title
        title_es   = _g('title_es')
        title_lat  = _g('title_lat')
        title_en   = _g('title_en')
        title_orig = _g('title_orig')
        showname   = _g('showname')   or showname
        year       = _g('year')       or year
        showyear   = _g('showyear')   or showyear
        season     = _g('season')     or season
        episode    = _g('episode')    or episode
        tmdb_id    = _g('tmdb')       or tmdb_id
        imdb_id    = _g('imdb')       or imdb_id
        tvdb_id    = _g('tvdb')       or tvdb_id
        trakt_id   = _g('trakt')      or trakt_id

        xbmc.log('Bridge Multi: search_other_engine=%s title=%s tmdb=%s' % (_se_engine, title, tmdb_id), xbmc.LOGINFO)

        _se_links, _se_matched = run_parallel_search(engine=_se_engine)

        _se_verified = False
        _auto_v = _bridge_addon.getSetting('auto_verify_links') == 'true'
        if _se_links and _auto_v:
            _pv = xbmcgui.DialogProgress()
            _pv.create('Bridge Multi', 'Comprobando disponibilidad...')
            _vl = _verify_links_headless(_se_links, engine=_se_engine, p_dialog=_pv)
            try: _pv.close()
            except: pass
            if _vl:
                _se_links  = _filter_and_sort_links(_vl)
                _se_verified = True

        _se_meta2 = dict(_se_meta)
        _se_meta2['engine'] = _se_engine
        _se_meta2['verified_only'] = _se_verified

        if _se_matched:
            _enrich_link_metadata(None, _se_meta2, _se_matched)
        try:
            with open(SEARCH_CACHE_FILE, 'w', encoding='utf-8') as _fw:
                json.dump({
                    'item': _serialize_item(_se_matched) if _se_matched else None,
                    'links': [_serialize_item(l) for l in (_se_links or [])],
                    'meta': _se_meta2,
                    'engine': _se_engine
                }, _fw)
        except: pass

        if not _se_links:
            _eng_name = 'Alfa' if _se_engine == 'alfa' else 'Balandro'
            xbmcgui.Dialog().notification('Bridge Multi', 'No se encontraron enlaces en %s' % _eng_name, '', 4000)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        _ts2 = int(time.time())
        _win_url2 = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (str(tmdb_id or _g('tmdb') or ''), _ts2)
        if _se_meta2.get('season') and _se_meta2.get('episode'):
            _win_url2 += '&season=%s&episode=%s' % (_se_meta2['season'], _se_meta2['episode'])
        xbmc.executebuiltin('ActivateWindow(10025, "%s", return)' % _win_url2)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    if action == 'verify_links':
        verify_and_filter_links()
        return

    if action == 'play_single_link':
        idx_str = get_param('index')
        eng = engine_param or 'alfa'
        try: idx = int(idx_str)
        except: idx = 0
        links = []
        matched_item = None
        meta = {}
        if os.path.exists(SEARCH_CACHE_FILE):
            try:
                with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as f: cache = json.load(f)
                eng = cache.get('engine', eng)
                links = [_deserialize_item(lnk, eng) for lnk in cache.get('links', [])]
                matched_item = _deserialize_item(cache.get('item'), engine=eng)
                meta = cache.get('meta', {})
            except: pass

        if links and 0 <= idx < len(links):
            chosen = links[idx]
            _enrich_link_metadata(chosen, meta, matched_item)
            media_key = _get_media_key(meta, chosen)
            is_s = bool(meta.get('season') and meta.get('episode'))
            bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s, season=meta.get('season'), episode=meta.get('episode'))
            seek_to_time = 0
            if bm:
                r_time = float(bm.get('resume_time', 0))
                mins = int(r_time // 60); secs = int(r_time % 60); hrs = mins // 60; mins = mins % 60
                time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
                dialog = xbmcgui.Dialog()
                t_title = meta.get('title') or getattr(matched_item, 'title', '') or 'este vídeo'
                res = dialog.yesno('Reanudar reproducción', '¿Deseas reanudar [B][COLOR cyan]%s[/COLOR][/B] desde [COLOR gold]%s[/COLOR] o reproducir desde el principio?' % (t_title, time_str), nolabel='Desde el principio', yeslabel='Reanudar (%s)' % time_str)
                if res:
                    seek_to_time = r_time

            played = _play_link_safely(chosen, engine=eng, matched_item=matched_item, meta=meta)
            if played:
                start_playback_monitor(media_key, title_str=meta.get('title', ''), seek_to_time=seek_to_time)
        else:
            xbmcgui.Dialog().notification('Bridge Multi', 'Enlace no disponible', '', 3000)
        return

    if action == 'play':
        # Cerrar inmediatamente el diálogo "Elige Acción" de TMDb Helper que queda abierto
        # mientras nuestro plugin corre. Lo hacemos al inicio antes de cualquier búsqueda.
        try:
            xbmc.executebuiltin('Dialog.Close(10101,true)')
        except: pass
        try:
            if xbmc.Player().isPlaying(): xbmc.Player().stop()
        except: pass

        _s_check = season if season is not None and str(season).strip() != '' else get_param('season')
        _e_check = episode if episode is not None and str(episode).strip() != '' else get_param('episode')
        _is_s_play = bool(_s_check is not None and str(_s_check).strip() != '' and _e_check is not None and str(_e_check).strip() != '')
        _res_meta = _resolve_localized_metadata(
            tmdb_id=tmdb_id or get_param('tmdb'),
            is_series=_is_s_play,
            season=season or get_param('season'),
            episode=episode or get_param('episode'),
            plot_lat=plot_lat or get_param('plot_lat'),
            plot_es=plot_es or get_param('plot_es'),
            plot_param=plot or get_param('plot'),
            tagline_lat=tagline_lat or get_param('tagline_lat'),
            tagline_es=tagline_es or get_param('tagline_es'),
            tagline_param=tagline or get_param('tagline'),
            title_lat=title_lat or get_param('title_lat'),
            title_es=title_es or get_param('title_es'),
            title_param=title or get_param('title') or showname or get_param('showname')
        )
        if _res_meta.get('plot'):
            plot = _res_meta['plot']
        if _res_meta.get('tagline') is not None:
            tagline = _res_meta['tagline']
        if _res_meta.get('title') and _res_meta.get('has_spanish'):
            title = _res_meta['title']

        _init_meta = {
            'tmdb': tmdb_id or get_param('tmdb'),
            'imdb': imdb_id or get_param('imdb'),
            'tvdb': tvdb_id or get_param('tvdb'),
            'trakt': trakt_id or get_param('trakt'),
            'title': title or get_param('title') or get_param('title_es') or get_param('title_lat') or ((showname if (season and episode) else '') or ''),
            'year': (showyear or get_param('showyear')) if (season and episode) else (year or get_param('year')),
            'season': season or get_param('season'),
            'episode': episode or get_param('episode'),
            'showname': showname or get_param('showname'),
            'showyear': showyear or get_param('showyear'),
            'plot': plot,
            'tagline': tagline,
            'poster': poster or get_param('poster'),
            'fanart': fanart or get_param('fanart'),
            'thumbnail': thumbnail or get_param('thumbnail')
        }
        sync_tmdbhelper_playerstring(_init_meta)

        links = []
        matched_item = None
        meta = dict(_init_meta)

        # Reutilizar cache reciente (<90s) SOLO si corresponde EXACTAMENTE al mismo contenido
        # (misma película o mismo episodio de serie con idéntica temporada y número de episodio)
        _use_cache = False
        _cached_payload = None
        try:
            if os.path.exists(SEARCH_CACHE_FILE):
                import json as _js
                import time as _time
                _mtime = os.path.getmtime(SEARCH_CACHE_FILE)
                _age = _time.time() - _mtime
                if _age < 90:
                    with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as _f:
                        _c = _js.load(_f)
                    _c_meta = _c.get('meta', {}) or {}
                    _c_links = _c.get('links', [])
                    _cached_engine = _c.get('engine', 'alfa') or 'alfa'

                    if _c_links and _is_same_media_item(_c_meta, _init_meta):
                        _cur_def_eng = _get_int_setting('default_engine', 0)
                        if _is_s_play:
                            # Para series, Balandro es el único motor. Si la cache es de Balandro, es válida
                            if _cached_engine == 'balandro':
                                _use_cache = True
                                _cached_payload = _c
                                xbmc.log(f"Bridge Multi: cache reciente {_age:.1f}s para episodio serie ({_get_media_key(_init_meta)}), reutilizando sin nueva búsqueda", xbmc.LOGINFO)
                            else:
                                _use_cache = False
                        elif _cur_def_eng == 1 and _cached_engine != 'alfa':
                            _use_cache = False
                        elif _cur_def_eng == 2 and _cached_engine != 'balandro':
                            _use_cache = False
                        elif _cur_def_eng == 0:
                            _use_cache = False
                        else:
                            _use_cache = True
                            _cached_payload = _c
                            xbmc.log(f"Bridge Multi: cache reciente {_age:.1f}s para {_get_media_key(_init_meta)}, reutilizando sin nueva búsqueda", xbmc.LOGINFO)
                    elif _c_links:
                        xbmc.log(f"Bridge Multi: cache descartada (pertenece a otro contenido: cache={_get_media_key(_c_meta)} vs actual={_get_media_key(_init_meta)}), buscando fresco", xbmc.LOGINFO)
        except Exception as _ce:
            xbmc.log(f"Bridge Multi: cache reciente error: {_ce}", xbmc.LOGINFO)
            _use_cache = False

        if _use_cache and _cached_payload:
            # Reutilizar cache reciente — respetar ajuste autoplay
            try:
                _c = _cached_payload
                _cached_engine  = _c.get('engine', 'alfa') or 'alfa'
                _cached_links   = [_deserialize_item(l, _cached_engine) for l in _c.get('links', [])]
                _cached_item    = _deserialize_item(_c.get('item'), _cached_engine)
                _cached_meta    = _c.get('meta', {})
                _cached_tmdb_v  = str(_c.get('meta', {}).get('tmdb') or '')
                _autoplay_cache = _bridge_addon.getSetting('autoplay_enabled') == 'true'

                if _autoplay_cache and _cached_links:
                    xbmc.log('Bridge Multi: cache reciente → autoplay con %d enlaces' % len(_cached_links), xbmc.LOGINFO)
                    _enrich_link_metadata(_cached_links[0], _cached_meta, _cached_item)
                    _mk = _get_media_key(_cached_meta, _cached_links[0])
                    _is_s = bool(_cached_meta.get('season') and _cached_meta.get('episode'))
                    _bm = get_bookmark(_mk, tmdb_id=_cached_meta.get('tmdb'), is_series=_is_s,
                                       season=_cached_meta.get('season'), episode=_cached_meta.get('episode'))
                    _seek = 0
                    if _bm:
                        _rt2 = float(_bm.get('resume_time', 0))
                        _m2 = int(_rt2 // 60); _s2 = int(_rt2 % 60); _h2 = _m2 // 60; _m2 = _m2 % 60
                        _ts2 = ('%d:%02d:%02d' % (_h2, _m2, _s2)) if _h2 else ('%d:%02d' % (_m2, _s2))
                        _tt2 = _cached_meta.get('title') or ''
                        if xbmcgui.Dialog().yesno('Reanudar reproducción',
                                '¿Reanudar [B][COLOR cyan]%s[/COLOR][/B] desde [COLOR gold]%s[/COLOR]?' % (_tt2, _ts2),
                                nolabel='Desde el principio', yeslabel='Reanudar (%s)' % _ts2):
                            _seek = _rt2
                    _played = _autoplay_with_fallback(
                        _cached_links, handle,
                        engine=_cached_engine, matched_item=_cached_item,
                        monitor_secs=60, max_attempts=999,
                        tmdb_for_list=_cached_tmdb_v,
                        meta=_cached_meta)

                    if _played:
                        start_playback_monitor(_mk, title_str=_cached_meta.get('title', ''),
                                               seek_to_time=_seek)
                    return

                else:
                    # Autoplay desactivado → abrir lista de enlaces
                    xbmc.log('Bridge Multi: cache reciente → abriendo list_links', xbmc.LOGINFO)
                    _ts3 = int(time.time())
                    _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cached_tmdb_v, _ts3)
                    if _cached_meta.get('season') and _cached_meta.get('episode'):
                        _win_url += '&season=%s&episode=%s' % (_cached_meta['season'], _cached_meta['episode'])
                    xbmc.executebuiltin('ActivateWindow(10025, "%s", return)' % _win_url)
                    return
            except Exception as _ce:
                xbmc.log('Bridge Multi: cache reciente error: ' + str(_ce), xbmc.LOGINFO)
                pass  # Si falla, continua con búsqueda normal

        if True:  # forzar fresco, no usar cache (si no es caso de doble busqueda)
            eng = 'alfa'
            def_engine = _get_int_setting('default_engine', 0)
            if _is_s_play:
                # Las series son exclusivas de Balandro (Alfa es solo para películas)
                eng = 'balandro'
                xbmc.log("Bridge Multi: Contenido es serie/episodio y Alfa solo soporta películas. Usando Balandro automáticamente.", xbmc.LOGINFO)
            elif def_engine == 0:
                _picked = _show_engine_picker()
                if _picked is None:
                    return
                eng = _picked
            elif def_engine == 1:
                eng = 'alfa'
            elif def_engine == 2:
                eng = 'balandro'

            links, matched_item = run_parallel_search(engine=eng)
            verified_flag = False
            _auto_verify = _bridge_addon.getSetting('auto_verify_links') == 'true'
            xbmc.log(f"Bridge Multi: auto_verify_links={_auto_verify} engine={eng} links={len(links) if links else 0}", xbmc.LOGINFO)
            if links and _auto_verify:
                p_diag = xbmcgui.DialogProgress()
                p_diag.create('Bridge Multi', 'Comprobando disponibilidad de servidores...')
                v_links = _verify_links_headless(links, engine=eng, p_dialog=p_diag)
                try: p_diag.close()
                except: pass
                if v_links:
                    links = _filter_and_sort_links(v_links)
                    verified_flag = True

            meta = {
                'tmdb': tmdb_id or get_param('tmdb'), 'imdb': imdb_id or get_param('imdb'), 'tvdb': tvdb_id or get_param('tvdb'), 'trakt': trakt_id or get_param('trakt'),
                'title': title or get_param('title') or get_param('title_es') or get_param('title_lat') or ((showname if (season and episode) else '') or ''),
                'year': (showyear or get_param('showyear')) if (season and episode) else (year or get_param('year')),
                'season': season or get_param('season'), 'episode': episode or get_param('episode'), 'showname': showname or get_param('showname'), 'showyear': showyear or get_param('showyear'),
                'plot': plot or get_param('plot'), 'director': director or get_param('director'), 'tagline': tagline or get_param('tagline'),
                'poster': poster or get_param('poster'), 'fanart': fanart or get_param('fanart'), 'thumbnail': thumbnail or get_param('thumbnail'),
                'verified_only': verified_flag, 'engine': eng
            }
            if matched_item:
                _enrich_link_metadata(None, meta, matched_item)
            # Siempre guardar cache aunque no haya enlaces, para no mostrar cache vieja de otra peli
            try:
                with open(SEARCH_CACHE_FILE, 'w', encoding='utf-8') as f:
                    json.dump({'item': _serialize_item(matched_item) if matched_item else None, 'links': [_serialize_item(l) for l in (links or [])], 'meta': meta, 'engine': eng}, f)
            except: pass

        if not links:
            _offer_elementum_search(meta)
            return


        autoplay = _bridge_addon.getSetting('autoplay_enabled') == 'true'
        if autoplay:
            _enrich_link_metadata(links[0], meta, matched_item)
            media_key = _get_media_key(meta, links[0])
            is_s = bool(meta.get('season') and meta.get('episode'))
            bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s,
                              season=meta.get('season'), episode=meta.get('episode'))
            seek_to_time = 0
            if bm:
                r_time = float(bm.get('resume_time', 0))
                mins = int(r_time // 60); secs = int(r_time % 60)
                hrs = mins // 60; mins = mins % 60
                time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
                t_title = meta.get('title') or getattr(matched_item, 'title', '') or 'este vídeo'
                res = xbmcgui.Dialog().yesno(
                    'Reanudar reproducción',
                    '¿Reanudar [B][COLOR cyan]%s[/COLOR][/B] desde [COLOR gold]%s[/COLOR]?' % (t_title, time_str),
                    nolabel='Desde el principio', yeslabel='Reanudar (%s)' % time_str)
                if res:
                    seek_to_time = r_time

            xbmc.log('Bridge Multi: autoplay con fallback, %d enlaces disponibles, motor=%s' % (
                len(links), meta.get('engine', 'alfa')), xbmc.LOGINFO)

            # Intenta TODOS los enlaces no-torrent con monitoreo de 60s cada uno
            played = _autoplay_with_fallback(
                links, handle,
                engine       = meta.get('engine', 'alfa'),
                matched_item = matched_item,
                monitor_secs = 60,
                max_attempts = 999,
                tmdb_for_list= str(tmdb_id or meta.get('tmdb') or ''),
                meta         = meta)


            if played:
                start_playback_monitor(media_key, title_str=meta.get('title', ''),
                                       seek_to_time=seek_to_time)


        else:
            # Autoplay desactivado → abrir directamente la lista de enlaces
            _cur_tmdb = str(tmdb_id or get_param('tmdb') or meta.get('tmdb') or '')
            _ts = int(time.time())
            _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
            if meta.get('season') and meta.get('episode'):
                _win_url += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
            xbmc.log("Bridge Multi: abriendo list_links via ActivateWindow -> " + _win_url, xbmc.LOGINFO)
            xbmc.executebuiltin('ActivateWindow(10025, "%s", return)' % _win_url)
            return

    if url:
        search_item = None
        if 'action=search' in url:
            _is_s_url = bool((season or get_param('season')) and (episode or get_param('episode')))
            if _is_s_url:
                eng = 'balandro'
                xbmc.log("Bridge Multi: Búsqueda para serie en URL -> Balandro asignado automáticamente", xbmc.LOGINFO)
            else:
                eng = 'alfa'
                def_engine = _get_int_setting('default_engine', 0)
                if def_engine == 0:
                    _picked = _show_engine_picker()
                    if _picked is None:
                        xbmcplugin.endOfDirectory(handle, succeeded=False)
                        return
                    eng = _picked
                elif def_engine == 1: eng = 'alfa'
                elif def_engine == 2: eng = 'balandro'

            links, matched_item = run_parallel_search(engine=eng)
        else:
            is_alfa = 'alfa' in url.lower()
            is_series = bool((season or get_param('season')) and (episode or get_param('episode')))
            if is_alfa and is_series:
                xbmcgui.Dialog().notification('Bridge Multi', 'Alfa solo soporta películas', '', 3000)
                xbmcplugin.endOfDirectory(handle, succeeded=False)
                return

            eng = 'alfa' if is_alfa else 'balandro'
            mods = _get_alfa_modules() if is_alfa else _get_balandro_modules()
            ItemClass = mods['Item'] if mods else object
            raw_b64 = url.split('plugin://plugin.video.alfa/?')[-1].split('plugin://plugin.video.balandro/?')[-1].split('&')[0]
            raw_b64 = uparse.unquote(raw_b64)
            search_item = decode_base64_item(raw_b64, ItemClass)
            target_channel = getattr(search_item, 'channel', '')
            target_title = (showname or get_param('showname') if is_series else (title or get_param('title'))) or get_param('title_es') or get_param('title_lat') or get_param('title_orig') or get_param('title_en') or ''
            target_year = (showyear or get_param('showyear')) if is_series else (year or get_param('year'))
            target_tmdb = tmdb_id or get_param('tmdb')
            target_imdb = imdb_id or get_param('imdb')
            _res_meta_url = _resolve_localized_metadata(
                tmdb_id=target_tmdb,
                is_series=is_series,
                season=season or get_param('season'),
                episode=episode or get_param('episode'),
                plot_lat=plot_lat or get_param('plot_lat'),
                plot_es=plot_es or get_param('plot_es'),
                plot_param=plot or get_param('plot'),
                tagline_lat=tagline_lat or get_param('tagline_lat'),
                tagline_es=tagline_es or get_param('tagline_es'),
                tagline_param=tagline or get_param('tagline'),
                title_lat=title_lat or get_param('title_lat'),
                title_es=title_es or get_param('title_es'),
                title_param=target_title
            )
            if _res_meta_url.get('plot'):
                plot = _res_meta_url['plot']
            if _res_meta_url.get('tagline') is not None:
                tagline = _res_meta_url['tagline']
            if _res_meta_url.get('title') and _res_meta_url.get('has_spanish'):
                if not title_es:
                    title_es = _res_meta_url['title']
            all_names = [t for t in [target_title, title or get_param('title'), title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_en or get_param('title_en'), title_orig or get_param('title_orig'), showname or get_param('showname')] if t]
            alt_terms = [t for t in [title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_orig or get_param('title_orig'), title_en or get_param('title_en'), showname or get_param('showname'), title or get_param('title')] if t and t != target_title]
            if target_channel and target_channel != 'search':
                p_dialog = xbmcgui.DialogProgress()
                p_dialog.create('Bridge Multi', 'Buscando en %s...' % target_channel.capitalize())
                if is_alfa:
                    matched_item, links = _search_channel_alfa(target_channel, target_title, target_year, is_series, season or get_param('season'), episode or get_param('episode'), all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
                else:
                    matched_item, links = _search_channel_balandro(target_channel, target_title, target_year, is_series, season or get_param('season'), episode or get_param('episode'), all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
                p_dialog.close()
            else:
                links, matched_item = run_parallel_search(engine=eng)

        if links and matched_item:
            verified_flag = False
            _auto_verify2 = _bridge_addon.getSetting('auto_verify_links') == 'true'
            xbmc.log(f"Bridge Multi: auto_verify_links={_auto_verify2} engine={eng} links={len(links) if links else 0}", xbmc.LOGINFO)
            if _auto_verify2:
                p_diag = xbmcgui.DialogProgress()
                p_diag.create('Bridge Multi', 'Comprobando disponibilidad de servidores...')
                v_links = _verify_links_headless(links, engine=eng, p_dialog=p_diag)
                try: p_diag.close()
                except: pass
                if v_links:
                    links = v_links
                    verified_flag = True

            links = _filter_and_sort_links(links)
            meta = {
                'tmdb': tmdb_id or get_param('tmdb'), 'imdb': imdb_id or get_param('imdb'), 'tvdb': tvdb_id or get_param('tvdb'), 'trakt': trakt_id or get_param('trakt'),
                'title': title or get_param('title') or get_param('title_es') or get_param('title_lat') or ((showname if (season and episode) else '') or ''),
                'year': (showyear or get_param('showyear')) if (season and episode) else (year or get_param('year')),
                'season': season or get_param('season'), 'episode': episode or get_param('episode'), 'showname': showname or get_param('showname'), 'showyear': showyear or get_param('showyear'),
                'plot': plot or get_param('plot'), 'director': director or get_param('director'), 'tagline': tagline or get_param('tagline'),
                'poster': poster or get_param('poster'), 'fanart': fanart or get_param('fanart'), 'thumbnail': thumbnail or get_param('thumbnail'),
                'verified_only': verified_flag, 'engine': eng
            }
            if matched_item:
                _enrich_link_metadata(None, meta, matched_item)
            try:
                with open(SEARCH_CACHE_FILE, 'w', encoding='utf-8') as f:
                    json.dump({'item': _serialize_item(matched_item), 'links': [_serialize_item(l) for l in links], 'meta': meta, 'engine': eng}, f)
            except Exception: pass

            autoplay = _bridge_addon.getSetting('autoplay_enabled') == 'true'
            if autoplay:
                _enrich_link_metadata(links[0], meta, matched_item)
                media_key = _get_media_key(meta, links[0])
                is_s = bool(meta.get('season') and meta.get('episode'))
                bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s,
                                  season=meta.get('season'), episode=meta.get('episode'))
                seek_to_time = 0
                if bm:
                    r_time = float(bm.get('resume_time', 0))
                    mins = int(r_time // 60); secs = int(r_time % 60)
                    hrs = mins // 60; mins = mins % 60
                    time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
                    t_title = meta.get('title') or getattr(matched_item, 'title', '') or 'este vídeo'
                    res = xbmcgui.Dialog().yesno(
                        'Reanudar reproducción',
                        '¿Reanudar [B][COLOR cyan]%s[/COLOR][/B] desde [COLOR gold]%s[/COLOR]?' % (t_title, time_str),
                        nolabel='Desde el principio', yeslabel='Reanudar (%s)' % time_str)
                    if res:
                        seek_to_time = r_time

                played = _autoplay_with_fallback(
                    links, handle,
                    engine       = meta.get('engine', 'alfa'),
                    matched_item = matched_item,
                    monitor_secs = 60,
                    max_attempts = 999,
                    tmdb_for_list= str(tmdb_id or meta.get('tmdb') or ''))
                if played:
                    start_playback_monitor(media_key, title_str=meta.get('title', ''),
                                           seek_to_time=seek_to_time)
            else:
                _cur_tmdb = str(tmdb_id or get_param('tmdb') or meta.get('tmdb') or '')
                _ts = int(time.time())
                _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
                if meta.get('season') and meta.get('episode'):
                    _win_url += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
                xbmc.log("Bridge Multi: abriendo list_links via ActivateWindow -> " + _win_url, xbmc.LOGINFO)
                xbmc.executebuiltin('ActivateWindow(10025, "%s", return)' % _win_url)
            return
        else:
            _meta_fallback = {
                'tmdb':    tmdb_id or get_param('tmdb'),
                'title':   title or get_param('title') or get_param('title_es') or get_param('title_lat') or showname or get_param('showname'),
                'season':  season or get_param('season'),
                'episode': episode or get_param('episode'),
                'showname': showname or get_param('showname'),
            }
            _offer_elementum_search(_meta_fallback)
        return




if __name__ == '__main__':
    main()
