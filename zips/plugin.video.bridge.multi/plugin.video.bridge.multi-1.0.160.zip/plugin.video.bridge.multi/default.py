import sqlite3
# -*- coding: utf-8 -*-
import sys
import os
import re
import subprocess
import json
import base64
import threading
import queue
import time
import datetime
import random
import socket
import builtins
import types

builtins.sys = sys
builtins.basestring = str
builtins.unicode = str
# Timeout global de sockets: ninguna operacion de red puede colgarse mas de 10s
# en la capa del SO (antes 30s). httptools impone sus propios timeouts (15s
# por defecto); este es el techo de seguridad para sockets crudos (TMDB, etc.).
socket.setdefaulttimeout(10)

import weakref

_BG_TASK_ABORT_EVENT = threading.Event()
_SHUTDOWN_REQUESTED = False

_OPEN_SOCKETS = weakref.WeakSet()
_OPEN_SOCKETS_LOCK = threading.Lock()
_ORIG_SOCKET_CLS = socket.socket

class _TrackedSocket(_ORIG_SOCKET_CLS):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if _SHUTDOWN_REQUESTED:
            try:
                self.close()
            except Exception:
                pass
            raise OSError("Kodi shutdown in progress")
        try:
            with _OPEN_SOCKETS_LOCK:
                _OPEN_SOCKETS.add(self)
        except Exception:
            pass

    def close(self):
        try:
            with _OPEN_SOCKETS_LOCK:
                _OPEN_SOCKETS.discard(self)
        except Exception:
            pass
        try:
            super().close()
        except Exception:
            pass

socket.socket = _TrackedSocket

def abort_all_network_sockets():
    """Cierra limpiamente los sockets TCP abiertos registrados por Python sin usar llamadas
    nativas de C (evita doble cierre de handles OS en Windows x64/Kodi)."""
    try:
        with _OPEN_SOCKETS_LOCK:
            socks = list(_OPEN_SOCKETS)
            _OPEN_SOCKETS.clear()
        for s in socks:
            try:
                if hasattr(s, 'fileno') and s.fileno() < 0:
                    continue
            except Exception:
                continue
            try:
                s.settimeout(0.01)
            except Exception:
                pass
            try:
                s.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                s.close()
            except Exception:
                pass
    except Exception:
        pass

_SHUTDOWN_WATCHDOG_STARTED = False
_SHUTDOWN_WATCHDOG_LOCK = threading.Lock()

def _ensure_shutdown_watchdog():
    global _SHUTDOWN_WATCHDOG_STARTED
    with _SHUTDOWN_WATCHDOG_LOCK:
        if _SHUTDOWN_WATCHDOG_STARTED:
            return
        _SHUTDOWN_WATCHDOG_STARTED = True

    def _watch():
        global _SHUTDOWN_REQUESTED, _SHUTDOWN_WATCHDOG_STARTED
        try:
            mon = xbmc.Monitor()
            while not mon.abortRequested():
                if mon.waitForAbort(0.15):
                    break
            _SHUTDOWN_REQUESTED = True
            _BG_TASK_ABORT_EVENT.set()
            try:
                socket.setdefaulttimeout(0.02)
            except Exception:
                pass
            abort_all_network_sockets()
        except Exception:
            pass
        finally:
            with _SHUTDOWN_WATCHDOG_LOCK:
                _SHUTDOWN_WATCHDOG_STARTED = False

    t = threading.Thread(target=_watch, name="MultiBridgeShutdownWatchdog", daemon=True)
    t.start()

import urllib
import urllib.parse as uparse
import urllib.request as urequest
import urllib.response as uresponse
import urllib.error as uerror
import html, html.parser, html.entities
import http.cookiejar
from contextlib import contextmanager

urllib.quote = uparse.quote
urllib.quote_plus = uparse.quote_plus
urllib.unquote = uparse.unquote
urllib.unquote_plus = uparse.unquote_plus
urllib.urlencode = uparse.urlencode
urllib.addinfourl = uresponse.addinfourl
urllib.request = urequest
urllib.response = uresponse

urequest.HTTPError = uerror.HTTPError
urequest.URLError = uerror.URLError
sys.modules['urllib2'] = urequest

html.parser.HTMLParser.unescape = staticmethod(html.unescape)
html_parser_mod = types.ModuleType('HTMLParser')
html_parser_mod.HTMLParser = html.parser.HTMLParser
sys.modules['HTMLParser'] = html_parser_mod
sys.modules['htmlentitydefs'] = html.entities
sys.modules['urlparse'] = uparse
sys.modules['cookielib'] = http.cookiejar

handle = -1
if len(sys.argv) > 1 and sys.argv[1]:
    try: handle = int(sys.argv[1])
    except Exception: handle = -1
original_argv = list(sys.argv)

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcplugin
import xbmcgui

# Guardar la clase Dialog original de Kodi de forma inmutable para diálogos interactivos seguros
_KODI_ORIG_DIALOG = xbmcgui.Dialog

if not hasattr(xbmc, 'translatePath'):
    xbmc.translatePath = xbmcvfs.translatePath

_bridge_addon = xbmcaddon.Addon('plugin.video.bridge.multi')
ADDON_PATH = xbmcvfs.translatePath(_bridge_addon.getAddonInfo('path'))
_ensure_shutdown_watchdog()

def _get_addon_white_texture():
    """Retorna una textura blanca sólida garantizada para fondos y bordes."""
    try:
        cand = os.path.normpath(os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'white.png'))
        if os.path.exists(cand):
            return cand
    except Exception:
        pass
    try:
        cand2 = os.path.normpath(os.path.join(ADDON_PATH, 'resources', 'media', 'white.png'))
        if os.path.exists(cand2):
            return cand2
    except Exception:
        pass
    try:
        cand3 = os.path.normpath(os.path.join(os.path.dirname(ADDON_PATH), 'service.guiaparental', 'resources', 'skins', 'Default', 'media', 'white.png'))
        if os.path.exists(cand3):
            return cand3
    except Exception:
        pass
    return 'special://home/addons/plugin.video.bridge.multi/resources/skins/Default/media/white.png'

def _show_bridge_notification(heading, message, time_ms=3500, icon=None):
    """Muestra una notificacion en pantalla de forma infalible en cualquier dispositivo y skin."""
    try:
        clean_h = str(heading).replace('"', "'").replace('\n', ' ')
        clean_m = str(message).replace('"', "'").replace('\n', ' ')
        clean_plain = re.sub(r'\[/?(?:B|I|COLOR[^\]]*)\]', '', clean_m)

        icon_path = icon or ''
        if not icon_path or not os.path.exists(str(icon_path)):
            try:
                addon_root = xbmcvfs.translatePath('special://home/addons/plugin.video.bridge.multi/icon.png')
                if os.path.exists(addon_root):
                    icon_path = addon_root
            except Exception:
                pass

        real_icon = icon_path.replace('\\', '/') if (icon_path and os.path.exists(str(icon_path))) else ''

        # 1. Dialog().notification nativo de Kodi (prioridad maxima)
        try:
            real_dlg = _orig_dialog_class or _KODI_ORIG_DIALOG or getattr(xbmcgui, 'Dialog')
            if real_dlg and real_dlg is not _SilentDialog:
                real_dlg().notification(clean_h, clean_m, real_icon or xbmcgui.NOTIFICATION_INFO, time_ms, False)
        except Exception as _e:
            xbmc.log("Multi Bridge: fallo en Dialog.notification: %s" % _e, xbmc.LOGDEBUG)

        # 2. Respaldo directo con Kodi Builtin Notification
        try:
            if real_icon:
                xbmc.executebuiltin('Notification("%s", "%s", %d, "%s")' % (clean_h, clean_plain, time_ms, real_icon))
            else:
                xbmc.executebuiltin('Notification("%s", "%s", %d)' % (clean_h, clean_plain, time_ms))
        except Exception:
            pass
    except Exception:
        pass

# Auto-load all script.module dependencies from Kodi addons directory
addons_root = xbmcvfs.translatePath('special://home/addons/')
alfa_path = os.path.join(addons_root, 'plugin.video.alfa')
_alfa_lib = os.path.join(alfa_path, 'lib')
balandro_path = os.path.join(addons_root, 'plugin.video.balandro')
_balandro_lib = os.path.join(balandro_path, 'lib')

if os.path.exists(addons_root):
    for _ad in os.listdir(addons_root):
        if _ad.startswith('script.module.'):
            _mod_lib = os.path.join(addons_root, _ad, 'lib')
            if os.path.isdir(_mod_lib):
                if _mod_lib not in sys.path: sys.path.append(_mod_lib)
            else:
                _ad_path = os.path.join(addons_root, _ad)
                if os.path.isdir(_ad_path) and _ad_path not in sys.path: sys.path.append(_ad_path)

def _patch_js2py_math_compatibility():
    """Corrige la incompatibilidad de js2py con bytecode de Python 3.14 (Math.* methods).
    En Python 3.14, 'a != a' genera opcode LOAD_FAST_BORROW_LOAD_FAST_BORROW que injector.py
    de js2py corrompe al anadir ('this', 'arguments'), causando AttributeError: 'float' object has no attribute 'TYPE'.
    Este parche reemplaza los metodos de Math directamente por funciones Python seguras."""
    try:
        import math
        import js2py
        from js2py.constructors import jsmath
        m = getattr(jsmath, 'Math', None)
        if not m:
            return
        NaN = getattr(jsmath, 'NaN', float('nan'))

        def _num(v):
            if v is None:
                return float('nan')
            if hasattr(v, 'to_number'):
                try:
                    return v.to_number().value
                except:
                    pass
            try:
                return float(v)
            except:
                return float('nan')

        def _u(fn):
            def _wrapped(x, this=None, arguments=None):
                val = _num(x)
                if math.isnan(val):
                    return NaN
                try:
                    res = fn(val)
                    if math.isnan(res):
                        return NaN
                    return res
                except:
                    return NaN
            return _wrapped

        if hasattr(m, 'get'):
            for fn_name, fn_impl in [
                ('abs', _u(abs)),
                ('acos', _u(lambda v: NaN if (v < -1 or v > 1) else math.acos(v))),
                ('asin', _u(lambda v: NaN if (v < -1 or v > 1) else math.asin(v))),
                ('atan', _u(math.atan)),
                ('ceil', _u(math.ceil)),
                ('cos', _u(math.cos)),
                ('exp', _u(math.exp)),
                ('floor', _u(math.floor)),
                ('log', _u(lambda v: NaN if v < 0 else math.log(v))),
                ('round', _u(round)),
                ('sin', _u(math.sin)),
                ('sqrt', _u(lambda v: NaN if v < 0 else math.sqrt(v))),
                ('tan', _u(math.tan)),
                ('atan2', lambda y, x, this=None, arguments=None: NaN if (y is None or x is None or math.isnan(_num(y)) or math.isnan(_num(x))) else math.atan2(_num(y), _num(x))),
                ('pow', lambda x, y, this=None, arguments=None: NaN if (x is None or y is None or math.isnan(_num(x)) or math.isnan(_num(y))) else (_num(x)**_num(y))),
            ]:
                item = m.get(fn_name)
                if item and hasattr(item, 'code'):
                    item.code = fn_impl
    except Exception as e:
        try:
            xbmc.log(f"Multi Bridge: aviso al aplicar parche js2py Math: {e}", xbmc.LOGWARNING)
        except:
            pass

_patch_js2py_math_compatibility()

TMDB_PLAYERS_PATH = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/players/')
BRIDGE_DATA_PATH = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.bridge.multi/')
if not os.path.exists(BRIDGE_DATA_PATH):
    try: os.makedirs(BRIDGE_DATA_PATH)
    except: pass
if not os.path.exists(TMDB_PLAYERS_PATH):
    try: os.makedirs(TMDB_PLAYERS_PATH)
    except: pass

SEARCH_CACHE_FILE = os.path.join(BRIDGE_DATA_PATH, 'bridge_multi_search_cache.json')
BOOKMARKS_FILE = os.path.join(BRIDGE_DATA_PATH, 'bridge_multi_bookmarks.json')
CONTINUE_WATCHING_FILE = os.path.join(BRIDGE_DATA_PATH, 'bridge_multi_continue_watching.json')
COMPLETED_ITEMS_FILE = os.path.join(BRIDGE_DATA_PATH, 'bridge_multi_completed.json')
CLOUD_SYNC_FILE = os.path.join(BRIDGE_DATA_PATH, 'cloud_sync_info.json')
CHANNELS_JSON_FILE = os.path.join(BRIDGE_DATA_PATH, 'channels.json')
SEARCH_LOCK_FILE = os.path.join(BRIDGE_DATA_PATH, 'bridge_search.lock')

_SEARCH_CACHE_LOCK = threading.Lock()

def _norm_id_str(val):
    if val is None: return ''
    s = str(val).strip()
    if s.lower() in ('none', '_', '0', ''): return ''
    try:
        if s.isdigit(): return str(int(s))
    except: pass
    return s

_LAST_SEARCH_CACHE_MTIME = 0
_LAST_SEARCH_CACHE_DATA = None

def _save_search_cache_atomic(cache_dict):
    """Guarda SEARCH_CACHE_FILE de forma completamente atomica con reemplazo seguro
    y copia de respaldo (.bak) para evitar lecturas concurrentes corruptas o vacias."""
    global _LAST_SEARCH_CACHE_MTIME, _LAST_SEARCH_CACHE_DATA
    if not isinstance(cache_dict, dict):
        return False
    _LAST_SEARCH_CACHE_DATA = cache_dict
    try:
        xbmcgui.Window(10000).setProperty('MultiBridge.SearchCacheJson', json.dumps(cache_dict))
    except Exception:
        pass
    with _SEARCH_CACHE_LOCK:
        try:
            dir_name = os.path.dirname(SEARCH_CACHE_FILE)
            if not os.path.exists(dir_name):
                try: os.makedirs(dir_name, exist_ok=True)
                except: pass
            tmp_file = "%s.tmp.%d.%d" % (SEARCH_CACHE_FILE, os.getpid(), threading.get_ident())
            with open(tmp_file, 'w', encoding='utf-8') as fw:
                json.dump(cache_dict, fw)
                fw.flush()
                try: os.fsync(fw.fileno())
                except: pass

            replaced = False
            for attempt in range(8):
                try:
                    os.replace(tmp_file, SEARCH_CACHE_FILE)
                    replaced = True
                    break
                except (OSError, PermissionError):
                    time.sleep(0.04)

            if not replaced:
                try:
                    import shutil
                    shutil.copyfile(tmp_file, SEARCH_CACHE_FILE)
                    replaced = True
                except: pass

            try:
                if os.path.exists(tmp_file):
                    os.remove(tmp_file)
            except: pass

            if replaced:
                try:
                    _LAST_SEARCH_CACHE_MTIME = os.path.getmtime(SEARCH_CACHE_FILE)
                except Exception:
                    pass
                if cache_dict.get('links'):
                    try:
                        bak_file = SEARCH_CACHE_FILE + '.bak'
                        import shutil
                        shutil.copyfile(SEARCH_CACHE_FILE, bak_file)
                    except: pass
            return replaced
        except Exception as e:
            try: xbmc.log("Multi Bridge: _save_search_cache_atomic error: %s" % e, xbmc.LOGWARNING)
            except: pass
            return False

def _read_search_cache_atomic(max_attempts=6, delay=0.05):
    global _LAST_SEARCH_CACHE_MTIME, _LAST_SEARCH_CACHE_DATA

    # 1. Comprobacion ultrarrapida por mtime (0 ms, sin I/O de disco ni parseo de JSON)
    try:
        if os.path.exists(SEARCH_CACHE_FILE):
            mtime = os.path.getmtime(SEARCH_CACHE_FILE)
            if mtime == _LAST_SEARCH_CACHE_MTIME and _LAST_SEARCH_CACHE_DATA is not None:
                return _LAST_SEARCH_CACHE_DATA
    except Exception:
        pass

    # 2. Window(10000) property para procesos paralelos en Kodi
    try:
        _mem = xbmcgui.Window(10000).getProperty('MultiBridge.SearchCacheJson')
        if _mem and _mem.strip():
            _d = json.loads(_mem)
            if isinstance(_d, dict) and _d.get('links'):
                valid_raw = [l for l in _d['links'] if l and isinstance(l, dict) and l.get('url')]
                if valid_raw:
                    _d['links'] = valid_raw
                    _LAST_SEARCH_CACHE_DATA = _d
                    try:
                        if os.path.exists(SEARCH_CACHE_FILE):
                            _LAST_SEARCH_CACHE_MTIME = os.path.getmtime(SEARCH_CACHE_FILE)
                    except Exception:
                        pass
                    return _d
                else:
                    xbmcgui.Window(10000).setProperty('MultiBridge.SearchCacheJson', '')
    except Exception:
        pass

    """Lee SEARCH_CACHE_FILE con reintentos para tolerar escrituras simultaneas
    en Windows y recurre a la copia .bak si el fichero principal falla."""
    if not os.path.exists(SEARCH_CACHE_FILE):
        bak = SEARCH_CACHE_FILE + '.bak'
        if os.path.exists(bak):
            try:
                with open(bak, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        _LAST_SEARCH_CACHE_DATA = data
                        return data
            except: pass
        return None

    last_err = None
    for attempt in range(max_attempts):
        try:
            with open(SEARCH_CACHE_FILE, 'r', encoding='utf-8') as f:
                content = f.read()
            if content and content.strip():
                data = json.loads(content)
                if isinstance(data, dict):
                    _LAST_SEARCH_CACHE_DATA = data
                    try:
                        _LAST_SEARCH_CACHE_MTIME = os.path.getmtime(SEARCH_CACHE_FILE)
                    except Exception:
                        pass
                    return data
        except (OSError, PermissionError, json.JSONDecodeError, ValueError) as e:
            last_err = e
            time.sleep(delay)
        except Exception as e:
            last_err = e
            break

    try:
        bak = SEARCH_CACHE_FILE + '.bak'
        if os.path.exists(bak):
            with open(bak, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, dict):
                    xbmc.log("Multi Bridge: cache leida exitosamente desde copia de respaldo .bak", xbmc.LOGINFO)
                    _LAST_SEARCH_CACHE_DATA = data
                    return data
    except: pass

    if last_err:
        xbmc.log("Multi Bridge: _read_search_cache_atomic fallo tras %d intentos: %s" % (max_attempts, last_err), xbmc.LOGWARNING)
    return None

def load_channels_data():
    if os.path.exists(CHANNELS_JSON_FILE):
        try:
            with open(CHANNELS_JSON_FILE, 'r', encoding='utf-8') as f:
                d = json.load(f)
            if isinstance(d, dict) and 'channels' in d:
                return d
        except Exception as e:
            xbmc.log("Multi Bridge: error cargando channels.json: %s" % e, xbmc.LOGWARNING)
    return {'version': 1, 'channels': {'alfa': {}, 'balandro': {}}}

def save_channels_data(data):
    try:
        if not os.path.exists(BRIDGE_DATA_PATH):
            os.makedirs(BRIDGE_DATA_PATH)
        with open(CHANNELS_JSON_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        xbmc.log("Multi Bridge: error guardando channels.json: %s" % e, xbmc.LOGWARNING)
        return False

_RAM_SEARCH_CACHE = {}

# Recolector tardio: hilos que terminan despues del cierre pierden sus
# enlaces. Aqui se guardan para que el recolector los anexe a la lista
# abierta (sin reordenar lo ya mostrado) con refresco del contenedor.
_LAST_SEARCH_TOKEN = None
_LAST_MERGED_PFS = set()
_LAST_RESULTS_DICT = {}

def _store_ram_search_cache(links, matched_item, meta, engine, unverified_links=None):
    global _RAM_SEARCH_CACHE
    try:
        _RAM_SEARCH_CACHE = {
            'links': list(links or []),
            'unverified_links': list(unverified_links or []),
            'matched_item': matched_item,
            'meta': dict(meta or {}),
            'engine': engine or 'alfa',
            'time': time.time(),
            'tmdb': _norm_id_str((meta or {}).get('tmdb')),
            'season': _norm_id_str((meta or {}).get('season')),
            'episode': _norm_id_str((meta or {}).get('episode'))
        }
    except Exception:
        pass

def _get_ram_search_cache(target_tmdb='', target_season='', target_episode='', max_age=1800):
    global _RAM_SEARCH_CACHE
    if not _RAM_SEARCH_CACHE or not isinstance(_RAM_SEARCH_CACHE, dict):
        return None

    # Si hay reproducción activa, mantener la caché activa durante toda la sesión (4 horas)
    p = xbmc.Player()
    is_playing = False
    try:
        is_playing = p.isPlayingVideo()
    except Exception:
        pass

    effective_max_age = 14400 if is_playing else max_age
    cache_time = _RAM_SEARCH_CACHE.get('time', 0)
    if (time.time() - cache_time) > effective_max_age:
        return None

    t_tmdb = _norm_id_str(target_tmdb)
    r_tmdb = _norm_id_str(_RAM_SEARCH_CACHE.get('tmdb'))
    if t_tmdb and r_tmdb and t_tmdb != r_tmdb:
        return None
    t_sea = _norm_id_str(target_season)
    r_sea = _norm_id_str(_RAM_SEARCH_CACHE.get('season'))
    if t_sea and r_sea and t_sea != r_sea:
        return None
    t_epi = _norm_id_str(target_episode)
    r_epi = _norm_id_str(_RAM_SEARCH_CACHE.get('episode'))
    if t_epi and r_epi and t_epi != r_epi:
        return None
    return _RAM_SEARCH_CACHE


def _is_cam_quality(link_or_dict):
    """Detecta si un enlace fue grabado en cine (CAM, TS, Telesync, HDCAM, etc.)
    para evitar que la verificacion interna sobrescriba la calidad con la resolucion
    del contenedor de video (ej. 1080p), protegiendo la advertencia de que es CAM."""
    if not link_or_dict:
        return False
    try:
        if isinstance(link_or_dict, dict):
            q = _safe_str(link_or_dict.get('quality', '') or '')
            t = _safe_str(link_or_dict.get('title', '') or '')
            u = _safe_str(link_or_dict.get('url', '') or '')
            o = _safe_str(link_or_dict.get('other', '') or '')
        else:
            q = _safe_str(getattr(link_or_dict, 'quality', '') or '')
            t = _safe_str(getattr(link_or_dict, 'title', '') or '')
            u = _safe_str(getattr(link_or_dict, 'url', '') or '')
            o = _safe_str(getattr(link_or_dict, 'other', '') or '')

        q_clean = q.strip().upper()
        if q_clean in ('CAM', 'TS', 'TC', 'HDCAM', 'CAMRIP', 'CAM-RIP', 'TELESYNC', 'TELECINE', 'SCREENER', 'SCR', 'DVD-SCR', 'DVDSCR'):
            return True
        if any(k in q_clean for k in ('CAM/TS', 'TS/CAM', 'HD-CAM', 'CAM-RIP', 'CAMRIP')):
            return True

        o_clean = o.strip().upper()
        if any(k in o_clean for k in ('CAM', 'TS', 'TC', 'HDCAM', 'CAMRIP', 'CAM-RIP', 'TELESYNC', 'TELECINE', 'SCREENER')):
            return True

        combined = (t + ' ' + u).upper()
        if re.search(r'\b(HDCAM|HD-CAM|CAM-?RIP|CAM/TS|TS/CAM|TELESYNC|TELECINE|DVD-?SCR|SCREENER)\b', combined):
            return True
        if re.search(r'\b(CAM|TS|TC)\b', combined):
            return True
    except Exception:
        pass
    return False

def _update_link_real_quality_in_cache(link_idx=None, real_res='', link_obj=None, media_key=''):
    """Actualiza la resolucion real verificada de un enlace en el objeto link,
    en la cache en RAM y en el archivo JSON en disco, de manera sincronizada y atomica."""
    if not real_res:
        return
    if link_obj is not None and _is_cam_quality(link_obj):
        return
    global _RAM_SEARCH_CACHE

    # 1. Actualizar objeto directo si fue pasado
    if link_obj is not None:
        try:
            link_obj.real_quality = real_res
            link_obj.quality = real_res
        except Exception:
            pass

    # 2. Actualizar en RAM cache
    if _RAM_SEARCH_CACHE and isinstance(_RAM_SEARCH_CACHE, dict):
        r_links = _RAM_SEARCH_CACHE.get('links', [])
        if link_idx is not None and isinstance(link_idx, int) and 0 <= link_idx < len(r_links):
            try:
                r_links[link_idx].real_quality = real_res
                r_links[link_idx].quality = real_res
            except Exception:
                pass
        elif link_obj is not None:
            target_u = _safe_str(getattr(link_obj, 'url', ''))
            for lnk in r_links:
                if lnk is link_obj or (target_u and _safe_str(getattr(lnk, 'url', '')) == target_u):
                    try:
                        lnk.real_quality = real_res
                        lnk.quality = real_res
                    except Exception:
                        pass

    # 3. Actualizar en disco atomicamente
    try:
        c_disk = _read_search_cache_atomic(max_attempts=3, delay=0.03)
        if c_disk and isinstance(c_disk, dict):
            d_links = c_disk.get('links', [])
            dirty = False
            if link_idx is not None and isinstance(link_idx, int) and 0 <= link_idx < len(d_links):
                try:
                    if isinstance(d_links[link_idx], dict):
                        d_links[link_idx]['real_quality'] = real_res
                        d_links[link_idx]['quality'] = real_res
                        dirty = True
                except Exception:
                    pass
            elif link_obj is not None:
                target_u = _safe_str(getattr(link_obj, 'url', ''))
                for dl in d_links:
                    if isinstance(dl, dict) and dl.get('url') == target_u:
                        dl['real_quality'] = real_res
                        dl['quality'] = real_res
                        dirty = True
            if dirty:
                _save_search_cache_atomic(c_disk)
    except Exception:
        pass


def _get_media_key(meta, item=None):
    if not meta: meta = {}
    s_val = meta.get('season') if meta.get('season') is not None else _safe_get_item_attr(item, 'season')
    e_val = meta.get('episode') if meta.get('episode') is not None else _safe_get_item_attr(item, 'episode')
    has_se = (s_val is not None and str(s_val).strip() != '') and (e_val is not None and str(e_val).strip() != '')
    is_series = bool(has_se or _safe_get_item_attr(item, 'contentType') == 'episode' or _safe_get_item_attr(item, 'contentSeason'))
    tmdb = meta.get('tmdb') or _safe_get_item_attr(item, 'tmdb_id') or _safe_get_item_attr(item, 'tmdb') or ''
    imdb = meta.get('imdb') or _safe_get_item_attr(item, 'imdb_id') or _safe_get_item_attr(item, 'imdb') or ''
    season = meta.get('season') or _safe_get_item_attr(item, 'season') or _safe_get_item_attr(item, 'contentSeason') or ''
    episode = meta.get('episode') or _safe_get_item_attr(item, 'episode') or _safe_get_item_attr(item, 'contentEpisodeNumber') or ''
    title = meta.get('title') or _safe_get_item_attr(item, 'contentTitle') or _safe_get_item_attr(item, 'title') or ''
    show = meta.get('showname') or _safe_get_item_attr(item, 'contentSerieName') or _safe_get_item_attr(item, 'show') or ''

    if is_series:
        s_str = '%02d' % int(season) if str(season).isdigit() else str(season)
        e_str = '%02d' % int(episode) if str(episode).isdigit() else str(episode)
        if tmdb: return 'tv_%s_s%s_e%s' % (tmdb, s_str, e_str)
        if imdb: return 'tv_%s_s%s_e%s' % (imdb, s_str, e_str)
        clean_s = clean_title(show or title)
        return 'tv_%s_s%s_e%s' % (clean_s, s_str, e_str)
    else:
        if tmdb: return 'movie_%s' % tmdb
        if imdb: return 'movie_%s' % imdb
        year = meta.get('year') or _safe_get_item_attr(item, 'year') or ''
        clean_t = clean_title(title)
        return 'movie_%s_%s' % (clean_t, year)

def _is_same_media_item(cached_meta, cur_meta):
    """Verifica si dos diccionarios meta corresponden exactamente al mismo contenido.
    Para series: comprueba que season y episode coincidan numéricamente y que
    sea la misma serie (mismo tmdb, imdb, tvdb o título/showname).
    Para películas: comprueba tmdb, imdb o título + año.
    """
    if not cached_meta or not cur_meta:
        return False

    c_s = cached_meta.get('season')
    c_e = cached_meta.get('episode')
    cur_s = cur_meta.get('season')
    cur_e = cur_meta.get('episode')

    c_is_series = bool(c_s is not None and str(c_s).strip() != '' and c_e is not None and str(c_e).strip() != '')
    cur_is_series = bool(cur_s is not None and str(cur_s).strip() != '' and cur_e is not None and str(cur_e).strip() != '')

    # Uno es serie y el otro película -> No es el mismo contenido
    if c_is_series != cur_is_series:
        return False

    if cur_is_series:
        # En series: temporada y episodio DEBEN coincidir numéricamente
        try:
            if int(c_s) != int(cur_s) or int(c_e) != int(cur_e):
                return False
        except (ValueError, TypeError):
            if str(c_s).strip() != str(cur_s).strip() or str(c_e).strip() != str(cur_e).strip():
                return False

        # Verificar que sea la misma serie (tmdb, imdb, tvdb o título)
        c_tmdb = str(cached_meta.get('tmdb') or '')
        cur_tmdb = str(cur_meta.get('tmdb') or '')
        if c_tmdb and cur_tmdb:
            return c_tmdb == cur_tmdb

        c_imdb = str(cached_meta.get('imdb') or '')
        cur_imdb = str(cur_meta.get('imdb') or '')
        if c_imdb and cur_imdb:
            return c_imdb == cur_imdb

        c_tvdb = str(cached_meta.get('tvdb') or '')
        cur_tvdb = str(cur_meta.get('tvdb') or '')
        if c_tvdb and cur_tvdb:
            return c_tvdb == cur_tvdb

        # Comparar por nombre de serie si no hay IDs
        c_name = clean_title(cached_meta.get('showname') or cached_meta.get('title') or '')
        cur_name = clean_title(cur_meta.get('showname') or cur_meta.get('title') or '')
        return bool(c_name and cur_name and c_name == cur_name)
    else:
        # En películas: Comprobar tmdb, imdb o título + año
        c_tmdb = str(cached_meta.get('tmdb') or '')
        cur_tmdb = str(cur_meta.get('tmdb') or '')
        if c_tmdb and cur_tmdb:
            return c_tmdb == cur_tmdb

        c_imdb = str(cached_meta.get('imdb') or '')
        cur_imdb = str(cur_meta.get('imdb') or '')
        if c_imdb and cur_imdb:
            return c_imdb == cur_imdb

        c_title = clean_title(cached_meta.get('title') or '')
        cur_title = clean_title(cur_meta.get('title') or '')
        c_year = str(cached_meta.get('year') or '')
        cur_year = str(cur_meta.get('year') or '')
        if c_title and cur_title and c_title == cur_title:
            if c_year and cur_year:
                return c_year == cur_year
            return True
        return False


def get_bookmark(media_key, tmdb_id=None, is_series=False, season=None, episode=None):
    if is_item_completed(media_key):
        return None
    # 1. Local bookmark database
    if media_key and os.path.exists(BOOKMARKS_FILE):
        try:
            with open(BOOKMARKS_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
            bm = data.get(media_key)
            if bm and isinstance(bm, dict):
                r_time = float(bm.get('resume_time', 0))
                t_time = float(bm.get('total_time', 0))
                if r_time > 20 and (t_time == 0 or (r_time / t_time < 0.80)):
                    return bm
        except Exception: pass

    # 2. Sync from TMDb Helper's Trakt cache (ItemDetails.db)
    if tmdb_id:
        try:
            tmdb_base = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/')
            db_files = []
            if os.path.exists(tmdb_base):
                for root, _, files in os.walk(tmdb_base):
                    for fn in files:
                        if fn.lower() == 'itemdetails.db':
                            db_files.append(os.path.join(root, fn))

            for db_path in db_files:
                try:
                    conn = sqlite3.connect(db_path)
                    c = conn.cursor()
                    if is_series and season is not None and episode is not None:
                        c.execute("SELECT playback_progress, runtime, title FROM simplecache WHERE tmdb_id = ? AND season_number = ? AND episode_number = ? AND item_type = 'episode' AND playback_progress > 0;", (int(tmdb_id), int(season), int(episode)))
                    else:
                        c.execute("SELECT playback_progress, runtime, title FROM simplecache WHERE tmdb_id = ? AND item_type = 'movie' AND playback_progress > 0;", (int(tmdb_id),))
                    row = c.fetchone()
                    conn.close()
                    if row:
                        progress_pct, runtime_mins, title = row[0], row[1], row[2]
                        if progress_pct and runtime_mins and float(progress_pct) > 0.2:
                            pct = float(progress_pct)
                            if pct <= 1.0 and pct > 0: pct = pct * 100.0
                            tot_sec = float(runtime_mins) * 60.0
                            res_sec = (pct / 100.0) * tot_sec
                            if res_sec > 20 and (res_sec / tot_sec < 0.80):
                                return {'resume_time': res_sec, 'total_time': tot_sec, 'title': title, 'source': 'trakt'}
                except Exception: pass
        except Exception: pass

    return None

def save_bookmark(media_key, resume_time, total_time, title=""):
    if not media_key: return
    try:
        data = {}
        if os.path.exists(BOOKMARKS_FILE):
            try:
                with open(BOOKMARKS_FILE, 'r', encoding='utf-8') as f: data = json.load(f)
            except: data = {}
        
        # Al llegar al 80% o estar completado, eliminar bookmark para no guardar en reanudar
        if (total_time > 0 and (resume_time / float(total_time) >= 0.80)) or is_item_completed(media_key):
            if media_key in data: del data[media_key]
        elif resume_time > 30:
            data[media_key] = {
                'resume_time': float(resume_time),
                'total_time': float(total_time),
                'title': title,
                'updated': time.time()
            }
        elif resume_time <= 30 and media_key in data:
            del data[media_key]

        # Escritura atomica (temp + replace): si Kodi mata el script a mitad
        # (cierre con hilos vivos), el archivo jamas queda corrupto a medias.
        try:
            _tmp = BOOKMARKS_FILE + '.tmp'
            with open(_tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(_tmp, BOOKMARKS_FILE)
        except Exception:
            try:
                with open(BOOKMARKS_FILE, 'w', encoding='utf-8') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            except: pass
    except: pass

def load_continue_watching_data():
    if os.path.exists(CONTINUE_WATCHING_FILE):
        try:
            with open(CONTINUE_WATCHING_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def _strip_emojis_and_symbols(text):
    if not text: return ""
    try:
        # Elimina emojis, iconos y caracteres decorativos unicode
        return re.sub(r'[\U00010000-\U0010ffff\u2500-\u2bef\u2600-\u27bf\u2300-\u23ff\u2b00-\u2bff]', '', str(text)).strip()
    except Exception:
        return str(text)

def save_continue_watching_record(media_key, record_data):
    if not media_key or not isinstance(record_data, dict): return
    try:
        if 'title' in record_data and record_data['title']:
            record_data['title'] = _strip_emojis_and_symbols(record_data['title'])
        if 'showname' in record_data and record_data['showname']:
            record_data['showname'] = _strip_emojis_and_symbols(record_data['showname'])
        data = load_continue_watching_data()
        data[media_key] = record_data
        _tmp = CONTINUE_WATCHING_FILE + '.tmp'
        with open(_tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(_tmp, CONTINUE_WATCHING_FILE)
    except Exception as e:
        xbmc.log(f"Multi Bridge: save_continue_watching_record error: {e}", xbmc.LOGWARNING)

def remove_continue_watching_record(media_key):
    if not media_key: return
    try:
        data = load_continue_watching_data()
        if media_key in data:
            del data[media_key]
            _tmp = CONTINUE_WATCHING_FILE + '.tmp'
            with open(_tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(_tmp, CONTINUE_WATCHING_FILE)
    except Exception as e:
        xbmc.log(f"Multi Bridge: remove_continue_watching_record error: {e}", xbmc.LOGWARNING)

def clear_all_continue_watching():
    try:
        _tmp = CONTINUE_WATCHING_FILE + '.tmp'
        with open(_tmp, 'w', encoding='utf-8') as f:
            json.dump({}, f, indent=2, ensure_ascii=False)
        os.replace(_tmp, CONTINUE_WATCHING_FILE)
    except Exception as e:
        xbmc.log(f"Multi Bridge: clear_all_continue_watching error: {e}", xbmc.LOGWARNING)

def load_completed_data():
    if os.path.exists(COMPLETED_ITEMS_FILE):
        try:
            with open(COMPLETED_ITEMS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def mark_item_as_completed(media_key, meta=None, title="", total_time=0):
    if not media_key: return
    try:
        data = load_completed_data()
        m_dict = meta if isinstance(meta, dict) else {}
        data[media_key] = {
            'title': _strip_emojis_and_symbols(title or m_dict.get('title') or ''),
            'showname': _strip_emojis_and_symbols(m_dict.get('showname') or ''),
            'tmdb': m_dict.get('tmdb') or m_dict.get('tmdb_id') or '',
            'imdb': m_dict.get('imdb') or m_dict.get('imdb_id') or '',
            'season': m_dict.get('season'),
            'episode': m_dict.get('episode'),
            'completed_at': time.time(),
            'total_time': float(total_time or 0)
        }
        _tmp = COMPLETED_ITEMS_FILE + '.tmp'
        with open(_tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(_tmp, COMPLETED_ITEMS_FILE)

        # 1. Eliminar inmediatamente del historial de Continuar viendo
        remove_continue_watching_record(media_key)

        # 2. Marcar como completado/visto en el VideoInfoTag del Player de Kodi y via JSON-RPC
        try:
            p = xbmc.Player()
            if p.isPlayingVideo():
                vt = p.getVideoInfoTag()
                if vt:
                    try: vt.setPlaycount(1)
                    except: pass
                playing_file = p.getPlayingFile()
                if playing_file:
                    params = {
                        "file": playing_file,
                        "media": "video",
                        "playcount": 1,
                        "resume": {"position": 0, "total": float(total_time or 0)}
                    }
                    xbmc.executeJSONRPC(json.dumps({
                        "jsonrpc": "2.0",
                        "method": "Files.SetFileDetails",
                        "params": params,
                        "id": "mb_watched"
                    }))
        except Exception:
            pass
        xbmc.log(f"Multi Bridge: contenido {media_key} alcanzado al 80% -> marcado como COMPLETO y eliminado de Continuar viendo.", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Multi Bridge: mark_item_as_completed error: {e}", xbmc.LOGWARNING)

def is_item_completed(media_key):
    if not media_key: return False
    try:
        data = load_completed_data()
        return bool(media_key in data)
    except Exception:
        return False

def remove_completed_record(media_key):
    if not media_key: return
    try:
        data = load_completed_data()
        if media_key in data:
            del data[media_key]
            _tmp = COMPLETED_ITEMS_FILE + '.tmp'
            with open(_tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            os.replace(_tmp, COMPLETED_ITEMS_FILE)
    except Exception as e:
        xbmc.log(f"Multi Bridge: remove_completed_record error: {e}", xbmc.LOGWARNING)

_floating_dialog_active = False
_floating_dialog_lock = threading.Lock()
_playback_monitor_token = 0
_playback_monitor_lock = threading.Lock()
_current_playing_link_index = -1
if '_BG_TASK_ABORT_EVENT' not in globals():
    _BG_TASK_ABORT_EVENT = threading.Event()

def _get_global_monitor_token():
    try:
        return xbmcgui.Window(10000).getProperty('BridgeMulti.MonitorToken') or ''
    except Exception:
        return ''

def _set_global_monitor_token(token):
    try:
        xbmcgui.Window(10000).setProperty('BridgeMulti.MonitorToken', str(token or ''))
    except Exception:
        pass

def _is_dialog_active_global():
    try:
        return xbmcgui.Window(10000).getProperty('BridgeMulti.DialogActive') == 'true'
    except Exception:
        return False

def _set_dialog_active_global(active):
    try:
        xbmcgui.Window(10000).setProperty('BridgeMulti.DialogActive', 'true' if active else 'false')
    except Exception:
        pass

def _acquire_search_lock_atomic(search_title=''):
    """Adquiere el bloqueo de búsqueda global de forma 100% atómica usando
    un cerrojo a nivel de kernel del SO (O_CREAT | O_EXCL) y propiedades de ventana de Kodi."""
    now = time.time()
    try:
        w = xbmcgui.Window(10000)
    except Exception:
        w = None

    # 1. Verificar si existe cerrojo en disco previo
    try:
        if 'SEARCH_LOCK_FILE' in globals() and os.path.exists(SEARCH_LOCK_FILE):
            mtime = os.path.getmtime(SEARCH_LOCK_FILE)
            if (now - mtime) > 90:
                try: os.remove(SEARCH_LOCK_FILE)
                except Exception: pass
            else:
                return False
    except Exception:
        pass

    # 2. Verificar propiedad en memoria de Kodi
    try:
        if w and w.getProperty('BridgeMulti.SearchProcessRunning') == 'true':
            st = w.getProperty('BridgeMulti.SearchProcessStartTime')
            if st and (now - float(st)) <= 90:
                return False
            else:
                try:
                    w.setProperty('BridgeMulti.SearchProcessRunning', 'false')
                except Exception: pass
    except Exception:
        pass

    # 3. Intentar crear el archivo de cerrojo de forma ATÓMICA en el kernel del SO
    fd = None
    try:
        if 'SEARCH_LOCK_FILE' in globals():
            lock_dir = os.path.dirname(SEARCH_LOCK_FILE)
            if not os.path.exists(lock_dir):
                try: os.makedirs(lock_dir, exist_ok=True)
                except Exception: pass
            fd = os.open(SEARCH_LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            payload = "%s|%f|%d" % (str(search_title or ''), now, os.getpid())
            os.write(fd, payload.encode('utf-8'))
    except (FileExistsError, OSError):
        # Otro proceso ganó la carrera atómica en este mismo instante
        return False
    finally:
        if fd is not None:
            try: os.close(fd)
            except Exception: pass

    # 4. Establecer las propiedades en memoria en Window(10000)
    try:
        if w:
            w.setProperty('BridgeMulti.SearchProcessRunning', 'true')
            w.setProperty('BridgeMulti.SearchProcessStartTime', str(now))
            if search_title:
                w.setProperty('BridgeMulti.SearchProcessTitle', str(search_title))
    except Exception:
        pass

    return True

def _update_search_lock_title(search_title):
    """Actualiza el título del contenido una vez resuelta la traducción."""
    if not search_title: return
    try:
        xbmcgui.Window(10000).setProperty('BridgeMulti.SearchProcessTitle', str(search_title))
    except Exception:
        pass

def _get_search_process_title_global():
    try:
        t = xbmcgui.Window(10000).getProperty('BridgeMulti.SearchProcessTitle')
        if t: return t
    except Exception:
        pass
    try:
        if 'SEARCH_LOCK_FILE' in globals() and os.path.exists(SEARCH_LOCK_FILE):
            data = open(SEARCH_LOCK_FILE, 'r', encoding='utf-8', errors='ignore').read()
            if '|' in data:
                return data.split('|')[0]
    except Exception:
        pass
    return ''

def _is_search_process_running_global():
    now = time.time()
    try:
        if 'SEARCH_LOCK_FILE' in globals() and os.path.exists(SEARCH_LOCK_FILE):
            mtime = os.path.getmtime(SEARCH_LOCK_FILE)
            if (now - mtime) <= 90:
                return True
            else:
                try: os.remove(SEARCH_LOCK_FILE)
                except Exception: pass
    except Exception:
        pass
    try:
        w = xbmcgui.Window(10000)
        if w.getProperty('BridgeMulti.SearchProcessRunning') == 'true':
            st = w.getProperty('BridgeMulti.SearchProcessStartTime')
            if st and (now - float(st)) <= 90:
                return True
    except Exception:
        pass
    return False

def _release_search_lock_atomic():
    """Libera el cerrojo atómico tanto en disco como en memoria."""
    try:
        if 'SEARCH_LOCK_FILE' in globals() and os.path.exists(SEARCH_LOCK_FILE):
            try: os.remove(SEARCH_LOCK_FILE)
            except Exception: pass
    except Exception:
        pass
    try:
        w = xbmcgui.Window(10000)
        w.setProperty('BridgeMulti.SearchProcessRunning', 'false')
        w.clearProperty('BridgeMulti.SearchProcessStartTime')
        w.clearProperty('BridgeMulti.SearchProcessTitle')
    except Exception:
        pass

_active_playback_monitor_thread = None
_ACTIVE_BG_THREADS = []
_ACTIVE_BG_THREADS_LOCK = threading.Lock()

def _register_bg_thread(th):
    if not th:
        return
    try:
        with _ACTIVE_BG_THREADS_LOCK:
            _ACTIVE_BG_THREADS[:] = [t for t in _ACTIVE_BG_THREADS if t.is_alive()]
            _ACTIVE_BG_THREADS.append(th)
    except Exception:
        pass

def wait_for_playback_monitor():
    """Mantiene vivo el hilo principal del invoker de Python mientras dure la reproducción.
    Esto evita que Kodi entre en 'CPythonInvoker: waiting on thread ...' y finalice Python
    por la fuerza tras 5 segundos (lo cual provoca crasheos con cambios de refresco de pantalla
    o salidas intempestivas)."""
    global _active_playback_monitor_thread
    if _active_playback_monitor_thread and _active_playback_monitor_thread.is_alive():
        mon = xbmc.Monitor()
        while _active_playback_monitor_thread.is_alive() and not mon.abortRequested():
            if mon.waitForAbort(0.25):
                break
    # Asegurar cierre limpio de recolectores/pipeline secundarios antes de salir del invoker
    _BG_TASK_ABORT_EVENT.set()
    try:
        with _ACTIVE_BG_THREADS_LOCK:
            pending = [t for t in _ACTIVE_BG_THREADS if t.is_alive()]
            _ACTIVE_BG_THREADS.clear()
        deadline = time.time() + 2.5
        for t in pending:
            rem = deadline - time.time()
            if rem <= 0:
                break
            try:
                t.join(timeout=min(0.5, rem))
            except Exception:
                pass
    except Exception:
        pass

def start_playback_monitor(media_key, title_str="", seek_to_time=0, current_link_index=0, meta=None, force_beginning=False, old_playing_file=None):
    if not media_key: return
    global _playback_monitor_token, _current_playing_link_index
    _BG_TASK_ABORT_EVENT.clear()
    _ensure_shutdown_watchdog()
    with _playback_monitor_lock:
        _playback_monitor_token += 1
        my_token = "%f_%d_%d" % (time.time(), _playback_monitor_token, random.randint(10000, 99999))
        _set_global_monitor_token(my_token)
        try:
            xbmcgui.Window(10000).setProperty('BridgeMulti.CurrentMediaKey', str(media_key or ''))
            xbmcgui.Window(10000).setProperty('BridgeMulti.CurrentPlayingIndex', str(current_link_index if current_link_index is not None else -1))
        except Exception:
            pass
        _current_playing_link_index = current_link_index

    # Pre-calentar en segundo plano la comprobación de siguiente episodio (para 0 latencia en pausa)
    if meta and meta.get('season') and meta.get('episode'):
        try:
            threading.Thread(target=_get_next_episode_info, args=(meta,), daemon=True).start()
        except Exception:
            pass

    # Limpiar cualquier estado residual de diálogo previo
    _set_dialog_active_global(False)

    def _monitor_loop():
        global _floating_dialog_active
        p = xbmc.Player()
        mon = xbmc.Monitor()
        xbmc.log("Multi Bridge: monitor de reproducción iniciado para %s (esperando inicio de vídeo)..." % (title_str or media_key), xbmc.LOGINFO)

        # Esperar hasta 180 segundos (3 minutos) a que inicie la reproducción
        # Esto es vital para torrents (Elementum, Quasar) que tardan en conectar con peers y descargar el pre-buffer
        video_started = False
        _switch_wait_start = time.time()
        for _w in range(720):
            if mon.abortRequested() or _get_global_monitor_token() != my_token:
                xbmc.log("Multi Bridge: monitor descartado antes de iniciar (superado por nuevo enlace o cancelado)", xbmc.LOGINFO)
                return
            if _is_kodi_modal_dialog_open():
                xbmc.log("Multi Bridge: monitor detectó error de reproducción de Kodi antes de iniciar", xbmc.LOGINFO)
                return
            if p.isPlayingVideo():
                if old_playing_file:
                    try:
                        _pf = p.getPlayingFile() or ''
                    except Exception:
                        _pf = ''
                    if _pf and _pf == old_playing_file and (time.time() - _switch_wait_start) < 3.5:
                        if mon.waitForAbort(0.1): return
                        continue
                # Comprobar que la clave de medios coincide con la sesión actual
                cur_k = ''
                try: cur_k = xbmcgui.Window(10000).getProperty('BridgeMulti.CurrentMediaKey') or ''
                except Exception: pass
                if cur_k and cur_k != str(media_key):
                    xbmc.log("Multi Bridge: monitor descartado (reproducción activa no coincide con media_key: %s != %s)" % (cur_k, media_key), xbmc.LOGINFO)
                    return
                video_started = True
                break
            if mon.waitForAbort(0.25): return

        if not video_started or not p.isPlayingVideo() or _get_global_monitor_token() != my_token:
            xbmc.log("Multi Bridge: monitor de reproducción cancelado (tiempo agotado o superado)", xbmc.LOGINFO)
            return

        xbmc.log("Multi Bridge: monitor de reproducción ACTIVO (vídeo detectado en reproducción: %s)" % (title_str or media_key), xbmc.LOGINFO)

        # Asegurar el cierre inmediato del spinner de carga y barras OSD/SeekBar tras cambio en caliente
        # para que los subtítulos aparezcan abajo desde el primer instante
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog,true)')
            xbmc.executebuiltin('Dialog.Close(extendedbusydialog,true)')
            xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
            if old_playing_file:
                xbmc.executebuiltin('Dialog.Close(seekbar,true)')
                xbmc.executebuiltin('Dialog.Close(videoosd,true)')
                xbmc.executebuiltin('Dialog.Close(fullscreeninfo,true)')
        except Exception:
            pass

        # Período de gracia para permitir que el ajuste de refresco de pantalla de Kodi
        # (Display resolution ADJUST / OnLostDisplay / OnResetDisplay) y la inicialización
        # de decodificadores de audio/video se asienten antes de realizar llamadas C++ al Player.
        # Detecta también freeze de códec Android MediaCodec: si getTime() se queda en 0.0s
        # durante mucho tiempo pese a que isPlayingVideo()=True, el monitor se cierra para que
        # el watchdog externo detecte el fallo y cambie de servidor.
        _grace_codec_timeout = 8.0  # máx tiempo esperando que el reloj supere 0.5s
        _grace_start = time.time()
        for _s in range(80):
            if mon.abortRequested() or not p.isPlayingVideo() or _get_global_monitor_token() != my_token:
                break
            try:
                if p.getTime() >= 0.5:
                    break
            except Exception:
                pass
            if (time.time() - _grace_start) > _grace_codec_timeout:
                # El reloj no ha avanzado en 8 segundos con isPlayingVideo()=True: fallo de códec
                xbmc.log("Multi Bridge: monitor de reproducción - getTime() estancado en 0s durante %.1fs -> posible freeze de códec, cancelando monitor [%s]" % (
                    _grace_codec_timeout, title_str or media_key), xbmc.LOGWARNING)
                return
            if mon.waitForAbort(0.1): return

        # Registrar sesión activa en Continuar viendo con estado inicial 'playing'
        _m_dict = dict(meta or {})
        try:
            xbmcgui.Window(10000).setProperty('BridgeMulti.PlaybackStartTs', str(time.time()))
        except Exception:
            pass

        # Disparar pipeline secuencial en segundo plano (Fase 1: verificar enlaces faltantes del capitulo actual -> Fase 2: precargar siguiente capitulo)
        try:
            _pipe_th = threading.Thread(
                target=_start_playback_background_pipeline,
                args=(_m_dict, my_token),
                daemon=True,
                name="MultiBridgePlaybackPipeline"
            )
            _register_bg_thread(_pipe_th)
            _pipe_th.start()
        except Exception as _pipe_e:
            xbmc.log("Multi Bridge: error lanzando pipeline en segundo plano: %s" % str(_pipe_e), xbmc.LOGWARNING)

        # Re-sincronizar inmediatamente metadatos globales para Trakt y TMDb Helper al iniciar vídeo
        sync_tmdbhelper_playerstring(_m_dict)
        try:
            vt = p.getVideoInfoTag()
            if vt:
                _t_id = str(_m_dict.get('tmdb') or '')
                _i_id = str(_m_dict.get('imdb') or '')
                _tv_id = str(_m_dict.get('tvdb') or '')
                _tr_id = str(_m_dict.get('trakt') or '')
                _is_s = bool(_m_dict.get('season') and _m_dict.get('episode'))
                _uids = {}
                if _t_id:
                    _uids['tmdb'] = _t_id
                    if _is_s: _uids['tvshow.tmdb'] = _t_id
                if _i_id:
                    _uids['imdb'] = _i_id
                    if _is_s: _uids['tvshow.imdb'] = _i_id
                if _tv_id:
                    _uids['tvdb'] = _tv_id
                    if _is_s: _uids['tvshow.tvdb'] = _tv_id
                if _tr_id:
                    _uids['trakt'] = _tr_id
                if _uids:
                    try: vt.setUniqueIDs(_uids, 'tmdb' if _t_id else ('imdb' if _i_id else ''))
                    except: pass
                if _i_id:
                    try: vt.setIMDbNumber(_i_id)
                    except: pass
                vt.setMediaType('episode' if _is_s else 'movie')
                if _is_s:
                    _sh = str(_m_dict.get('showname') or '')
                    _ti = str(_m_dict.get('title') or '')
                    _se = _m_dict.get('season')
                    _ep = _m_dict.get('episode')
                    if _sh: vt.setTvShowTitle(_sh)
                    if _ti: vt.setTitle(_ti)
                    elif _sh and _se and _ep:
                        try: vt.setTitle(f"{_sh} {int(_se)}x{int(_ep):02d}")
                        except: vt.setTitle(f"{_sh} {_se}x{_ep}")
                    if _se:
                        try: vt.setSeason(int(_se))
                        except: pass
                    if _ep:
                        try: vt.setEpisode(int(_ep))
                        except: pass
                else:
                    _ti = str(_m_dict.get('title') or '')
                    if _ti: vt.setTitle(_ti)
                _yr = _m_dict.get('showyear' if _is_s else 'year') or _m_dict.get('year')
                if _yr:
                    try: vt.setYear(int(_yr))
                    except: pass
                _pl_str = _m_dict.get('plot')
                if _pl_str: vt.setPlot(str(_pl_str))
                xbmc.log("Multi Bridge: VideoInfoTag del Player actualizado tras arranque de reproduccion", xbmc.LOGINFO)
        except Exception as _e_tag:
            xbmc.log("Multi Bridge: error inyectando VideoInfoTag en Player: %s" % _e_tag, xbmc.LOGINFO)
        try:
            _pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            _pos = _pl.getposition()
            if 0 <= _pos < _pl.size():
                _cur_item = _pl[_pos]
                if _cur_item:
                    set_listitem_info(_cur_item, meta=_m_dict)
        except Exception:
            pass

        _logo_val = _m_dict.get('clearlogo') or ''
        if not _logo_val and _m_dict.get('tmdb'):
            try:
                _logo_val = _get_clearlogo(_m_dict.get('tmdb'), bool(_m_dict.get('season') and _m_dict.get('episode')))
            except Exception:
                pass
        if _logo_val:
            _m_dict['clearlogo'] = _logo_val
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.ClearLogo', _logo_val)
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.CropImage', _logo_val)
                xbmcgui.Window(10000).setProperty('TMDbHelper.Player.ClearLogo', _logo_val)
                xbmcgui.Window(10000).setProperty('Player.Art(clearlogo)', _logo_val)
                xbmcgui.Window(10000).setProperty('MultiBridge.ClearLogo', _logo_val)
            except Exception:
                pass

        _genre_val = _m_dict.get('genre') or ''
        if not _genre_val and _m_dict.get('tmdb'):
            try:
                _g_list = _get_genres(_m_dict.get('tmdb'), bool(_m_dict.get('season') and _m_dict.get('episode')))
                if _g_list:
                    _genre_val = " / ".join(_g_list)
            except Exception:
                pass
        if _genre_val:
            _m_dict['genre'] = _genre_val
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Genre', _genre_val)
                xbmcgui.Window(10000).setProperty('VideoPlayer.Genre', _genre_val)
                xbmcgui.Window(10000).setProperty('MultiBridge.Genre', _genre_val)
            except Exception:
                pass

        _director_val = _clean_single_director(_m_dict.get('director'))
        if not _director_val and _m_dict.get('tmdb'):
            try:
                _d_list = _get_directors(_m_dict.get('tmdb'), bool(_m_dict.get('season') and _m_dict.get('episode')))
                if _d_list:
                    _director_val = _clean_single_director(_d_list[0])
            except Exception:
                pass
        if _director_val:
            _m_dict['director'] = _director_val
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Director', _director_val)
                xbmcgui.Window(10000).setProperty('VideoPlayer.Director', _director_val)
                xbmcgui.Window(10000).setProperty('MultiBridge.Director', _director_val)
            except Exception:
                pass

        _still_val = _m_dict.get('thumbnail') or ''
        if bool(_m_dict.get('season') and _m_dict.get('episode')) and _m_dict.get('tmdb'):
            try:
                _ep_still = _get_episode_still(_m_dict.get('tmdb'), _m_dict.get('season'), _m_dict.get('episode'))
                if _ep_still:
                    _still_val = _ep_still
                    _m_dict['thumbnail'] = _still_val
            except Exception:
                pass
        if _still_val:
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Thumb', _still_val)
                xbmcgui.Window(10000).setProperty('TMDbHelper.Player.Thumb', _still_val)
                xbmcgui.Window(10000).setProperty('Player.Art(thumb)', _still_val)
                xbmcgui.Window(10000).setProperty('Player.Art(poster)', _still_val)
                xbmcgui.Window(10000).setProperty('VideoPlayer.Cover', _still_val)
                xbmcgui.Window(10000).setProperty('MultiBridge.EpisodeStill', _still_val)
            except Exception:
                pass
        session_record = {
            'media_key': media_key,
            'status': 'playing',
            'interrupted': True,
            'tmdb': _m_dict.get('tmdb') or '',
            'imdb': _m_dict.get('imdb') or '',
            'tvdb': _m_dict.get('tvdb') or '',
            'trakt': _m_dict.get('trakt') or '',
            'is_series': bool(_m_dict.get('season') and _m_dict.get('episode')),
            'season': _m_dict.get('season'),
            'episode': _m_dict.get('episode'),
            'title': title_str or _m_dict.get('title') or '',
            'showname': _m_dict.get('showname') or '',
            'year': _m_dict.get('year') or _m_dict.get('showyear') or '',
            'plot': _m_dict.get('plot') or '',
            'poster': _m_dict.get('poster') or _m_dict.get('thumbnail') or '',
            'fanart': _m_dict.get('fanart') or '',
            'clearlogo': _m_dict.get('clearlogo') or '',
            'genre': _m_dict.get('genre') or '',
            'director': _m_dict.get('director') or '',
            'thumbnail': _m_dict.get('thumbnail') or '',
            'resume_time': float(seek_to_time or 0),
            'total_time': 0,
            'last_heartbeat': time.time()
        }
        save_continue_watching_record(media_key, session_record)

        if seek_to_time > 2:
            for _s in range(30):
                if mon.abortRequested() or _get_global_monitor_token() != my_token: return
                try:
                    if p.isPlayingVideo() and (p.getTime() > 0 or p.getTotalTime() > 0):
                        break
                except: pass
                if mon.waitForAbort(0.25): return
            try:
                _cur_seek_t = float(p.getTime() or 0.0)
                if abs(_cur_seek_t - float(seek_to_time)) > 4.0:
                    xbmc.log("Multi Bridge: saltando a reanudar %.0fs (key=%s)" % (float(seek_to_time), media_key), xbmc.LOGINFO)
                    p.seekTime(float(seek_to_time))
                    mon.waitForAbort(0.15)
                if old_playing_file:
                    xbmc.executebuiltin('Dialog.Close(seekbar,true)')
                    xbmc.executebuiltin('Dialog.Close(videoosd,true)')
                    xbmcgui.Window(10000).clearProperty('BridgeMulti.HotSwitching')
            except Exception as _ske:
                xbmc.log("Multi Bridge: error seekTime: %s" % str(_ske), xbmc.LOGINFO)
        elif seek_to_time <= 0 or force_beginning:
            # Si se reproduce desde el principio, asegurar que Kodi no salte a un bookmark residual de otra sesion
            for _s in range(15):
                if mon.abortRequested() or _get_global_monitor_token() != my_token: return
                try:
                    if p.isPlayingVideo() and p.getTime() > 3:
                        xbmc.log("Multi Bridge: detectado salto residual a %.1fs en contenido nuevo, forzando inicio a 0s" % p.getTime(), xbmc.LOGINFO)
                        p.seekTime(0.0)
                        break
                    elif p.isPlayingVideo() and p.getTime() > 0:
                        break
                except Exception: pass
                if mon.waitForAbort(0.25): return

        last_saved_time = 0
        tot_time = 0
        last_pause_state = False
        pause_cooldown = time.time() + 5.0
        active_idx = current_link_index

        _trakt_reassert_deadline = time.time() + 15.0
        while p.isPlayingVideo() and not mon.abortRequested():
            if _get_global_monitor_token() != my_token:
                xbmc.log("Multi Bridge: monitor finalizado (un nuevo monitor tomó el control)", xbmc.LOGINFO)
                break
            try:
                # Sincronizar active_idx dinámicamente si la Fase 1 reordenó la lista de enlaces
                try:
                    _p_idx_prop = xbmcgui.Window(10000).getProperty('BridgeMulti.CurrentPlayingIndex')
                    if _p_idx_prop and _p_idx_prop.isdigit():
                        active_idx = int(_p_idx_prop)
                except Exception:
                    pass

                # Mantener IDs de Trakt activos durante el arranque para evitar que eventos stop asíncronos los borren
                if time.time() < _trakt_reassert_deadline:
                    if not xbmcgui.Window(10000).getProperty('script.trakt.ids'):
                        sync_tmdbhelper_playerstring(_m_dict)

                cur_time = p.getTime()
                tot = p.getTotalTime()
                if tot > 0: tot_time = tot

                # Al llegar al 80% o más: Marcar como COMPLETO y NO guardar en Continuar viendo
                is_completed = bool(tot_time > 0 and (cur_time / float(tot_time) >= 0.80))
                if is_completed:
                    mark_item_as_completed(media_key, meta=_m_dict, title=title_str, total_time=tot_time)
                    save_bookmark(media_key, cur_time, tot_time, title=title_str)
                    last_saved_time = cur_time
                elif abs(cur_time - last_saved_time) >= 5:
                    save_bookmark(media_key, cur_time, tot_time, title=title_str)
                    last_saved_time = cur_time

                    # Actualizar latido continuo en Continuar viendo SOLO si no ha alcanzado el 80%
                    session_record['resume_time'] = float(cur_time)
                    session_record['total_time'] = float(tot_time)
                    session_record['last_heartbeat'] = time.time()
                    save_continue_watching_record(media_key, session_record)

                # Detección de pausa en vivo
                is_paused = bool(xbmc.getCondVisibility("Player.Paused"))
                pause_setting = str(_bridge_addon.getSetting('live_switch_on_pause') or '').strip().lower()

                if is_paused and not last_pause_state and pause_setting not in ('false', '2'):
                    now = time.time()
                    if now > pause_cooldown and cur_time >= 2.0 and not _floating_dialog_active and not _is_dialog_active_global():
                        xbmc.log("Multi Bridge: PAUSA DETECTADA en reproducción (cur_time=%.1fs, server_idx=%d)" % (cur_time, active_idx), xbmc.LOGINFO)
                        with _floating_dialog_lock:
                            _floating_dialog_active = True
                        _set_dialog_active_global(True)
                        try:
                            c_links, c_matched, c_meta, c_eng = _load_cached_links_for_dialog()
                            if c_links:
                                open_links = False
                                if pause_setting == '1':
                                    open_links = True
                                else:
                                    curr_srv = _get_link_server_name(c_links[active_idx]) if active_idx < len(c_links) else ""
                                    curr_qual = _format_quality(c_links[active_idx]) if active_idx < len(c_links) else ""
                                    prompt_dlg = _PausePromptDialog(current_server_name=curr_srv, current_quality=curr_qual, meta=c_meta)
                                    prompt_dlg.doModal()
                                    ans = prompt_dlg.selected
                                    next_ep_info = getattr(prompt_dlg, 'next_ep', None)
                                    del prompt_dlg
                                    if ans == 1 and p.isPlayingVideo():
                                        open_links = True
                                    elif ans == 2 and next_ep_info:
                                        # Usuario seleccionó reproducir siguiente capítulo
                                        try:
                                            if p.isPlayingVideo():
                                                p.stop()
                                        except Exception:
                                            pass
                                        _play_next_episode(c_meta, next_ep_info)
                                        return
                                    else:
                                        if p.isPlayingVideo() and xbmc.getCondVisibility("Player.Paused"):
                                            try: p.pause()
                                            except: pass
                                        is_paused = False
                                        last_pause_state = False
                                        pause_cooldown = time.time() + 4.0

                                if open_links and p.isPlayingVideo():
                                    cur_mk = _get_media_key(c_meta, c_links[active_idx] if active_idx < len(c_links) else None) or media_key
                                    cur_failed_sigs = _get_session_failed_signatures(media_key=cur_mk, meta=c_meta)
                                    cur_failed_links = {l for l in c_links if getattr(l, 'bridge_failed', False) or (_get_link_unique_id(l) in cur_failed_sigs)}
                                    dlg = _FloatingLinksDialog(c_links, current_index=active_idx, meta=c_meta, engine=c_eng, is_playback=True, failed_links=cur_failed_links)
                                    dlg.doModal()
                                    chosen_idx = dlg.selected
                                    chosen_link = getattr(dlg, 'selected_link', None)
                                    del dlg
                                    xbmc.sleep(150)
                                    if chosen_idx == 'force_search':
                                        try:
                                            if p.isPlayingVideo():
                                                p.stop()
                                        except Exception:
                                            pass
                                        _u = 'plugin://plugin.video.bridge.multi/?action=force_search'
                                        _t_id = str(c_meta.get('tmdb') or c_meta.get('tmdb_id') or '')
                                        _s = str(c_meta.get('season') or '')
                                        _e = str(c_meta.get('episode') or '')
                                        _t = str(c_meta.get('title') or '')
                                        _sn = str(c_meta.get('showname') or '')
                                        _y = str(c_meta.get('year') or '')
                                        _sy = str(c_meta.get('showyear') or '')
                                        _imdb = str(c_meta.get('imdb') or c_meta.get('imdb_id') or '')
                                        _eng = str(c_eng or c_meta.get('engine') or '')
                                        if _t_id: _u += '&tmdb=' + _t_id
                                        if _s and _e: _u += '&season=' + _s + '&episode=' + _e
                                        if _t: _u += '&title=' + uparse.quote_plus(_t)
                                        if _sn: _u += '&showname=' + uparse.quote_plus(_sn)
                                        if _y: _u += '&year=' + _y
                                        if _sy: _u += '&showyear=' + _sy
                                        if _imdb: _u += '&imdb=' + _imdb
                                        if _eng: _u += '&engine=' + _eng
                                        xbmc.executebuiltin('RunPlugin(%s)' % _u)
                                        return
                                    elif chosen_idx == 'other_engine':
                                        try:
                                            if p.isPlayingVideo():
                                                p.stop()
                                        except Exception:
                                            pass
                                        _other_engine = 'balandro' if c_eng == 'alfa' else 'alfa'
                                        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.bridge.multi/?action=search_other_engine&engine=%s)' % _other_engine)
                                        return
                                    elif chosen_idx == 'verify_links':
                                        try:
                                            if p.isPlayingVideo():
                                                p.stop()
                                        except Exception:
                                            pass
                                        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.bridge.multi/?action=verify_links)')
                                        return
                                    elif isinstance(chosen_idx, int) and chosen_idx >= 0:
                                        if chosen_link is None and 0 <= chosen_idx < len(c_links):
                                            chosen_link = c_links[chosen_idx]
                                        switched = _switch_to_link(chosen_idx, c_links, c_meta, c_matched, engine=c_eng, force_cur_time=cur_time, chosen_link=chosen_link)
                                        if switched:
                                            chosen_l = chosen_link or c_links[chosen_idx]
                                            srv_n = _get_link_server_name(chosen_l) or 'Servidor'
                                            is_t = (srv_n.lower() == 'torrent' or _is_torrent_link(chosen_l))
                                            switch_ok = _verify_playback_started(is_torrent=is_t)
                                            if not switch_ok and not p.isPlayingVideo():
                                                _record_session_failed_link(chosen_l, index=chosen_idx, media_key=cur_mk, meta=c_meta)
                                                if _is_kodi_modal_dialog_open():
                                                    _wait_for_kodi_modal_dialog_to_dismiss(max_wait=60.0)
                                                show_floating_links_dialog()
                                            return
                                        else:
                                            if not p.isPlayingVideo():
                                                chosen_l = chosen_link or c_links[chosen_idx]
                                                _record_session_failed_link(chosen_l, index=chosen_idx, media_key=cur_mk, meta=c_meta)
                                                if _is_kodi_modal_dialog_open():
                                                    _wait_for_kodi_modal_dialog_to_dismiss(max_wait=60.0)
                                                show_floating_links_dialog()
                                            return
                                    else:
                                        _clear_session_failed_links(cur_mk)
                                        for _l in c_links:
                                            try: setattr(_l, 'bridge_failed', False)
                                            except Exception: pass
                                        if p.isPlayingVideo() and xbmc.getCondVisibility("Player.Paused"):
                                            try: p.pause()
                                            except: pass
                                        is_paused = False
                                        last_pause_state = False
                                        pause_cooldown = time.time() + 4.0
                        except Exception as _de:
                            xbmc.log(f"Multi Bridge: floating dialog error: {_de}", xbmc.LOGINFO)
                        finally:
                            _set_dialog_active_global(False)
                            with _floating_dialog_lock:
                                _floating_dialog_active = False

                last_pause_state = is_paused

            except Exception:
                pass

            if mon.waitForAbort(0.25): break

        _BG_TASK_ABORT_EVENT.set()
        if mon.abortRequested() or _SHUTDOWN_REQUESTED:
            abort_all_network_sockets()
        if _get_global_monitor_token() != my_token:
            xbmc.log("Multi Bridge: monitor anterior finalizado limpiamente (control transferido al nuevo servidor)", xbmc.LOGINFO)
            return

        if _get_global_monitor_token() == my_token:
            _set_global_monitor_token('')
            try:
                xbmcgui.Window(10000).clearProperty('BridgeMulti.CurrentMediaKey')
                xbmcgui.Window(10000).clearProperty('BridgeMulti.CurrentPlayingIndex')
                xbmcgui.Window(10000).clearProperty('TMDbHelper.ListItem.ClearLogo')
                xbmcgui.Window(10000).clearProperty('TMDbHelper.ListItem.CropImage')
                xbmcgui.Window(10000).clearProperty('TMDbHelper.Player.ClearLogo')
                xbmcgui.Window(10000).clearProperty('Player.Art(clearlogo)')
                xbmcgui.Window(10000).clearProperty('MultiBridge.ClearLogo')
                xbmcgui.Window(10000).clearProperty('TMDbHelper.ListItem.Genre')
                xbmcgui.Window(10000).clearProperty('VideoPlayer.Genre')
                xbmcgui.Window(10000).clearProperty('MultiBridge.Genre')
                xbmcgui.Window(10000).clearProperty('TMDbHelper.ListItem.Director')
                xbmcgui.Window(10000).clearProperty('VideoPlayer.Director')
                xbmcgui.Window(10000).clearProperty('MultiBridge.Director')
                xbmcgui.Window(10000).clearProperty('script.trakt.ids')
            except Exception: pass

        if last_saved_time > 0 or tot_time > 0:
            save_bookmark(media_key, last_saved_time, tot_time, title=title_str)

        # Distinción exacta: Parada normal voluntaria vs Interrupción anormal (corte de luz / crash)
        normal_exit = not mon.abortRequested()
        video_finished = bool(tot_time > 0 and (last_saved_time / float(tot_time) >= 0.80))

        if video_finished:
            xbmc.log("Multi Bridge: vídeo alcanzado al 80% o más. Marcando como COMPLETO y purgando Continuar viendo.", xbmc.LOGINFO)
            mark_item_as_completed(media_key, meta=_m_dict, title=title_str, total_time=tot_time)
            remove_continue_watching_record(media_key)
            _clear_session_failed_links(media_key)
        elif normal_exit:
            # El usuario pulsó Stop, volvió atrás o vio el final: parada limpia
            xbmc.log("Multi Bridge: parada normal voluntaria. Limpiando registro de Continuar viendo.", xbmc.LOGINFO)
            remove_continue_watching_record(media_key)
            _clear_session_failed_links(media_key)
        else:
            # Cierre forzado o interrupción inesperada de Kodi (< 80%)
            xbmc.log("Multi Bridge: parada abrupta/interrupción inesperada detectada (<80%). Preservando en Continuar viendo.", xbmc.LOGINFO)

    global _active_playback_monitor_thread
    _th = threading.Thread(target=_monitor_loop, daemon=True)
    _th.name = "BridgeMultiPlaybackMonitor"
    _active_playback_monitor_thread = _th
    _th.start()

alfa_icon = 'DefaultVideo.png'

def _safe_str(val):
    if val is None: return ""
    if isinstance(val, bytes):
        try: return val.decode('utf-8', errors='ignore')
        except: return str(val)
    return str(val)

def _safe_get_item_attr(item, attr_name, default=''):
    if not item: return default
    if hasattr(item, '__dict__') and attr_name in item.__dict__:
        val = item.__dict__[attr_name]
        if val is not None and val != '': return val
    if hasattr(item, '__dict__') and 'infoLabels' in item.__dict__:
        il = item.__dict__['infoLabels']
        if isinstance(il, dict) and attr_name in il:
            val = il[attr_name]
            if val is not None and val != '': return val
    return default

# ---------------------------------------------------------
# Dynamic Module Switcher for Clean Alfa / Balandro Execution
# ---------------------------------------------------------
_current_engine_env = None
_engine_lock = threading.RLock()

def _is_addon_installed(addon_id):
    """Comprueba si un add-on determinado está instalado y disponible en Kodi."""
    if not addon_id:
        return False
    try:
        if xbmc.getCondVisibility('System.HasAddon("%s")' % addon_id):
            return True
    except Exception:
        pass
    try:
        _a = xbmcaddon.Addon(addon_id)
        if _a and _a.getAddonInfo('id'):
            return True
    except Exception:
        pass
    return False


def _is_engine_installed(engine):
    """Comprueba si el motor (alfa o balandro) está instalado y disponible en Kodi."""
    addon_id = 'plugin.video.alfa' if engine == 'alfa' else 'plugin.video.balandro'
    addon_dir = alfa_path if engine == 'alfa' else balandro_path

    try:
        if xbmc.getCondVisibility('System.HasAddon("%s")' % addon_id):
            return True
    except Exception:
        pass

    try:
        _a = xbmcaddon.Addon(addon_id)
        if _a and _a.getAddonInfo('id'):
            return True
    except Exception:
        pass

    try:
        if os.path.isdir(addon_dir) and os.path.isdir(os.path.join(addon_dir, 'channels')):
            return True
    except Exception:
        pass

    return False

def _switch_engine_environment(target_engine):
    global _current_engine_env
    if _current_engine_env == target_engine:
        return
    with _engine_lock:
        if _current_engine_env == target_engine:
            return
        for m in list(sys.modules.keys()):
            if any(m == sm or m.startswith(sm + '.') for sm in ['platformcode', 'core', 'channels', 'servers', 'modules', 'lib']):
                del sys.modules[m]
        sys.path = [p for p in sys.path if p not in (alfa_path, _alfa_lib, balandro_path, _balandro_lib)]
        if target_engine == 'alfa':
            sys.argv[0] = 'plugin://plugin.video.alfa/'
            if alfa_path not in sys.path: sys.path.insert(0, alfa_path)
            if os.path.exists(_alfa_lib) and _alfa_lib not in sys.path: sys.path.append(_alfa_lib)
        else:
            sys.argv[0] = 'plugin://plugin.video.balandro/'
            if balandro_path not in sys.path: sys.path.insert(0, balandro_path)
            if os.path.exists(_balandro_lib) and _balandro_lib not in sys.path: sys.path.append(_balandro_lib)
        _current_engine_env = target_engine

_ALFA_MODULES_CACHE = None
_BALANDRO_MODULES_CACHE = None

def _get_alfa_modules():
    global _ALFA_MODULES_CACHE
    if _ALFA_MODULES_CACHE is not None and _current_engine_env == 'alfa':
        return _ALFA_MODULES_CACHE
    if not _is_engine_installed('alfa'):
        return None
    try:
        _switch_engine_environment('alfa')
        from platformcode import config, platformtools
        from core.item import Item, InfoLabels
        from core import servertools, httptools, scrapertools
        config.get_runtime_path = lambda: alfa_path
        try:
            from core import tmdb as _a_tmdb
            _a_tmdb.set_infoLabels = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
            _a_tmdb.set_infoLabels_itemlist = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
        except Exception: pass
        _ALFA_MODULES_CACHE = {
            'path': alfa_path, 'config': config, 'platformtools': platformtools,
            'Item': Item, 'InfoLabels': InfoLabels, 'servertools': servertools,
            'httptools': httptools, 'scrapertools': scrapertools
        }
        return _ALFA_MODULES_CACHE
    except Exception as e:
        xbmc.log("Multi Bridge: Error cargando Alfa: " + str(e), xbmc.LOGWARNING)
        return None

def _get_balandro_modules():
    global _BALANDRO_MODULES_CACHE
    if _BALANDRO_MODULES_CACHE is not None and _current_engine_env == 'balandro':
        return _BALANDRO_MODULES_CACHE
    if not _is_engine_installed('balandro'):
        return None
    try:
        _switch_engine_environment('balandro')
        _patch_js2py_math_compatibility()
        from platformcode import config, platformtools
        from core.item import Item, InfoLabels
        from core import servertools, httptools, scrapertools
        config.get_runtime_path = lambda: balandro_path
        try:
            from core import tmdb as _b_tmdb
            _b_tmdb.set_infoLabels = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
            _b_tmdb.set_infoLabels_itemlist = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
            _b_tmdb.set_infoLabels_item = lambda *args, **kwargs: 0
        except Exception: pass

        orig_set_infolabels = platformtools.set_infolabels
        def _enhanced_balandro_set_infolabels(listitem, item, player=False):
            tmdb_id = str(_safe_get_item_attr(item, 'tmdb_id') or _safe_get_item_attr(item, 'tmdb') or _safe_get_item_attr(item, 'code') or '')
            imdb_id = str(_safe_get_item_attr(item, 'imdb_id') or _safe_get_item_attr(item, 'imdb') or _safe_get_item_attr(item, 'imdbnumber') or '')
            tvdb_id = str(_safe_get_item_attr(item, 'tvdb_id') or _safe_get_item_attr(item, 'tvdb') or '')
            trakt_id = str(_safe_get_item_attr(item, 'trakt_id') or _safe_get_item_attr(item, 'trakt') or '')

            title_str = str(_safe_get_item_attr(item, 'title') or _safe_get_item_attr(item, 'contentTitle') or '')
            showname_str = str(_safe_get_item_attr(item, 'tvshowtitle') or _safe_get_item_attr(item, 'contentSerieName') or _safe_get_item_attr(item, 'show') or '')
            season_num = _safe_get_item_attr(item, 'season', None)
            if season_num is None: season_num = _safe_get_item_attr(item, 'contentSeason', None)
            episode_num = _safe_get_item_attr(item, 'episode', None)
            if episode_num is None: episode_num = _safe_get_item_attr(item, 'contentEpisodeNumber', None)
            year_num = _safe_get_item_attr(item, 'year', None)
            plot_str = str(_safe_get_item_attr(item, 'plot') or _safe_get_item_attr(item, 'sinopsis') or '')
            tagline_str = str(_safe_get_item_attr(item, 'tagline') or _safe_get_item_attr(item, 'slogan') or '')

            try: orig_set_infolabels(listitem, item, player=player)
            except Exception: pass

            try:
                is_ep = bool(season_num is not None and episode_num is not None and str(season_num) != '' and str(episode_num) != '')
                unique_dict = {}
                if tmdb_id: unique_dict['tmdb'] = tmdb_id
                if imdb_id: unique_dict['imdb'] = imdb_id
                if tvdb_id: unique_dict['tvdb'] = tvdb_id
                if trakt_id: unique_dict['trakt'] = trakt_id

                if unique_dict:
                    try: listitem.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else 'imdb')
                    except: pass

                if tmdb_id: listitem.setProperty('tmdb_id', tmdb_id)
                if imdb_id: listitem.setProperty('imdb_id', imdb_id)
                if tvdb_id: listitem.setProperty('tvdb_id', tvdb_id)

                trakt_payload = {}
                if tmdb_id: trakt_payload['tmdb'] = int(tmdb_id) if tmdb_id.isdigit() else tmdb_id
                if imdb_id: trakt_payload['imdb'] = imdb_id
                if tvdb_id: trakt_payload['tvdb'] = int(tvdb_id) if tvdb_id.isdigit() else tvdb_id
                if trakt_payload:
                    listitem.setProperty('script.trakt.ids', json.dumps(trakt_payload))

                try:
                    vt = listitem.getVideoInfoTag()
                    if vt:
                        if unique_dict:
                            try: vt.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else ('imdb' if imdb_id else ''))
                            except: pass
                        if imdb_id:
                            try: vt.setIMDbNumber(imdb_id)
                            except: pass
                        if is_ep:
                            vt.setMediaType('episode')
                            if showname_str: vt.setTvShowTitle(showname_str)
                            if season_num: vt.setSeason(int(season_num))
                            if episode_num: vt.setEpisode(int(episode_num))
                            if title_str: vt.setTitle(title_str)
                        else:
                            vt.setMediaType('movie')
                            if title_str: vt.setTitle(title_str)
                        if year_num:
                            try: vt.setYear(int(year_num))
                            except: pass
                        if plot_str: vt.setPlot(plot_str)
                        if tagline_str:
                            try: vt.setTagLine(tagline_str)
                            except: pass
                except: pass
            except Exception: pass

        platformtools.set_infolabels = _enhanced_balandro_set_infolabels

        _BALANDRO_MODULES_CACHE = {
            'path': balandro_path, 'config': config, 'platformtools': platformtools,
            'Item': Item, 'InfoLabels': InfoLabels, 'servertools': servertools,
            'httptools': httptools, 'scrapertools': scrapertools
        }
        return _BALANDRO_MODULES_CACHE
    except Exception as e:
        xbmc.log("Multi Bridge: Error cargando Balandro: " + str(e), xbmc.LOGWARNING)
        return None

_dialog_silence_depth = 0
_dialog_silence_lock = threading.RLock()
_dialog_orig_pt = {}
_dialog_orig_tmdb = {}
_dialog_orig_modules = {}
_orig_dialog_class = None
_search_in_progress = False
_links_view_active = False

class _SilentDialog:
    def __init__(self, *args, **kwargs): pass
    def ok(self, *args, **kwargs): return True
    def yesno(self, *args, **kwargs): return True
    def select(self, *args, **kwargs): return -1
    def multiselect(self, *args, **kwargs): return []
    def notification(self, *args, **kwargs): return None
    def textviewer(self, *args, **kwargs): pass
    def input(self, *args, **kwargs): return ''
    def browse(self, *args, **kwargs): return ''
    def numeric(self, *args, **kwargs): return 0
    def contextmenu(self, *args, **kwargs): return -1

def _apply_silence_all():
    global _orig_dialog_class
    if hasattr(xbmcgui, 'Dialog') and xbmcgui.Dialog is not _SilentDialog:
        if _orig_dialog_class is None:
            _orig_dialog_class = xbmcgui.Dialog
        try:
            xbmcgui.Dialog = _SilentDialog
        except:
            pass

    for m_name, m_mod in list(sys.modules.items()):
        if not m_mod:
            continue
        if hasattr(m_mod, 'Dialog'):
            cur_d = getattr(m_mod, 'Dialog', None)
            if cur_d is not None and cur_d is not _SilentDialog:
                if m_name not in _dialog_orig_modules:
                    _dialog_orig_modules[m_name] = cur_d
                try:
                    setattr(m_mod, 'Dialog', _SilentDialog)
                except:
                    pass

        if 'platformtools' in m_name:
            if m_name not in _dialog_orig_pt:
                _dialog_orig_pt[m_name] = {
                    'dialog_ok': getattr(m_mod, 'dialog_ok', None),
                    'dialog_notification': getattr(m_mod, 'dialog_notification', None),
                    'dialog_yesno': getattr(m_mod, 'dialog_yesno', None),
                    'dialog_select': getattr(m_mod, 'dialog_select', None),
                    'dialog_multiselect': getattr(m_mod, 'dialog_multiselect', None),
                }
            m_mod.dialog_ok = lambda *args, **kwargs: None
            m_mod.dialog_notification = lambda *args, **kwargs: None
            m_mod.dialog_yesno = lambda *args, **kwargs: True
            m_mod.dialog_select = lambda *args, **kwargs: -1
            m_mod.dialog_multiselect = lambda *args, **kwargs: []

        if hasattr(m_mod, 'platformtools') and getattr(m_mod, 'platformtools', None):
            try:
                pt = getattr(m_mod, 'platformtools')
                pt_id = id(pt)
                if pt_id not in _dialog_orig_pt:
                    _dialog_orig_pt[pt_id] = {
                        'mod': pt,
                        'dialog_ok': getattr(pt, 'dialog_ok', None),
                        'dialog_notification': getattr(pt, 'dialog_notification', None),
                        'dialog_yesno': getattr(pt, 'dialog_yesno', None),
                        'dialog_select': getattr(pt, 'dialog_select', None),
                        'dialog_multiselect': getattr(pt, 'dialog_multiselect', None),
                    }
                pt.dialog_ok = lambda *args, **kwargs: None
                pt.dialog_notification = lambda *args, **kwargs: None
                pt.dialog_yesno = lambda *args, **kwargs: True
                pt.dialog_select = lambda *args, **kwargs: -1
                pt.dialog_multiselect = lambda *args, **kwargs: []
            except:
                pass

    # Silenciar también en cachés de módulos de motores si ya están cargadas
    for c_mods in (_ALFA_MODULES_CACHE, _BALANDRO_MODULES_CACHE):
        if c_mods and isinstance(c_mods, dict) and 'platformtools' in c_mods:
            try:
                pt = c_mods['platformtools']
                pt_id = id(pt)
                if pt_id not in _dialog_orig_pt:
                    _dialog_orig_pt[pt_id] = {
                        'mod': pt,
                        'dialog_ok': getattr(pt, 'dialog_ok', None),
                        'dialog_notification': getattr(pt, 'dialog_notification', None),
                        'dialog_yesno': getattr(pt, 'dialog_yesno', None),
                        'dialog_select': getattr(pt, 'dialog_select', None),
                        'dialog_multiselect': getattr(pt, 'dialog_multiselect', None),
                    }
                pt.dialog_ok = lambda *args, **kwargs: None
                pt.dialog_notification = lambda *args, **kwargs: None
                pt.dialog_yesno = lambda *args, **kwargs: True
                pt.dialog_select = lambda *args, **kwargs: -1
                pt.dialog_multiselect = lambda *args, **kwargs: []
            except:
                pass

        if 'core.tmdb' in m_name or m_name == 'tmdb' or (hasattr(m_mod, 'tmdb') and getattr(m_mod, 'tmdb', None)):
            t_targets = []
            if 'core.tmdb' in m_name or m_name == 'tmdb':
                t_targets.append((m_name, m_mod))
            if hasattr(m_mod, 'tmdb') and getattr(m_mod, 'tmdb', None):
                t_targets.append((m_name + '.tmdb', getattr(m_mod, 'tmdb')))
            for t_name, t_obj in t_targets:
                if t_name not in _dialog_orig_tmdb:
                    _dialog_orig_tmdb[t_name] = {
                        'obj': t_obj,
                        'set_infoLabels': getattr(t_obj, 'set_infoLabels', None),
                        'set_infoLabels_itemlist': getattr(t_obj, 'set_infoLabels_itemlist', None),
                        'set_infoLabels_item': getattr(t_obj, 'set_infoLabels_item', None),
                    }
                _dummy_sil = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
                try:
                    t_obj.set_infoLabels = _dummy_sil
                    t_obj.set_infoLabels_itemlist = _dummy_sil
                    if hasattr(t_obj, 'set_infoLabels_item'):
                        t_obj.set_infoLabels_item = lambda *args, **kwargs: 0
                except: pass

def _restore_silence_all():
    global _orig_dialog_class
    with _dialog_silence_lock:
        try:
            if hasattr(xbmcgui, 'Dialog'):
                target_cls = _orig_dialog_class or _KODI_ORIG_DIALOG
                if target_cls:
                    xbmcgui.Dialog = target_cls
        except Exception:
            pass
        _orig_dialog_class = None

        # Restaurar Dialog en todos los módulos de sys.modules afectados
        try:
            for m_name, orig_d in list(_dialog_orig_modules.items()):
                try:
                    if m_name in sys.modules and orig_d is not None:
                        setattr(sys.modules[m_name], 'Dialog', orig_d)
                except Exception:
                    pass
        except Exception:
            pass
        _dialog_orig_modules.clear()

        try:
            pt_items = list(_dialog_orig_pt.items())
        except Exception:
            pt_items = []
        for k, v in pt_items:
            try:
                if isinstance(k, str) and k in sys.modules:
                    m = sys.modules.get(k)
                    if m:
                        for fn, orig in list(v.items()):
                            if orig is not None:
                                try: setattr(m, fn, orig)
                                except Exception: pass
                elif isinstance(k, int) and 'mod' in v:
                    m = v.get('mod')
                    if m:
                        for fn in ('dialog_ok', 'dialog_notification', 'dialog_yesno', 'dialog_select', 'dialog_multiselect'):
                            orig = v.get(fn)
                            if orig is not None:
                                try: setattr(m, fn, orig)
                                except Exception: pass
            except Exception:
                pass
        _dialog_orig_pt.clear()

        try:
            tmdb_items = list(_dialog_orig_tmdb.items())
        except Exception:
            tmdb_items = []
        for k, v in tmdb_items:
            try:
                m = v.get('obj')
                if m is not None:
                    for fn in ('set_infoLabels', 'set_infoLabels_itemlist', 'set_infoLabels_item'):
                        orig = v.get(fn)
                        if orig is not None:
                            try: setattr(m, fn, orig)
                            except Exception: pass
                elif isinstance(k, str) and k in sys.modules:
                    m = sys.modules.get(k)
                    if m:
                        for fn, orig in list(v.items()):
                            if orig is not None:
                                try: setattr(m, fn, orig)
                                except Exception: pass
            except Exception:
                pass
        _dialog_orig_tmdb.clear()

def _restore_dialog_noblock():
    """Restaura xbmcgui.Dialog real SIN usar cerrojos globales."""
    try:
        target_cls = _orig_dialog_class or _KODI_ORIG_DIALOG
        if target_cls is not None and hasattr(xbmcgui, 'Dialog'):
            xbmcgui.Dialog = target_cls
            return True
    except Exception:
        pass
    return False

def _ask_resume_dialog(title_text, time_str, media_key=""):
    """Pregunta reanudar usando la ventana nativa de Kodi.
    Retorna:
      'resume': Si eligio Continuar
      'restart': Si eligio Reiniciar
      'cancel': Si presiono Cancelar, Atras o Escape
    """
    try:
        _rsel = show_resume_dialog(time_str, title_text)
        if _rsel == 0:
            return 'resume'
        elif _rsel == 1:
            if media_key:
                try: save_bookmark(media_key, 0, 0, title=title_text)
                except: pass
            return 'restart'
        else:
            return 'cancel'
    except Exception:
        return 'cancel' 

@contextmanager
def silenced_dialogs():
    global _dialog_silence_depth
    with _dialog_silence_lock:
        _apply_silence_all()
        _dialog_silence_depth += 1

    try:
        yield
    finally:
        _need_restore = False
        with _dialog_silence_lock:
            _dialog_silence_depth -= 1
            if _dialog_silence_depth <= 0:
                _dialog_silence_depth = 0
                if not (_search_in_progress or _links_view_active):
                    _need_restore = True
        if _need_restore:
            _restore_silence_all()

def _prepare_playable_link(link, engine='alfa'):
    """Prepara un enlace decodificando URLs protegidas (ej. data_url base64 en Cinecalidad)
    y ejecutando canal.play(item) si el canal implementa resolutor propio."""
    if not link:
        return None

    item = link.clone() if hasattr(link, 'clone') else link

    # 1. Base64 data_url decode si url esta vacia o 'None'
    data_url = _safe_str(getattr(item, 'data_url', '') or '')
    cur_url = _safe_str(getattr(item, 'url', '') or '')
    if (not cur_url or cur_url.lower() == 'none') and data_url:
        try:
            item.url = base64.b64decode(data_url).decode('utf-8')
        except Exception as e:
            xbmc.log(f"Multi Bridge: error decodificando data_url: {e}", xbmc.LOGINFO)

    # 2. Si el canal tiene metodo play(), ejecutarlo para resolver wrappers/protectores (igual que Balandro/Alfa nativo)
    ch_name = _safe_str(getattr(item, 'channel', '') or '').strip()
    if ch_name:
        if engine == 'balandro':
            try:
                _switch_engine_environment('balandro')
                ch_mod = __import__('channels.' + ch_name, fromlist=[''])
                if hasattr(ch_mod, 'play'):
                    with silenced_dialogs():
                        p_res = ch_mod.play(item)
                        if p_res:
                            if isinstance(p_res, list) and len(p_res) > 0:
                                if isinstance(p_res[0], list):
                                    item.video_urls = p_res
                                elif hasattr(p_res[0], 'url') or hasattr(p_res[0], 'server'):
                                    item = p_res[0]
                            elif hasattr(p_res, 'url'):
                                item = p_res
                            elif isinstance(p_res, str) and p_res.startswith('http'):
                                item.url = p_res
            except Exception as e:
                xbmc.log(f"Multi Bridge: balandro canal {ch_name}.play error: {e}", xbmc.LOGINFO)
        else:  # alfa
            try:
                _switch_engine_environment('alfa')
                ch_mod = __import__('channels.' + ch_name, fromlist=[''])
                if hasattr(ch_mod, 'play'):
                    with silenced_dialogs():
                        p_res = ch_mod.play(item)
                        if p_res:
                            if isinstance(p_res, list) and len(p_res) > 0:
                                if isinstance(p_res[0], list):
                                    item.video_urls = p_res
                                elif hasattr(p_res[0], 'url') or hasattr(p_res[0], 'server'):
                                    item = p_res[0]
                            elif hasattr(p_res, 'url'):
                                item = p_res
                            elif isinstance(p_res, str) and p_res.startswith('http'):
                                item.url = p_res
            except Exception as e:
                xbmc.log(f"Multi Bridge: alfa canal {ch_name}.play error: {e}", xbmc.LOGINFO)

    # 3. Comprobacion secundaria de data_url si url sigue vacia
    if (not getattr(item, 'url', '') or str(getattr(item, 'url', '')).lower() == 'none') and getattr(item, 'data_url', ''):
        try:
            item.url = base64.b64decode(item.data_url).decode('utf-8')
        except Exception:
            pass

    return item

# ---------------------------------------------------------
# Request URL Parameter Parsing (Supports Nested URLs)
# ---------------------------------------------------------
def get_param(name):
    for arg in (sys.argv[1:] if len(sys.argv) > 1 else []):
        if not arg or not isinstance(arg, str): continue
        params = arg.split('?', 1)[1] if '?' in arg else arg
        if params.startswith('?'): params = params[1:]
        for pair in params.split('&'):
            if '=' in pair:
                k, v = pair.split('=', 1)
                if k == name and v:
                    val = uparse.unquote_plus(v).strip()
                    if val.lower() in ('none', 'null', 'undefined', '_', ''):
                        return ''
                    return val
        if 'url=' in params:
            nested_part = params.split('url=', 1)[1]
            unq_nested = uparse.unquote_plus(nested_part)
            if '?' in unq_nested:
                inner_q = unq_nested.split('?', 1)[1]
                for pair in inner_q.split('&'):
                    if '=' in pair:
                        k, v = pair.split('=', 1)
                        if k == name and v:
                            val = uparse.unquote(v).strip()
                            if val.lower() in ('none', 'null', 'undefined', '_', ''):
                                return ''
                            return val
    return ''

url = get_param('url')
action = get_param('action')
view = get_param('view')
engine_param = get_param('engine')
title = get_param('title')
year = get_param('year')
season = get_param('season')
episode = get_param('episode')
showname = get_param('showname')
showyear = get_param('showyear')
title_es = get_param('title_es')
title_lat = get_param('title_lat')
title_en = get_param('title_en')
title_orig = get_param('title_orig')
tmdb_id = get_param('tmdb')
imdb_id = get_param('imdb')
tvdb_id = get_param('tvdb')
trakt_id = get_param('trakt')
plot = get_param('plot')
plot_lat = get_param('plot_lat')
plot_es = get_param('plot_es')
director = get_param('director')
tagline = get_param('tagline')
tagline_lat = get_param('tagline_lat')
tagline_es = get_param('tagline_es')
poster = get_param('poster')
fanart = get_param('fanart')
thumbnail = get_param('thumbnail')
clearlogo = get_param('clearlogo')
genre = get_param('genre')

def decode_base64_item(b64_str, ItemClass):
    try:
        decoded_bytes = base64.b64decode(b64_str)
        decoded_str = decoded_bytes.decode('utf-8', errors='ignore')
        data = json.loads(decoded_str)
        it = ItemClass()
        it.__dict__.update(data)
        for k, v in data.items():
            try: setattr(it, k, v)
            except: pass
        return it
    except Exception:
        try: return ItemClass().fromurl('plugin://plugin.video.alfa/?' + b64_str)
        except: return ItemClass()

# ---------------------------------------------------------
# Title Matching and Normalization
# ---------------------------------------------------------

# ── Leading-article stripping (The/El/La/etc.) ──────────────────────────────
_LEADING_ARTICLES = frozenset([
    'the', 'el', 'la', 'los', 'las', 'a', 'an', 'un', 'una',
    'le', 'les', 'der', 'die', 'das', 'de', 'het',
])

def _strip_leading_article(s):
    """Remove leading article from a *cleaned* title string for comparison.
    'the office' → 'office', 'la casa de papel' stays (only drops first word)."""
    words = s.split()
    if len(words) > 1 and words[0] in _LEADING_ARTICLES:
        return ' '.join(words[1:])
    return s

# ── Roman-numeral → Arabic normalization ────────────────────────────────────
_ROMAN_PATTERNS = [
    (re.compile(r'\bxx\b'),   '20'), (re.compile(r'\bxix\b'),  '19'),
    (re.compile(r'\bxviii\b'),'18'), (re.compile(r'\bxvii\b'), '17'),
    (re.compile(r'\bxvi\b'),  '16'), (re.compile(r'\bxv\b'),   '15'),
    (re.compile(r'\bxiv\b'),  '14'), (re.compile(r'\bxiii\b'), '13'),
    (re.compile(r'\bxii\b'),  '12'), (re.compile(r'\bxi\b'),   '11'),
    (re.compile(r'\bx\b'),    '10'), (re.compile(r'\bix\b'),    '9'),
    (re.compile(r'\bviii\b'),  '8'), (re.compile(r'\bvii\b'),   '7'),
    (re.compile(r'\bvi\b'),    '6'), (re.compile(r'\biv\b'),    '4'),
    (re.compile(r'\bv\b'),     '5'), (re.compile(r'\biii\b'),   '3'),
    (re.compile(r'\bii\b'),    '2'),
]

def _normalize_numerals(s):
    """Convert roman numerals to arabic digits: 'rocky ii' → 'rocky 2'.
    Only standalone words, not inside larger tokens."""
    if not s: return ''
    for pat, num in _ROMAN_PATTERNS:
        s = pat.sub(num, s)
    return s

_WORD_NUMBERS = [
    (re.compile(r'\bse7en\b', re.IGNORECASE), '7'),
    (re.compile(r'\bscre4m\b', re.IGNORECASE), 'scream 4'),
    (re.compile(r'\bfant4stic\b', re.IGNORECASE), 'fantastic 4'),
    (re.compile(r'\bzero\b|\bcero\b', re.IGNORECASE), '0'),
    (re.compile(r'\bone\b|\buno\b', re.IGNORECASE), '1'),
    (re.compile(r'\btwo\b|\bdos\b', re.IGNORECASE), '2'),
    (re.compile(r'\bthree\b|\btres\b', re.IGNORECASE), '3'),
    (re.compile(r'\bfour\b|\bcuatro\b', re.IGNORECASE), '4'),
    (re.compile(r'\bfive\b|\bcinco\b', re.IGNORECASE), '5'),
    (re.compile(r'\bsix\b|\bseis\b', re.IGNORECASE), '6'),
    (re.compile(r'\bseven\b|\bsiete\b', re.IGNORECASE), '7'),
    (re.compile(r'\beight\b|\bocho\b', re.IGNORECASE), '8'),
    (re.compile(r'\bnine\b|\bnueve\b', re.IGNORECASE), '9'),
    (re.compile(r'\bten\b|\bdiez\b', re.IGNORECASE), '10'),
    (re.compile(r'\beleven\b|\bonce\b', re.IGNORECASE), '11'),
    (re.compile(r'\btwelve\b|\bdoce\b', re.IGNORECASE), '12'),
    (re.compile(r'\bthirteen\b|\btrece\b', re.IGNORECASE), '13'),
    (re.compile(r'\bfourteen\b|\bcatorce\b', re.IGNORECASE), '14'),
    (re.compile(r'\bfifteen\b|\bquince\b', re.IGNORECASE), '15'),
    (re.compile(r'\bsixteen\b|\bdieciseis\b', re.IGNORECASE), '16'),
    (re.compile(r'\bseventeen\b|\bdiecisiete\b', re.IGNORECASE), '17'),
    (re.compile(r'\beighteen\b|\bdieciocho\b', re.IGNORECASE), '18'),
    (re.compile(r'\bnineteen\b|\bdiecinueve\b', re.IGNORECASE), '19'),
    (re.compile(r'\btwenty\b|\bveinte\b', re.IGNORECASE), '20'),
    (re.compile(r'\bthirty\b|\btreinta\b', re.IGNORECASE), '30'),
    (re.compile(r'\bforty\b|\bcuarenta\b', re.IGNORECASE), '40'),
    (re.compile(r'\bfifty\b|\bcincuenta\b', re.IGNORECASE), '50'),
    (re.compile(r'\bhundred\b|\bcien\b|\bciento\b', re.IGNORECASE), '100'),
    (re.compile(r'\bthousand\b|\bmil\b', re.IGNORECASE), '1000'),
]

def _normalize_number_words(s):
    if not s: return ''
    for pat, rep in _WORD_NUMBERS:
        s = pat.sub(rep, s)
    return s

_SPECIAL_CHAR_MAP = {
    'ß': 'ss', 'ẞ': 'ss',
    'æ': 'ae', 'Æ': 'ae',
    'œ': 'oe', 'Œ': 'oe',
    'ø': 'o',  'Ø': 'o',
    'ł': 'l',  'Ł': 'l',
    'đ': 'd',  'Đ': 'd',
    'ð': 'd',  'Ð': 'd',
    'þ': 'th', 'Þ': 'th',
    'ı': 'i',  'İ': 'i',
}

_ARTICLES_DEFINITE = frozenset([
    'the', 'el', 'la', 'los', 'las', 'le', 'les', 'der', 'die', 'das', 'het',
])
_ARTICLES_INDEFINITE = frozenset([
    'a', 'an', 'un', 'una', 'unos', 'unas', 'ein', 'eine',
])
_ALL_ARTICLES = _ARTICLES_DEFINITE | _ARTICLES_INDEFINITE

def _strip_all_articles(s):
    return ' '.join(w for w in s.split() if w not in _ALL_ARTICLES)

def _has_conflicting_articles(s1, s2):
    """Comprueba si dos títulos tienen artículos distintos en la misma posición.
    Permite omisiones puras (ej. '2001 una odisea' vs '2001 odisea', 'the office' vs 'office').
    Rechaza discrepancias de artículos opuestos (ej. 'una' vs 'la', 'the' vs 'a', 'un' vs 'el')."""
    tokens1 = s1.split()
    tokens2 = s2.split()
    core1 = [w for w in tokens1 if w not in _ALL_ARTICLES]
    core2 = [w for w in tokens2 if w not in _ALL_ARTICLES]
    if core1 != core2:
        return False

    def get_article_slots(tokens):
        slots = []
        cur_art = []
        for w in tokens:
            if w in _ALL_ARTICLES:
                cur_art.append(w)
            else:
                slots.append(tuple(cur_art))
                cur_art = []
        slots.append(tuple(cur_art))
        return slots

    slots1 = get_article_slots(tokens1)
    slots2 = get_article_slots(tokens2)
    if len(slots1) != len(slots2):
        return False
    for art1, art2 in zip(slots1, slots2):
        if art1 and art2:
            if art1 != art2:
                return True
    return False

def clean_title(title_str):
    """Normalize a title for fuzzy comparison.

    Handles: Kodi tags, brackets/parens, quality flags, & and + → and,
    Foreign ligatures/characters (ß, æ, ø, ł, etc.),
    Unicode accents (all scripts via NFD), possessives, roman numerals.
    Result is lowercase ASCII alphanumeric words joined by single spaces.
    """
    title_str = _safe_str(title_str)
    if not title_str: return ''
    # 1. Strip Kodi markup tags
    c = re.sub(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|LIGHT|CR)\]', '', title_str, flags=re.IGNORECASE)
    # 2. Strip content inside brackets / parens / braces (year, quality, etc.)
    c = re.sub(r'[\(\[\{][^\)\]\}]{0,80}[\)\]\}]', '', c)
    # 3. Strip quality / language / codec keywords
    c = re.sub(
        r'(?i)\b(4k|uhd|2160p|1080p|720p|480p|360p|'
        r'bluray|blu-ray|bdrip|brrip|hdrip|hdtv|dvdrip|dvdscr|'
        r'web-dl|webdl|webrip|web-rip|'
        r'x264|x265|h264|h265|hevc|avc|xvid|divx|'
        r'latino|castellano|espa[ñn]ol|subtitulado|dual|audio|'
        r'hdr|sdr|dts|aac|ac3|mp3|'
        r'extended|remastered|unrated|theatrical|directors.cut)\b',
        '', c)
    # 4. Normalize & and + to and
    c = re.sub(r'\s*[&+]\s*', ' and ', c)
    # 5. Map special ligatures / foreign letters that NFKD does not decompose
    for ch, repl in _SPECIAL_CHAR_MAP.items():
        if ch in c:
            c = c.replace(ch, repl)
    # 6. Unicode NFKD decomposition (handles European/Latin accents)
    try:
        import unicodedata as _ud
        nfkd = _ud.normalize('NFKD', c)
        c = ''.join(ch for ch in nfkd if not _ud.combining(ch))
    except Exception:
        pass
    c = c.lower()
    # 7. Possessives and apostrophes: "Pan's" → "pans", "it's" → "its"
    c = re.sub(r"[\u2019\u2018\u0027\u0060\u00b4]s\b", 's', c)
    c = re.sub(r"[\u2019\u2018\u0027\u0060\u00b4]", '', c)
    # 8. Keep only ASCII alphanumeric; everything else → space
    c = re.sub(r'[^a-z0-9]', ' ', c)
    return ' '.join(c.split())

# Unificacion de conjunciones entre idiomas (y/and/e/&). Ej. 'Tom y Jerry'
# casa con 'Tom & Jerry' porque clean_title ya mapea & -> and.
# Mecanismo GENERAL sin diccionarios: no hay lista de palabras que mantener.
# (Distinguir traducciones como Wolverine/Lobezno sin datos externos es
# imposible localmente; para eso esta el titulo original de TMDb.)
_TITLE_CONJUNCTIONS = frozenset(['y', 'and', 'e'])

def _alias_variants(names):
    """Genera variantes con conjunciones unificadas a 'and'.
    Solo ANIADE candidatos: jamas quita ni rechaza nada, asi que no puede
    romper matches que ya funcionaban."""
    out = []
    try:
        seen = set()
        for _n in (names or []):
            _s = _safe_str(_n).lower().strip()
            if _s:
                seen.add(_s)
        for name in (names or []):
            base = _safe_str(name)
            if not base:
                continue
            toks = clean_title(base).split()
            if not toks:
                continue
            core = [('and' if t in _TITLE_CONJUNCTIONS else t) for t in toks]
            c = ' '.join(core)
            if c and c not in seen:
                seen.add(c)
                out.append(c)
    except Exception:
        pass
    return out

def _extract_year_from_val(val):
    if not val: return None
    s = str(val).strip()
    m = re.search(r'\b(19\d\d|20\d\d)\b', s)
    if m:
        try:
            y = int(m.group(1))
            if 1900 <= y <= 2099:
                return y
        except:
            pass
    return None

def _extract_title_embedded_years(target_titles):
    """Finds 4-digit numbers that are part of target titles (e.g. 1917, 1984 in Wonder Woman 1984)."""
    embedded = set()
    for t in (target_titles or []):
        if t:
            for y in re.findall(r'\b(19\d\d|20\d\d)\b', str(t)):
                embedded.add(int(y))
    return embedded

def _get_item_year(item=None, title_str=None, embedded_title_years=None):
    """Extract a 4-digit year (1900-2099) as integer, or None, avoiding title embedded numbers."""
    embedded = embedded_title_years or set()
    # 1. From item.infoLabels
    if item:
        _il = getattr(item, 'infoLabels', {}) if hasattr(item, 'infoLabels') else {}
        if isinstance(_il, dict):
            for k in ('year', 'release_date', 'premiered', 'aired'):
                y = _extract_year_from_val(_il.get(k))
                if y and y not in embedded:
                    return y
        for attr in ('year', 'contentYear'):
            y = _extract_year_from_val(getattr(item, attr, None))
            if y and y not in embedded:
                return y
    # 2. From explicit year tags in title: (YYYY) or [YYYY]
    for t in (title_str, getattr(item, 'title', None) if item else None, getattr(item, 'contentTitle', None) if item else None):
        if t:
            m = re.search(r'[\(\[]\s*(19\d\d|20\d\d)\s*[\)\]]', str(t))
            if m:
                return int(m.group(1))
    # 3. From trailing year in title: ONLY if not an embedded title year
    for t in (title_str, getattr(item, 'title', None) if item else None, getattr(item, 'contentTitle', None) if item else None):
        if t:
            m = re.search(r'(?:\s*-\s*|\s+)(19\d\d|20\d\d)\s*$', str(t))
            if m:
                y = int(m.group(1))
                if y not in embedded:
                    return y
    # 4. From URL: ONLY if not an embedded title year
    if item:
        url = _safe_str(getattr(item, 'url', ''))
        if url:
            for m in re.finditer(r'[-_/(](19\d\d|20\d\d)(?:[-_/.)]|$)', url):
                y = int(m.group(1))
                if y not in embedded:
                    return y
    return None

def _get_item_tmdb(item):
    if not item: return None
    _il = getattr(item, 'infoLabels', {}) if hasattr(item, 'infoLabels') else {}
    if isinstance(_il, dict):
        for k in ('tmdb_id', 'tmdb'):
            val = _safe_str(_il.get(k))
            if val.isdigit() and int(val) > 0:
                return val
    for attr in ('tmdb_id', 'tmdb'):
        val = _safe_str(getattr(item, attr, ''))
        if val.isdigit() and int(val) > 0:
            return val
    url = _safe_str(getattr(item, 'url', ''))
    if url:
        m = re.search(r'[?&](?:tmdb_id|tmdb)=(\d+)', url)
        if m and int(m.group(1)) > 0:
            return m.group(1)
        ch = _safe_str(getattr(item, 'channel', '')).lower()
        if any(x in ch for x in ('poseidon', 'cuevana', 'pelisplus', 'estrenosgo', 'pelisforte')):
            m = re.search(r'/(?:pelicula|serie|series|tv|movie)/(\d{2,9})(?:/|[-_]|$)', url)
            if m and int(m.group(1)) > 0 and not (1900 <= int(m.group(1)) <= 2099):
                return m.group(1)
            m2 = re.search(r'/(?:pelicula|serie|series|tv|movie)/[^/?#]*-(\d{5,9})(?:[/?#]|$)', url)
            if m2 and int(m2.group(1)) > 0:
                return m2.group(1)
        else:
            m = re.search(r'/(?:pelicula|serie|series|tv|movie)/(\d{2,9})/(?:[^/?#]+)', url)
            if m and int(m.group(1)) > 0 and not (1900 <= int(m.group(1)) <= 2099):
                return m.group(1)
    return None

def _get_item_imdb(item):
    if not item: return None
    _il = getattr(item, 'infoLabels', {}) if hasattr(item, 'infoLabels') else {}
    if isinstance(_il, dict):
        for k in ('imdb_id', 'imdb', 'IMDBNumber'):
            val = _safe_str(_il.get(k)).lower()
            if val.startswith('tt'): return val
    for attr in ('imdb_id', 'imdb'):
        val = _safe_str(getattr(item, attr, '')).lower()
        if val.startswith('tt'): return val
    url = _safe_str(getattr(item, 'url', '')).lower()
    if url:
        m = re.search(r'(tt\d{6,10})', url)
        if m: return m.group(1)
    return None

def _clean_search_term(term):
    term = _safe_str(term)
    if not term: return ""
    term = re.sub(r'\s*\(\d{4}\)', '', term)
    term = re.sub(r'[\:\-\_]', ' ', term)
    term = re.sub(r'\s+', ' ', term)
    return term.strip().lower()

def get_core_title(t):
    t = _safe_str(t)
    if not t: return ''
    core = re.sub(r'\s*\(\d{4}\)', '', t)
    core = re.split(r'[:\-–—]', core)[0]
    return core.strip()

def _extract_title_number(title_str):
    title_str = _safe_str(title_str)
    if not title_str: return None
    s = _normalize_number_words(title_str.lower())
    m = re.search(r'\b(?:volumen|vol\.?|parte|part)\s*(\d+)\b', s)
    if m: return int(m.group(1))
    m = re.search(r'\b(?:volumen|vol\.?|parte|part)\s*(iv|v|vi|vii|viii|ix|x|iii|ii|i)\b', s)
    if m:
        romans = {'i': 1, 'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
        return romans.get(m.group(1))
    m = re.search(r'\b(\d+)\b', s)
    if m: return int(m.group(1))
    m = re.search(r'\b(iv|v|vi|vii|viii|ix|x|iii|ii)\b', s)
    if m:
        romans = {'ii': 2, 'iii': 3, 'iv': 4, 'v': 5, 'vi': 6, 'vii': 7, 'viii': 8, 'ix': 9, 'x': 10}
        return romans.get(m.group(1))
    return None

def is_slug_or_raw_consistent(raw_title, target_title, target_year, item=None, embedded_years=None):
    raw_title = _safe_str(raw_title)
    target_title = _safe_str(target_title)
    if not raw_title or not target_title: return True
    raw_sub = re.sub(r'\s*\(\d{4}\)', '', raw_title)
    tgt_sub = re.sub(r'\s*\(\d{4}\)', '', target_title)
    raw_has_colon = ':' in raw_sub or ' - ' in raw_sub or '–' in raw_sub
    tgt_has_colon = ':' in tgt_sub or ' - ' in tgt_sub or '–' in tgt_sub
    if tgt_has_colon and not raw_has_colon:
        tgt_parts = re.split(r'[:\-–—]', tgt_sub)
        if len(tgt_parts) > 1:
            subtitle = clean_title(tgt_parts[1])
            if subtitle and len(subtitle) >= 3:
                raw_c = clean_title(raw_sub)
                if subtitle not in raw_c:
                    raw_y_match = _get_item_year(item, raw_title, embedded_title_years=embedded_years)
                    if raw_y_match and target_year:
                        if int(raw_y_match) != int(target_year): return False
    raw_num = _extract_title_number(raw_sub)
    tgt_num = _extract_title_number(tgt_sub)
    if raw_num is not None or tgt_num is not None:
        if raw_num != tgt_num: return False
    return True

def score_match(result_title, target_year, all_names, target_tmdb=None, item=None, target_imdb=None, is_series=None):
    """Calculates a match confidence score (integer > 0) or returns 0 if rejected.

    Higher score indicates greater precision and relevance.
    Scoring components:
      - TMDb match: +10000 (mismatch: REJECT)
      - IMDb match: +8000  (mismatch: REJECT)
      - Exact Year match: +3000
      - Year mismatch (!=): REJECT (0)
      - Exact Clean Title match: +1000
      - Compact de-spaced match (hyphens/dots/acronyms): +950
      - Number words & Roman numerals normalized match: +900
      - All articles stripped match: +880
      - Article/Numeral normalized match: +800
      - Subtitle prefix match: +800
      - Substring match: +300
      - Media type compatibility (movie vs show): +500
      - Title similarity is MANDATORY: with no title match the result is
        REJECTED (0), even with TMDb/IMDb/year (channel items inherit the
        search-item IDs via Item.clone, so matching IDs alone prove nothing).
    """
    result_title = _safe_str(result_title)
    if not result_title: return 0
    low_title = result_title.lower().strip()

    if any(p in low_title for p in ['siguiente', 'siguientes', 'next page', 'pagina siguiente', 'página siguiente', 'anterior', 'anteriores']) or low_title.startswith('>>') or low_title.startswith('<<') or low_title.endswith('>>') or low_title.endswith('<<'):
        return 0

    url_str = _safe_str(getattr(item, 'url', '')).lower() if item else ''
    content_type = _safe_str(getattr(item, 'contentType', '')).lower() if item else ''

    if is_series is False:
        # Searching for movie
        if content_type in ('tvshow', 'season', 'episode'):
            return 0
        if '/serie/' in url_str or '/series/' in url_str or '/temporada/' in url_str:
            return 0
        if re.search(r'\b(?:temporada\s*\d+|capitulo\s*\d+|season\s*\d+|episodio\s*\d+)\b', low_title):
            return 0
    elif is_series is True:
        # Searching for series
        if content_type == 'movie' and not getattr(item, 'contentSerieName', ''):
            return 0
        if '/pelicula/' in url_str and not ('/serie/' in url_str or '/temporada/' in url_str):
            return 0

    # 2. TMDb Check
    item_tmdb = _get_item_tmdb(item)
    tmdb_score = 0
    if target_tmdb and item_tmdb:
        if str(target_tmdb) == str(item_tmdb):
            tmdb_score = 10000
        else:
            # Explicit TMDb conflict!
            return 0

    # 3. IMDb Check
    item_imdb = _get_item_imdb(item)
    imdb_score = 0
    if target_imdb and item_imdb:
        if str(target_imdb).lower() == str(item_imdb).lower():
            imdb_score = 8000
        else:
            return 0

    # 4. Year Check (avoid treating title embedded numbers like 1917, 1984 as release years)
    embedded_years = _extract_title_embedded_years(all_names)
    item_year = _get_item_year(item, result_title, embedded_title_years=embedded_years)
    year_score = 0
    if item_year and target_year:
        try:
            if int(item_year) == int(target_year):
                year_score = 3000
            else:
                # Strict exact year only (any difference >= 1 year is rejected)
                return 0
        except:
            pass

    clean_res = clean_title(result_title)
    if not clean_res: return 0

    _cr_na       = _strip_leading_article(clean_res)
    _cr_nr       = _normalize_numerals(clean_res)
    _cr_nw       = _normalize_number_words(clean_res)
    _cr_nw_nr    = _normalize_numerals(_cr_nw)
    _cr_compact  = clean_res.replace(' ', '')
    _cr_nw_comp  = _cr_nw_nr.replace(' ', '')
    _cr_all_art  = _strip_all_articles(clean_res)
    _cr_art_comp = _cr_all_art.replace(' ', '')

    best_title_score = 0

    for name in (all_names or []):
        name = _safe_str(name)
        if not name: continue
        clean_target = clean_title(name)
        if not clean_target: continue

        if not is_slug_or_raw_consistent(result_title, name, target_year, item=item, embedded_years=embedded_years):
            continue

        _ct_na       = _strip_leading_article(clean_target)
        _ct_nr       = _normalize_numerals(clean_target)
        _ct_nw       = _normalize_number_words(clean_target)
        _ct_nw_nr    = _normalize_numerals(_ct_nw)
        _ct_compact  = clean_target.replace(' ', '')
        _ct_nw_comp  = _ct_nw_nr.replace(' ', '')
        _ct_all_art  = _strip_all_articles(clean_target)
        _ct_art_comp = _ct_all_art.replace(' ', '')

        # 1. Exact clean match
        if clean_res == clean_target:
            best_title_score = max(best_title_score, 1000)
            continue

        # 2. Compact match (handles hyphens, dots, spaces: Spider-Man/Spiderman, S.W.A.T./SWAT, Kick-Ass/Kickass, WALL·E/Wall-E)
        if _cr_compact == _ct_compact and len(_cr_compact) >= 3:
            best_title_score = max(best_title_score, 950)
            continue

        # 3. Number words / Roman numerals normalized (12 Monkeys/Twelve Monkeys, Ocean's 11/Ocean's Eleven, Rocky II/Rocky 2)
        if _cr_nw_nr == _ct_nw_nr or _cr_nr == _ct_nr:
            best_title_score = max(best_title_score, 900)
            continue

        # 4. All articles stripped match (e.g. 2001: Una odisea del espacio vs 2001: Odisea del espacio)
        if _cr_all_art and _ct_all_art and (_cr_all_art == _ct_all_art or (_cr_art_comp == _ct_art_comp and len(_cr_art_comp) >= 3)):
            if not _has_conflicting_articles(clean_res, clean_target):
                best_title_score = max(best_title_score, 880)
                continue

        # 5. Compact + Number words normalized
        if _cr_nw_comp == _ct_nw_comp and len(_cr_nw_comp) >= 3:
            best_title_score = max(best_title_score, 850)
            continue

        # 6. Article-stripped match
        if (_cr_na == _ct_na and _cr_na) or (_cr_na.replace(' ', '') == _ct_na.replace(' ', '') and len(_cr_na) >= 3):
            if not _has_conflicting_articles(clean_res, clean_target):
                best_title_score = max(best_title_score, 800)
                continue

        # 7. Subtitle split handling: "Supergirl: Woman of Tomorrow" vs "Supergirl", "Dr. Strangelove or:..." vs "Dr. Strangelove"
        if ':' in name or ' - ' in name or '–' in name:
            parts = re.split(r'[:\-–—]', name)
            if len(parts) > 1:
                prefix = clean_title(parts[0])
                prefix_comp = prefix.replace(' ', '')
                if (prefix and clean_res == prefix) or (prefix_comp and _cr_compact == prefix_comp):
                    if tmdb_score > 0:
                        best_title_score = max(best_title_score, 1000)
                    elif year_score > 0:
                        best_title_score = max(best_title_score, 800)
                    elif target_year is None:
                        best_title_score = max(best_title_score, 500)
                    continue

        if ':' in result_title or ' - ' in result_title or '–' in result_title:
            res_parts = re.split(r'[:\-–—]', result_title)
            if len(res_parts) > 1:
                res_prefix = clean_title(res_parts[0])
                res_pref_comp = res_prefix.replace(' ', '')
                if (res_prefix and res_prefix == clean_target) or (res_pref_comp and res_pref_comp == _ct_compact):
                    if tmdb_score > 0:
                        best_title_score = max(best_title_score, 1000)
                    elif year_score > 0:
                        best_title_score = max(best_title_score, 800)
                    elif target_year is None:
                        best_title_score = max(best_title_score, 500)
                    continue

        # 8. Substring match (palabra completa estricta; sin letras/palabras extra no autorizadas)
        for _rv, _tv in [(clean_res, clean_target), (_cr_na, _ct_na)]:
            if not _rv or not _tv or _rv == _tv: continue
            _sub_fwd = bool(re.search(r'\b' + re.escape(_tv) + r'\b', _rv))
            _sub_rev = bool(re.search(r'\b' + re.escape(_rv) + r'\b', _tv))
            if not _sub_fwd and not _sub_rev: continue

            _wc_res = len(_rv.split())
            _wc_tgt = len(_tv.split())
            _same_wc = _wc_res == _wc_tgt

            # Si el resultado tiene palabras extra respecto al objetivo (ej. 'Avatar Extended' vs 'Avatar')
            if _sub_fwd and not _same_wc:
                _pos = _rv.find(_tv)
                _extra = (_rv[:_pos].strip() + ' ' + _rv[_pos + len(_tv):].strip()).strip()
                if _extra and any(ch.isalpha() for ch in _extra):
                    continue

            # Si el objetivo tiene palabras extra respecto al resultado (ej. 'Heart of the Beast' vs 'Beast')
            # NUNCA permitir que una película distinta con un título más corto ('Beast') coincida con ('Heart of the Beast')
            if _sub_rev and not _same_wc:
                _pos = _tv.find(_rv)
                _extra = (_tv[:_pos].strip() + ' ' + _tv[_pos + len(_rv):].strip()).strip()
                if _extra and any(ch.isalpha() for ch in _extra):
                    continue

            if year_score > 0 or tmdb_score > 0 or _same_wc:
                best_title_score = max(best_title_score, 300)
                break

    # Si el titulo de la web es una variacion local distinta (ej. "El Elegido" en Cuevana2
    # para la serie con slug "/serie/the-chosen"), verificar si el slug de la URL coincide exactamente con alguno de los titulos
    if best_title_score == 0 and url_str:
        clean_url = re.sub(r'https?://[^/]+', '', url_str).split('?')[0].strip('/')
        # Extraer segmentos de ruta (ej. 'the-chosen', 'el-elegido')
        slug_candidates = [re.sub(r'^\d+-', '', s) for s in clean_url.split('/') if s and s not in ('serie', 'series', 'pelicula', 'peliculas', 'tv', 'movie', 'ver')]
        for sc in slug_candidates:
            clean_sc = clean_title(sc.replace('-', ' ').replace('_', ' '))
            if not clean_sc or len(clean_sc) < 3:
                continue
            for name in (all_names or []):
                clean_target = clean_title(name)
                if clean_target and (clean_sc == clean_target or clean_sc.replace(' ', '') == clean_target.replace(' ', '')):
                    best_title_score = 900
                    break
            if best_title_score > 0:
                break

    # El titulo es obligatorio: los resultados de canal heredan los IDs del
    # item de busqueda via Item.clone() (ej. allcalidad clona it_search con
    # tmdb_id/imdb_id inyectados), asi que IDs coincidentes sin similitud de
    # titulo no prueban nada ('Pinky y Cerebro' llegaba a 21500 con el tmdb
    # heredado). Sin titulo -> RECHAZO aunque haya IDs/anio.
    if best_title_score == 0:
        return 0

    total_score = tmdb_score + imdb_score + year_score + best_title_score
    if is_series is False and ('/pelicula/' in url_str or content_type == 'movie'):
        total_score += 500
    elif is_series is True and ('/serie/' in url_str or content_type == 'tvshow'):
        total_score += 500

    return total_score

def match_title(result_title, target_year, all_names, target_tmdb=None, item=None, target_imdb=None, is_series=None):
    """Return True if result_title matches any name in all_names, considering year and IDs."""
    return score_match(result_title, target_year, all_names, target_tmdb=target_tmdb, item=item, target_imdb=target_imdb, is_series=is_series) > 0


# ---------------------------------------------------------
# Item Formatting & Quality / Server / Language Helpers
# ---------------------------------------------------------
def _is_torrent_link(link):
    if not link: return False

    srv = _safe_str(getattr(link, 'server', '')).lower().strip()
    direct_servers = ('doodstream', 'streamtape', 'mixdrop', 'gamovideo', 'voe', 'vudeo', 'waaw', 'streamwish', 'filelions', 'vidhide', 'luluvdo', 'uqload')
    if srv and any(ds in srv for ds in direct_servers):
        return False

    # 1. Server check
    if srv:
        if srv in ('torrent', 'magnet', 'torrents', 'bittorrent', 'utorrent', 'elementum'):
            return True
        if 'torrent' in srv or 'magnet' in srv:
            return True

    # 2. URL check
    url_str = _safe_str(getattr(link, 'url', '')).lower().strip()
    if url_str:
        if url_str.startswith('magnet:') or 'magnet:?' in url_str or 'xt=urn:btih' in url_str or 'urn:btih:' in url_str:
            return True
        if '.torrent' in url_str:
            return True

    # 3. Action check
    act = _safe_str(getattr(link, 'action', '')).lower().strip()
    if act in ('play_torrent', 'torrent', 'download_torrent'):
        return True

    # 4. Extra / Stream type / Format / Type check
    extra = _safe_str(getattr(link, 'extra', '')).lower()
    if 'torrent' in extra:
        return True
    st_type = _safe_str(getattr(link, 'stream_type', '')).lower()
    if 'torrent' in st_type:
        return True
    l_type = _safe_str(getattr(link, 'type', '')).lower()
    if 'torrent' in l_type:
        return True

    # 5. Channel check (canales torrent conocidos en Balandro y Alfa)
    ch = _safe_str(getattr(link, 'channel', '')).lower().strip()
    if ch:
        if 'torrent' in ch or 'divx' in ch:
            return True
        torrent_channels = (
            'dontorrent', 'dontorrents', 'dontorrentsin', 'dontorrent21',
            'elitetorrent', 'elitetorrentnz', 'grantorrent', 'hacktorrent',
            'mejortorrent', 'mejortorrentapp', 'mejortorrentin', 'mitorrent',
            'pasateatorrent', 'pediatorrent', 'subtorrents', 'todotorrents',
            'torrentgalaxy', 'vivatorrents', 'divxtotal', 'divxatope',
            'tomadivx', 'eztv', 'yts', 'pelitorrent', 'yestorrent',
            'wolfmax4k', 'moviesdvdr', 'reinventorrent'
        )
        if ch in torrent_channels:
            return True

    # 6. video_urls check
    video_urls = getattr(link, 'video_urls', None)
    if video_urls and isinstance(video_urls, list):
        for v in video_urls:
            v_str = str(v).lower()
            if 'magnet:' in v_str or '.torrent' in v_str or '[torrent]' in v_str:
                return True

    # 7. other / title check
    other = _safe_str(getattr(link, 'other', '')).lower()
    if '[torrent]' in other or '(torrent)' in other or other.startswith('torrent'):
        return True

    return False


def _get_torrent_client(is_magnet=False):
    """Lee el ajuste 'cliente_torrent' de Balandro y devuelve (addon_id, url_template).

    url_template usa %s como placeholder para la URL/magnet codificada.
    Si is_magnet es True y el cliente define 'url_magnet' (ej. Torrest), usa esa plantilla.
    Retorna (None, None) si no hay cliente configurado o no está instalado.
    """
    try:
        bal_addon = xbmcaddon.Addon('plugin.video.balandro')
        cliente = (bal_addon.getSetting('cliente_torrent') or '').strip().lower()

        # Si el cliente no está configurado o está en 'seleccionar':
        if not cliente or cliente in ('ninguno', 'seleccionar', ''):
            try:
                _switch_engine_environment('balandro')
                from modules import filters
                from core.item import Item
                dummy_item = Item()
                dummy_item.no_obsoletes = True
                ret = filters.show_clients_torrent_no_obsoletes(dummy_item)
                if ret and ret != -1 and isinstance(ret, (list, tuple)) and len(ret) >= 2:
                    c_name = ret[0]
                    c_id = str(ret[1]).split()[0]
                    if xbmc.getCondVisibility('System.HasAddon("%s")' % c_id):
                        try:
                            dlg_yesno = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)().yesno(
                                'Multi Bridge — Cliente Torrent',
                                'Seleccionado: [COLOR yellow][B]%s[/B][/COLOR]\n\n¿Deseas guardar este cliente como habitual en Balandro para no volver a seleccionarlo?' % c_name,
                                nolabel='Solo por ahora',
                                yeslabel='Guardar habitual'
                            )
                            if dlg_yesno:
                                bal_addon.setSetting('cliente_torrent', str(c_name).capitalize())
                        except Exception:
                            pass
                        cliente = str(c_name).lower()
            except Exception as _fe:
                xbmc.log("Multi Bridge: selector de clientes Balandro no disponible: %s" % _fe, xbmc.LOGINFO)

        if not cliente or cliente in ('ninguno', 'seleccionar', ''):
            return None, None

        # Leer torrent.json de Balandro para obtener la URL template
        bal_path = bal_addon.getAddonInfo('path')
        torrent_json_path = os.path.join(bal_path, 'servers', 'torrent.json')
        if not os.path.exists(torrent_json_path):
            return None, None

        import json as _json
        with open(torrent_json_path, 'r', encoding='utf-8') as _f:
            _data = _json.load(_f)

        for client in _data.get('clients', []):
            if client.get('name', '').lower() == cliente:
                addon_id = client.get('id', '')
                if addon_id and xbmc.getCondVisibility('System.HasAddon("%s")' % addon_id):
                    tpl = client.get('url_magnet') if (is_magnet and client.get('url_magnet')) else client.get('url', '')
                    return addon_id, tpl
                else:
                    xbmc.log('Multi Bridge: cliente torrent "%s" (%s) no instalado' % (cliente, addon_id), xbmc.LOGINFO)
                    return None, None

        xbmc.log('Multi Bridge: cliente torrent "%s" no encontrado en torrent.json' % cliente, xbmc.LOGINFO)
        return None, None

    except Exception as _e:
        xbmc.log('Multi Bridge: _get_torrent_client error: ' + str(_e), xbmc.LOGINFO)
        return None, None


# Segundos maximos esperando al play() del canal al resolver un torrent.
_TORRENT_PLAY_BUDGET = 25

def _resolve_torrent_url(link, engine='balandro'):
    """Resuelve la URL real (magnet/.torrent) de un enlace torrent.
    1) Decodifica data_url (cinecalidad* guardan ahi el magnet con url vacia).
    2) Si sigue sin ser magnet/.torrent, pide al play() del canal con un
       presupuesto de _TORRENT_PLAY_BUDGET segundos y dialogo de progreso.
    Devuelve (url, detalle_fallo). No lanza reproduccion."""
    fail_detail = ''
    actual_engine = getattr(link, 'bridge_engine', '') or engine or 'balandro'
    try:
        prep = _prepare_playable_link(link, engine=actual_engine)
    except Exception:
        prep = None
    torrent_url = _safe_str(getattr(prep, 'url', '') or '') if prep is not None else ''
    if not torrent_url:
        torrent_url = _safe_str(getattr(link, 'url', '') or '')

    # Si todavía no es magnet ni .torrent:
    if not (torrent_url.startswith('magnet:') or torrent_url.endswith('.torrent')):
        # 1. Comprobar si data_url contiene el enlace en base64
        d_url = _safe_str(getattr(link, 'data_url', '') or '')
        if d_url:
            try:
                dec = base64.b64decode(d_url).decode('utf-8')
                if dec.startswith('magnet:') or dec.endswith('.torrent'):
                    return dec, ''
            except Exception:
                pass

        # 2. Invocar play() del canal correspondiente
        try:
            _switch_engine_environment(actual_engine)
            _ch_dbg = _safe_str(getattr(link, 'channel', '') or '').strip()
            if _ch_dbg:
                _ch_mod = __import__('channels.' + _ch_dbg, fromlist=[''])
                if hasattr(_ch_mod, 'play'):
                    _play_holder = [None]
                    _play_err = [None]
                    _item_to_play = link.clone() if hasattr(link, 'clone') else link
                    if not getattr(_item_to_play, 'server', None):
                        _item_to_play.server = 'torrent'

                    def _do_play():
                        try:
                            with silenced_dialogs():
                                _play_holder[0] = _ch_mod.play(_item_to_play)
                        except Exception as _ex:
                            _play_err[0] = _ex

                    _pt = threading.Thread(target=_do_play, daemon=True)
                    _pt.start()
                    try:
                        _pdlg = xbmcgui.DialogProgressBG()
                        _pdlg.create('Multi Bridge', 'Resolviendo torrent (%s)...' % _ch_dbg)
                    except Exception:
                        _pdlg = None
                    _deadline = time.time() + _TORRENT_PLAY_BUDGET
                    try:
                        while _pt.is_alive() and time.time() < _deadline:
                            if xbmc.Monitor().abortRequested():
                                break
                            time.sleep(0.2)
                    except Exception:
                        pass
                    try:
                        if _pdlg:
                            _pdlg.close()
                    except Exception:
                        pass

                    if _pt.is_alive():
                        xbmc.log("Multi Bridge: torrent %s canal.play supero %ds, se abandona" % (_ch_dbg, _TORRENT_PLAY_BUDGET), xbmc.LOGWARNING)
                        fail_detail = 'El canal tardó demasiado en responder'
                        _p_res = None
                    elif _play_err[0] is not None:
                        xbmc.log("Multi Bridge: torrent canal.play error: %s" % _play_err[0], xbmc.LOGINFO)
                        fail_detail = str(_play_err[0])
                        _p_res = None
                    else:
                        _p_res = _play_holder[0]

                    if _p_res is not None:
                        if isinstance(_p_res, str) and _p_res.strip():
                            fail_detail = re.sub(r'\[/?COLOR[^\]]*\]|\[/?B\]|\[CR\]', '', _p_res).strip()
                        else:
                            _cand = None
                            if isinstance(_p_res, list) and _p_res:
                                _cand = _p_res[0]
                                if isinstance(_cand, list):
                                    _cand = _cand[0] if _cand else None
                            elif hasattr(_p_res, 'url'):
                                _cand = _p_res
                            if _cand is not None and _safe_str(getattr(_cand, 'url', '') or ''):
                                cand_url = _safe_str(getattr(_cand, 'url', '') or '')
                                torrent_url = cand_url
                                xbmc.log("Multi Bridge: torrent %s resuelto via canal.play (%s...)" % (_ch_dbg, torrent_url[:30]), xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log("Multi Bridge: torrent canal.play error: %s" % _e, xbmc.LOGINFO)

    return torrent_url, fail_detail


def _play_torrent_link(torrent_url, matched_item=None, meta=None):
    """Reproduce un link torrent usando el cliente configurado en Balandro.

    Enriquece la URL con datos TMDb (tmdb_id, type, season, episode, show)
    para que Elementum/Quasar puedan identificar el contenido correctamente.

    Returns True si se lanzó la reproducción, 'no_client' si no hay cliente configurado, False si fallo.
    """
    if not torrent_url:
        return False

    _tl = torrent_url.strip()
    if not (_tl.startswith('magnet:') or _tl.endswith('.torrent')):
        xbmc.log('Multi Bridge: _play_torrent_link rechaza URL no-torrent: %s...' % _tl[:80], xbmc.LOGWARNING)
        return False
    torrent_url = _tl

    _is_magnet = torrent_url.startswith('magnet:')
    _tor_id, _tor_tpl = _get_torrent_client(is_magnet=_is_magnet)
    if not (_tor_id and _tor_tpl):
        xbmcgui.Dialog().notification(
            'Multi Bridge',
            'Configura un cliente torrent en Ajustes → Balandro → Torrents',
            '', 5000)
        return 'no_client'

    encoded = uparse.quote_plus(torrent_url)
    play_url = _tor_tpl % encoded

    if not meta:
        _cf = _read_search_cache_atomic()
        if _cf and isinstance(_cf, dict):
            meta = dict(_cf.get('meta', {}) or {})
        else:
            meta = {}
    else:
        meta = dict(meta)

    # Enriquecer meta exhaustivamente desde matched_item si este posee infoLabels
    if matched_item:
        _info = getattr(matched_item, 'infoLabels', {}) or {}
        if not meta.get('tmdb'): meta['tmdb'] = str(_info.get('tmdb_id', '') or _info.get('tmdb', '') or '')
        if not meta.get('imdb'): meta['imdb'] = str(_info.get('imdb_id', '') or _info.get('imdb', '') or _info.get('code', '') or '')
        if not meta.get('tvdb'): meta['tvdb'] = str(_info.get('tvdb_id', '') or _info.get('tvdb', '') or '')
        if not meta.get('trakt'): meta['trakt'] = str(_info.get('trakt_id', '') or _info.get('trakt', '') or '')
        if not meta.get('season'): meta['season'] = str(getattr(matched_item, 'contentSeason', '') or _info.get('season', '') or '')
        if not meta.get('episode'): meta['episode'] = str(getattr(matched_item, 'contentEpisode', '') or _info.get('episode', '') or '')
        if not meta.get('showname'): meta['showname'] = str(getattr(matched_item, 'contentSerieName', '') or _info.get('tvshowtitle', '') or '')
        if not meta.get('title'): meta['title'] = str(getattr(matched_item, 'contentTitle', '') or _info.get('title', '') or '')
        if not meta.get('year'): meta['year'] = str(_info.get('year', '') or '')
        if not meta.get('plot'): meta['plot'] = str(_info.get('plot', '') or '')
        if not meta.get('poster'): meta['poster'] = str(_info.get('poster', '') or _info.get('thumbnail', '') or '')
        if not meta.get('fanart'): meta['fanart'] = str(_info.get('fanart', '') or '')
        if not meta.get('thumbnail'): meta['thumbnail'] = str(_info.get('thumbnail', '') or _info.get('poster', '') or '')
        if not meta.get('clearlogo'): meta['clearlogo'] = str(_info.get('clearlogo', '') or '')
        if not meta.get('genre'): meta['genre'] = str(_info.get('genre', '') or '')
        if not meta.get('director'): meta['director'] = str(_info.get('director', '') or '')

    _tmdb   = str(meta.get('tmdb', '') or '')
    _imdb   = str(meta.get('imdb', '') or '')
    _tvdb   = str(meta.get('tvdb', '') or '')
    _trakt  = str(meta.get('trakt', '') or '')
    _season = str(meta.get('season', '') or '')
    _epnum  = str(meta.get('episode', '') or '')
    _show   = str(meta.get('showname', '') or meta.get('title', '') or '')
    _title  = str(meta.get('title', '') or '')
    _year   = str(meta.get('showyear' if (_season and _epnum) else 'year') or meta.get('year', '') or '')
    _ctype  = 'episode' if (_season and _epnum) else 'movie'

    # Guardar metadatos activos en Window(10000) para inyeccion inmediata por BridgePlayerService (service.py) y PlayerMonitor
    try:
        xbmcgui.Window(10000).setProperty('MultiBridge.ActivePlaybackMeta', json.dumps(meta))
        xbmcgui.Window(10000).setProperty('MultiBridge.ActivePlaybackTime', str(time.time()))
        xbmcgui.Window(10000).setProperty('MultiBridge.IsTorrentPlayback', 'true')
    except Exception:
        pass

    # ── Enriquecimiento TMDb para Elementum / Quasar ───────────────────────
    _tor_name = _tor_id.rsplit('.', 1)[-1].lower()   # 'elementum', 'quasar', ...
    if _tor_name in ('elementum', 'quasar'):
        if _tmdb or _imdb:
            if _ctype == 'episode' and _season and _epnum:
                play_url += ('&episode=%s&library=&season=%s&show=%s&tmdb=%s&type=episode'
                             % (_epnum, _season, _tmdb or _imdb, _tmdb or _imdb))
                if _imdb: play_url += '&imdb=%s' % uparse.quote_plus(_imdb)
                if _tvdb: play_url += '&tvdb=%s' % uparse.quote_plus(_tvdb)
                if _show: play_url += '&showname=%s' % uparse.quote_plus(_show)
                if _title: play_url += '&title=%s' % uparse.quote_plus(_title)
                xbmc.log('Multi Bridge: torrent enriquecido [serie] tmdb=%s imdb=%s S%sE%s' % (
                    _tmdb, _imdb, _season, _epnum), xbmc.LOGINFO)
            else:
                play_url += '&library=&tmdb=%s&type=movie' % (_tmdb or _imdb)
                if _imdb: play_url += '&imdb=%s' % uparse.quote_plus(_imdb)
                if _title: play_url += '&title=%s' % uparse.quote_plus(_title)
                if _year: play_url += '&year=%s' % uparse.quote_plus(_year)
                xbmc.log('Multi Bridge: torrent enriquecido [peli] tmdb=%s imdb=%s' % (_tmdb, _imdb), xbmc.LOGINFO)

    xbmc.log('Multi Bridge: torrent → %s' % _tor_id, xbmc.LOGINFO)
    sync_tmdbhelper_playerstring(meta)

    try:
        xbmc.log('Multi Bridge: lanzando torrent via PlayMedia: %s' % play_url, xbmc.LOGINFO)
        xbmc.executebuiltin('PlayMedia("%s")' % play_url)
    except Exception as _pe:
        xbmc.log('Multi Bridge: error en PlayMedia torrent: %s' % _pe, xbmc.LOGWARNING)
        return False
    return True


def _offer_elementum_search(meta):
    """Si elementum_fallback está activo, pregunta si buscar en Elementum.

    Se ejecuta después de que el handle del plugin ha sido descartado y TMDb Helper
    ha finalizado, evitando cualquier interferencia o espera de player.
    """
    has_elementum = bool(xbmc.getCondVisibility('System.HasAddon("plugin.video.elementum")'))
    fallback_enabled = (_bridge_addon.getSetting('elementum_fallback') == 'true')

    tmdb_id = str(meta.get('tmdb', '') or '')
    is_episode = bool(meta.get('season') and meta.get('episode'))
    title = str(meta.get('title') or meta.get('showname') or '')
    label = '[B]%s[/B]' % title if title else 'este contenido'

    if not fallback_enabled or not has_elementum or not tmdb_id:
        _show_bridge_notification('Multi Bridge', 'No se encontraron enlaces para %s' % (title or 'este contenido'), 3500)
        return False

    dlg = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)()
    ans = dlg.yesno(
        'Multi Bridge — Sin enlaces',
        'No se encontraron enlaces para %s.\n¿Buscar en [B]Elementum[/B]?' % label,
        nolabel='No',
        yeslabel='Sí')

    if not ans:
        return False

    # URL de Elementum para buscar y mostrar la lista modal de torrents por TMDb ID
    if is_episode:
        _s = str(meta.get('season', '') or '')
        _e = str(meta.get('episode', '') or '')
        elem_url = 'plugin://plugin.video.elementum/show/%s/season/%s/episode/%s/links' % (tmdb_id, _s, _e)
    else:
        elem_url = 'plugin://plugin.video.elementum/movie/%s/links' % tmdb_id

    xbmc.log('Multi Bridge: lanzando Elementum via PlayMedia → %s' % elem_url, xbmc.LOGINFO)

    # PlayMedia asigna a Elementum un handle de reproductor real para que al elegir el torrent
    # Elementum pueda resolver e iniciar la reproducción en Kodi. Multi Bridge termina aquí su ejecución.
    sync_tmdbhelper_playerstring(meta)
    xbmc.executebuiltin('PlayMedia("%s")' % elem_url)
    return True






def _get_link_server_name(link):


    if not link: return 'Directo'
    srv = _safe_str(getattr(link, 'server', '')).strip()
    other = _safe_str(getattr(link, 'other', '')).strip()
    url_str = _safe_str(getattr(link, 'url', '')).strip().lower()

    clean_other = re.sub(r'[\(\)\[\]]', '', other).strip()
    clean_other = re.sub(r'\s+D$', '', clean_other, flags=re.IGNORECASE).strip()

    domain_map = [
        ('fastream', 'Fastream'), ('streamwish', 'Streamwish'), ('strwish', 'Streamwish'),
        ('swish', 'Streamwish'), ('audinifer', 'Streamwish'), ('hanerix', 'Streamwish'),
        ('vidhide', 'Vidhide'), ('vidhideplus', 'Vidhide'), ('vidhidepro', 'Vidhide'),
        ('voe', 'Voe'), ('voesx', 'Voe'), ('vidmoly', 'Vidmoly'), ('dood', 'Doodstream'),
        ('ds2play', 'Doodstream'), ('mixdrop', 'Mixdrop'), ('uqload', 'Uqload'),
        ('vudeo', 'Vudeo'), ('turbovid', 'Turboviplay'), ('emturbovid', 'Turboviplay'),
        ('turboviplay', 'Turboviplay'), ('filelions', 'Filelions'), ('lion', 'Filelions'),
        ('luluvdo', 'Lulustream'), ('lulustream', 'Lulustream'), ('waaw', 'Waaw'),
        ('netu', 'Waaw'), ('gamovideo', 'Gamovideo'), ('streamtape', 'Streamtape'),
        ('streamlare', 'Streamlare'), ('supervideo', 'Supervideo'), ('dropload', 'Dropload'),
        ('userload', 'Userload'), ('upstream', 'Upstream'), ('wolfstream', 'Wolfstream'),
        ('hexupload', 'Hexupload'), ('mega', 'Mega'), ('1fichier', '1fichier'),
        ('okru', 'Okru'), ('ok.ru', 'Okru'), ('kinoger', 'Kinoger'), ('vimeos', 'Vimeos'), ('zures', 'Vimeos'),
        ('powvideo', 'Powvideo'), ('povwideo', 'Powvideo'), ('powwideo', 'Powvideo'), ('povvideo', 'Powvideo'),
        ('streamplay', 'Streamplay'), ('straemplay', 'Streamplay'), ('streamp1ay', 'Streamplay'), ('steamplay', 'Streamplay'), ('stremplay', 'Streamplay')
    ]

    if not srv or srv.lower() in ('various', 'zures', 'videoapp', 'directo', 'none', ''):
        if clean_other and clean_other.lower() not in ('various', 'zures', 'videoapp', 'directo', 'none', ''):
            for d_key, d_name in domain_map:
                if d_key in clean_other.lower(): return d_name
            return clean_other.capitalize()
        for d_key, d_name in domain_map:
            if d_key in url_str: return d_name
        if _is_torrent_link(link): return 'Torrent'
        return 'Directo'

    for d_key, d_name in domain_map:
        if d_key == srv.lower() or d_key in srv.lower():
            return d_name

    if clean_other and clean_other.lower() not in ('various', 'zures', 'videoapp', 'directo', 'none', ''):
        for d_key, d_name in domain_map:
            if d_key in clean_other.lower(): return d_name
        return clean_other.capitalize()

    return srv.capitalize()

# --------------------------------------------------------------------------------------------------
# Gestion de Enlaces Fallidos Persistentes por Sesion de Medios
# Permite que un enlace que fallo antes o durante la reproduccion permanezca marcado como [FALLIDO]
# --------------------------------------------------------------------------------------------------
_SESSION_FAILED_LINKS = {}

def _get_link_unique_id(link, fallback_index=None):
    if not link:
        return ''
    uid = getattr(link, '_bridge_uid', None)
    if uid:
        return uid

    srv = _get_link_server_name(link).strip().lower()
    ch = _safe_str(getattr(link, 'channel', '')).strip().lower()
    lang = _safe_str(getattr(link, 'language', '')).strip().lower()
    qual = _safe_str(getattr(link, 'quality', '')).strip().lower()
    data_url = _safe_str(getattr(link, 'data_url', '')).strip().lower()
    url = _safe_str(getattr(link, 'url', '')).strip().lower()
    extra = _safe_str(getattr(link, 'extra', '')).strip().lower()
    title = _safe_str(getattr(link, 'title', '')).strip().lower()
    post = _safe_str(getattr(link, 'post', '')).strip().lower()
    idx = getattr(link, '_bridge_orig_idx', None)
    if idx is None and fallback_index is not None:
        idx = fallback_index

    parts = [srv, ch, lang, qual]
    if idx is not None:
        parts.append('idx_%s' % idx)
    if data_url:
        parts.append('durl_%s' % data_url)
    elif url:
        parts.append('url_%s' % url)
    if extra:
        parts.append('ext_%s' % extra)
    if post:
        parts.append('post_%s' % post)
    if title:
        parts.append('tit_%s' % title)

    uid = '|'.join(parts)
    try: setattr(link, '_bridge_uid', uid)
    except Exception: pass
    return uid

def _get_session_failed_signatures(media_key=None, meta=None):
    global _SESSION_FAILED_LINKS
    mk = str(media_key or (meta and _get_media_key(meta)) or '').strip()
    if not mk:
        try:
            mk = str(xbmcgui.Window(10000).getProperty('BridgeMulti.CurrentMediaKey') or '').strip()
        except Exception:
            pass
    sigs = set()
    if mk and mk in _SESSION_FAILED_LINKS:
        sigs.update(_SESSION_FAILED_LINKS[mk].get('signatures', set()))
    try:
        win = xbmcgui.Window(10000)
        win_mk = win.getProperty('BridgeMulti.FailedMediaKey')
        if win_mk and (not mk or win_mk == mk):
            raw = win.getProperty('BridgeMulti.FailedSignatures')
            if raw:
                data = json.loads(raw)
                if isinstance(data, list):
                    sigs.update(data)
    except Exception:
        pass
    return sigs

def _record_session_failed_link(link, index=None, media_key=None, meta=None):
    global _SESSION_FAILED_LINKS
    mk = str(media_key or (meta and _get_media_key(meta)) or '').strip()
    if not mk:
        try:
            mk = str(xbmcgui.Window(10000).getProperty('BridgeMulti.CurrentMediaKey') or '').strip()
        except Exception:
            pass
    if not link:
        return
    try:
        setattr(link, 'bridge_failed', True)
    except Exception:
        pass
    sig = _get_link_unique_id(link, fallback_index=index)
    if not mk:
        mk = 'default_media'

    if mk not in _SESSION_FAILED_LINKS:
        _SESSION_FAILED_LINKS[mk] = {'signatures': set(), 'indices': set(), 'objects': set()}

    if sig:
        _SESSION_FAILED_LINKS[mk]['signatures'].add(sig)
    if index is not None and isinstance(index, int):
        _SESSION_FAILED_LINKS[mk]['indices'].add(index)
    _SESSION_FAILED_LINKS[mk]['objects'].add(link)

    try:
        win = xbmcgui.Window(10000)
        win.setProperty('BridgeMulti.FailedMediaKey', mk)
        win.setProperty('BridgeMulti.FailedSignatures', json.dumps(list(_SESSION_FAILED_LINKS[mk]['signatures'])))
    except Exception:
        pass

def _clear_session_failed_links(media_key=None):
    global _SESSION_FAILED_LINKS, _RAM_SEARCH_CACHE
    try:
        if media_key:
            mk = str(media_key).strip()
            _SESSION_FAILED_LINKS.pop(mk, None)
        else:
            _SESSION_FAILED_LINKS.clear()
    except Exception:
        pass
    try:
        win = xbmcgui.Window(10000)
        win.clearProperty('BridgeMulti.FailedMediaKey')
        win.clearProperty('BridgeMulti.FailedSignatures')
        win.setProperty('BridgeMulti.FailedMediaKey', '')
        win.setProperty('BridgeMulti.FailedSignatures', '')
    except Exception:
        pass
    try:
        if _RAM_SEARCH_CACHE and isinstance(_RAM_SEARCH_CACHE.get('links'), list):
            for l in _RAM_SEARCH_CACHE['links']:
                try:
                    setattr(l, 'bridge_failed', False)
                except Exception:
                    pass
    except Exception:
        pass

def _format_language(link):
    lang = getattr(link, 'language', '')
    if isinstance(lang, list): lang = ' / '.join([_safe_str(l) for l in lang])
    lang = _safe_str(lang).strip()
    title_str = _safe_str(getattr(link, 'title', ''))
    combined = (lang + ' ' + title_str).lower()
    if 'lat' in combined or 'latino' in combined or 'dual' in combined: return 'LATINO'
    if 'cast' in combined or 'esp' in combined or 'castellano' in combined or 'español' in combined: return 'CASTELLANO'
    if 'vose' in combined or 'sub' in combined or 'vos' in combined: return 'VOSE'
    if 'eng' in combined or 'ingles' in combined: return 'INGLES'
    return 'LATINO' if not lang else lang.upper()

def _get_link_language_group(link):
    f_lang = _format_language(link)
    if 'LAT' in f_lang: return 'LAT'
    if 'CAST' in f_lang or 'ESP' in f_lang: return 'ESP'
    if 'VOSE' in f_lang or 'SUB' in f_lang: return 'VOSE'
    return 'OTHER'

def _has_4k_token(combined):
    """Detecta 4K real (4K/2160/UHD como palabra) sin picar con IDs
    aleatorios de embeds/magnets que contienen esas letras
    (ej. '...f4klam...' no es 4K)."""
    try:
        if re.search(r'\b4\s?K\b', combined): return True
        if re.search(r'\b2160P?\b', combined): return True
        if re.search(r'\bUHD\b', combined): return True
    except Exception:
        pass
    return False

def _format_quality(link):
    if _is_cam_quality(link):
        return 'CAM'
    qual = _safe_str(getattr(link, 'quality', '')).strip()
    title_str = _safe_str(getattr(link, 'title', '')).strip()
    url_str = _safe_str(getattr(link, 'url', '')).strip()
    combined = (qual + ' ' + title_str + ' ' + url_str).upper()
    if _is_torrent_link(link):
        # Torrents: conservar fuente (WEB-DL vs WEBRip importa) + resolucion.
        # Ej. 'WEB-DL 1080p', 'Dual 1080p', 'WEBRip', 'Dual 720p'.
        parts = []
        _has_src = False
        if 'WEB-DL' in combined or 'WEBDL' in combined or 'WEB DL' in combined:
            parts.append('WEB-DL'); _has_src = True
        elif 'WEBRIP' in combined or 'WEB-RIP' in combined or 'WEB RIP' in combined:
            parts.append('WEBRip'); _has_src = True
        elif 'BLURAY' in combined or 'BLU-RAY' in combined or 'BRRIP' in combined or 'BDRIP' in combined:
            parts.append('BluRay'); _has_src = True
        elif 'DVDRIP' in combined or ('DVD' in combined and 'RIP' in combined):
            parts.append('DVDRip'); _has_src = True
        elif 'DVD' in combined:
            parts.append('DVD'); _has_src = True
        elif 'HDTV' in combined:
            parts.append('HDTV'); _has_src = True
        elif 'CAM' in combined or re.search(r'\bTS\b', combined) or 'TELESYNC' in combined:
            parts.append('CAM'); _has_src = True
        if 'DUAL' in combined:
            parts.append('Dual')
        if _has_4k_token(combined):
            parts.append('4K')
        elif '1080P' in combined or 'FULLHD' in combined or 'FHD' in combined or '1080' in combined:
            parts.append('1080p')
        elif '720P' in combined or 'HD' in combined:
            parts.append('720p')
        elif '480P' in combined or '480' in combined:
            parts.append('480p')
        elif not _has_src and ('RIP' in combined or 'DVD' in combined):
            parts.append('SD')
        if parts:
            return ' '.join(parts)
        return 'N/A'

    # Enlaces directos: si ya se detectó la calidad técnica real del stream, devolverla con máxima prioridad
    real_q = _safe_str(getattr(link, 'real_quality', '') or getattr(link, 'real_res', '')).strip()
    srv_name = _get_link_server_name(link).strip().lower()
    streaming_hosts_no_4k = (
        'voe', 'streamwish', 'strwish', 'swish', 'vidhide', 'vidhideplus', 'vidhidepro',
        'turbovid', 'turboviplay', 'fastream', 'doodstream', 'dood', 'mixdrop', 'uqload',
        'vidmoly', 'supervideo', 'filelions', 'lulustream', 'waaw', 'netu', 'upstream',
        'wolfstream', 'hexupload', 'okru', 'kinoger', 'gamovideo', 'streamtape'
    )
    is_cyberlocker = any(h in srv_name for h in streaming_hosts_no_4k)

    if real_q:
        if is_cyberlocker and real_q == '4K':
            real_q = '1080p'
        return real_q

    # Deteccion de resolucion por texto en URL, nombre de archivo o titulo
    detected_text = _detect_resolution_from_text(combined)
    if detected_text:
        if is_cyberlocker and detected_text == '4K':
            detected_text = '1080p'
        return detected_text

    # Si el canal es conocido por ser de catalogo exclusivo Full HD 1080p (Cinecalidad, Granpelis, SoloEnCine, etc.):
    ch_name = _safe_str(getattr(link, 'channel', '')).lower()
    if any(c in ch_name for c in ('cinecalidad', 'granpelis', 'soloencine')):
        return '1080p'

    # Servidores de alta fidelidad y directos que en sitios de streaming alojan 1080p (Full HD)
    srv_name = _get_link_server_name(link).strip().lower()
    streaming_hosts_1080 = (
        'streamwish', 'strwish', 'swish', 'mega', '1fichier', 'filemoon', 'voe',
        'vidhide', 'vidhideplus', 'vidhidepro', 'turbovid', 'turboviplay', 'fastream',
        'doodstream', 'dood', 'mixdrop', 'uqload', 'vidmoly', 'supervideo',
        'filelions', 'lulustream', 'waaw', 'netu', 'upstream', 'wolfstream',
        'hexupload', 'okru', 'kinoger', 'gamovideo', 'streamtape'
    )

    if not is_cyberlocker and (_has_4k_token(combined) or '2160' in combined):
        return '4K'
    if '1080P' in combined or 'FULLHD' in combined or 'FHD' in combined or re.search(r'\b1080\b', combined):
        return '1080p'
    if '720P' in combined or re.search(r'\b720\b', combined):
        return '720p'
    if '480P' in combined or re.search(r'\b480\b', combined) or 'SD' in combined or 'DVD' in combined or 'DVDRIP' in combined:
        return '480p'
    if '360P' in combined or re.search(r'\b360\b', combined):
        return '360p'
    if '240P' in combined or re.search(r'\b240\b', combined):
        return '240p'
    if 'CAM' in combined or re.search(r'\bTS\b', combined) or 'TELESYNC' in combined:
        return 'CAM'

    # En streaming moderno web, 'HD' o 'HDRIP' o 'WEB-DL' sin 720 corresponde a Full HD 1080p
    if re.search(r'\bHD\b', combined) or 'HDRIP' in combined or 'HD-RIP' in combined or 'WEBRIP' in combined or 'WEB-DL' in combined:
        return '1080p'

    # Servidores directos reconocidos: almacenan copias Full HD 1080p por defecto
    if srv_name in streaming_hosts_1080:
        return '1080p'

    return '1080p'

def _get_link_quality_score(link, pref_quality=0):
    if _is_torrent_link(link):
        q = _format_quality(link)
        if '4K' in q or '2160' in q: return 500
        if '1080' in q: return 400
        if '720' in q: return 300
        if '480' in q: return 200
        if '360' in q: return 150
        if '240' in q: return 100
        if 'CAM' in q: return 50
        if q in ('SD', 'DVD', 'DVDRip') or 'RIP' in q or 'WEBRIP' in q.upper(): return 200
        return 50

    q = _format_quality(link)
    is_1080 = ('1080' in q or 'FULLHD' in q or 'FHD' in q)
    is_720 = ('720' in q or 'HD' in q) and not is_1080
    is_480 = ('480' in q or 'SD' in q or 'DVD' in q) and not is_1080 and not is_720
    is_360 = ('360' in q) and not is_1080 and not is_720 and not is_480
    is_240 = ('240' in q) and not is_1080 and not is_720 and not is_480 and not is_360
    is_cam = ('CAM' in q or 'TS' in q or 'TELESYNC' in q)

    try:
        pq = int(pref_quality)
    except Exception:
        pq = 0

    if pq == 0:   # Preferir 1080p
        if is_1080: return 400
        if is_720:  return 300
        if is_480:  return 200
        if is_360:  return 150
        if is_240:  return 100
        if is_cam:  return 50
        return 120
    elif pq == 1: # Preferir 720p
        if is_720:  return 400
        if is_1080: return 300
        if is_480:  return 200
        if is_360:  return 150
        if is_240:  return 100
        if is_cam:  return 50
        return 120
    elif pq == 2: # Preferir 480p
        if is_480:  return 400
        if is_360:  return 350
        if is_240:  return 300
        if is_720:  return 200
        if is_1080: return 150
        if is_cam:  return 50
        return 120
    return 120

def _stream_quality_score(entry):
    """Calcula la puntuacion ordinal de calidad tecnica de un flujo o etiqueta (4K > 1080p > 720p > 480p > SD).
    Soporta resoluciones nativas de Okru (ultra > full > hd > sd > low > lowest), Streamwish y CDNs con parametro type=."""
    if not entry:
        return 0
    lbl = ''
    url = ''
    if isinstance(entry, (list, tuple)):
        lbl = _safe_str(entry[0]) if len(entry) > 0 else ''
        url = _safe_str(entry[1]) if len(entry) > 1 else ''
    elif isinstance(entry, str):
        lbl = entry
    comb = (lbl + ' ' + url).upper()
    if _has_4k_token(comb) or any(k in comb for k in ('2160P', '2160', '4K', 'UHD', '3840X2160', 'ULTRA')) or 'TYPE=7' in comb:
        return 400
    if any(k in comb for k in ('1080P', '1080', 'FHD', 'FULLHD', '1920X1080', '1920X1088', 'QUAD')) or re.search(r'\bFULL\b', comb) or 'TYPE=5' in comb or 'TYPE=6' in comb:
        return 300
    if (any(k in comb for k in ('720P', '720', '1280X720')) or re.search(r'\bHD\b', comb) or 'TYPE=4' in comb) and not any(k in comb for k in ('1080P', '1080', 'FHD', 'FULLHD', 'QUAD', 'ULTRA')):
        return 200
    if any(k in comb for k in ('480P', '480', 'DVD', '854X480', '720X480')) or re.search(r'\bSD\b', comb) or 'TYPE=3' in comb:
        return 100
    if any(k in comb for k in ('360P', '360', '640X360')) or re.search(r'\bLOW\b', comb) or 'TYPE=2' in comb:
        return 50
    if any(k in comb for k in ('240P', '240')) or re.search(r'\b(?:LOWEST|MOBILE)\b', comb) or 'TYPE=1' in comb:
        return 20
    return 10

def _format_channel(link):
    ch = _safe_str(getattr(link, 'channel', ''))
    if ch: return ch.capitalize()
    return 'General'

def _get_int_setting(key, default_val):
    try:
        val = _bridge_addon.getSetting(key)
        if val is None or val == '': return default_val
        return int(float(val))
    except Exception:
        return default_val

def _parse_csv_setting(val):
    if not val: return []
    return [_safe_str(s).strip().lower() for s in str(val).split(',') if s.strip()]

def _get_discarded_servers_list():
    try:
        srv_on = _bridge_addon.getSetting('filter_servers_enabled') != 'false'
        if not srv_on:
            return []
        raw = _bridge_addon.getSetting('servers_discarded')
        if raw is None or raw == '':
            raw = 'rapidgator,directo,waaw'
        return [s.strip().lower() for s in str(raw).split(',') if s.strip()]
    except Exception:
        return ['rapidgator', 'directo', 'waaw']


def _parse_mp4_resolution(data):
    """Extrae el ancho y alto en píxeles del encabezado tkhd de un archivo MP4 sin reproducirlo."""
    import struct
    pos = 0
    while True:
        idx = data.find(b'tkhd', pos)
        if idx == -1 or idx < 4:
            break
        try:
            version = data[idx + 4]
            if version == 0:
                w_offset = idx + 80
            elif version == 1:
                w_offset = idx + 92
            else:
                pos = idx + 4
                continue
            if w_offset + 8 <= len(data):
                w_int, _, h_int, _ = struct.unpack('>HHHH', data[w_offset:w_offset+8])
                if 240 <= w_int <= 7680 and 140 <= h_int <= 4320:
                    return w_int, h_int
        except Exception:
            pass
        pos = idx + 4
    return None, None


def _parse_mkv_resolution(data):
    """Extrae el ancho y alto en píxeles de los elementos EBML de un contenedor MKV/WebM."""
    pos = 0
    while pos < len(data) - 4:
        idx_w = data.find(b'\xb0', pos)
        if idx_w == -1:
            break
        sz = data[idx_w + 1]
        length = sz & 0x7F if (sz & 0x80) else (sz & 0x3F if (sz & 0x40) else 0)
        if length in (1, 2, 4) and idx_w + 2 + length <= len(data):
            w_val = int.from_bytes(data[idx_w + 2: idx_w + 2 + length], 'big')
            if 240 <= w_val <= 7680:
                idx_h = data.find(b'\xba', idx_w + 2 + length, idx_w + 50)
                if idx_h != -1:
                    sz_h = data[idx_h + 1]
                    length_h = sz_h & 0x7F if (sz_h & 0x80) else (sz_h & 0x3F if (sz_h & 0x40) else 0)
                    if length_h in (1, 2, 4) and idx_h + 2 + length_h <= len(data):
                        h_val = int.from_bytes(data[idx_h + 2: idx_h + 2 + length_h], 'big')
                        if 140 <= h_val <= 4320:
                            return w_val, h_val
        pos = idx_w + 1
    return None, None


def _detect_resolution_from_text(text):
    """Detecta etiquetas de resolucion tecnica (4K, 1080p, 720p, 480p, 360p, 240p)
    desde el texto de una URL resuelta, nombre de archivo, etiquetas de servidor (Okru, Streamwish) o titulo de enlace."""
    if not text:
        return None
    t = str(text).upper()
    if re.search(r'\b(?:2160P?|3840X2160|4K|UHD|ULTRA)\b', t) or 'TYPE=7' in t:
        return '4K'
    if re.search(r'\b(?:1440P?|QUAD|2K)\b', t) or 'TYPE=6' in t:
        return '1080p'
    if '1080P' in t or '1080' in t or 'FULLHD' in t or 'FHD' in t or '1920X1080' in t or '1920X1088' in t or re.search(r'\bFULL\b', t) or 'TYPE=5' in t:
        return '1080p'
    if '720P' in t or '720' in t or '1280X720' in t or re.search(r'\bHD\b', t) or 'TYPE=4' in t:
        return '720p'
    if '480P' in t or '480' in t or '854X480' in t or '720X480' in t or re.search(r'\bSD\b', t) or 'TYPE=3' in t:
        return '480p'
    if '360P' in t or '360' in t or '640X360' in t or re.search(r'\bLOW\b', t) or 'TYPE=2' in t:
        return '360p'
    if '240P' in t or '240' in t or re.search(r'\b(?:LOWEST|MOBILE)\b', t) or 'TYPE=1' in t:
        return '240p'
    return None


def _classify_resolution(w=None, h=None):
    """Clasifica la resolucion de video de forma tecnica y precisa,
    contemplando relaciones de aspecto panoramicas (Cinemascope 2.39:1 / 2.40:1, ej. 1920x800, 1920x1088, 1280x536)."""
    try: w = int(w) if w else 0
    except Exception: w = 0
    try: h = int(h) if h else 0
    except Exception: h = 0

    if not w and not h:
        return None

    # 4K / UHD
    if w >= 3200 or h >= 1800:
        return '4K'

    # 1080p / Full HD (1920x1080, 1920x1088 H.264 macroblock, o 1920x800 Cinemascope sin barras negras)
    if w >= 1600 or h >= 750:
        return '1080p'

    # 720p / HD (1280x720 o 1280x536 Cinemascope sin barras negras)
    if w >= 1100 or h >= 520:
        return '720p'

    # 480p / SD (854x480, 720x480, etc.)
    if w >= 700 or h >= 440:
        return '480p'

    # 360p (640x360)
    if w >= 480 or h >= 320:
        return '360p'

    return '240p'


def _parse_ts_sps(chunk):
    """Extrae el ancho y alto en pixeles del Sequence Parameter Set (SPS H.264 / HEVC)
    en un flujo de paquetes MPEG-TS (188 bytes con sync 0x47)."""
    if not chunk or len(chunk) < 188:
        return None, None
    sync_positions = [i for i in range(min(564, len(chunk))) if chunk[i] == 0x47]
    is_ts = False
    for sp in sync_positions:
        if sp + 188 < len(chunk) and chunk[sp + 188] == 0x47:
            is_ts = True
            break
    if not is_ts:
        return None, None

    idx = 0
    limit = len(chunk) - 32
    while idx < limit:
        pos = chunk.find(b'\x00\x00\x01', idx, limit)
        if pos == -1:
            break
        nal_header = chunk[pos + 3]
        if (nal_header & 0x1F) == 7:  # H.264 SPS
            sps_bytes = chunk[pos + 4: pos + 64]
            try:
                rbsp = bytearray()
                i = 0
                while i < len(sps_bytes):
                    if i + 2 < len(sps_bytes) and sps_bytes[i] == 0 and sps_bytes[i+1] == 0 and sps_bytes[i+2] == 3:
                        rbsp.append(sps_bytes[i]); rbsp.append(sps_bytes[i+1]); i += 3
                    else:
                        rbsp.append(sps_bytes[i]); i += 1

                class _BitReader:
                    def __init__(self, data):
                        self.data = data; self.b_idx = 0; self.bit_idx = 0
                    def read_bit(self):
                        if self.b_idx >= len(self.data): return 0
                        bit = (self.data[self.b_idx] >> (7 - self.bit_idx)) & 1
                        self.bit_idx += 1
                        if self.bit_idx == 8: self.bit_idx = 0; self.b_idx += 1
                        return bit
                    def read_bits(self, n):
                        val = 0
                        for _ in range(n): val = (val << 1) | self.read_bit()
                        return val
                    def read_ue(self):
                        zeros = 0
                        while self.read_bit() == 0 and zeros < 32: zeros += 1
                        if zeros == 0: return 0
                        return (1 << zeros) - 1 + self.read_bits(zeros)

                reader = _BitReader(rbsp)
                profile = reader.read_bits(8)
                reader.read_bits(8); reader.read_bits(8)
                reader.read_ue()  # sps_id
                if profile in (100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135):
                    chroma = reader.read_ue()
                    if chroma == 3: reader.read_bit()
                    reader.read_ue(); reader.read_ue()
                    reader.read_bit()
                    if reader.read_bit():
                        cnt = 12 if chroma == 3 else 8
                        for _ in range(cnt):
                            if reader.read_bit(): pass
                reader.read_ue()
                poc = reader.read_ue()
                if poc == 0: reader.read_ue()
                elif poc == 1:
                    reader.read_bit(); reader.read_ue(); reader.read_ue()
                    for _ in range(reader.read_ue()): reader.read_ue()
                reader.read_ue(); reader.read_bit()
                w = (reader.read_ue() + 1) * 16
                h = (reader.read_ue() + 1) * 16 * (2 - reader.read_bit())
                if 140 <= w <= 8192 and 140 <= h <= 4320:
                    return w, h
            except Exception:
                pass
        idx = pos + 1
    return None, None


def _classify_resolution_height(h):
    """Wrapper retrocompatible."""
    return _classify_resolution(h=h)


def _validate_mp4_integrity(chunk, clean_url, headers, req_to):
    """Verifica la integridad estructural básica de un contenedor MP4/MOV.
    Detecta átomos 'moov' duplicados/corruptos (que desplazan los offsets stco y provocan
    errores de bitstream en MediaCodec y 47 canales / cuelgue de XAudio en FFmpeg)
    y páginas HTML inyectadas tras la cabecera inicial."""
    try:
        if not chunk or len(chunk) < 12 or chunk[4:8] != b'ftyp':
            return True
        import struct
        import requests
        VALID_BOXES = {
            b'ftyp', b'free', b'skip', b'wide', b'moov', b'mdat',
            b'moof', b'meta', b'udta', b'uuid', b'sidx', b'styp', b'emsg', b'prft', b'pdin'
        }
        pos = 0
        seen_moov = False
        seen_mdat = False
        moov_end = None
        while pos + 8 <= len(chunk):
            sz, typ = struct.unpack('>I4s', chunk[pos:pos + 8])
            hdr_len = 8
            if sz == 1 and pos + 16 <= len(chunk):
                sz = struct.unpack('>Q', chunk[pos + 8:pos + 16])[0]
                hdr_len = 16
            if typ not in VALID_BOXES:
                xbmc.log("Multi Bridge: MP4 inválido (box desconocido %r en offset %d): %s" % (typ, pos, clean_url), xbmc.LOGINFO)
                return False
            if sz != 0 and sz < hdr_len:
                return False
            if typ == b'moov':
                if seen_moov:
                    xbmc.log("Multi Bridge: MP4 corrupto (átomo MOOV duplicado en chunk inicial): %s" % clean_url, xbmc.LOGWARNING)
                    return False
                seen_moov = True
                if pos + hdr_len + 8 <= len(chunk):
                    c_sz, c_typ = struct.unpack('>I4s', chunk[pos + hdr_len:pos + hdr_len + 8])
                    if c_sz < 8 or (sz > 0 and c_sz > sz) or not all(32 <= b < 127 for b in c_typ):
                        xbmc.log("Multi Bridge: MP4 corrupto (sub-átomo MOOV inválido %r): %s" % (c_typ, clean_url), xbmc.LOGWARNING)
                        return False
                if sz > 0:
                    moov_end = pos + sz
            elif typ == b'mdat':
                seen_mdat = True
                data_start = pos + hdr_len
                if data_start + 16 <= len(chunk):
                    pay = chunk[data_start:data_start + 64]
                    pay_low = pay.lower()
                    if b'<!doctype' in pay_low or b'<html' in pay_low or pay[4:8] == b'moov':
                        xbmc.log("Multi Bridge: MP4 corrupto (payload mdat inválido): %s" % clean_url, xbmc.LOGWARNING)
                        return False
                break
            if sz == 0:
                break
            pos += sz

        # Faststart MP4: moov supera los primeros 64KB -> comprobar qué átomo sigue a moov
        if seen_moov and not seen_mdat and moov_end and moov_end >= len(chunk) and moov_end < 80 * 1024 * 1024:
            probe_pos = moov_end
            for _hop in range(4):
                r_probe = None
                pb = b''
                try:
                    hp = dict(headers)
                    hp['Range'] = f'bytes={probe_pos}-{probe_pos + 63}'
                    p_to = (min(2.0, req_to[0] if isinstance(req_to, tuple) else float(req_to)),
                            min(2.0, req_to[1] if isinstance(req_to, tuple) else float(req_to)))
                    r_probe = requests.get(clean_url, headers=hp, stream=True, timeout=p_to, allow_redirects=True, verify=False)
                    if r_probe.status_code != 206:
                        break
                    pb = r_probe.raw.read(64) if hasattr(r_probe, 'raw') else (r_probe.content[:64] if r_probe.content else b'')
                except Exception:
                    break
                finally:
                    if r_probe is not None:
                        try: r_probe.close()
                        except Exception: pass
                if not pb or len(pb) < 8:
                    break
                pb_low = pb[:48].lower()
                if b'<!doctype' in pb_low or b'<html' in pb_low:
                    xbmc.log("Multi Bridge: MP4 corrupto (HTML tras moov): %s" % clean_url, xbmc.LOGWARNING)
                    return False
                psz, ptyp = struct.unpack('>I4s', pb[:8])
                phdr = 8
                if psz == 1 and len(pb) >= 16:
                    psz = struct.unpack('>Q', pb[8:16])[0]
                    phdr = 16
                if ptyp == b'moov':
                    xbmc.log("Multi Bridge: MP4 corrupto (átomo MOOV duplicado en offset %d): %s" % (probe_pos, clean_url), xbmc.LOGWARNING)
                    return False
                if ptyp not in VALID_BOXES or (psz != 0 and psz < phdr):
                    xbmc.log("Multi Bridge: MP4 corrupto (átomo %r inválido tras moov en offset %d): %s" % (ptyp, probe_pos, clean_url), xbmc.LOGWARNING)
                    return False
                if ptyp == b'mdat':
                    if len(pb) >= phdr + 12:
                        mpay = pb[phdr:phdr + 48]
                        if b'<!doctype' in mpay.lower() or b'<html' in mpay.lower() or mpay[4:8] == b'moov':
                            xbmc.log("Multi Bridge: MP4 corrupto (mdat contiene HTML/moov en offset %d): %s" % (probe_pos, clean_url), xbmc.LOGWARNING)
                            return False
                    break
                if ptyp in (b'free', b'skip', b'wide', b'meta', b'udta', b'uuid') and 8 <= psz <= 2 * 1024 * 1024:
                    probe_pos += psz
                else:
                    break
        return True
    except Exception:
        return True


def _check_stream_url_playable(stream_url, server_name='', timeout=3.0):
    """Verifica si la URL directa responde y entrega multimedia (evitando servidores caídos como 522/404),
    y detecta la resolución REAL de vídeo (1080p, 720p, 480p, 360p, 240p) leyendo los metadatos HLS o contenedores MP4/MKV.
    Retorna (is_playable: bool, detected_res: str|None)."""
    if not stream_url or xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
        return False, None
    if stream_url.startswith(('magnet:', 'plugin:', 'file:')) or stream_url.endswith('.torrent'):
        return True, None
    clean_url = stream_url.split('|')[0].strip()
    if not clean_url.startswith(('http://', 'https://')):
        return True, None

    cu = clean_url.lower()

    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
    req_to = (min(2.5, float(timeout or 2.5)), min(2.5, float(timeout or 2.5)))
    srv_low = str(server_name or '').lower()
    if 'okcdn.ru' in cu or srv_low in ('okru', 'ok.ru'):
        headers['Referer'] = 'https://ok.ru/'
        req_to = (min(3.5, float(timeout or 3.5)), min(3.5, float(timeout or 3.5)))
    elif 'dood' in srv_low or 'cloudatacdn' in cu or 'ds2play' in srv_low or 'playmogo' in cu:
        headers['Referer'] = 'https://playmogo.com/'
    elif 'streamtape' in srv_low or 'tapecontent' in cu:
        headers['Referer'] = 'https://streamtape.com/'
    elif 'voe' in srv_low:
        headers['Referer'] = 'https://voe.sx/'
    elif 'mixdrop' in srv_low:
        headers['Referer'] = 'https://mixdrop.co/'
    elif 'uqload' in srv_low:
        headers['Referer'] = 'https://uqload.io/'
    elif 'vidmoly' in srv_low:
        headers['Referer'] = 'https://vidmoly.to/'
    elif 'filelions' in srv_low:
        headers['Referer'] = 'https://filelions.to/'
    elif 'goodstream' in srv_low:
        headers['Referer'] = 'https://goodstream.uno/'
    if '|' in stream_url:
        pipe_parts = stream_url.split('|', 1)[1]
        for h in pipe_parts.split('&'):
            if '=' in h:
                hk, hv = h.split('=', 1)
                clean_hk = uparse.unquote_plus(hk.strip()).strip()
                clean_hv = uparse.unquote_plus(hv.strip()).split('|')[0].strip()
                if clean_hk and clean_hv and clean_hk.lower() != 'verifypeer':
                    headers[clean_hk] = clean_hv

    try:
        import requests
        is_hls = ('.m3u8' in cu) or ('/hls/' in cu) or ('/hls2/' in cu) or ('/hls3/' in cu)
        if is_hls:
            if xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                return False, None
            r = None
            manifest_text = ''
            try:
                r = requests.get(clean_url, headers=headers, timeout=req_to, verify=False)
                if r.status_code >= 400:
                    xbmc.log("Multi Bridge: URL HLS descartada por HTTP %d: %s" % (r.status_code, clean_url), xbmc.LOGINFO)
                    return False, None
                manifest_text = r.text or ''
            except Exception as e_m3u8:
                xbmc.log("Multi Bridge: URL HLS inalcanzable (%s): %s" % (clean_url, e_m3u8), xbmc.LOGINFO)
                return False, None
            finally:
                if r is not None:
                    try: r.close()
                    except Exception: pass

            if '#EXTM3U' not in manifest_text and '#EXT-X' not in manifest_text:
                xbmc.log("Multi Bridge: URL HLS descartada por contenido inválido: %s" % clean_url, xbmc.LOGINFO)
                return False, None

            # Detectar resolución técnica desde etiquetas HLS (#EXT-X-STREAM-INF: ... RESOLUTION=WxH)
            detected_res = None
            res_matches = re.findall(r'RESOLUTION=(\d+)x(\d+)', manifest_text, re.IGNORECASE)
            if res_matches:
                max_w = max(int(m[0]) for m in res_matches)
                max_h = max(int(m[1]) for m in res_matches)
                detected_res = _classify_resolution(max_w, max_h)

            # Buscar sub-manifiesto o segmento
            sub_url = None
            for line in manifest_text.splitlines():
                line = line.strip()
                if line and not line.startswith('#'):
                    sub_url = uparse.urljoin(clean_url, line)
                    break

            if sub_url:
                # Si sub_url es otro playlist m3u8 (variante), obtener el primer segmento real
                if xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                    return False, None
                if '.m3u8' in sub_url.lower() or not any(ext in sub_url.lower() for ext in ('.ts', '.m4s', '.mp4')):
                    r_var = None
                    try:
                        r_var = requests.get(sub_url, headers=headers, timeout=req_to, verify=False)
                        if r_var.status_code >= 400:
                            xbmc.log("Multi Bridge: sub-playlist HLS falló con HTTP %d: %s" % (r_var.status_code, sub_url), xbmc.LOGINFO)
                            return False, None
                        var_text = r_var.text or ''
                        if not detected_res:
                            var_res = re.findall(r'RESOLUTION=(\d+)x(\d+)', var_text, re.IGNORECASE)
                            if var_res:
                                detected_res = _classify_resolution(max(int(m[0]) for m in var_res), max(int(m[1]) for m in var_res))
                        for line2 in var_text.splitlines():
                            line2 = line2.strip()
                            if line2 and not line2.startswith('#'):
                                sub_url = uparse.urljoin(sub_url, line2)
                                break
                    except Exception as e_sub:
                        xbmc.log("Multi Bridge: error al leer sub-playlist HLS (%s): %s" % (sub_url, e_sub), xbmc.LOGINFO)
                        return False, None
                    finally:
                        if r_var is not None:
                            try: r_var.close()
                            except Exception: pass

                # Probar el segmento con HEAD o GET Range
                if xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                    return False, None
                r_seg = None
                try:
                    h2 = dict(headers)
                    h2['Range'] = 'bytes=0-65535'
                    r_seg = requests.get(sub_url, headers=h2, timeout=req_to, verify=False, stream=True)
                    if r_seg.status_code in (401, 403, 404, 410, 500, 502, 503, 504, 520, 521, 522, 523, 524, 525, 526) or r_seg.status_code >= 400:
                        xbmc.log("Multi Bridge: segmento HLS descartado por HTTP %d: %s" % (r_seg.status_code, sub_url), xbmc.LOGINFO)
                        return False, None
                    seg_chunk = r_seg.raw.read(65536) if hasattr(r_seg, 'raw') else (r_seg.content[:65536] if r_seg.content else b'')
                    if seg_chunk:
                        seg_low = seg_chunk[:200].lower()
                        if b'<!doctype' in seg_low or b'<html' in seg_low:
                            xbmc.log("Multi Bridge: segmento HLS devolvió HTML inválido: %s" % sub_url, xbmc.LOGINFO)
                            return False, None
                    if not detected_res and seg_chunk:
                        w_s, h_s = _parse_ts_sps(seg_chunk)
                        if not h_s:
                            w_s, h_s = _parse_mp4_resolution(seg_chunk)
                        if h_s or w_s:
                            detected_res = _classify_resolution(w_s, h_s)
                except Exception as e_seg:
                    _err_s = str(e_seg).lower()
                    if any(_b in _err_s for _b in ('401', '403', 'forbidden', 'unauthorized', 'ssl', 'certificate', 'connection reset', 'connection refused')):
                        xbmc.log("Multi Bridge: segmento HLS bloqueado/caído (%s: %s) -> descartando enlace" % (sub_url, e_seg), xbmc.LOGINFO)
                        return False, None
                    # Si dio lentitud genérica pero el manifiesto respondió 200 OK, permitir que Kodi pruebe con su búfer
                    xbmc.log("Multi Bridge: segmento HLS lento o advertencia (%s: %s), pero playlist m3u8 es válida -> conservando enlace" % (sub_url, e_seg), xbmc.LOGINFO)
                finally:
                    if r_seg is not None:
                        try: r_seg.close()
                        except Exception: pass

            # Si no se detecto resolucion por etiqueta RESOLUTION, buscar patrones en la URL
            if not detected_res:
                detected_res = _detect_resolution_from_text(clean_url)
            if not detected_res:
                if any(k in cu for k in ('1080p', '1080', 'fullhd', 'fhd')) or 'type=5' in cu or 'type=6' in cu:
                    detected_res = '1080p'
                elif any(k in cu for k in ('720p', '720', '/hd/')) or 'type=4' in cu:
                    detected_res = '720p'
                elif re.search(r'(?:[._\-/]480p?|dvd|dvdrip|sd)', cu) or 'type=3' in cu:
                    detected_res = '480p'
                elif any(k in cu for k in ('360p', '360')) or 'type=2' in cu:
                    detected_res = '360p'
                elif any(k in cu for k in ('240p', '240')) or 'type=1' in cu:
                    detected_res = '240p'

            return True, detected_res

        # Caso 2: Streams HTTP directos (mp4, mkv, etc.)
        if xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
            return False, None
        detected_res = None
        h_range = dict(headers)
        h_range['Range'] = 'bytes=0-65535'
        r = None
        ct = ''
        chunk = b''
        try:
            r = requests.get(clean_url, headers=h_range, stream=True, timeout=req_to, allow_redirects=True, verify=False)
            if r.status_code in (401, 403, 404, 410) or r.status_code >= 500:
                xbmc.log("Multi Bridge: URL descartada por código HTTP %d: %s" % (r.status_code, clean_url), xbmc.LOGINFO)
                return False, None
            ct = (r.headers.get('Content-Type') or '').lower()
            cr = (r.headers.get('Content-Range') or '').strip()
            if '/' in cr:
                try:
                    tot_sz = int(cr.rsplit('/', 1)[1].strip())
                    if 0 < tot_sz < 150000:
                        xbmc.log("Multi Bridge: URL descartada por tamaño de vídeo inválido (%d bytes): %s" % (tot_sz, clean_url), xbmc.LOGINFO)
                        return False, None
                except Exception:
                    pass
            try:
                chunk = r.raw.read(65536) if hasattr(r, 'raw') else (r.content[:65536] if r.content else b'')
            except Exception:
                pass
        finally:
            if r is not None:
                try: r.close()
                except Exception: pass

        # Descartar si el servidor no entregó datos reales (evita que proxies colgados como megaserver congelen Kodi)
        if not chunk or len(chunk) < 64:
            xbmc.log("Multi Bridge: URL descartada por no entregar bytes de vídeo (%s bytes): %s" % (len(chunk) if chunk else 0, clean_url), xbmc.LOGINFO)
            return False, None

        chunk_low = chunk[:200].lower()
        if b'<!doctype' in chunk_low or b'<html' in chunk_low or b'<head' in chunk_low:
            xbmc.log("Multi Bridge: URL descartada por devolver HTML en vez de stream: %s" % clean_url, xbmc.LOGINFO)
            return False, None

        if not _validate_mp4_integrity(chunk, clean_url, headers, req_to):
            return False, None

        if chunk:
            w, h = _parse_mp4_resolution(chunk)
            if not h:
                w, h = _parse_mkv_resolution(chunk)
            if h:
                detected_res = _classify_resolution(w, h)

        if not detected_res:
            if any(k in cu for k in ('1080p', '1080', 'fullhd', 'fhd')) or 'type=5' in cu or 'type=6' in cu:
                detected_res = '1080p'
            elif any(k in cu for k in ('720p', '720', '/hd/')) or 'type=4' in cu:
                detected_res = '720p'
            elif re.search(r'(?:[._\-/]480p?|dvd|dvdrip|\bsd\b)', cu) or 'type=3' in cu:
                detected_res = '480p'
            elif any(k in cu for k in ('360p', '360')) or 'type=2' in cu:
                detected_res = '360p'
            elif any(k in cu for k in ('240p', '240')) or 'type=1' in cu:
                detected_res = '240p'

        return True, detected_res
    except Exception as e:
        xbmc.log("Multi Bridge: comprobación de streaming (%s) falló por excepción: %s" % (clean_url, e), xbmc.LOGINFO)
        return False, None


def _is_stream_url_playable(stream_url, server_name='', timeout=3.0):
    """Wrapper retrocompatible: retorna True si la URL es reproducible."""
    is_ok, _ = _check_stream_url_playable(stream_url, server_name=server_name, timeout=timeout)
    return is_ok


def _format_language_display(lang_str, colored=True):
    l = (str(lang_str or '')).upper().strip()
    l = l.replace('[', '').replace(']', '').replace('(', '').replace(')', '').strip()
    if any(k in l for k in ('LAT', 'LATINO')):
        lbl = 'Latino'
        color = 'deepskyblue'
    elif any(k in l for k in ('ESP', 'CAST', 'CASTELLANO', 'ESPAÑOL', 'SPANISH')):
        lbl = 'Castellano'
        color = 'gold'
    elif any(k in l for k in ('VOSE', 'SUB', 'SUBTITULADO')):
        lbl = 'VOSE'
        color = 'mediumpurple'
    elif any(k in l for k in ('ENG', 'INGLES', 'INGLÉS', 'VO')):
        lbl = 'Inglés'
        color = 'orange'
    else:
        lbl = str(lang_str or '').replace('[', '').replace(']', '').strip() or 'Desconocido'
        color = 'lightgray'
    if colored:
        return '[COLOR %s]%s[/COLOR]' % (color, lbl)
    return lbl


def _is_preferred_lang_candidate(cand, b_prefs, all_done=False):
    """Determina si un candidato de enlace debe probarse de inmediato o esperar
    a que los canales con idiomas de mayor preferencia terminen de buscar."""
    if not cand:
        return False
    l_str = (_safe_str(getattr(cand, 'language', '')) + ' ' + _get_link_language_group(cand)).upper()
    if 'LAT' in l_str: grp = 'Lat'
    elif 'ESP' in l_str or 'CAST' in l_str: grp = 'Esp'
    elif 'VOS' in l_str or 'VO' in l_str or 'SUB' in l_str or 'ENG' in l_str: grp = 'VO'
    else: grp = '?'

    p_lat = b_prefs.get('preferencia_idioma_lat', 1)
    p_esp = b_prefs.get('preferencia_idioma_esp', 2)
    p_vos = b_prefs.get('preferencia_idioma_vos', 3)
    p_map = {'Lat': p_lat, 'Esp': p_esp, 'VO': p_vos, '?': 4}
    p_val = p_map.get(grp, 4)

    if p_val == 0:
        return False

    if all_done:
        return True

    active_prios = [v for k, v in [('Lat', p_lat), ('Esp', p_esp), ('VO', p_vos)] if v > 0]
    best_prio = min(active_prios) if active_prios else 1

    # Solo reproducir de inmediato si el candidato pertenece al idioma de mayor preferencia (ej. Latino si es 1).
    # Si tiene menor prioridad (ej. Castellano con prio 2), esperar a que los demas canales terminen de buscar.
    return p_val <= best_prio


def _is_web_captcha_server(server_name, item=None):
    s = str(server_name or '').strip().lower()
    if 'captcha' in s:
        return True
    captcha_domains = (
        'powvideo', 'povwideo', 'powwideo', 'povvideo',
        'streamplay', 'straemplay', 'streamp1ay', 'steamplay', 'stremplay'
    )
    if any(c in s for c in captcha_domains):
        return True
    if item:
        url = str(getattr(item, 'url', '') or '').lower()
        if any(d in url for d in captcha_domains) or 'captcha' in url:
            return True
        srv = str(getattr(item, 'server', '') or '').lower()
        if any(d in srv for d in captcha_domains) or 'captcha' in srv:
            return True
        other = str(getattr(item, 'other', '') or '').lower()
        if any(d in other for d in captcha_domains) or 'captcha' in other:
            return True
    return False


def _is_server_discarded(it, disc_list=None):
    if not it:
        return True

    # Ocultar enlaces con verificacion Captcha si el usuario activo la opcion
    try:
        if _bridge_addon.getSetting('hide_captcha_links') == 'true':
            srv = (_get_link_server_name(it) or getattr(it, 'server', '') or '').strip().lower()
            if _is_web_captcha_server(srv, it):
                return True
    except Exception:
        pass

    if disc_list is None:
        disc_list = _get_discarded_servers_list()
    if not disc_list:
        return False

    if _is_torrent_link(it):
        return 'torrent' in disc_list

    srv_canon = (_get_link_server_name(it) or '').strip().lower()
    if srv_canon and srv_canon in disc_list:
        return True

    srv_raw = _safe_str(getattr(it, 'server', '') or '').strip().lower()
    if srv_raw and srv_raw in disc_list:
        return True

    other_raw = _safe_str(getattr(it, 'other', '') or '').strip().lower()
    if other_raw:
        for d in disc_list:
            if d and d in other_raw:
                return True

    url_raw = _safe_str(getattr(it, 'url', '') or '').strip().lower()
    if url_raw:
        for d in disc_list:
            if d and d in url_raw:
                return True

    if not srv_canon and not srv_raw:
        if 'indeterminado' in disc_list or 'directo' in disc_list:
            return True

    return False


def _filter_discarded_links(links, disc_list=None):
    if not links:
        return []
    if disc_list is None:
        disc_list = _get_discarded_servers_list()
    if not disc_list:
        return list(links)
    valid_links = []
    for l in links:
        if _is_server_discarded(l, disc_list):
            s_name = _get_link_server_name(l) or getattr(l, 'server', '') or 'descartado'
            xbmc.log("Multi Bridge: enlace [%s] descartado inmediatamente (servidor en lista negra)" % s_name, xbmc.LOGDEBUG)
            continue
        valid_links.append(l)
    return valid_links


def _get_filter_prefs():
    def _bi(key, def_val):
        try:
            val = _bridge_addon.getSetting(key)
            if val is None or val == '': return def_val
            return int(float(val))
        except:
            return def_val

    def _bcsv(key, def_val):
        try:
            val = _bridge_addon.getSetting(key)
            if not val: return def_val
            return [s.strip().lower() for s in str(val).split(',') if s.strip()]
        except:
            return def_val

    lang_on = _bridge_addon.getSetting('filter_lang_enabled') != 'false'
    qual_on = _bridge_addon.getSetting('filter_quality_enabled') != 'false'
    srv_on  = _bridge_addon.getSetting('filter_servers_enabled') != 'false'
    force_torrents_bottom = _bridge_addon.getSetting('force_torrents_bottom') != 'false'

    # Jerarquía configurable de prioridades (1ª, 2ª, 3ª)
    # 0 = Idioma, 1 = Calidad, 2 = Servidor
    p1 = _bi('sort_prio_1', 0)
    p2 = _bi('sort_prio_2', 1)
    p3 = _bi('sort_prio_3', 2)
    KEY_MAP = {0: 'lang', 1: 'quality', 2: 'server'}
    raw_order = [KEY_MAP.get(p1, 'lang'), KEY_MAP.get(p2, 'quality'), KEY_MAP.get(p3, 'server')]
    resolved_order = []
    for k in raw_order:
        if k not in resolved_order:
            resolved_order.append(k)
    for fallback in ('lang', 'quality', 'server'):
        if fallback not in resolved_order:
            resolved_order.append(fallback)

    return {
        'preferencia_idioma_lat': _bi('preferencia_idioma_lat', 1) if lang_on else 1,
        'preferencia_idioma_esp': _bi('preferencia_idioma_esp', 2) if lang_on else 1,
        'preferencia_idioma_vos': _bi('preferencia_idioma_vos', 3) if lang_on else 1,
        'servers_sort_quality': _bi('servers_sort_quality', 0) if qual_on else 0,
        'servers_preferred': _bcsv('servers_preferred', ['mega', 'okru', 'doodstream', 'vidmoly', 'streamwish']) if srv_on else [],
        'servers_unfavored': _bcsv('servers_unfavored', ['uqload', 'torrent']) if srv_on else [],
        'servers_discarded': _bcsv('servers_discarded', ['rapidgator', 'directo', 'waaw']) if srv_on else [],
        'sort_hierarchy': tuple(resolved_order),
        'force_torrents_bottom': force_torrents_bottom,
    }

_get_balandro_preferences = _get_filter_prefs

def _get_hierarchical_sort_key(it, b_prefs=None, sort_q=0):
    if b_prefs is None:
        b_prefs = _get_filter_prefs()
    if sort_q == 0 and b_prefs:
        sort_q = b_prefs.get('servers_sort_quality', 0)

    is_tor = _is_torrent_link(it)
    is_cap = (not is_tor) and _is_web_captcha_server(_get_link_server_name(it), it)
    srv = 'torrent' if is_tor else (_get_link_server_name(it) or getattr(it, 'server', '') or '').lower()
    if not srv: srv = 'indeterminado'

    # 1. IDIOMA
    p_lat = b_prefs.get('preferencia_idioma_lat', 1)
    p_esp = b_prefs.get('preferencia_idioma_esp', 2)
    p_vos = b_prefs.get('preferencia_idioma_vos', 3)
    prefs_lang = {'Lat': p_lat, 'Esp': p_esp, 'VO': p_vos, '?': 4}

    l_str = (_safe_str(getattr(it, 'language', '')) + ' ' + _get_link_language_group(it)).upper()
    if 'LAT' in l_str: grp = 'Lat'
    elif 'ESP' in l_str or 'CAST' in l_str: grp = 'Esp'
    elif 'VOS' in l_str or 'VO' in l_str or 'SUB' in l_str or 'ENG' in l_str: grp = 'VO'
    else: grp = '?'
    l_key = prefs_lang.get(grp, 4)

    # 2. SERVIDOR & TIPO DE ENLACE:
    unfav_list = [u.lower() for u in b_prefs.get('servers_unfavored', [])]
    is_unfav = 1 if (srv in unfav_list or (is_tor and 'torrent' in unfav_list)) else 0

    pref_list = [p.lower() for p in b_prefs.get('servers_preferred', [])]
    if srv in pref_list:
        srv_key = pref_list.index(srv)
    elif is_unfav:
        srv_key = 100 + (unfav_list.index(srv) if srv in unfav_list else 50)
    else:
        srv_key = 50

    # 3. CALIDAD:
    q_score = _get_link_quality_score(it, pref_quality=sort_q)
    q_key = -q_score

    # Mapeo de criterios según la jerarquía elegida:
    criteria_map = {
        'lang': (l_key,),
        'quality': (q_key,),
        'server': (is_unfav, srv_key),
    }

    hierarchy = b_prefs.get('sort_hierarchy', ('lang', 'quality', 'server'))
    key = []

    # Categoría fija: Directos/HTTP (0) -> Captchas en su propia categoría (1) -> Torrents (2 si force_torrents_bottom)
    if is_cap:
        cat_rank = 1
    elif is_tor and b_prefs.get('force_torrents_bottom', True):
        cat_rank = 2
    else:
        cat_rank = 0
    key.append(cat_rank)

    for crit in hierarchy:
        key.extend(criteria_map.get(crit, ()))

    # Desempate final: confianza del match de título/año (bridge_score)
    try:
        b_score = -int(getattr(it, 'bridge_score', 0) or 0)
    except Exception:
        b_score = 0
    key.append(b_score)

    return tuple(key)


def _filter_and_sort_links(links):
    if not links: return []

    safe_links = []
    for l in links:
        try:
            _u = _safe_str(getattr(l, 'url', ''))
            if _u and len(_u) > 1500:
                continue
            safe_links.append(l)
        except:
            safe_links.append(l)

    b_prefs = _get_filter_prefs()

    # PASO 0: desempate por confianza del match (los anclados por TMDb/IMDb o
    # año primero dentro de igual calidad/servidor/idioma). Al ser el primer
    # sorted estable, solo ordena entre empatados: no quita ni agrega nada.
    try:
        safe_links = sorted(safe_links, key=lambda it: -int(getattr(it, 'bridge_score', 0) or 0))
    except: pass

    # PASO 1: filter_and_sort_by_quality
    # 0: 1080p, 1: 720p, 2: 480p (para enlaces directos; torrents conservan su prioridad máxima)
    sort_q = b_prefs.get('servers_sort_quality', 0)
    safe_links = sorted(safe_links, key=lambda it: _get_link_quality_score(it, pref_quality=sort_q), reverse=True)

    # PASO 2 de Balandro: filter_and_sort_by_server
    # 2a. Descartar servidores descartados por el usuario
    disc_list = b_prefs.get('servers_discarded', [])
    safe_links = _filter_discarded_links(safe_links, disc_list=disc_list)

        # PASO 3 de Balandro: filter_and_sort_by_language
    # 3a. Quitar idiomas con valor 0 (Descartar)
    p_lat = b_prefs.get('preferencia_idioma_lat', 1)
    p_esp = b_prefs.get('preferencia_idioma_esp', 2)
    p_vos = b_prefs.get('preferencia_idioma_vos', 3)
    prefs_lang = {'Lat': p_lat, 'Esp': p_esp, 'VO': p_vos, '?': 4}

    def _get_lang_grp(it):
        l_str = (_safe_str(getattr(it, 'language', '')) + ' ' + _get_link_language_group(it)).upper()
        if 'LAT' in l_str: return 'Lat'
        if 'ESP' in l_str or 'CAST' in l_str: return 'Esp'
        if 'VOS' in l_str or 'VO' in l_str or 'SUB' in l_str or 'ENG' in l_str: return 'VO'
        return '?'

    # Descartar idiomas con valor 0 (Descartar)
    safe_links = [it for it in safe_links if _is_torrent_link(it) or prefs_lang.get(_get_lang_grp(it), 4) != 0]

    # 3b. Ordenar respetando jerarquia: Idioma -> HTTP normales primero -> Torrents debajo dentro de su idioma
    safe_links = sorted(safe_links, key=lambda it: _get_hierarchical_sort_key(it, b_prefs=b_prefs, sort_q=sort_q))

    # PASO 4: Priorizar enlaces confirmados sobre enlaces debiles
    # Evita que un enlace debil/no confirmado (posible homonimo de otro anio)
    # se cuele al inicio de la lista o sea reproducido por autoplay por mejor calidad/servidor.
    try:
        safe_links = sorted(safe_links, key=lambda it: 1 if getattr(it, 'bridge_weak', False) else 0)
    except: pass

    return safe_links

# ---------------------------------------------------------
# Headless Link Verification System
# ---------------------------------------------------------
def _extract_valid_streams(video_urls):
    if not video_urls: return None
    res = []
    if isinstance(video_urls, list):
        for entry in video_urls:
            if isinstance(entry, list) and len(entry) >= 2:
                stream_url = _safe_str(entry[1])
                if stream_url.startswith('http') or stream_url.startswith('rtmp'):
                    res.append(entry)
            elif isinstance(entry, str) and (entry.startswith('http') or entry.startswith('rtmp')):
                res.append(['', entry])
    if not res:
        return None
    try:
        res.sort(key=_stream_quality_score, reverse=True)
    except Exception:
        pass
    return res

def _link_cache_key(lnk):
    """Huella estable de un enlace para reutilizar su resolucion.
    Dos enlaces con la misma huella son intercambiables (mismos atributos),
    asi que resolver uno solo da el mismo resultado final que resolver ambos.
    Se excluye 'video_urls' (es el producto de la resolucion, no la entrada)."""
    try:
        d = dict(getattr(lnk, '__dict__', {}) or {})
        d.pop('video_urls', None)
        return json.dumps(d, sort_keys=True, default=str, ensure_ascii=False)
    except Exception:
        return '%s|%s|%s|%s' % (getattr(lnk, 'server', ''), getattr(lnk, 'url', ''),
                                getattr(lnk, 'title', ''), getattr(lnk, 'language', ''))

_PIPELINE_VERIFIED_SEARCH = False

def _check_web_captcha_link_alive(url, timeout=5.0):
    """Comprobacion rapida HTTP para servidores protegidos con captcha (ej. Powvideo, Streamplay).
    Determina si el enlace esta vivo sin lanzar navegador ni abrir ventanas modales.
    Retorna True si el enlace responde 200 OK (o Cloudflare 403/503), False si devuelve 404/Not Found o archivo borrado."""
    if not url: return False
    try:
        import urllib.request as _urq
        import urllib.error as _ure
        check_url = str(url).strip()
        m = re.search(r'(?:embed-|player-)?([a-zA-Z0-9]+)(?:-[0-9x]+)?\.html', check_url)
        if m and m.group(1) and ('embed-' in check_url or 'player-' in check_url):
            base = check_url.split('/player-')[0].split('/embed-')[0].rstrip('/')
            if '/' in base[8:]:
                base = base[:base.find('/', 8)]
            check_url = '%s/%s' % (base, m.group(1))

        req = _urq.Request(
            check_url,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            }
        )
        with _urq.urlopen(req, timeout=timeout) as resp:
            body = resp.read(2048).decode('utf-8', errors='ignore')
            body_low = body.lower()
            if 'file was deleted' in body_low or 'no such file' in body_low:
                return False
            if 200 <= resp.status < 400:
                return True
    except _ure.HTTPError as e:
        if e.code == 404:
            return False
        if e.code in (403, 503):
            return True
        return False
    except Exception:
        return False
    return False

def _resolve_single_link_for_verification(lnk, engine='alfa', servertools=None):
    if not lnk: return None
    if _is_torrent_link(lnk): return lnk
    if servertools is None:
        mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
        if not mods: return None
        servertools = mods.get('servertools')
        if not servertools: return None

    test_item = lnk.clone() if hasattr(lnk, 'clone') else lnk
    video_urls = None
    puedes = False
    try:
        prep = _prepare_playable_link(test_item, engine=engine)
        if not prep: return None
        if _is_torrent_link(prep):
            return prep

        actual_srv = (getattr(prep, 'server', '') or _get_link_server_name(prep)).lower().strip()
        raw_srv = (getattr(prep, 'server', '') or '').lower().strip()
        url = getattr(prep, 'url', '')
        pwd = getattr(prep, 'password', '')

        if not url and not getattr(prep, 'video_urls', None):
            return None

        # Servidores protegidos con captcha (ej. Powvideo, Streamplay):
        # Jamás se verifican por red; se devuelven directamente si no están ocultos.
        if _is_web_captcha_server(actual_srv, prep):
            if _bridge_addon.getSetting('hide_captcha_links') == 'true':
                return None
            return prep

        servers_to_try = []
        if actual_srv and actual_srv not in ('directo', 'none', ''): servers_to_try.append(actual_srv)
        if raw_srv and raw_srv not in servers_to_try and raw_srv not in ('directo', 'none', ''): servers_to_try.append(raw_srv)
        if 'various' not in servers_to_try: servers_to_try.append('various')

        if getattr(prep, 'video_urls', None):
            video_urls = prep.video_urls
            puedes = True
        else:
            with silenced_dialogs():
                for srv_try in servers_to_try:
                    if engine == 'balandro':
                        try:
                            video_urls, puedes, _ = servertools.resolve_video_urls_for_playing(srv_try, url)
                            if puedes and video_urls: break
                        except Exception: pass
                    else:
                        try:
                            video_urls, puedes, _ = servertools.resolve_video_urls_for_playing(srv_try, url, pwd, False)
                            if puedes and video_urls: break
                        except Exception: pass

        if puedes and video_urls:
            valid_streams = _extract_valid_streams(video_urls)
            if valid_streams:
                for stream_entry in valid_streams:
                    st_url = stream_entry[1] if isinstance(stream_entry, (list, tuple)) and len(stream_entry) > 1 else (stream_entry if isinstance(stream_entry, str) else '')
                    if not st_url:
                        continue
                    check_to = 5.0 if (actual_srv in ('okru', 'ok.ru') or 'okcdn.ru' in st_url) else 3.0
                    is_ok, real_res = _check_stream_url_playable(st_url, server_name=actual_srv, timeout=check_to)
                    if is_ok:
                        prep.video_urls = valid_streams
                        st_lbl = stream_entry[0] if isinstance(stream_entry, (list, tuple)) and len(stream_entry) > 0 else ''
                        label_res = _detect_resolution_from_text(st_lbl) or _detect_resolution_from_text(st_url)
                        if _is_cam_quality(lnk):
                            final_res = 'CAM'
                        else:
                            final_res = real_res
                            if label_res and (not final_res or _stream_quality_score(label_res) > _stream_quality_score(final_res)):
                                final_res = label_res
                            elif real_res and label_res and _stream_quality_score(real_res) >= _stream_quality_score(label_res):
                                final_res = real_res

                        if final_res:
                            prep.real_quality = final_res
                            prep.quality = final_res
                            try: lnk.real_quality = final_res; lnk.quality = final_res
                            except: pass
                        try:
                            prep._bridge_verified = True
                            lnk._bridge_verified = True
                        except Exception:
                            pass
                        return prep
        return None
    except Exception:
        return None

class _PipelineLinkVerifier:
    def __init__(self, engine='alfa'):
        self.engine = engine
        mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
        self.servertools = mods.get('servertools') if mods else None
        
        self.max_workers = min(20, max(2, _get_int_setting('verify_threads_max', 16)))
        self.verify_timeout = _get_int_setting('verify_timeout', 10)
        if self.verify_timeout < 3: self.verify_timeout = 3
        self.verify_max_functional = _get_int_setting('verify_max_functional', 12)
        if self.verify_max_functional < 0: self.verify_max_functional = 0

        self.b_prefs = _get_filter_prefs()
        self.sort_q = self.b_prefs.get('servers_sort_quality', 0)
        self.p_lat = self.b_prefs.get('preferencia_idioma_lat', 1)
        self.p_esp = self.b_prefs.get('preferencia_idioma_esp', 2)
        self.p_vos = self.b_prefs.get('preferencia_idioma_vos', 3)
        self.prefs_lang = {'Lat': self.p_lat, 'Esp': self.p_esp, 'VO': self.p_vos, '?': 4}

        self.lock = threading.Lock()
        self.global_stop = threading.Event()
        self.direct_done = threading.Event()
        self.queue = queue.PriorityQueue()
        
        self.seen_keys = set()
        self.prep_cache = {}
        self._CACHE_MISS = object()
        
        self.seq_counter = 0
        self.verified_torrents = []
        self.verified_captchas = []
        self.verified_direct = []
        self.active_workers = 0
        self.threads = []

    def start(self):
        if not self.servertools:
            return
        try:
            xbmc.log("Multi Bridge: Pipeline verifier iniciado con %d hilos de verificación" % self.max_workers, xbmc.LOGINFO)
        except Exception: pass
        for i in range(self.max_workers):
            t = threading.Thread(target=self._worker_loop, daemon=True, name="PipelineVerifier-%d" % i)
            self.threads.append(t)
            t.start()

    def _get_lang_grp(self, lnk):
        l_str = (_safe_str(getattr(lnk, 'language', '')) + ' ' + _get_link_language_group(lnk)).upper()
        if 'LAT' in l_str: return 'Lat'
        if 'ESP' in l_str or 'CAST' in l_str: return 'Esp'
        if 'VOS' in l_str or 'VO' in l_str or 'SUB' in l_str or 'ENG' in l_str: return 'VO'
        return '?'

    def feed(self, links):
        """Alimenta enlaces de un canal recién terminado respetando prioridad de idioma."""
        if not links or self.global_stop.is_set():
            return
        flt = _filter_discarded_links(links)
        for lnk in flt:
            if self.global_stop.is_set():
                break

            with self.lock:
                ckey = _link_cache_key(lnk)
                if ckey in self.seen_keys:
                    continue
                self.seen_keys.add(ckey)

                # Torrents y Captchas se envían directamente sin verificar como funcionales
                # y NUNCA cuentan para la meta de enlaces directos funcionales
                if _is_torrent_link(lnk):
                    self.verified_torrents.append(lnk)
                elif _is_web_captcha_server(_get_link_server_name(lnk), lnk):
                    if _bridge_addon.getSetting('hide_captcha_links') != 'true':
                        self.verified_captchas.append(lnk)
                else:
                    # Si ya alcanzamos la meta de directos funcionales, no sobrecargar cola
                    if self.verify_max_functional > 0 and len(self.verified_direct) >= self.verify_max_functional:
                        continue
                    # Descartar enlaces cuyo idioma esté configurado con valor 0 (Descartar)
                    grp = self._get_lang_grp(lnk)
                    if self.prefs_lang.get(grp, 4) == 0:
                        continue

                    self.seq_counter += 1
                    # Prioridad jerárquica: (idioma_key, is_unfav, srv_key, -q_score)
                    prio = _get_hierarchical_sort_key(lnk, b_prefs=self.b_prefs, sort_q=self.sort_q)
                    self.queue.put((prio, self.seq_counter, ckey, lnk))

    def _worker_loop(self):
        orig_to = socket.getdefaulttimeout()
        try:
            socket.setdefaulttimeout(self.verify_timeout)
        except: pass
        while not self.global_stop.is_set() and not xbmc.Monitor().abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
            with self.lock:
                if self.verify_max_functional > 0 and len(self.verified_direct) >= self.verify_max_functional:
                    break

            try:
                prio, seq, ckey, lnk = self.queue.get(timeout=0.15)
            except (queue.Empty, TypeError, ValueError):
                continue

            with self.lock:
                self.active_workers += 1

            try:
                if self.global_stop.is_set():
                    break
                with self.lock:
                    hit = self.prep_cache.get(ckey, self._CACHE_MISS)
                if hit is self._CACHE_MISS:
                    res = _resolve_single_link_for_verification(lnk, engine=self.engine, servertools=self.servertools)
                    with self.lock:
                        self.prep_cache[ckey] = res
                else:
                    res = hit

                if res is not None and not self.global_stop.is_set():
                    cp = res.clone() if hasattr(res, 'clone') else res
                    with self.lock:
                        if _is_torrent_link(cp):
                            self.verified_torrents.append(cp)
                        elif _is_web_captcha_server(_get_link_server_name(cp), cp):
                            # Salvaguarda: si resultó ser captcha, enviar directamente sin contar como funcional ni marcar verificado
                            if _bridge_addon.getSetting('hide_captcha_links') != 'true':
                                self.verified_captchas.append(cp)
                        else:
                            if self.verify_max_functional <= 0 or len(self.verified_direct) < self.verify_max_functional:
                                try: setattr(cp, '_bridge_verified', True)
                                except Exception: pass
                                self.verified_direct.append(cp)
                            if self.verify_max_functional > 0 and len(self.verified_direct) >= self.verify_max_functional:
                                self.direct_done.set()
                                self.global_stop.set()
            except Exception:
                pass
            finally:
                with self.lock:
                    self.active_workers -= 1
                self.queue.task_done()
        try:
            socket.setdefaulttimeout(orig_to)
        except: pass

    def get_stats(self):
        with self.lock:
            return len(self.verified_direct), len(self.verified_torrents), len(self.verified_captchas), self.active_workers, self.queue.qsize()

    def finish_post_search(self, target_title='', p_dialog=None):
        """Continúa verificando enlaces prioritarios tras la búsqueda de canales hasta alcanzar meta de directos o timeout."""
        with self.lock:
            n_dir = len(self.verified_direct)
            if self.verify_max_functional > 0 and n_dir >= self.verify_max_functional:
                self.global_stop.set()
                return
            if self.queue.empty() and self.active_workers == 0:
                self.global_stop.set()
                return

        max_wait = min(35, max(15, self.verify_timeout * 2))
        start_wait = time.time()
        _dialog_cooldown = 0.0

        while time.time() - start_wait < max_wait and not _BG_TASK_ABORT_EVENT.is_set():
            if xbmc.Monitor().abortRequested():
                break
            if p_dialog and p_dialog.iscanceled():
                xbmc.log("Multi Bridge: usuario canceló espera de verificación post-búsqueda", xbmc.LOGINFO)
                break

            with self.lock:
                n_dir = len(self.verified_direct)
                n_tor = len(self.verified_torrents)
                n_cap = len(self.verified_captchas)
                q_size = self.queue.qsize()
                n_act = self.active_workers

            if self.verify_max_functional > 0 and n_dir >= self.verify_max_functional:
                xbmc.log("Multi Bridge: meta de directos funcionales alcanzada en post-verificación (%d >= %d)" % (n_dir, self.verify_max_functional), xbmc.LOGINFO)
                break

            if q_size == 0 and n_act == 0:
                break

            now = time.time()
            if p_dialog and (now - _dialog_cooldown > 0.15):
                _dialog_cooldown = now
                if self.verify_max_functional > 0:
                    v_frac = min(1.0, n_dir / float(self.verify_max_functional))
                    pct = min(98, int(85 + v_frac * 13))
                    meta_str = "/%d directos" % self.verify_max_functional
                else:
                    pct = 95
                    meta_str = " directos"

                parts = []
                if n_dir > 0: parts.append('[COLOR lime]%d directos[/COLOR]' % n_dir)
                if n_tor > 0: parts.append('[COLOR cyan]%d torrents[/COLOR]' % n_tor)
                if n_cap > 0: parts.append('[COLOR orange]%d captchas[/COLOR]' % n_cap)
                if n_act > 0 or q_size > 0: parts.append('[COLOR yellow]comprobando (%d)[/COLOR]' % (n_act + q_size))
                status_str = ' • '.join(parts) if parts else 'Comprobando servidores...'

                l1 = '%s (%d%s)' % (target_title, n_dir, meta_str)
                l2 = status_str
                l3 = '[COLOR grey]Cancelar para abrir los enlaces disponibles ahora[/COLOR]'
                if hasattr(p_dialog, 'set_metrics'):
                    p_dialog.set_metrics(
                        n_dir=n_dir, n_tor=n_tor + n_cap, n_ver=n_act + q_size,
                        status_line=status_str
                    )
                try: p_dialog.update(pct, '%s\n%s\n%s' % (l1, l2, l3))
                except: pass

            time.sleep(0.08)

        if p_dialog:
            try: p_dialog.update(100)
            except: pass
        self.global_stop.set()
        for t in list(self.threads):
            try:
                if t.is_alive():
                    t.join(timeout=0.05)
            except Exception:
                pass

    def get_results(self, fallback_links=None):
        self.global_stop.set()
        for t in list(self.threads):
            try:
                if t.is_alive():
                    t.join(timeout=0.05)
            except Exception:
                pass
        with self.lock:
            d_list = self.verified_direct[:self.verify_max_functional] if self.verify_max_functional > 0 else list(self.verified_direct)
            all_v = d_list + self.verified_torrents + self.verified_captchas
            if all_v:
                return all_v
        return fallback_links or []

def _verify_links_headless(links, engine='alfa', p_dialog=None):
    if not links: return []
    links = _filter_discarded_links(links)
    if not links: return []

    # Separar enlaces torrent y captcha de enlaces directos.
    # Torrents y Captchas se envían directamente sin verificar como funcionales
    # y NUNCA cuentan para la meta de enlaces directos funcionales.
    verified_results = {}
    direct_items_to_test = []
    direct_verified_indices = set()
    torrent_indices = set()
    captcha_indices = set()

    for idx, lnk in enumerate(links):
        if _is_torrent_link(lnk):
            verified_results[idx] = lnk
            torrent_indices.add(idx)
        elif _is_web_captcha_server(_get_link_server_name(lnk), lnk):
            if _bridge_addon.getSetting('hide_captcha_links') != 'true':
                verified_results[idx] = lnk
                captcha_indices.add(idx)
        else:
            direct_items_to_test.append((idx, lnk))

    if not direct_items_to_test:
        xbmc.log("Multi Bridge: _verify_links_headless - todos los enlaces son torrents/captchas (%d), ninguno a verificar" % len(links), xbmc.LOGINFO)
        return [verified_results[idx] for idx in sorted(verified_results.keys())]

    mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
    if not mods: return links

    servertools = mods['servertools']
    total_to_check = len(direct_items_to_test)
    checked_count = [0]
    finished_indices = set()
    lock = threading.Lock()
    stop_event = threading.Event()

    max_workers = min(20, max(2, _get_int_setting('verify_threads_max', 16)))
    verify_timeout = _get_int_setting('verify_timeout', 10)
    verify_max_functional = _get_int_setting('verify_max_functional', 12)
    if verify_max_functional < 0: verify_max_functional = 0
    if max_workers < 1: max_workers = 1
    if verify_timeout < 3: verify_timeout = 3
    if not p_dialog:
        # Modo segundo plano: timeout estricto de socket (máx 5s) para evitar hilos huérfanos
        verify_timeout = min(verify_timeout, 5)

    orig_timeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(verify_timeout)

    # Cache de resoluciones: los mismos enlaces (misma huella) se resuelven
    # una sola vez por red y el resto reutiliza el resultado. El clone() de
    # Balandro es deepcopy, asi que cada indice recibe un objeto independiente
    # con el mismo contenido -> el resultado final no cambia.
    prep_cache = {}
    _CACHE_MISS = object()

    def _resolve_one(lnk):
        return _resolve_single_link_for_verification(lnk, engine=engine, servertools=servertools)

    def _test_worker(orig_idx, lnk):
        if stop_event.is_set() or xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set(): return
        # Doble salvaguarda: si es torrent o captcha, jamás verificar por red ni contar como funcional
        if _is_torrent_link(lnk):
            with lock:
                if orig_idx not in finished_indices:
                    finished_indices.add(orig_idx)
                    verified_results[orig_idx] = lnk
                    torrent_indices.add(orig_idx)
                checked_count[0] += 1
            return
        if _is_web_captcha_server(_get_link_server_name(lnk), lnk):
            with lock:
                if orig_idx not in finished_indices:
                    finished_indices.add(orig_idx)
                    if _bridge_addon.getSetting('hide_captcha_links') != 'true':
                        verified_results[orig_idx] = lnk
                        captcha_indices.add(orig_idx)
                checked_count[0] += 1
            return

        try:
            if stop_event.is_set() or xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set(): return
            _ckey = _link_cache_key(lnk)
            with lock:
                _hit = prep_cache.get(_ckey, _CACHE_MISS)
            if _hit is _CACHE_MISS:
                if stop_event.is_set() or xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set(): return
                _res = _resolve_one(lnk)
                if stop_event.is_set() or xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set(): return
                with lock:
                    prep_cache[_ckey] = _res
            else:
                _res = _hit
            if _res is None or stop_event.is_set() or xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                return
            _cp = _res.clone() if hasattr(_res, 'clone') else _res
            with lock:
                if orig_idx not in finished_indices:
                    finished_indices.add(orig_idx)
                    if _is_torrent_link(_cp):
                        verified_results[orig_idx] = _cp
                        torrent_indices.add(orig_idx)
                    elif _is_web_captcha_server(_get_link_server_name(_cp), _cp):
                        if _bridge_addon.getSetting('hide_captcha_links') != 'true':
                            verified_results[orig_idx] = _cp
                            captcha_indices.add(orig_idx)
                    else:
                        if verify_max_functional <= 0 or len(direct_verified_indices) < verify_max_functional:
                            try: setattr(_cp, '_bridge_verified', True)
                            except Exception: pass
                            verified_results[orig_idx] = _cp
                            direct_verified_indices.add(orig_idx)
        except Exception: pass
        finally:
            with lock:
                if orig_idx not in finished_indices:
                    finished_indices.add(orig_idx)
                checked_count[0] += 1

    threads = []
    for orig_idx, lnk in direct_items_to_test:
        threads.append((orig_idx, threading.Thread(target=_test_worker, args=(orig_idx, lnk), daemon=True)))

    running = []
    i = 0
    try:
        _verify_loop_start = time.time()
        while (i < len(threads) or running) and not xbmc.Monitor().abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
            if p_dialog and p_dialog.iscanceled() and (time.time() - _verify_loop_start > 0.5):
                xbmc.log("Multi Bridge: usuario canceló diálogo de verificación de enlaces", xbmc.LOGINFO)
                break
            now = time.time()
            running = [(orig_idx, t, st) for (orig_idx, t, st) in running if t.is_alive() and (now - st < verify_timeout)]

            while i < len(threads) and len(running) < max_workers:
                orig_idx, t = threads[i]
                t.start()
                running.append((orig_idx, t, time.time()))
                i += 1

            with lock:
                done = checked_count[0]
                # Funcionales = SOLO los enlaces directos verificados correctamente
                funcionales = len(direct_verified_indices)
            if verify_max_functional > 0 and funcionales >= verify_max_functional:
                stop_event.set()
                xbmc.log("Multi Bridge: límite de enlaces directos funcionales alcanzado (%d >= %d), finalizando verificación anticipadamente" % (funcionales, verify_max_functional), xbmc.LOGINFO)
                if p_dialog:
                    _l1 = 'Verificando %d enlaces' % len(links)
                    _l2 = '[COLOR lime]%d Funcionales alcanzados (límite)[/COLOR]' % funcionales
                    _l3 = '[COLOR grey]Completado anticipadamente[/COLOR]'
                    try: p_dialog.update(100, "%s\n%s\n%s" % (_l1, _l2, _l3))
                    except: pass
                    time.sleep(0.3)
                break
            if p_dialog:
                pct = int((done / float(total_to_check)) * 100) if total_to_check else 100
                _l1 = 'Verificando %d enlaces' % len(links)
                _l2parts = []
                if funcionales > 0:
                    _l2parts.append('[COLOR lime]%d Funcionales[/COLOR]' % funcionales)
                if len(torrent_indices) > 0:
                    _l2parts.append('[COLOR cyan]%d Torrents[/COLOR]' % len(torrent_indices))
                if len(captcha_indices) > 0:
                    _l2parts.append('[COLOR orange]%d Captchas[/COLOR]' % len(captcha_indices))
                _l2 = ' · '.join(_l2parts)
                _l3 = '[COLOR grey]Cerrar para reproducir los enlaces[/COLOR]' if funcionales > 0 else ''
                p_dialog.update(pct, '%s\n%s\n%s' % (_l1, _l2, _l3))

            if not running and i >= len(threads): break
            if xbmc.Monitor().waitForAbort(0.08) or _BG_TASK_ABORT_EVENT.is_set():
                break
    finally:
        stop_event.set()
        if xbmc.Monitor().abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
            abort_all_network_sockets()
        for _orig_idx, _t, _st in list(running):
            try:
                if _t.is_alive():
                    _t.join(timeout=0.05)
            except Exception:
                pass
        try:
            socket.setdefaulttimeout(orig_timeout or 10.0)
        except Exception:
            pass

    return [verified_results[orig_idx] for orig_idx in sorted(verified_results.keys()) if orig_idx in verified_results]

def _build_bridge_terms(target_title, alt_terms, all_names):
    candidates = []
    seen_raw = set()
    def add_cand(t):
        if not t:
            return
        t_str = _safe_str(t).strip()
        if not t_str:
            return
        low = t_str.lower()
        if low in seen_raw:
            return
        seen_raw.add(low)
        candidates.append(t_str)
        # Extraer variantes entre parentesis: "The Chosen (Los elegidos)" -> "The Chosen", "Los elegidos"
        if '(' in t_str and ')' in t_str:
            for inside in re.findall(r'\((.*?)\)', t_str):
                inside_clean = inside.strip()
                if inside_clean and not re.match(r'^\d{4}$', inside_clean):
                    add_cand(inside_clean)
            outside = re.sub(r'\(.*?\)', '', t_str).strip()
            if outside:
                add_cand(outside)
        # Extraer variantes separadas por ':' o '-'
        if ':' in t_str or ' - ' in t_str or '–' in t_str:
            for part in re.split(r'[:\-–—]', t_str):
                part_clean = part.strip()
                if part_clean and len(part_clean) >= 3:
                    add_cand(part_clean)

    add_cand(target_title)
    if alt_terms:
        for t in alt_terms:
            add_cand(t)
    if all_names:
        for t in all_names:
            add_cand(t)
    terms = []
    seen_clean = set()
    for raw in candidates:
        cleaned = _clean_search_term(raw)
        if cleaned and cleaned.lower() not in seen_clean:
            seen_clean.add(cleaned.lower())
            terms.append(cleaned)
        core_raw = get_core_title(raw)
        if core_raw and core_raw != raw:
            core_clean = _clean_search_term(core_raw)
            if core_clean and core_clean.lower() not in seen_clean:
                seen_clean.add(core_clean.lower())
                terms.append(core_clean)
    return terms[:5]


_tmdb_translations_cache = {}

def _resolve_localized_metadata(tmdb_id=None, is_series=False, season=None, episode=None,
                                 plot_lat='', plot_es='', plot_param='',
                                 tagline_lat='', tagline_es='', tagline_param='',
                                 title_lat='', title_es='', title_param=''):
    """Resuelve de forma independiente la traducción del contenido usando TMDb API /translations.
    Prioridad:
      1. Español (México) (es-MX)
      2. Si no hay es-MX, usar Español (España) (es-ES) para sinopsis, slogan y título
      3. Si no hay es-MX ni es-ES (solo inglés u otro idioma), sinopsis = 'Sinopsis sin traducción'
    """
    tmdb_id_str = str(tmdb_id or '').strip()
    s_val = str(season or '').strip()
    e_val = str(episode or '').strip()
    is_ep = bool(is_series and s_val and e_val and s_val.isdigit() and e_val.isdigit())

    cache_key = f"{tmdb_id_str}_{s_val}_{e_val}" if is_ep else f"{tmdb_id_str}_{1 if is_series else 0}"

    cur_plot = str(plot_param or '').strip()
    cur_tagline = str(tagline_param or '').strip()
    cur_title = str(title_param or '').strip()

    if tmdb_id_str.isdigit() and cache_key in _tmdb_translations_cache:
        return dict(_tmdb_translations_cache[cache_key])

    tmdb_mx_plot = ''
    tmdb_mx_tagline = ''
    tmdb_mx_title = ''
    tmdb_es_plot = ''
    tmdb_es_tagline = ''
    tmdb_es_title = ''
    tmdb_oth_plot = ''
    tmdb_oth_tagline = ''
    tmdb_oth_title = ''
    has_tmdb_data = False

    if tmdb_id_str.isdigit():
        api_key = "a1ab8b8669da03637a4b98fa39c39228"
        import urllib.request as _ureq
        import ssl as _ssl
        import json as _json

        ctx = None
        try:
            ctx = _ssl._create_unverified_context()
        except Exception:
            pass

        urls_to_try = []
        if is_ep:
            urls_to_try.append(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}/season/{s_val}/episode/{e_val}/translations?api_key={api_key}")
            urls_to_try.append(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}/translations?api_key={api_key}")
        elif is_series:
            urls_to_try.append(f"https://api.themoviedb.org/3/tv/{tmdb_id_str}/translations?api_key={api_key}")
        else:
            urls_to_try.append(f"https://api.themoviedb.org/3/movie/{tmdb_id_str}/translations?api_key={api_key}")

        for u in urls_to_try:
            try:
                req = _ureq.Request(u, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
                kw = {'timeout': 3.5}
                if ctx:
                    kw['context'] = ctx
                with _ureq.urlopen(req, **kw) as resp:
                    raw = resp.read().decode('utf-8', errors='ignore')
                    data = _json.loads(raw)
                    translations = data.get('translations', [])
                    if translations:
                        has_tmdb_data = True
                        for t in translations:
                            iso_639 = (t.get('iso_639_1') or '').lower()
                            iso_3166 = (t.get('iso_3166_1') or '').upper()
                            d = t.get('data', {})
                            if iso_639 == 'es':
                                p = (d.get('overview') or '').strip()
                                tg = (d.get('tagline') or '').strip()
                                tt = (d.get('title') or d.get('name') or '').strip()
                                if iso_3166 == 'MX':
                                    if p and not tmdb_mx_plot: tmdb_mx_plot = p
                                    if tg and not tmdb_mx_tagline: tmdb_mx_tagline = tg
                                    if tt and not tmdb_mx_title: tmdb_mx_title = tt
                                elif iso_3166 == 'ES':
                                    if p and not tmdb_es_plot: tmdb_es_plot = p
                                    if tg and not tmdb_es_tagline: tmdb_es_tagline = tg
                                    if tt and not tmdb_es_title: tmdb_es_title = tt
                                else:
                                    if p and not tmdb_oth_plot: tmdb_oth_plot = p
                                    if tg and not tmdb_oth_tagline: tmdb_oth_tagline = tg
                                    if tt and not tmdb_oth_title: tmdb_oth_title = tt
                        # NOTA: no pre-poblar _tmdb_titles_cache aqui a proposito:
                        # solo tenemos titulos ES y _fetch_tmdb_titles necesita
                        # pedir el original en ingles; pre-poblarla la
                        # envenenaria y el fetch creeria que ya esta completa.
                    if tmdb_mx_plot or tmdb_es_plot:
                        break
            except Exception as e:
                pass

    # Resolver SINOPSIS (plot):
    if tmdb_mx_plot:
        final_plot = tmdb_mx_plot
    elif tmdb_es_plot:
        final_plot = tmdb_es_plot
    elif tmdb_oth_plot:
        final_plot = tmdb_oth_plot
    elif has_tmdb_data:
        final_plot = "Sinopsis sin traducción"
    elif plot_lat and plot_lat.strip():
        final_plot = plot_lat.strip()
    elif plot_es and plot_es.strip():
        final_plot = plot_es.strip()
    elif cur_plot:
        final_plot = cur_plot
    else:
        final_plot = "Sinopsis sin traducción"

    # Resolver SLOGAN (tagline):
    if tmdb_mx_tagline:
        final_tagline = tmdb_mx_tagline
    elif tmdb_es_tagline:
        final_tagline = tmdb_es_tagline
    elif tmdb_oth_tagline:
        final_tagline = tmdb_oth_tagline
    elif has_tmdb_data:
        final_tagline = ''
    elif tagline_lat and tagline_lat.strip():
        final_tagline = tagline_lat.strip()
    elif tagline_es and tagline_es.strip():
        final_tagline = tagline_es.strip()
    elif cur_tagline:
        final_tagline = cur_tagline
    else:
        final_tagline = ''

    # Resolver TÍTULO:
    final_title = cur_title
    if tmdb_mx_title:
        final_title = tmdb_mx_title
    elif tmdb_es_title:
        final_title = tmdb_es_title
    elif tmdb_oth_title:
        final_title = tmdb_oth_title
    elif title_lat and title_lat.strip():
        final_title = title_lat.strip()
    elif title_es and title_es.strip():
        final_title = title_es.strip()

    res = {
        'plot': final_plot,
        'tagline': final_tagline,
        'title': final_title,
        'has_spanish': bool(tmdb_mx_plot or tmdb_es_plot or tmdb_oth_plot)
    }
    if tmdb_id_str.isdigit():
        _tmdb_translations_cache[cache_key] = res

    try:
        xbmc.log(f"Multi Bridge: traducción resuelta (tmdb={tmdb_id_str}): plot={final_plot[:50]}... tagline={final_tagline} title={final_title}", xbmc.LOGINFO)
    except Exception:
        pass

    return res


_tmdb_titles_cache = {}
_tmdb_verify_cache = {}

def _notify_scan(channel_id):
    # Aviso desactivado por peticion del usuario: el chequeo sigue corriendo
    # en silencio (solo deja rastro en el log, sin ventanas emergentes).
    try:
        xbmc.log('Multi Bridge: comprobando año en web real (%s)...' % channel_id, xbmc.LOGINFO)
    except Exception:
        pass

def extract_year_from_url(url):
    """Extrae el año (1900-2039) del slug o ruta de una URL si viene embebido.
    0ms de latencia, evita peticiones de red innecesarias.
    Ejemplos: /pelicula/horas-desesperadas-2013 -> 2013
              /pelicula/37-horas-desesperadas-1990.html -> 1990
              /serie/the-boys-2019/ -> 2019
    """
    if not url:
        return None
    try:
        import re as _re_url
        m = _re_url.search(r'[-_/](19\d\d|20[0-3]\d)(?:[-_/]|\.html?|$)', str(url))
        if m:
            return int(m.group(1))
    except Exception:
        pass
    return None

_channel_cookie_jar = None
_channel_cookie_jar_time = 0

def _get_channel_cookie_opener():
    global _channel_cookie_jar, _channel_cookie_jar_time
    import time, http.cookiejar, urllib.request, ssl
    now = time.time()
    if _channel_cookie_jar is None or (now - _channel_cookie_jar_time) > 60:
        cj = http.cookiejar.MozillaCookieJar()
        for addon_id in ('plugin.video.balandro', 'plugin.video.alfa'):
            try:
                c_path = xbmcvfs.translatePath('special://userdata/addon_data/%s/cookies.dat' % addon_id)
                if os.path.exists(c_path):
                    cj.load(c_path, ignore_discard=True, ignore_expires=True)
            except Exception:
                pass
        _channel_cookie_jar = cj
        _channel_cookie_jar_time = now

    ctx = ssl._create_unverified_context() if hasattr(ssl, '_create_unverified_context') else None
    handlers = [urllib.request.HTTPCookieProcessor(_channel_cookie_jar)]
    if ctx:
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    return urllib.request.build_opener(*handlers)

def _norm_person_name(s):
    if not s: return ''
    import unicodedata, re as _re
    s = unicodedata.normalize('NFKD', str(s)).encode('ASCII', 'ignore').decode('utf-8')
    s = _re.sub(r'[^a-zA-Z0-9\s]', '', s).lower()
    return ' '.join(s.split())

def _match_actors(web_set, tmdb_set):
    if not web_set or not tmdb_set:
        return False
    if web_set.intersection(tmdb_set):
        return True
    for w in web_set:
        w_parts = set(w.split())
        if len(w_parts) >= 2:
            for t in tmdb_set:
                t_parts = set(t.split())
                if len(t_parts) >= 2 and len(w_parts.intersection(t_parts)) >= 2:
                    return True
    return False

def _extract_web_actors(html):
    import re as _re
    actors = []
    # 1. Links de actores (ej: /stars/..., /actor/..., /actores/...)
    for a in _re.findall(r'<a[^>]+href=[\'"][^\'"]*(?:/stars?/|/actors?/)[^\'"]*[\'"][^>]*>([^<]+)</a>', html, _re.I):
        c = a.strip()
        if len(c) > 2 and c not in actors:
            actors.append(c)
    # 2. Bloque etiquetado de reparto (Actors, Actores, Reparto, Elenco, Cast)
    if not actors:
        lbl_block = _re.search(r'(?:<strong>|<span>|<p>|<div[^>]*>)\s*(?:Actors|Actores|Reparto|Cast|Elenco)\s*[:<](.*?)</(?:p|div|ul|li|section)>', html, _re.I | _re.DOTALL)
        if lbl_block:
            content = lbl_block.group(1)
            sub_as = _re.findall(r'<a[^>]*>([^<]+)</a>', content)
            if sub_as:
                for a in sub_as:
                    c = a.strip()
                    if len(c) > 2 and c not in actors:
                        actors.append(c)
            else:
                clean = _re.sub(r'<[^>]+>', ' ', content)
                for part in _re.split(r'[,;/•|]', clean):
                    p = part.strip()
                    if len(p) > 2 and len(p) < 40 and p not in actors:
                        actors.append(p)
    # 3. Microdata / schema.org itemprop="actor"
    if not actors:
        for a in _re.findall(r'itemprop=[\'"]actor[\'"].*?<span[^>]+itemprop=[\'"]name[\'"]>([^<]+)</span>', html, _re.I | _re.DOTALL):
            c = a.strip()
            if len(c) > 2 and c not in actors:
                actors.append(c)
    return actors

_tmdb_cast_cache = {}

def _fetch_tmdb_cast(tmdb_id, is_series=False):
    global _tmdb_cast_cache
    if not tmdb_id:
        return []
    tmdb_id_str = str(tmdb_id).strip()
    if not tmdb_id_str.isdigit():
        return []
    cache_key = f"{tmdb_id_str}_{1 if is_series else 0}"
    if cache_key in _tmdb_cast_cache:
        return _tmdb_cast_cache[cache_key]
    cast = []
    try:
        api_key = "a1ab8b8669da03637a4b98fa39c39228"
        tmdb_type = "tv" if is_series else "movie"
        import json as _json
        import urllib.request as _ureq
        import ssl
        ctx = ssl._create_unverified_context() if hasattr(ssl, '_create_unverified_context') else None
        url = f"https://api.themoviedb.org/3/{tmdb_type}/{tmdb_id_str}/credits?api_key={api_key}"
        req = _ureq.Request(url)
        with _ureq.urlopen(req, timeout=4, context=ctx) as resp:
            data = _json.loads(resp.read().decode('utf-8', errors='ignore'))
            for c in data.get('cast', [])[:12]:
                name = (c.get('name') or c.get('original_name') or '').strip()
                if name and name not in cast:
                    cast.append(name)
    except Exception:
        pass
    if len(_tmdb_cast_cache) > 200:
        _tmdb_cast_cache.clear()
    _tmdb_cast_cache[cache_key] = cast
    return cast

def _detail_year_consistent(url, target_year, channel_id='', item=None, target_imdb=None, target_tmdb=None, is_series=False):
    # Comprueba si el candidato coincide con el año objetivo, IMDb ID o reparto.
    # True = mantener (coherente o no concluyente). False = descartar.
    # Ante cualquier duda o fallo devuelve True: nunca quita por error.
    # Si la web confirma positivamente el año objetivo, IMDb o actores, marca item._web_year_confirmed = True.
    year_t = None
    try:
        if target_year:
            year_t = int(str(target_year).strip())
            if year_t < 1900 or year_t > 2100:
                year_t = None
    except Exception:
        year_t = None

    if not year_t and not target_imdb and not target_tmdb:
        return True

    _u = _safe_str(url or '').strip()
    if not _u.startswith('http'):
        return True

    def _mark_confirmed():
        if item is not None:
            try:
                setattr(item, '_web_year_confirmed', True)
                if hasattr(item, 'infoLabels') and isinstance(getattr(item, 'infoLabels', None), dict):
                    if year_t:
                        item.infoLabels['year'] = year_t
                    if target_imdb:
                        item.infoLabels['imdb_id'] = str(target_imdb)
                    if target_tmdb:
                        item.infoLabels['tmdb_id'] = str(target_tmdb)
                        item.infoLabels['tmdb'] = str(target_tmdb)
                if year_t:
                    item.year = year_t
                if target_tmdb:
                    item.tmdb_id = str(target_tmdb)
            except Exception:
                pass

    # 0. Verificación ultrarrápida (0ms) en la propia URL si incluye el año en el slug
    if year_t:
        try:
            _url_year = extract_year_from_url(_u)
            if _url_year:
                if int(_url_year) != int(year_t):
                    try:
                        xbmc.log("Multi Bridge: %s '%s' descartado por año en URL (%d != %d)" % (channel_id, _u, _url_year, year_t), xbmc.LOGINFO)
                    except: pass
                    return False
                # Coincide exactamente con el año objetivo
                _mark_confirmed()
                return True
        except Exception:
            pass

    _notify_scan(channel_id or 'web')
    html = ''
    try:
        import urllib.request as _ureq
        opener = _get_channel_cookie_opener()
        req = _ureq.Request(_u, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.8010.12 Safari/537.36',
            'Referer': '/'.join(_u.split('/')[:3]) + '/'})
        with opener.open(req, timeout=6) as resp:
            # Si el servidor redirige a una URL genérica de login (/login), no es la ficha del contenido
            final_url = resp.geturl() or ''
            if final_url.rstrip('/').endswith('/login'):
                return True
            # 80KB es suficiente para capturar head, h1, metadatos y JSON-LD sin descargar megabytes
            html = resp.read(80000).decode('utf-8', errors='ignore')
    except Exception as _e:
        try:
            xbmc.log('Multi Bridge: page-check sin red (%s): %s' % (channel_id, _e), xbmc.LOGINFO)
        except: pass
        return True
    if not html or len(html) < 200:
        return True
    try:
        import re as _re2
        years_re = r'\b(19\d\d|20[0-3]\d)\b'

        # 0.5. Verificación por IMDb ID (100% inequívoca si coincide)
        imdb_mismatch = False
        if target_imdb:
            t_imdb = str(target_imdb).strip().lower()
            if t_imdb.startswith('tt'):
                page_imdbs = [m.lower() for m in _re2.findall(r'imdb\.com/title/(tt\d+)', html, _re2.I)]
                if page_imdbs:
                    if t_imdb in page_imdbs:
                        _mark_confirmed()
                        return True
                    else:
                        # IMDb diferente en la web (ej: HdFull pone el IMDb del piloto tt9471404 en The Chosen).
                        # No descartar inmediatamente si el año o reparto en la web coincide.
                        imdb_mismatch = True
                        try:
                            xbmc.log("Multi Bridge: %s '%s' IMDb en web no coincide (%s != %s), verificando por año/reparto..." % (channel_id, _u, page_imdbs[0], t_imdb), xbmc.LOGINFO)
                        except: pass

        # Verificación por Reparto/Actores si target_tmdb está disponible:
        # Se verifica SIEMPRE (haya o no año objetivo) cuando el sitio web liste actores.
        # Si la web lista 3 o más actores y ninguno coincide con el reparto oficial de TMDB,
        # es un homónimo o contenido completamente distinto (ej. documental vs película nueva).
        if target_tmdb:
            try:
                web_actors = _extract_web_actors(html)
                if web_actors and len(web_actors) >= 2:
                    tmdb_cast = _fetch_tmdb_cast(target_tmdb, is_series=is_series)
                    if tmdb_cast and len(tmdb_cast) >= 2:
                        norm_web = {_norm_person_name(a) for a in web_actors if _norm_person_name(a)}
                        norm_tmdb = {_norm_person_name(a) for a in tmdb_cast if _norm_person_name(a)}
                        if _match_actors(norm_web, norm_tmdb):
                            _mark_confirmed()
                            try:
                                xbmc.log("Multi Bridge: %s '%s' confirmado por coincidencia de actores" % (channel_id, _u), xbmc.LOGINFO)
                            except: pass
                            return True
                        elif len(web_actors) >= 3:
                            try:
                                xbmc.log("Multi Bridge: %s '%s' descartado por reparto no coincidente (%d actores web vs TMDB)" % (channel_id, _u, len(web_actors)), xbmc.LOGINFO)
                            except: pass
                            return False
            except Exception: pass

        if not year_t:
            return True

        # 0.8. Check específico de HDFull y similares (ej: /buscar/year/2013 o /year/2013)
        hdfull_years = [int(y) for y in _re2.findall(r'/(?:buscar/)?year/(\d{4})', html, _re2.I)]
        if hdfull_years:
            if any(y == year_t for y in hdfull_years):
                _mark_confirmed()
                return True
            else:
                try:
                    xbmc.log("Multi Bridge: %s '%s' descartado por año en ficha HDFull (%d != %d)" % (channel_id, _u, hdfull_years[0], year_t), xbmc.LOGINFO)
                except: pass
                return False

        # 1. Encabezados h1, h2 y enlaces bookmark (lo más fiable: título principal de la ficha)
        # Portales como GnulaTv o temas de WordPress usan h2 con rel="bookmark" o título del post
        cand_title = ''
        if item is not None:
            cand_title = _safe_str(getattr(item, 'contentTitle', '') or getattr(item, 'title', '')).strip()
        cand_words = [w.lower() for w in _re2.findall(r'[a-zA-ZáéíóúÁÉÍÓÚñÑ]{4,}', cand_title)] if cand_title else []

        headings = []
        # Enlaces permalink del post con rel="bookmark" (ej. Gnula: <a rel="bookmark" title="Ver ... (2011) online">)
        headings.extend(_re2.findall(r'<a[^>]+rel=["\']bookmark["\'][^>]*>(.*?)</a>', html, flags=_re2.IGNORECASE | _re2.DOTALL))
        # Clases CSS explícitas de título del post/obra
        headings.extend(_re2.findall(r'<[^>]+class=["\'][^"\']*(?:entry-title|post-title|item-title|film-title|tit_peli)[^"\']*["\'][^>]*>(.*?)</', html, flags=_re2.IGNORECASE | _re2.DOTALL))
        # h1 (siempre)
        headings.extend(_re2.findall(r'<h1[^>]*>(.*?)</h1>', html, flags=_re2.IGNORECASE | _re2.DOTALL))
        # h2 (si coincide con palabras del título o términos de reproducción/post)
        h2s = _re2.findall(r'<h2[^>]*>(.*?)</h2>', html, flags=_re2.IGNORECASE | _re2.DOTALL)
        for _h in h2s:
            _htxt = _re2.sub(r'<[^>]+>', ' ', _h).strip()
            if cand_words and any(w in _htxt.lower() for w in cand_words):
                headings.append(_h)
            elif 'rel="bookmark"' in _h.lower() or 'online' in _htxt.lower() or 'ver ' in _htxt.lower():
                headings.append(_h)

        head_years = []
        for _h in headings:
            _t = _re2.sub(r'<[^>]+>', ' ', _h)
            hy = [int(y) for y in _re2.findall(years_re, _t)]
            if hy:
                head_years.extend(hy)

        if head_years:
            if any(y == year_t for y in head_years):
                _mark_confirmed()
                return True
            try:
                xbmc.log("Multi Bridge: %s '%s' descartado por año en encabezado/título de la web (%s != %s)" % (channel_id, _u, head_years[0], year_t), xbmc.LOGINFO)
            except: pass
            return False

        # 2. Meta tags og:title / twitter:title
        meta_titles = _re2.findall(r'<meta[^>]+(?:property|name)=["\'](?:og:title|twitter:title)["\'][^>]+content=["\']([^"\']+)["\']', html, _re2.I)
        meta_titles += _re2.findall(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\'](?:og:title|twitter:title)["\']', html, _re2.I)
        all_my = []
        for mt in meta_titles:
            all_my.extend([int(y) for y in _re2.findall(years_re, mt)])
        if all_my:
            if any(y == year_t for y in all_my):
                _mark_confirmed()
                return True
            return False

        # 3. Meta release_date estricto (ignora fechas de subida como uploadDate)
        meta_dates = _re2.findall(r'<meta[^>]+(?:property|name)=["\'](?:(?:video:)?video:)?release_date)["\'][^>]+content=["\']([^"\']+)["\']', html, _re2.I)
        meta_dates += _re2.findall(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+(?:property|name)=["\'](?:(?:video:)?video:)?release_date)["\']', html, _re2.I)
        all_md = []
        for md in meta_dates:
            all_md.extend([int(y) for y in _re2.findall(years_re, md)])
        if all_md:
            if any(y == year_t for y in all_md):
                _mark_confirmed()
                return True
            return False

        # 4. Título de la pestaña (<title>)
        _mt = _re2.search(r'<title[^>]*>(.*?)</title>', html, flags=_re2.IGNORECASE | _re2.DOTALL)
        if _mt:
            _t = _re2.sub(r'<[^>]+>', ' ', _mt.group(1))
            ty = [int(y) for y in _re2.findall(years_re, _t)]
            if ty:
                if any(y == year_t for y in ty):
                    _mark_confirmed()
                    return True
                return False

        # 5. JSON-LD releaseDate / releasedEvent
        j_dates = _re2.findall(r'["\'](?:releaseDate|releasedEvent)["\']\s*:\s*["\']?(19\d\d|20[0-3]\d)', html, _re2.IGNORECASE)
        if j_dates:
            jy = [int(y) for y in j_dates]
            if any(y == year_t for y in jy):
                _mark_confirmed()
                return True
            return False

        # 6. Campos etiquetados explícitos (ej. >Año:</span> 2013 o <span>Estreno</span>: 2013 o <span>A&ntilde;o: </span>)
        lbl_m = _re2.search(r'>\s*(?:A(?:ñ|&ntilde;|&#241;)o|Estreno|Fecha\s+de\s+estreno|Year|Release(?:\s+date)?)\s*[:<](?:<[^>]+>|\s)*\b(19\d\d|20[0-3]\d)\b|>\s*(?:A(?:ñ|&ntilde;|&#241;)o|Estreno|Fecha\s+de\s+estreno|Year|Release(?:\s+date)?)\s*(?:<[^>]+>\s*)*:\s*(?:<[^>]+>\s*)*\b(19\d\d|20[0-3]\d)\b', html, _re2.IGNORECASE)
        if lbl_m:
            ly = int(lbl_m.group(1) or lbl_m.group(2))
            if ly == year_t:
                _mark_confirmed()
                return True
            return False

        # 6.5. Patrones de estreno o ficha en texto inline (ej. Ver película online [2011, Latino, HD])
        inline_m = _re2.search(r'(?:ver\s+pel[ií]cula|online|estreno|a[ñn]o)[^<]{0,50}(?:\[|\()\s*(19\d\d|20[0-3]\d)\s*(?:\]|\)|,)', html, _re2.IGNORECASE)
        if inline_m:
            iy = int(inline_m.group(1))
            if iy == year_t:
                _mark_confirmed()
                return True
            try:
                xbmc.log("Multi Bridge: %s '%s' descartado por año inline en web (%d != %d)" % (channel_id, _u, iy, year_t), xbmc.LOGINFO)
            except: pass
            return False

        # 7. Clase CSS meta estricta (<span class="year">2013</span>)
        cls_m = _re2.search(r'<[^>]+class=["\'][^"\']*\b(?:year|release)\b[^"\']*["\'][^>]*>\s*\b(19\d\d|20[0-3]\d)\b\s*<', html, _re2.IGNORECASE)
        if cls_m:
            cy = int(cls_m.group(1))
            if cy == year_t:
                _mark_confirmed()
                return True
            return False

        # 8. Formato de ficha AresHD y similares: >2026</span>...Año
        areshd_lbl = _re2.search(r'>\s*\b(19\d\d|20[0-3]\d)\b\s*</span[^>]*>\s*(?:<[^>]+>\s*)*A[ñn]o\b', html, _re2.IGNORECASE)
        if areshd_lbl:
            ay = int(areshd_lbl.group(1))
            if ay == year_t:
                _mark_confirmed()
                return True
            return False

        # 9. Verificación por Reparto / Actores (Nivel 4 de máxima precisión):
        # Si la web no tiene año en título/metadatos o no fue concluyente (ej. Homecine),
        # se extraen los actores y se comparan contra el reparto de TMDb.
        # Debe ejecutarse ANTES de escanear texto general para no dejarse engañar por
        # menús o pies de página (ej. 'Estrenos 2026' en el menú de navegación).
        if target_tmdb:
            try:
                web_actors = _extract_web_actors(html)
                if web_actors and len(web_actors) >= 2:
                    tmdb_cast = _fetch_tmdb_cast(target_tmdb, is_series=is_series)
                    if tmdb_cast and len(tmdb_cast) >= 2:
                        norm_web = {_norm_person_name(a) for a in web_actors if _norm_person_name(a)}
                        norm_tmdb = {_norm_person_name(a) for a in tmdb_cast if _norm_person_name(a)}
                        if _match_actors(norm_web, norm_tmdb):
                            _mark_confirmed()
                            try:
                                xbmc.log("Multi Bridge: %s '%s' confirmado por coincidencia de actores" % (channel_id, _u), xbmc.LOGINFO)
                            except: pass
                            return True
                        elif len(web_actors) >= 3:
                            try:
                                xbmc.log("Multi Bridge: %s '%s' descartado por reparto no coincidente (%s != %s)" % (channel_id, _u, web_actors[:3], tmdb_cast[:3]), xbmc.LOGINFO)
                            except: pass
                            return False
            except Exception as _ce:
                try:
                    xbmc.log("Multi Bridge: cast verify error (%s): %s" % (channel_id, _ce), xbmc.LOGINFO)
                except: pass

        # 10. Resto de la página (fallback de último recurso si no hubo actores):
        # Si sale un único año distinto repetido (>=3 veces), es otra obra.
        _all = [int(y) for y in _re2.findall(years_re, html)]
        if _all:
            _uniq = set(_all)
            if len(_uniq) == 1 and len(_all) >= 3 and list(_uniq)[0] != year_t:
                return False

        if imdb_mismatch:
            try:
                xbmc.log("Multi Bridge: %s '%s' descartado por IMDb diferente en web sin confirmación de año/reparto" % (channel_id, _u), xbmc.LOGINFO)
            except: pass
            return False

        return True
    except Exception:
        return True

def _verify_candidate_tmdb(title_check, target_year, target_tmdb, is_series=False):
    """Confirma contra la API de TMDb que un candidato debil (match solo por
    titulo, sin IDs ni anio) es realmente el contenido buscado.
    Devuelve True si el primer resultado de busqueda coincide con target_tmdb
    SIN forzar &year= (evita sesgo circular) y sin homonimos con distinto anio.
    Cache de sesion, 1 llamada como maximo por candidato, timeout 4s. Nunca lanza excepciones."""
    try:
        t = _safe_str(title_check).strip()
        if not t or not target_tmdb:
            return False
        key = ('tv' if is_series else 'movie', t.lower(), str(target_year or ''), str(target_tmdb))
        if key in _tmdb_verify_cache:
            return _tmdb_verify_cache[key]
        ok = False
        try:
            api_key = "a1ab8b8669da03637a4b98fa39c39228"
            kind = "tv" if is_series else "movie"
            import json as _json
            import urllib.request as _ureq
            q = uparse.quote(t)
            # Busqueda abierta sin forzar anio para no enmascarar homonimos de otros anios
            url = f"https://api.themoviedb.org/3/search/{kind}?api_key={api_key}&query={q}&language=es-MX&page=1&include_adult=false"
            with _ureq.urlopen(url, timeout=4) as resp:
                data = _json.loads(resp.read().decode('utf-8', errors='ignore'))
            results = data.get('results', []) if isinstance(data, dict) else []
            if results and isinstance(results[0], dict):
                top_id = str(results[0].get('id', ''))
                if top_id and top_id == str(target_tmdb):
                    # Comprobar si existen homonimos con el mismo titulo pero distinto año
                    homonyms = False
                    t_clean = t.lower()
                    target_y = int(str(target_year).strip()) if target_year and str(target_year).isdigit() else 0
                    for r in results[1:6]:
                        if not isinstance(r, dict): continue
                        rt = (r.get('title') or r.get('name') or '').strip().lower()
                        rot = (r.get('original_title') or r.get('original_name') or '').strip().lower()
                        ry_str = (r.get('release_date') or r.get('first_air_date') or '')[:4]
                        if (rt == t_clean or rot == t_clean) and ry_str.isdigit():
                            ry = int(ry_str)
                            if target_y and ry != target_y:
                                homonyms = True
                                break
                    if not homonyms:
                        ok = True
        except Exception:
            ok = False
        try:
            if len(_tmdb_verify_cache) > 500:
                _tmdb_verify_cache.clear()
            _tmdb_verify_cache[key] = ok
        except Exception:
            pass
        return ok
    except Exception:
        return False

_tmdb_identity_cache = {}
_tmdb_runtime_cache = {}

def _fetch_tmdb_runtime_secs(tmdb_id):
    """Obtiene la duración oficial en segundos desde TMDb para validar películas."""
    if not tmdb_id:
        return 0
    tid = str(tmdb_id).strip()
    if not tid.isdigit():
        return 0
    if tid in _tmdb_runtime_cache:
        return _tmdb_runtime_cache[tid]
    secs = 0
    try:
        api_key = "a1ab8b8669da03637a4b98fa39c39228"
        import json as _json
        import urllib.request as _ureq
        import ssl as _ssl
        ctx = None
        try: ctx = _ssl._create_unverified_context()
        except Exception: pass
        url = f"https://api.themoviedb.org/3/movie/{tid}?api_key={api_key}&language=en"
        kwargs = {'timeout': 3.5}
        if ctx: kwargs['context'] = ctx
        with _ureq.urlopen(url, **kwargs) as resp:
            data = _json.loads(resp.read().decode('utf-8', errors='ignore'))
        rt = int(data.get('runtime') or 0) if isinstance(data, dict) else 0
        if rt > 0:
            secs = rt * 60
    except Exception:
        secs = 0
    try:
        if len(_tmdb_runtime_cache) > 300:
            _tmdb_runtime_cache.clear()
        if secs > 0:
            _tmdb_runtime_cache[tid] = secs
    except Exception:
        pass
    return secs

def _is_playing_wrong_runtime(player, tmdb_id, is_series=False):
    """Verifica tras iniciar reproducción si el archivo pertenece realmente a otra película
    (ej. película de 2h cuando el original en TMDb dura 1h20-1h30, o tráiler/corto).
    Retorna (mismatch_bool, expected_mins, actual_mins)."""
    if is_series or not tmdb_id:
        return False, 0, 0
    expected_secs = _fetch_tmdb_runtime_secs(tmdb_id)
    if expected_secs < 2400:
        return False, 0, 0
    actual_secs = 0.0
    for _ in range(15):
        try:
            if not player.isPlayingVideo():
                break
            actual_secs = float(player.getTotalTime() or 0.0)
            if actual_secs >= 60.0:
                break
        except Exception:
            break
        xbmc.sleep(100)
    if actual_secs < 60.0:
        return False, 0, 0
    exp_m = int(round(expected_secs / 60.0))
    act_m = int(round(actual_secs / 60.0))
    if actual_secs < 900.0:
        return True, exp_m, act_m
    diff = abs(actual_secs - float(expected_secs))
    if diff > max(1200.0, float(expected_secs) * 0.25):
        return True, exp_m, act_m
    return False, exp_m, act_m

_PAREN_TAG_RE = re.compile(r'(?i)^\s*(4k|uhd|2160p|1080p|720p|480p|360p|bluray|blu-ray|bdrip|brrip|hdrip|hdtv|dvdrip|dvdscr|web-?d[l1]|webrip|web-rip|x26[45]|h26[45]|hevc|avc|xvid|divx|latino|castellano|espa[ñn]ol|subtitulad[oa]s?|dual|audio|hdr|sdr|dts|aac|ac3|mp3|extended|remastered|unrated|theatrical|directors?\s*cut|3d|sbs|hsbs|hdts|hd-ts|cam|ts|vose?|repack|proper)\s*$')

def _stripped_paren_extra(raw_title):
    """Texto entre parentesis/corchetes que NO es anio ni etiqueta tecnica.
    Ej. '(Cuenta Atras)' -> 'Cuenta Atras'; '(1995)', '(Latino)' -> ''.
    El limpiador clean_title borra estos segmentos para puntuar, pero aqui se
    detecta si lo borrado era significativo (desambigua homonimos)."""
    try:
        segs = re.findall(r'[\(\[\{]([^\)\]\}]{1,80})[\)\]\}]', _safe_str(raw_title) or '')
        out = []
        for s in segs:
            t = _safe_str(s).strip()
            if not t:
                continue
            if re.search(r'(19\d\d|20\d\d)', t):
                continue
            if _PAREN_TAG_RE.match(t):
                continue
            out.append(t)
        return ' '.join(out)
    except Exception:
        return ''

def _tmdb_identity_conflict(raw_title, target_tmdb, target_year):
    """True si TMDb reconoce el titulo EXACTO como OTRA pelicula (!= target).
    Caza homonimos con parentesis distintivo: 'Horas Desesperadas (Cuenta
    Atras)' es Hours 2013, no Desperate Hours (tmdb 18612). Solo cuenta si el
    top-1 de TMDb casa exacto con el titulo Y su anio difiere del objetivo
    (misma pelicula = mismo anio). Fail-open: ante cualquier duda, False.
    1 llamada API como maximo por titulo (cache de sesion), timeout 4s."""
    try:
        t = _safe_str(raw_title).strip()
        if not t or not target_tmdb:
            return False
        key = ('movie', t.lower(), str(target_tmdb))
        if key in _tmdb_identity_cache:
            return _tmdb_identity_cache[key]
        conflict = False
        try:
            api_key = "a1ab8b8669da03637a4b98fa39c39228"
            import json as _json
            import urllib.request as _ureq
            q = uparse.quote(t)
            url = f"https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={q}&language=es-MX&page=1&include_adult=false"
            with _ureq.urlopen(url, timeout=4) as resp:
                data = _json.loads(resp.read().decode('utf-8', errors='ignore'))
            results = data.get('results', []) if isinstance(data, dict) else []
            if results and isinstance(results[0], dict):
                top = results[0]
                top_id = str(top.get('id', ''))
                if top_id and top_id != str(target_tmdb):
                    for _k in ('title', 'original_title'):
                        _tt = _safe_str(top.get(_k) or '').strip()
                        if _tt and clean_title(_tt) == clean_title(t):
                            _ry = _safe_str(top.get('release_date') or '')[:4]
                            _ty = _safe_str(target_year or '').strip()
                            if _ry.isdigit() and _ty.isdigit():
                                if int(_ry) != int(_ty):
                                    conflict = True
                            else:
                                conflict = True
                            break
        except Exception:
            conflict = False
        try:
            if len(_tmdb_identity_cache) > 500:
                _tmdb_identity_cache.clear()
            _tmdb_identity_cache[key] = conflict
        except Exception:
            pass
        return conflict
    except Exception:
        return False

def _fetch_tmdb_titles(tmdb_id, is_series=False):
    # Cache + 3 idiomas en paralelo (es-MX, es-ES y EN siempre: el titulo
    # original ingles es el que casa con webs extranjeras) + 1 reintento por
    # idioma + timeout holgado (5s) para Celeron con red lenta.
    titles = []
    if not tmdb_id:
        return titles
    tmdb_id_str = str(tmdb_id).strip()
    if not tmdb_id_str.isdigit():
        return titles
    cache_key = f"{tmdb_id_str}_{1 if is_series else 0}"
    if cache_key in _tmdb_titles_cache:
        try:
            xbmc.log(f"Multi Bridge: tmdb titles cache-hit {cache_key}: {_tmdb_titles_cache[cache_key]}", xbmc.LOGINFO)
        except: pass
        return list(_tmdb_titles_cache[cache_key])
    try:
        api_key = "a1ab8b8669da03637a4b98fa39c39228"
        tmdb_type = "tv" if is_series else "movie"
        import json as _json
        import urllib.request as _ureq
        import ssl as _ssl
        ctx = None
        try:
            ctx = _ssl._create_unverified_context()
        except Exception:
            pass
        langs = ["es-MX", "es-ES", "en"]
        results = {}
        def _fetch_lang(lang):
            try:
                url = f"https://api.themoviedb.org/3/{tmdb_type}/{tmdb_id_str}?api_key={api_key}&language={lang}"
                # Intento con urllib (5s) sin pasar por httptools para no bloquear lock; 1 reintento
                for _att in range(2):
                    try:
                        kwargs = {'timeout': 5}
                        if ctx: kwargs['context'] = ctx
                        with _ureq.urlopen(url, **kwargs) as resp2:
                            raw = resp2.read().decode('utf-8', errors='ignore')
                            data = _json.loads(raw)
                            if data:
                                t = data.get('title') or data.get('name') or ""
                                o = data.get('original_title') or data.get('original_name') or ""
                                results[lang] = [x for x in [t, o] if x]
                                break
                    except Exception:
                        results[lang] = []
                        continue
            except Exception:
                results[lang] = []
        # Paralelo
        import threading
        threads = []
        for lang in langs:
            th = threading.Thread(target=_fetch_lang, args=(lang,), daemon=True)
            th.start()
            threads.append(th)
        for th in threads:
            th.join(timeout=5.5)
        for lang in langs:
            try:
                xbmc.log(f"Multi Bridge: tmdb titles {lang}: {results.get(lang, [])}", xbmc.LOGINFO)
            except: pass
            for cand in results.get(lang, []):
                if cand and cand not in titles:
                    titles.append(cand)
        # Cache
        uniq = []
        seen = set()
        for t in titles:
            if not t:
                continue
            low = t.lower().strip()
            if low in seen:
                continue
            seen.add(low)
            uniq.append(t)
        _tmdb_titles_cache[cache_key] = list(uniq)
        return uniq
    except Exception as e:
        try:
            xbmc.log(f"Multi Bridge: _fetch_tmdb_titles error: {e}", xbmc.LOGINFO)
        except:
            pass
        return []
        return []


def _enrich_with_tmdb(results, engine):
    # Desactivado intencionalmente: busquedas a ciegas en TMDb sobre resultados de canales
    # sin contexto de destino sobreescriben items con metadatos de peliculas equivocadas
    # (ej. 'El Origen' -> TMDb ID 8355 'Ice Age 3: El origen de los dinosaurios'),
    # generan alta latencia y contaminan la lista.
    # Los metadatos canonicos de TMDb Helper (meta) se aplican de forma fidedigna.
    return

# ---------------------------------------------------------
# ---------------------------------------------------------
# Search Implementation: Alfa Engine & Balandro Engine
# ---------------------------------------------------------
def _search_planb(target_title, target_year, is_series, s_num, e_num, all_names, target_tmdb=None, target_imdb=None):
    # PlanB: intentar con cada variante de titulo (por si vitaminar depende del titulo) y con tmdb/imdb
    try:
        mods = _get_alfa_modules()
        if not mods:
            return None, None
        Item = mods['Item']
        planb = None
        with _engine_lock:
            _switch_engine_environment('alfa')
            try:
                from lib import planb_py3 as planb
            except Exception:
                try:
                    from lib import planb
                except Exception:
                    planb = None
        if not planb:
            return None, None
        try:
            alt_for_planb = [t for t in (all_names or []) if t and t != target_title]
            terms_for_planb = _build_bridge_terms(target_title, alt_for_planb, all_names)
            if not terms_for_planb:
                terms_for_planb = [_clean_search_term(target_title) or target_title]
        except:
            terms_for_planb = [target_title]
        for try_title in terms_for_planb:
            it_vit = Item(
                channel='PlanB',
                action='vitaminar',
                contentType='episode' if is_series else 'movie',
                contentTitle=try_title,
                infoLabels={
                    'tmdb_id': str(target_tmdb or ''),
                    'imdb_id': str(target_imdb or ''),
                    'year': str(target_year or ''),
                    'title': try_title,
                    'mediatype': 'episode' if is_series else 'movie'
                }
            )
            if is_series:
                try:
                    it_vit.contentSeason = int(s_num or 1)
                except:
                    pass
                try:
                    it_vit.contentEpisodeNumber = int(e_num or 1)
                except:
                    pass
                try:
                    it_vit.infoLabels['season'] = int(s_num or 1)
                except:
                    pass
                try:
                    it_vit.infoLabels['episode'] = int(e_num or 1)
                except:
                    pass
                it_vit.infoLabels['tvshowtitle'] = try_title
            raw_links = []
            with silenced_dialogs():
                if hasattr(planb, 'vitaminar'):
                    try:
                        raw_links = planb.vitaminar(it_vit) or []
                    except Exception as e:
                        xbmc.log("Multi Bridge: PlanB vitaminar error title '%s': %s" % (try_title, str(e)), xbmc.LOGINFO)
                if not raw_links and hasattr(planb, 'findvideos'):
                    try:
                        raw_links = planb.findvideos(it_vit) or []
                    except Exception as e:
                        xbmc.log("Multi Bridge: PlanB findvideos error title '%s': %s" % (try_title, str(e)), xbmc.LOGINFO)
            if raw_links and isinstance(raw_links, list):
                valid_links = []
                for l in raw_links:
                    if getattr(l, 'action', '') == 'play' or getattr(l, 'server', '') or getattr(l, 'url', ''):
                        l.channel = 'PlanB'
                        l.is_vitamina = True
                        l.bridge_engine = 'alfa'
                        valid_links.append(l)
                if valid_links:
                    xbmc.log("Multi Bridge: PlanB encontro %d enlaces para '%s' (try_title='%s')" % (len(valid_links), target_title, try_title), xbmc.LOGINFO)
                    return it_vit, valid_links
            xbmc.log("Multi Bridge: PlanB sin enlaces para try_title='%s'" % try_title, xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("Multi Bridge: PlanB search error: " + str(e), xbmc.LOGWARNING)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGINFO)
    return None, None

def _search_channel_alfa(channel_id, target_title, target_year, is_series, s_num, e_num, all_names, base_item=None, alt_terms=None, target_tmdb=None, target_imdb=None):
    if str(channel_id).lower() in ('planb', 'plan_b'):
        return _search_planb(target_title, target_year, is_series, s_num, e_num, all_names, target_tmdb=target_tmdb, target_imdb=target_imdb)
    mods = _get_alfa_modules()
    if not mods:
        return None, None
    Item = mods['Item']
    terms_to_try = _build_bridge_terms(target_title, alt_terms, all_names)
    if not terms_to_try:
        cleaned = _clean_search_term(target_title)
        if cleaned:
            terms_to_try = [cleaned]
        else:
            return None, None
    xbmc.log("Multi Bridge: %s terms_to_try=%s" % (channel_id, terms_to_try), xbmc.LOGINFO)
    canal = None
    with _engine_lock:
        try:
            _switch_engine_environment('alfa')
            canal = __import__('channels.' + channel_id, fromlist=[''])
            try:
                if hasattr(canal, 'canonical') and isinstance(canal.canonical, dict):
                    canal.canonical['global_search_active'] = True
            except:
                pass
            if hasattr(canal, 'platformtools') and getattr(canal, 'platformtools', None):
                try:
                    canal.platformtools.dialog_yesno = lambda *args, **kwargs: True
                    canal.platformtools.dialog_ok = lambda *args, **kwargs: None
                    canal.platformtools.dialog_select = lambda *args, **kwargs: -1
                    canal.platformtools.dialog_multiselect = lambda *args, **kwargs: []
                    canal.platformtools.dialog_notification = lambda *args, **kwargs: None
                except:
                    pass
            if hasattr(canal, 'tmdb') and getattr(canal, 'tmdb', None):
                try:
                    canal.tmdb.set_infoLabels = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
                    canal.tmdb.set_infoLabels_itemlist = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
                    canal.tmdb.set_infoLabels_item = lambda *args, **kwargs: 0
                except:
                    pass
            if hasattr(canal, 'httptools') and getattr(canal, 'httptools', None):
                try:
                    _ht = canal.httptools
                    _orig_dp_proxy = getattr(_ht, 'downloadpage_proxy', None)
                    if _orig_dp_proxy:
                        def _fast_dp_proxy(c_name, url, *args, **kwargs):
                            kwargs['timeout'] = min(3, kwargs.get('timeout', 3) or 3)
                            try:
                                r = _ht.downloadpage(url, *args, **kwargs)
                                if r and getattr(r, 'sucess', False) and len(getattr(r, 'data', '') or '') > 200:
                                    return r
                            except: pass
                            return type('Resp', (), {'sucess': False, 'code': 500, 'data': '', 'headers': {}})()
                        _ht.downloadpage_proxy = _fast_dp_proxy
                except:
                    pass
            if hasattr(canal, 'read_api') and callable(getattr(canal, 'read_api', None)):
                try:
                    if not getattr(canal.read_api, '_bridge_hooked', False):
                        _orig_ra = canal.read_api
                        def _hooked_ra(*args, **kwargs):
                            data = _orig_ra(*args, **kwargs)
                            try:
                                if isinstance(data, dict):
                                    candidates_lists = []
                                    d_data = data.get('data') if isinstance(data.get('data'), dict) else data
                                    if isinstance(d_data, dict):
                                        for k in ('posts', 'searchFilm', 'items', 'films', 'movies', 'results'):
                                            v = d_data.get(k)
                                            if isinstance(v, list): candidates_lists.append(v)
                                        pag = d_data.get('paginationFilm')
                                        if isinstance(pag, dict) and isinstance(pag.get('items'), list):
                                            candidates_lists.append(pag['items'])

                                    if not hasattr(canal, '_bridge_post_metadata'):
                                        canal._bridge_post_metadata = {}

                                    for cl in candidates_lists:
                                        for p in cl:
                                            if isinstance(p, dict):
                                                pid = p.get('_id') or p.get('id')
                                                rd = str(p.get('release_date') or p.get('first_air_date') or p.get('premiered') or '').strip()
                                                t_str = str(p.get('title') or p.get('name') or p.get('name_es') or '').strip()
                                                orig_t = str(p.get('original_title') or p.get('original_name') or '').strip()
                                                slug_str = str(p.get('slug') or '').strip()
                                                y_found = None
                                                if rd and len(rd) >= 4 and rd[:4].isdigit():
                                                    y_found = int(rd[:4])
                                                elif t_str:
                                                    m_y = re.search(r'\b(19\d\d|20[0-3]\d)\b', t_str)
                                                    if m_y:
                                                        y_found = int(m_y.group(1))
                                                if not y_found and slug_str:
                                                    m_s = re.search(r'\b(19\d\d|20[0-3]\d)\b', slug_str)
                                                    if m_s:
                                                        y_found = int(m_s.group(1))
                                                if pid:
                                                    entry = {
                                                        'year': y_found,
                                                        'title': t_str,
                                                        'original_title': orig_t,
                                                        'release_date': rd
                                                    }
                                                    canal._bridge_post_metadata[str(pid)] = entry
                                                    try: canal._bridge_post_metadata[int(pid)] = entry
                                                    except: pass
                            except Exception:
                                pass
                            return data
                        _hooked_ra._bridge_hooked = True
                        canal.read_api = _hooked_ra
                except Exception:
                    pass
        except Exception as e:
            xbmc.log("Multi Bridge: %s import error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
            return None, None

    search_actions = []
    if not base_item and hasattr(canal, 'mainlist'):
        try:
            with silenced_dialogs():
                mainlist_items = canal.mainlist(Item(channel=channel_id))
                search_actions = [elem for elem in (mainlist_items or []) if getattr(elem, 'action', '') == 'search']
        except Exception as e:
            xbmc.log("Multi Bridge: %s mainlist error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
            search_actions = []

    for cur_term in terms_to_try:
        if xbmc.Monitor().abortRequested():
            break
        results = []
        with silenced_dialogs():
            if search_actions:
                for s_act in search_actions:
                    try:
                        res = canal.search(s_act, cur_term)
                        if isinstance(res, list) and res:
                            results.extend(res)
                    except TypeError:
                        try:
                            res = canal.search(s_act, cur_term, 'tvshow' if is_series else 'movie')
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e2:
                            xbmc.log("Multi Bridge: %s search(s_act) TypeError fallback failed: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log("Multi Bridge: %s search(s_act) error term '%s': %s" % (channel_id, cur_term, str(e)), xbmc.LOGINFO)
            else:
                try:
                    if base_item and hasattr(base_item, 'clone'):
                        try:
                            it_search = base_item.clone()
                        except:
                            it_search = Item(channel=channel_id)
                    else:
                        it_search = Item(channel=channel_id)
                    it_search.channel = channel_id
                    it_search.buscando = cur_term
                    it_search.text = cur_term
                    it_search.terms = cur_term
                    it_search.term = cur_term
                    it_search.c_type = 'search'
                    it_search.search_type = 'tvshow' if is_series else 'movie'
                    if not hasattr(it_search, 'infoLabels') or not isinstance(getattr(it_search, 'infoLabels', None), dict):
                        it_search.infoLabels = {}
                    else:
                        it_search.infoLabels = dict(it_search.infoLabels)
                    # Nunca pre-inyectar tmdb_id/imdb_id/year en it_search.infoLabels antes de canal.search():
                    # muchos canales usan it_search.clone(...) y contaminarían resultados erróneos haciéndolos pasar por válidos.
                    for _pk in ('tmdb_id', 'tmdb', 'imdb_id', 'imdb', 'year', 'release_date', 'premiered'):
                        it_search.infoLabels.pop(_pk, None)
                    try: it_search.year = ''
                    except Exception: pass
                    try: it_search.tmdb_id = ''
                    except Exception: pass
                    if is_series:
                        it_search.contentSerieName = cur_term
                        it_search.contentType = 'tvshow'
                    else:
                        it_search.contentTitle = cur_term
                        it_search.contentType = 'movie'
                    ch_host = None
                    try:
                        if hasattr(canal, 'canonical') and isinstance(canal.canonical, dict):
                            alt = canal.canonical.get('host_alt', [])
                            if alt and isinstance(alt, list) and alt and alt[0].startswith('http'):
                                ch_host = alt[0]
                        if not ch_host and hasattr(canal, 'host') and getattr(canal, 'host', '') and str(canal.host).startswith('http'):
                            ch_host = str(canal.host)
                    except:
                        pass
                    if not getattr(it_search, 'url', '') or not str(it_search.url).startswith('http'):
                        if ch_host:
                            it_search.url = ch_host
                    if hasattr(canal, 'search'):
                        try:
                            res = canal.search(it_search, cur_term)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except TypeError:
                            try:
                                res = canal.search(it_search, cur_term, 'tvshow' if is_series else 'movie')
                                if isinstance(res, list) and res:
                                    results.extend(res)
                            except Exception as e2:
                                xbmc.log("Multi Bridge: %s fallback TypeError2: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log("Multi Bridge: %s fallback search error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    elif hasattr(canal, 'list_all'):
                        try:
                            res = canal.list_all(it_search)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e:
                            xbmc.log("Multi Bridge: %s list_all fallback error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Multi Bridge: %s fallback construction error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
        if not results:
            xbmc.log("Multi Bridge: %s sin resultados para '%s'" % (channel_id, cur_term), xbmc.LOGINFO)
            continue
        xbmc.log("Multi Bridge: %s obtuvo %d resultados para '%s'" % (channel_id, len(results), cur_term), xbmc.LOGINFO)
        if results:
            for it in results:
                try:
                    # 1. Rescate por metadatos de API capturados
                    if hasattr(canal, '_bridge_post_metadata'):
                        pid = getattr(it, '_id', None)
                        if pid is None: pid = getattr(it, 'id', None)
                        if pid is not None and pid in canal._bridge_post_metadata:
                            p_meta = canal._bridge_post_metadata[pid]
                            y_val = p_meta.get('year')
                            if y_val:
                                if not hasattr(it, 'infoLabels') or not isinstance(getattr(it, 'infoLabels', None), dict):
                                    it.infoLabels = {}
                                it.infoLabels['year'] = y_val
                                if p_meta.get('release_date'):
                                    it.infoLabels['release_date'] = p_meta.get('release_date')
                                it.year = y_val
                                if target_year and str(y_val) == str(target_year).strip():
                                    setattr(it, '_web_year_confirmed', True)
                                xbmc.log("Multi Bridge: %s rescatado año %s para '%s' de metadatos API" % (channel_id, y_val, getattr(it, 'title', '')), xbmc.LOGINFO)
                            if p_meta.get('title') and not getattr(it, 'contentTitle', None):
                                it.contentTitle = p_meta.get('title')

                    # 2. Rescate universal para cualquier canal presente o futuro:
                    # Si el item no tiene año en infoLabels/year pero su título o contenido incluye (YYYY) o [YYYY]
                    it_y = None
                    if hasattr(it, 'infoLabels') and isinstance(getattr(it, 'infoLabels', None), dict):
                        it_y = it.infoLabels.get('year')
                    if not it_y:
                        it_y = getattr(it, 'year', None)
                    if not it_y:
                        t_check = getattr(it, 'title', '') or getattr(it, 'contentTitle', '') or ''
                        m_y = re.search(r'[\(\[]\s*(19\d\d|20[0-3]\d)\s*[\)\]]', str(t_check))
                        if m_y:
                            y_parsed = int(m_y.group(1))
                            if not hasattr(it, 'infoLabels') or not isinstance(getattr(it, 'infoLabels', None), dict):
                                it.infoLabels = {}
                            it.infoLabels['year'] = y_parsed
                            it.year = y_parsed
                            if target_year and y_parsed == int(str(target_year).strip()):
                                setattr(it, '_web_year_confirmed', True)
                except Exception:
                    pass
        _enrich_with_tmdb(results, 'alfa')
        candidates = []
        for it in results:
            title_check = getattr(it, 'title', '') or getattr(it, 'contentTitle', '') or getattr(it, 'contentSerieName', '')
            if not title_check:
                continue
            # Filtrar items de paginacion / siguiente pagina que contaminan resultados (ej. CineCalidad, PelisPedia, HDFull)
            _low_title = _safe_str(title_check).lower().strip()
            if any(p in _low_title for p in ['siguiente', 'siguientes', 'next page', 'pagina siguiente', 'página siguiente', 'anterior', 'anteriores']) or _low_title.startswith('>>') or _low_title.startswith('<<') or _low_title.endswith('>>') or _low_title.endswith('<<'):
                xbmc.log(f"Multi Bridge: {channel_id} skip pagination '{title_check}'", xbmc.LOGINFO)
                continue
            score = score_match(title_check, target_year, all_names, target_tmdb=target_tmdb, item=it, target_imdb=target_imdb, is_series=is_series)
            if score <= 0:
                continue
            candidates.append((score, it, title_check))

        candidates.sort(key=lambda c: c[0], reverse=True)

        for score, it, title_check in candidates:
            # Confianza del match (pelis y series): sin TMDb/IMDb ni año no se puede
            # distinguir homonimos (ej. Horas desesperadas 1990 vs 2013, o series homónimas).
            try:
                _it_tmdb_c = _get_item_tmdb(it)
                _it_imdb_c = _get_item_imdb(it)
                _it_year_c = _get_item_year(it, title_check)
                _w_weak = (not _it_tmdb_c and not _it_imdb_c and not _it_year_c)
                _needs_web_check = _w_weak or (not is_series and target_tmdb and not _it_tmdb_c and not _it_imdb_c)
            except Exception:
                _w_weak = False
                _needs_web_check = False
            xbmc.log("Multi Bridge: %s MATCH (score=%d) '%s' para term '%s' (target_year=%s tmdb=%s)%s" % (channel_id, score, title_check, cur_term, target_year, target_tmdb, ' [match debil: sin anio ni ID]' if _w_weak else ''), xbmc.LOGINFO)
            # Chequeo de pagina real: verifica año exacto, IMDb ID y reparto TMDB en la ficha real de la web.
            if _needs_web_check and (target_year or target_imdb or target_tmdb):
                try:
                    if not _detail_year_consistent(getattr(it, 'url', ''), target_year, channel_id, item=it, target_imdb=target_imdb, target_tmdb=target_tmdb, is_series=is_series):
                        xbmc.log("Multi Bridge: %s '%s' descartado: la web muestra otro año, ID o reparto" % (channel_id, title_check), xbmc.LOGINFO)
                        continue
                    if getattr(it, '_web_year_confirmed', False):
                        _w_weak = False
                        if target_tmdb:
                            try:
                                if not hasattr(it, 'infoLabels') or not isinstance(getattr(it, 'infoLabels', None), dict):
                                    it.infoLabels = {}
                                it.infoLabels['tmdb_id'] = str(target_tmdb)
                                it.infoLabels['tmdb'] = str(target_tmdb)
                                it.tmdb_id = str(target_tmdb)
                            except: pass
                        xbmc.log("Multi Bridge [Alfa]: %s confirmado en web (%s), match verificado (no débil)" % (channel_id, target_year or target_imdb or target_tmdb), xbmc.LOGINFO)
                except Exception:
                    pass
            # Conflicto de identidad TMDb (solo Alfa): aunque el match sea
            # FUERTE por IDs, si el titulo traia parentesis con texto
            # significativo ('(Cuenta Atras)') que el limpiador borra, TMDb
            # puede reconocer ese titulo exacto como OTRA pelicula
            # (Hours 2013 vs tmdb 18612). En ese caso se rechaza.
            try:
                if not is_series and target_tmdb:
                    _extra_txt = _stripped_paren_extra(title_check)
                    if _extra_txt and _tmdb_identity_conflict(title_check, target_tmdb, target_year):
                        xbmc.log("Multi Bridge: %s '%s' descartado: TMDb lo identifica como otra pelicula (parentesis '%s')" % (channel_id, title_check, _extra_txt), xbmc.LOGINFO)
                        continue
            except: pass
            if is_series and hasattr(canal, 'episodios'):
                try:
                    if target_tmdb:
                        if not hasattr(it, 'infoLabels') or not isinstance(getattr(it, 'infoLabels', None), dict):
                            it.infoLabels = {}
                        it.infoLabels['tmdb_id'] = str(target_tmdb)
                        it.infoLabels['tvdb_id'] = str(target_tmdb)
                        it.tvdb_id = str(target_tmdb)
                    it.perpage = 500
                    it.page = 0
                    with silenced_dialogs():
                        ep_list = canal.episodios(it)
                    if not ep_list:
                        xbmc.log("Multi Bridge: %s episodios vacio para '%s'" % (channel_id, title_check), xbmc.LOGINFO)
                    for ep in (ep_list or []):
                        ep_season = int(getattr(ep, 'contentSeason', 0) or getattr(ep, 'infoLabels', {}).get('season', 0) or getattr(ep, 'season', 0) or 0)
                        ep_episode = int(getattr(ep, 'contentEpisodeNumber', 0) or getattr(ep, 'infoLabels', {}).get('episode', 0) or getattr(ep, 'episode', 0) or 0)
                        if ep_season == int(s_num or 1) and ep_episode == int(e_num or 1):
                            links = None
                            try:
                                with silenced_dialogs():
                                    links = canal.findvideos(ep) if hasattr(canal, 'findvideos') else None
                            except Exception as e:
                                xbmc.log("Multi Bridge: %s findvideos(ep) error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                            if links and isinstance(links, list) and len(links) > 0:
                                valid = [l for l in links if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                                if valid:
                                    for l in valid:
                                        l.channel = channel_id
                                        l.bridge_engine = 'alfa'
                                        try:
                                            l.bridge_score = int(score)
                                            l.bridge_weak = bool(_w_weak)
                                        except: pass
                                    xbmc.log("Multi Bridge: %s OK serie %dx%d %d enlaces" % (channel_id, ep_season, ep_episode, len(valid)), xbmc.LOGINFO)
                                    return ep, valid
                                else:
                                    xbmc.log("Multi Bridge: %s findvideos(ep) sin enlaces validos" % channel_id, xbmc.LOGINFO)
                            else:
                                xbmc.log("Multi Bridge: %s findvideos(ep) vacio" % channel_id, xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Multi Bridge: %s episodios exception: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    import traceback
                    xbmc.log(traceback.format_exc(), xbmc.LOGINFO)
            elif hasattr(canal, 'findvideos'):
                try:
                    with silenced_dialogs():
                        links = canal.findvideos(it)
                    if links and isinstance(links, list) and len(links) > 0:
                        valid = [l for l in links if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                        valid = _filter_discarded_links(valid)
                        if valid:
                            # Inyeccion TMDb en vivo: si el match es debil, se
                            # confirma contra la API y se inyecta el tmdb
                            # correcto al item (solo memoria, sin tocar disco).
                            _w_conf = bool(getattr(it, '_web_year_confirmed', False))
                            if _w_weak and not _w_conf:
                                try:
                                    _w_conf = _verify_candidate_tmdb(title_check, target_year, target_tmdb, is_series=False)
                                    if _w_conf:
                                        try:
                                            if not hasattr(it, 'infoLabels') or not isinstance(getattr(it, 'infoLabels', None), dict):
                                                it.infoLabels = {}
                                            it.infoLabels['tmdb_id'] = str(target_tmdb)
                                            it.infoLabels['tmdb'] = str(target_tmdb)
                                            it.tmdb_id = str(target_tmdb)
                                        except: pass
                                        xbmc.log("Multi Bridge: %s TMDb confirmado (%s), inyectado" % (channel_id, target_tmdb), xbmc.LOGINFO)
                                except: pass
                            for l in valid:
                                l.channel = channel_id
                                l.bridge_engine = 'alfa'
                                try:
                                    l.bridge_score = int(score)
                                    l.bridge_weak = bool(_w_weak and not _w_conf)
                                except: pass
                            xbmc.log("Multi Bridge: %s OK peli %d enlaces para '%s'" % (channel_id, len(valid), title_check), xbmc.LOGINFO)
                            return it, valid
                        else:
                            xbmc.log("Multi Bridge: %s findvideos sin enlaces validos para '%s'" % (channel_id, title_check), xbmc.LOGINFO)
                    else:
                        xbmc.log("Multi Bridge: %s findvideos vacio para '%s'" % (channel_id, title_check), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Multi Bridge: %s findvideos error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    import traceback
                    xbmc.log(traceback.format_exc(), xbmc.LOGINFO)
        if is_series and candidates:
            break
    return None, None

def _search_channel_balandro(channel_id, target_title, target_year, is_series, s_num, e_num, all_names, base_item=None, alt_terms=None, target_tmdb=None, target_imdb=None):
    mods = _get_balandro_modules()
    if not mods:
        return None, None
    terms_to_try = _build_bridge_terms(target_title, alt_terms, all_names)
    if not terms_to_try:
        cleaned = _clean_search_term(target_title)
        if cleaned:
            terms_to_try = [cleaned]
        else:
            return None, None
    xbmc.log("Multi Bridge [Balandro]: %s terms_to_try=%s" % (channel_id, terms_to_try), xbmc.LOGINFO)
    canal = None
    with _engine_lock:
        try:
            _switch_engine_environment('balandro')
            canal = __import__('channels.' + channel_id, fromlist=[''])
            try:
                if hasattr(canal, 'canonical') and isinstance(canal.canonical, dict):
                    canal.canonical['global_search_active'] = True
            except:
                pass
            if hasattr(canal, 'platformtools') and getattr(canal, 'platformtools', None):
                try:
                    canal.platformtools.dialog_yesno = lambda *args, **kwargs: True
                    canal.platformtools.dialog_ok = lambda *args, **kwargs: None
                    canal.platformtools.dialog_select = lambda *args, **kwargs: -1
                    canal.platformtools.dialog_multiselect = lambda *args, **kwargs: []
                    canal.platformtools.dialog_notification = lambda *args, **kwargs: None
                except:
                    pass
            if hasattr(canal, 'tmdb') and getattr(canal, 'tmdb', None):
                try:
                    canal.tmdb.set_infoLabels = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
                    canal.tmdb.set_infoLabels_itemlist = lambda source=None, *args, **kwargs: (source if isinstance(source, list) else [])
                    canal.tmdb.set_infoLabels_item = lambda *args, **kwargs: 0
                except:
                    pass
            if hasattr(canal, 'httptools') and getattr(canal, 'httptools', None):
                try:
                    _ht = canal.httptools
                    if getattr(getattr(_ht, 'downloadpage_proxy', None), '_bridge_fast', False) is not True:
                        def _fast_dp_proxy(c_name, url, *args, **kwargs):
                            kwargs['timeout'] = min(5, kwargs.get('timeout', 5) or 5)
                            try:
                                r = _ht.downloadpage(url, *args, **kwargs)
                                if r and getattr(r, 'sucess', False) and len(getattr(r, 'data', '') or '') > 200:
                                    return r
                            except: pass
                            return type('Resp', (), {'sucess': False, 'code': 500, 'data': '', 'headers': {}})()
                        _fast_dp_proxy._bridge_fast = True
                        _ht.downloadpage_proxy = _fast_dp_proxy
                except:
                    pass
            # Parche en runtime (solo memoria, sin tocar disco externo):
            # pelispanda.episodios() usa un regex con multiples ".*?" + DOTALL
            # sobre el JSON completo de la serie (~58KB) que provoca backtracking
            # catastrofico (100-150s reteniendo el GIL = freeze total de Kodi).
            # Se sustituye la extraccion por json.loads (0.003s) replicando su
            # logica posterior (paginacion, titulos, idiomas). Si el JSON falla,
            # se delega a la funcion original del canal.
            if str(channel_id).lower() == 'pelispanda' and hasattr(canal, 'episodios'):
                try:
                    if getattr(canal.episodios, '_bridge_json_safe', False) is not True:
                        _orig_panda_episodios = canal.episodios
                        def _pelispanda_episodios_safe(item, *args, **kwargs):
                            try:
                                import json as _pjs
                                import re as _pre
                                if not getattr(item, 'page', None): item.page = 0
                                if not getattr(item, 'perpage', None): item.perpage = 50
                                _data = canal.do_downloadpage(item.url)
                                _data = _pre.sub(r'\n|\r|\t|\s{2}|&nbsp;', '', _data)
                                _matches = []
                                _obj = _pjs.loads(_data)
                                _dls = _obj.get('downloads', []) if isinstance(_obj, dict) else []
                                _season = str(getattr(item, 'contentSeason', ''))
                                for _d in (_dls or []):
                                    if not isinstance(_d, dict): continue
                                    if str(_d.get('season', '')) != _season: continue
                                    _matches.append((str(_d.get('episode', '')), str(_d.get('quality', '')),
                                                     str(_d.get('size', '')), str(_d.get('download_link', '')),
                                                     str(_d.get('language', ''))))
                            except Exception:
                                try:
                                    return _orig_panda_episodios(item, *args, **kwargs)
                                except Exception as _e2:
                                    xbmc.log("Multi Bridge [Balandro]: pelispanda episodios fallback error: %s" % _e2, xbmc.LOGINFO)
                                    return []
                            try:
                                if item.page == 0 and item.perpage == 50:
                                    item.perpage = len(_matches) or 50
                                _itemlist = []
                                for _epis, _qlty, _size, _link, _lang in _matches[item.page * item.perpage:]:
                                    _lang = _lang.replace('\\/', '/')
                                    if 'Latino/Ingles' in _lang: _lang = 'Lat'
                                    elif 'Castellano/Ingles' in _lang: _lang = 'Esp'
                                    elif 'Latino/Japones' in _lang: _lang = 'Vos'
                                    elif 'Castellano' in _lang: _lang = 'Esp'
                                    elif 'Latino' in _lang: _lang = 'Lat'
                                    elif 'Subtitulado' in _lang: _lang = 'Vose'
                                    elif 'Version Original' in _lang: _lang = 'VO'
                                    _link = _link.replace('\\/', '/')
                                    _titulo = str(item.contentSeason) + 'x' + str(_epis) + ' ' + str(getattr(item, 'contentSerieName', '')).replace('&#038;', '&').replace('&#8217;', "'")
                                    try:
                                        _itemlist.append(item.clone(action='findvideos', url=_link, title=_titulo, language=_lang, quality=_qlty, size=_size,
                                                                    contentType='episode', contentSeason=item.contentSeason, contentEpisodeNumber=_epis))
                                    except Exception:
                                        break
                                    if len(_itemlist) >= item.perpage:
                                        break
                                return _itemlist
                            except Exception as _e3:
                                xbmc.log("Multi Bridge [Balandro]: pelispanda episodios safe error: %s" % _e3, xbmc.LOGINFO)
                                return []
                        _pelispanda_episodios_safe._bridge_json_safe = True
                        canal.episodios = _pelispanda_episodios_safe
                except:
                    pass
            # Canales solo-peliculas (sin temporadas ni episodios) no pueden
            # resolver episodios de series: se omiten con log explicito en vez
            # de buscar para nada (ej. repelishd).
            if is_series and not hasattr(canal, 'temporadas') and not hasattr(canal, 'episodios'):
                xbmc.log("Multi Bridge [Balandro]: %s sin soporte para series (solo peliculas), omitido" % channel_id, xbmc.LOGINFO)
                return None, None
        except Exception as e:
            xbmc.log("Multi Bridge [Balandro]: %s import error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
            return None, None

    search_actions = []
    if not base_item and hasattr(canal, 'mainlist'):
        try:
            with silenced_dialogs():
                mainlist_items = canal.mainlist(Item(channel=channel_id))
                filtered_actions = [elem for elem in (mainlist_items or []) if getattr(elem, 'action', '') == 'search' and getattr(elem, 'search_type', '') in ('all', 'tvshow' if is_series else 'movie') and not getattr(elem, 'target_action', '') and not getattr(elem, 'group', '')]
                search_actions = filtered_actions if filtered_actions else [elem for elem in (mainlist_items or []) if getattr(elem, 'action', '') == 'search']
        except Exception as e:
            xbmc.log("Multi Bridge [Balandro]: %s mainlist error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
            search_actions = []

    for cur_term in terms_to_try:
        if xbmc.Monitor().abortRequested():
            break
        results = []
        with silenced_dialogs():
            if search_actions:
                for s_act in search_actions:
                    try:
                        res = canal.search(s_act, cur_term)
                        if isinstance(res, list) and res:
                            results.extend(res)
                    except TypeError:
                        try:
                            res = canal.search(s_act, cur_term, 'tvshow' if is_series else 'movie')
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e2:
                            xbmc.log("Multi Bridge [Balandro]: %s search TypeError fallback: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log("Multi Bridge [Balandro]: %s search error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
            else:
                try:
                    if base_item and hasattr(base_item, 'clone'):
                        try:
                            it_search = base_item.clone()
                        except:
                            it_search = Item(channel=channel_id)
                    else:
                        it_search = Item(channel=channel_id)
                    it_search.channel = channel_id
                    it_search.buscando = cur_term
                    it_search.text = cur_term
                    it_search.terms = cur_term
                    it_search.term = cur_term
                    it_search.c_type = 'search'
                    it_search.search_type = 'tvshow' if is_series else 'movie'
                    if not hasattr(it_search, 'infoLabels') or not isinstance(getattr(it_search, 'infoLabels', None), dict):
                        it_search.infoLabels = {}
                    else:
                        it_search.infoLabels = dict(it_search.infoLabels)
                    # Nunca pre-inyectar tmdb_id/imdb_id/year en it_search.infoLabels antes de canal.search():
                    # muchos canales usan it_search.clone(...) y contaminarían resultados erróneos haciéndolos pasar por válidos.
                    for _pk in ('tmdb_id', 'tmdb', 'imdb_id', 'imdb', 'year', 'release_date', 'premiered'):
                        it_search.infoLabels.pop(_pk, None)
                    try: it_search.year = ''
                    except Exception: pass
                    try: it_search.tmdb_id = ''
                    except Exception: pass
                    if is_series:
                        it_search.contentSerieName = cur_term
                        it_search.contentType = 'tvshow'
                    else:
                        it_search.contentTitle = cur_term
                        it_search.contentType = 'movie'
                    ch_host = None
                    try:
                        if hasattr(canal, 'host') and getattr(canal, 'host', '') and str(canal.host).startswith('http'):
                            ch_host = str(canal.host)
                    except:
                        pass
                    if not getattr(it_search, 'url', '') or not str(it_search.url).startswith('http'):
                        if ch_host:
                            it_search.url = ch_host
                    if hasattr(canal, 'search'):
                        try:
                            res = canal.search(it_search, cur_term)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except TypeError:
                            try:
                                res = canal.search(it_search, cur_term, 'tvshow' if is_series else 'movie')
                                if isinstance(res, list) and res:
                                    results.extend(res)
                            except Exception as e2:
                                xbmc.log("Multi Bridge [Balandro]: %s fallback TypeError2: %s" % (channel_id, str(e2)), xbmc.LOGINFO)
                        except Exception as e:
                            xbmc.log("Multi Bridge [Balandro]: %s fallback error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                    elif hasattr(canal, 'list_all'):
                        try:
                            res = canal.list_all(it_search)
                            if isinstance(res, list) and res:
                                results.extend(res)
                        except Exception as e:
                            xbmc.log("Multi Bridge [Balandro]: %s list_all error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log("Multi Bridge [Balandro]: %s fallback construction error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
        if not results:
            xbmc.log("Multi Bridge [Balandro]: %s sin resultados para '%s'" % (channel_id, cur_term), xbmc.LOGINFO)
            continue
        xbmc.log("Multi Bridge [Balandro]: %s obtuvo %d resultados para '%s'" % (channel_id, len(results), cur_term), xbmc.LOGINFO)
        _debug_nomatch_count = 0
        _enrich_with_tmdb(results, 'balandro')
        candidates = []
        for it in results:
            title_check = getattr(it, 'title', '') or getattr(it, 'contentTitle', '') or getattr(it, 'contentSerieName', '')
            if not title_check:
                continue
            # Filtrar items de paginacion / siguiente pagina que contaminan resultados (ej. CineCalidad, PelisPedia, HDFull)
            _low_title = _safe_str(title_check).lower().strip()
            if any(p in _low_title for p in ['siguiente', 'siguientes', 'next page', 'pagina siguiente', 'página siguiente', 'anterior', 'anteriores']) or _low_title.startswith('>>') or _low_title.startswith('<<') or _low_title.endswith('>>') or _low_title.endswith('<<'):
                xbmc.log(f"Multi Bridge: {channel_id} skip pagination '{title_check}'", xbmc.LOGINFO)
                continue
            score = score_match(title_check, target_year, all_names, target_tmdb=target_tmdb, item=it, target_imdb=target_imdb, is_series=is_series)
            if score <= 0:
                if _debug_nomatch_count < 5:
                    _item_yr = _get_item_year(it, title_check)
                    _item_tmdb = _get_item_tmdb(it)
                    xbmc.log("Multi Bridge [Balandro]: %s NO match '%s' yr=%s tmdb=%s" % (channel_id, title_check, _item_yr, _item_tmdb), xbmc.LOGINFO)
                    _debug_nomatch_count += 1
                continue
            candidates.append((score, it, title_check))

        candidates.sort(key=lambda c: c[0], reverse=True)

        for score, it, title_check in candidates:
            try:
                _it_tmdb_c = _get_item_tmdb(it)
                _it_imdb_c = _get_item_imdb(it)
                _it_year_c = _get_item_year(it, title_check)
                _w_weak = (not _it_tmdb_c and not _it_imdb_c and not _it_year_c)
                _needs_web_check = _w_weak or (not is_series and target_tmdb and not _it_tmdb_c and not _it_imdb_c)
            except Exception:
                _w_weak = False
                _needs_web_check = False
            xbmc.log("Multi Bridge [Balandro]: %s MATCH (score=%d) '%s' para term '%s'%s" % (channel_id, score, title_check, cur_term, ' [match debil: sin anio ni ID]' if _w_weak else ''), xbmc.LOGINFO)
            if _needs_web_check and (target_year or target_imdb or target_tmdb):
                try:
                    if not _detail_year_consistent(getattr(it, 'url', ''), target_year, channel_id, item=it, target_imdb=target_imdb, target_tmdb=target_tmdb, is_series=is_series):
                        xbmc.log("Multi Bridge [Balandro]: %s '%s' descartado: la web muestra otro año, ID o reparto" % (channel_id, title_check), xbmc.LOGINFO)
                        continue
                    if getattr(it, '_web_year_confirmed', False):
                        _w_weak = False
                        if target_tmdb:
                            try:
                                if not hasattr(it, 'infoLabels') or not isinstance(getattr(it, 'infoLabels', None), dict):
                                    it.infoLabels = {}
                                it.infoLabels['tmdb_id'] = str(target_tmdb)
                                it.infoLabels['tmdb'] = str(target_tmdb)
                                it.tmdb_id = str(target_tmdb)
                            except: pass
                        xbmc.log("Multi Bridge [Balandro]: %s confirmado en web (%s), match verificado (no débil)" % (channel_id, target_year or target_imdb or target_tmdb), xbmc.LOGINFO)
                except Exception:
                    pass
            if is_series:
                _target_s = int(s_num or 1)
                _target_e = int(e_num or 1)
                _found_ep = False

                def _ep_nums(ep):
                    """Extrae (season, episode) de un item episodio de Balandro."""
                    s = int(getattr(ep, 'contentSeason', 0) or
                            getattr(ep, 'infoLabels', {}).get('season', 0) or 0)
                    e = int(getattr(ep, 'contentEpisodeNumber', 0) or
                            getattr(ep, 'infoLabels', {}).get('episode', 0) or 0)
                    return s, e

                def _try_ep_list(ep_list):
                    """Busca TODOS los items del episodio correcto (distintos idiomas) y devuelve todos sus links."""
                    _all_valid = []
                    _any_ep = None
                    for ep in (ep_list or []):
                        ep_s, ep_e = _ep_nums(ep)
                        if ep_s == _target_s and ep_e == _target_e:
                            _lk = None
                            try:
                                with silenced_dialogs():
                                    _lk = canal.findvideos(ep) if hasattr(canal, 'findvideos') else None
                            except Exception as _fe:
                                xbmc.log('Multi Bridge [Balandro]: %s findvideos error: %s' % (channel_id, _fe), xbmc.LOGINFO)
                            if _lk and isinstance(_lk, list):
                                valid = [l for l in _lk if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                                if valid:
                                    for l in valid:
                                        l.channel = channel_id
                                        l.bridge_engine = 'balandro'
                                        try:
                                            l.bridge_score = int(score)
                                            l.bridge_weak = bool(_w_weak)
                                        except: pass
                                    _all_valid.extend(valid)
                                    if _any_ep is None:
                                        _any_ep = ep
                    if _all_valid:
                        xbmc.log('Multi Bridge [Balandro]: %s OK serie %sx%s %d enlaces' % (channel_id, _target_s, _target_e, len(_all_valid)), xbmc.LOGINFO)
                        return _any_ep, _all_valid
                    return None, None

                # Patrón estándar Balandro: temporadas() → episodios(season_item)
                if hasattr(canal, 'temporadas') and hasattr(canal, 'episodios'):
                    try:
                        xbmc.log('Multi Bridge [Balandro]: %s show_url=%s' % (channel_id, getattr(it, 'url', '?')[:80]), xbmc.LOGINFO)
                        with silenced_dialogs():
                            seasons = canal.temporadas(it)

                        xbmc.log('Multi Bridge [Balandro]: %s temporadas() -> %d items' % (channel_id, len(seasons) if seasons else 0), xbmc.LOGINFO)
                        if not seasons:
                            pass
                        else:
                            # Detectar si temporadas() ya devolvio episodios directamente
                            # (ocurre en series de 1 sola temporada en hdfull y otros canales)
                            _first = seasons[0]
                            _is_ep_list = (
                                int(getattr(_first, 'contentEpisodeNumber', 0) or 0) > 0 or
                                getattr(_first, 'contentType', '') == 'episode' or
                                getattr(_first, 'action', '') not in ('episodios', 'temporadas', '')
                            )

                            if _is_ep_list:
                                # temporadas() devolvio episodios directamente (1 temporada)
                                xbmc.log('Multi Bridge [Balandro]: %s temporadas devolvio %d eps directo' % (channel_id, len(seasons)), xbmc.LOGINFO)
                                _rep_ep, _rep_lk = _try_ep_list(seasons)
                                if _rep_lk:
                                    return _rep_ep, _rep_lk
                                _found_ep = True
                            else:
                                # Lista de temporadas — buscar la correcta
                                sea_item = None
                                for sea in seasons:
                                    sea_num = int(getattr(sea, 'contentSeason', 0) or
                                                  getattr(sea, 'infoLabels', {}).get('season', 0) or 0)
                                    if sea_num == _target_s:
                                        sea_item = sea
                                        break
                                if sea_item is None:
                                    sea_item = seasons[0]  # fallback a primera temporada
                                xbmc.log('Multi Bridge [Balandro]: %s usando temporada %s' % (channel_id, getattr(sea_item, 'contentSeason', '?')), xbmc.LOGINFO)
                                if target_tmdb:
                                    sea_item.tmdb_id = str(target_tmdb)
                                    if not hasattr(sea_item, 'infoLabels') or not isinstance(sea_item.infoLabels, dict):
                                        sea_item.infoLabels = {}
                                    sea_item.infoLabels['tmdb_id'] = str(target_tmdb)
                                    sea_item.infoLabels['tvdb_id'] = str(target_tmdb)
                                    sea_item.tvdb_id = str(target_tmdb)
                                sea_item.perpage = 500
                                sea_item.page = 0
                                with silenced_dialogs():
                                    ep_list = canal.episodios(sea_item)
                                _rep_ep, _rep_lk = _try_ep_list(ep_list)
                                if _rep_lk:
                                    return _rep_ep, _rep_lk
                                if ep_list:
                                    _found_ep = True
                    except Exception as e:
                        xbmc.log('Multi Bridge [Balandro]: %s temporadas/episodios error: %s' % (channel_id, str(e)), xbmc.LOGINFO)

                # Fallback: intentar episodios() directo en el show (algunos canales lo soportan)
                if not _found_ep and hasattr(canal, 'episodios'):
                    try:
                        _it_fallback = it.clone() if hasattr(it, 'clone') else it
                        _it_fallback.contentSeason = _target_s  # inyectar temporada para canales como homecine
                        if target_tmdb:
                            _it_fallback.tmdb_id = str(target_tmdb)
                            if not hasattr(_it_fallback, 'infoLabels') or not isinstance(_it_fallback.infoLabels, dict):
                                _it_fallback.infoLabels = {}
                            _it_fallback.infoLabels['tmdb_id'] = str(target_tmdb)
                            _it_fallback.infoLabels['tvdb_id'] = str(target_tmdb)
                            _it_fallback.tvdb_id = str(target_tmdb)
                        _it_fallback.perpage = 500
                        _it_fallback.page = 0
                        with silenced_dialogs():
                            ep_list = canal.episodios(_it_fallback)
                        xbmc.log('Multi Bridge [Balandro]: %s episodios fallback(s=%s) -> %d items' % (channel_id, _target_s, len(ep_list) if ep_list else 0), xbmc.LOGINFO)
                        _rep_ep, _rep_lk = _try_ep_list(ep_list)
                        if _rep_lk:
                            return _rep_ep, _rep_lk
                    except Exception as e:
                        xbmc.log('Multi Bridge [Balandro]: %s episodios directo error: %s' % (channel_id, str(e)), xbmc.LOGINFO)

            elif hasattr(canal, 'findvideos'):
                try:
                    with silenced_dialogs():
                        links = canal.findvideos(it)
                    if links and isinstance(links, list) and len(links) > 0:
                        valid = [l for l in links if getattr(l, 'url', '') or getattr(l, 'server', '') or getattr(l, 'action', '') == 'play']
                        valid = _filter_discarded_links(valid)
                        if valid:
                            # Inyeccion TMDb en vivo: si el match es debil, se
                            # confirma contra la API y se inyecta el tmdb
                            # correcto al item (solo memoria, sin tocar disco).
                            _w_conf = bool(getattr(it, '_web_year_confirmed', False))
                            if _w_weak and not _w_conf:
                                try:
                                    _w_conf = _verify_candidate_tmdb(title_check, target_year, target_tmdb, is_series=False)
                                    if _w_conf:
                                        try:
                                            if not hasattr(it, 'infoLabels') or not isinstance(getattr(it, 'infoLabels', None), dict):
                                                it.infoLabels = {}
                                            it.infoLabels['tmdb_id'] = str(target_tmdb)
                                            it.infoLabels['tmdb'] = str(target_tmdb)
                                            it.tmdb_id = str(target_tmdb)
                                        except: pass
                                        xbmc.log("Multi Bridge [Balandro]: %s TMDb confirmado (%s), inyectado" % (channel_id, target_tmdb), xbmc.LOGINFO)
                                except: pass
                            for l in valid:
                                l.channel = channel_id
                                l.bridge_engine = 'balandro'
                                try:
                                    l.bridge_score = int(score)
                                    l.bridge_weak = bool(_w_weak and not _w_conf)
                                except: pass
                            return it, valid
                except Exception as e:
                    xbmc.log("Multi Bridge [Balandro]: %s findvideos error: %s" % (channel_id, str(e)), xbmc.LOGINFO)
        if is_series and candidates:
            break
    return None, None

def _search_on_player(player_data_or_file, engine, is_series, target_title, target_year, s_num, e_num, all_names, alt_terms=None, target_tmdb=None, target_imdb=None):
    try:
        if isinstance(player_data_or_file, dict):
            data = player_data_or_file
            target_channel = data.get('channel') or data.get('id') or ''
            p_engine = data.get('engine', engine)
        else:
            player_file = str(player_data_or_file)
            fpath = os.path.join(TMDB_PLAYERS_PATH, player_file)
            if os.path.exists(fpath):
                with open(fpath, 'r', encoding='utf-8') as f: data = json.load(f)
            else:
                ch_clean = player_file.lower().replace('.json', '')
                prefix = 'alfa-' if engine == 'alfa' else 'balandro-'
                if ch_clean.startswith(prefix): ch_clean = ch_clean[len(prefix):]
                ch_clean = re.sub(r'-(series|movies?)$', '', ch_clean).strip()
                ch_map = load_channels_data().get('channels', {}).get(engine, {})
                data = ch_map.get(ch_clean, {})
            target_channel = data.get('channel', '')
            p_engine = 'alfa' if player_file.lower().startswith('alfa-') else ('balandro' if player_file.lower().startswith('balandro-') else engine)

        key = 'play_episode' if is_series else 'play_movie'
        url_list = data.get(key, [])
        url_str = ''
        if isinstance(url_list, list) and url_list:
            url_str = url_list[0]
        elif isinstance(url_list, str):
            url_str = url_list

        mods = _get_alfa_modules() if p_engine == 'alfa' else _get_balandro_modules()
        if not mods: return None, None
        ItemClass = mods['Item']
        search_item = None

        if url_str:
            if 'plugin://plugin.video.alfa/?' in url_str:
                raw_b64 = url_str.split('plugin://plugin.video.alfa/?')[1].split('&')[0]
                raw_b64 = uparse.unquote(raw_b64)
                search_item = decode_base64_item(raw_b64, ItemClass)
                if not target_channel:
                    target_channel = getattr(search_item, 'channel', '')
            elif 'plugin://plugin.video.balandro/?' in url_str:
                raw_b64 = url_str.split('plugin://plugin.video.balandro/?')[1].split('&')[0]
                raw_b64 = uparse.unquote(raw_b64)
                search_item = decode_base64_item(raw_b64, ItemClass)
                if not target_channel:
                    target_channel = getattr(search_item, 'channel', '')

        if not target_channel:
            target_channel = str(data.get('id', '')).lower()

        if not target_channel or target_channel == 'search': return None, None

        if p_engine == 'alfa':
            res_it, res_links = _search_channel_alfa(target_channel, target_title, target_year, is_series, s_num, e_num, all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
            if res_links:
                res_links = _filter_discarded_links(res_links)
                for l in res_links: l.bridge_engine = 'alfa'
            return res_it, res_links
        else:
            res_it, res_links = _search_channel_balandro(target_channel, target_title, target_year, is_series, s_num, e_num, all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
            if res_links:
                res_links = _filter_discarded_links(res_links)
                for l in res_links: l.bridge_engine = 'balandro'
            return res_it, res_links
    except Exception as e:
        xbmc.log("Multi Bridge: error en _search_on_player: %s" % e, xbmc.LOGWARNING)
        return None, None

# ---------------------------------------------------------
# Master Parallel Search Execution
# ---------------------------------------------------------
_last_autoplay_toggle_ts = [0.0]

def _handle_autoplay_toggle_event(dlg_win=None):
    try:
        now = time.time()
        if now - _last_autoplay_toggle_ts[0] < 0.75:
            return
        _last_autoplay_toggle_ts[0] = now
        win = xbmcgui.Window(10000)
        current = (_bridge_addon.getSetting('autoplay_enabled') == 'true')
        new_val = not current
        _bridge_addon.setSetting('autoplay_enabled', 'true' if new_val else 'false')
        win.setProperty("bridge.autoplay_toggle_active", "true" if new_val else "false")
        lbl = "[COLOR FF00FF7F]●[/COLOR] [B]AUTO PLAY[/B]" if new_val else "[COLOR FFFF3333]●[/COLOR] [B]AUTO PLAY[/B]"
        win.setProperty("bridge.autoplay_toggle_label", lbl)
        if dlg_win:
            try:
                btn = dlg_win.getControl(250)
                if btn: btn.setLabel(lbl)
            except Exception:
                pass
        if not new_val:
            # Solo notificar al pasar de autoplay a modo normal (petición de usuario)
            _show_bridge_notification("Multi Bridge", "Modo normal activado · Se aplicará en el próximo arranque", 3500)
    except Exception as e:
        xbmc.log("Multi Bridge toggle error: %s" % e, xbmc.LOGWARNING)

class _RadialSearchProgressWindow(xbmcgui.WindowXMLDialog):
    PROGRESS_CTRL = 20
    CANCEL_BTN = 200
    AUTOPLAY_BTN = 250

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.is_canceled = False
        self._last_toggle_time = 0

    def _update_autoplay_ui(self, is_active=None):
        try:
            if is_active is None:
                is_active = (_bridge_addon.getSetting('autoplay_enabled') == 'true')
            xbmcgui.Window(10000).setProperty("bridge.autoplay_toggle_active", "true" if is_active else "false")
            lbl = "[COLOR FF00FF7F]●[/COLOR] [B]AUTO PLAY[/B]" if is_active else "[COLOR FFFF3333]●[/COLOR] [B]AUTO PLAY[/B]"
            xbmcgui.Window(10000).setProperty("bridge.autoplay_toggle_label", lbl)
            try:
                btn = self.getControl(self.AUTOPLAY_BTN)
                if btn:
                    btn.setLabel(lbl)
            except Exception:
                pass
        except Exception:
            pass

    def toggle_autoplay(self):
        _handle_autoplay_toggle_event(self)

    def onInit(self):
        self.is_canceled = False
        self._update_autoplay_ui()
        try:
            self.setFocusId(self.CANCEL_BTN)
            btn = self.getControl(self.CANCEL_BTN)
            if btn: self.setFocus(btn)
        except Exception:
            pass
        try:
            xbmc.executebuiltin("SetFocus(200)")
        except:
            pass

    def onAction(self, action):
        try:
            aid = action.getId() if hasattr(action, 'getId') else action
            if aid in (9, 10, 92, 110, 13, 216, 247):
                self.is_canceled = True
                try: xbmcgui.Window(10000).setProperty("bridge.search_canceled", "true")
                except: pass
                self.close()
                return
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == self.AUTOPLAY_BTN:
            return
        if control_id == self.CANCEL_BTN:
            self.is_canceled = True
            try: xbmcgui.Window(10000).setProperty("bridge.search_canceled", "true")
            except: pass
            self.close()

    def onControl(self, control):
        cid = None
        try: cid = control.getId() if hasattr(control, 'getId') else control
        except: pass
        if cid == self.AUTOPLAY_BTN:
            return
        if cid == self.CANCEL_BTN:
            self.is_canceled = True
            try: xbmcgui.Window(10000).setProperty("bridge.search_canceled", "true")
            except: pass
            self.close()


class _RadialSearchProgressDialog(object):
    """Controlador nativo en C++ para el diálogo de progreso con Anillo Radial (progress_radial.xml)."""

    def __init__(self, target_title="", poster_url="", fanart_url="", engine="balandro"):
        self.target_title = target_title or ""
        self.poster_url = poster_url or ""
        self.fanart_url = fanart_url or ""
        self.engine_name = "Alfa" if str(engine).lower() == "alfa" else "Balandro"
        self._dlg = None
        self._canceled = False
        self._last_pct = 0

    def _set_prop(self, k, v):
        try:
            xbmcgui.Window(10000).setProperty(k, str(v if v is not None else ''))
        except Exception:
            pass

    def create(self, heading="", line1="", line2="", line3=""):
        try:
            try: xbmcgui.Window(10000).setProperty("bridge.search_canceled", "")
            except: pass
            self._canceled = False
            skin_dir = "Default"
            xml_file = "progress_radial.xml"
            addon_path = _bridge_addon.getAddonInfo("path")
            self._dlg = _RadialSearchProgressWindow(xml_file, addon_path, skin_dir, "1080i")

            self._set_prop("bridge.search_title", _safe_str(self.target_title))
            self._set_prop("bridge.search_engine", self.engine_name.upper())
            self._set_prop("bridge.search_poster", _safe_str(self.poster_url))
            self._set_prop("bridge.search_fanart", _safe_str(self.fanart_url))
            self._set_prop("bridge.search_pct", "0")
            self._set_prop("bridge.search_channels_count", "0/0")
            self._set_prop("bridge.count_directos", "0")
            self._set_prop("bridge.count_torrents", "0")
            self._set_prop("bridge.count_verificando", "0")
            self._set_prop("bridge.search_status_line", _safe_str(line1 or "Preparando búsqueda..."))
            _cur_auto = (_bridge_addon.getSetting('autoplay_enabled') == 'true')
            self._set_prop("bridge.autoplay_toggle_click", "")
            self._set_prop("bridge.autoplay_toggle_active", "true" if _cur_auto else "false")
            self._set_prop("bridge.autoplay_toggle_label", "[COLOR FF00FF7F]●[/COLOR] [B]AUTO PLAY[/B]" if _cur_auto else "[COLOR FFFF3333]●[/COLOR] [B]AUTO PLAY[/B]")

            self._dlg.show()
            self._start_toggle_watcher()
            def _steal_focus_rad(d=self._dlg):
                for _ms in (0.04, 0.12, 0.25):
                    time.sleep(_ms)
                    try:
                        if d and not getattr(d, 'is_canceled', False):
                            d.setFocusId(200)
                            btn = d.getControl(200)
                            if btn: d.setFocus(btn)
                    except: pass
                    try: xbmc.executebuiltin("SetFocus(200)")
                    except: pass
            threading.Thread(target=_steal_focus_rad, daemon=True).start()
        except Exception as e:
            xbmc.log("Multi Bridge: error abriendo progress_radial.xml: %s (fallback a DialogProgress)" % e, xbmc.LOGWARNING)
            self._dlg = xbmcgui.DialogProgress()
            self._dlg.create(heading or "Multi Bridge", line1, line2, line3)

    def set_metrics(self, completed_str="", n_dir=0, n_tor=0, n_ver=0, status_line=""):
        try:
            if completed_str:
                self._set_prop("bridge.search_channels_count", str(completed_str))
            self._set_prop("bridge.count_directos", str(n_dir))
            self._set_prop("bridge.count_torrents", str(n_tor))
            self._set_prop("bridge.count_verificando", str(n_ver))
            if status_line:
                clean_s = _clean_dialog_text(str(status_line)).strip()
                if clean_s:
                    self._set_prop("bridge.search_status_line", clean_s)
        except Exception:
            pass

    def update(self, pct, message=""):
        if not self._dlg:
            return
        if isinstance(self._dlg, xbmcgui.DialogProgress):
            try: self._dlg.update(pct, message)
            except: pass
            return

        try:
            pct_int = max(getattr(self, '_last_pct', 0), max(0, min(100, int(pct))))
            self._last_pct = pct_int
            self._set_prop("bridge.search_pct", str(pct_int))

            if self._dlg and not getattr(self, '_canceled', False):
                try:
                    p_ctrl = self._dlg.getControl(20)
                    if p_ctrl:
                        p_ctrl.setPercent(pct_int)
                except Exception:
                    pass

            if message:
                lines = message.splitlines() if isinstance(message, str) else []
                header_line = lines[0] if len(lines) > 0 else ""

                m_ch = re.search(r'\((\d+/\d+)\s*canales\)', header_line)
                if m_ch:
                    self._set_prop("bridge.search_channels_count", m_ch.group(1))

                m_dir = re.search(r'(\d+)\s*(?:funcionales|directos)(?!/)', header_line, re.IGNORECASE)
                if m_dir:
                    self._set_prop("bridge.count_directos", m_dir.group(1))

                m_tor = re.search(r'(\d+)\s*torrents', header_line, re.IGNORECASE)
                if m_tor:
                    self._set_prop("bridge.count_torrents", m_tor.group(1))

                m_ver = re.search(r'(?:verificando|comprobando)\s*\((\d+)\)', header_line, re.IGNORECASE)
                if m_ver:
                    self._set_prop("bridge.count_verificando", m_ver.group(1))

                status_txt = ""
                for l in lines[1:]:
                    l_clean = _clean_dialog_text(l).strip()
                    if l_clean and not l_clean.startswith("Buscando:") and not l_clean.startswith("Cancelar"):
                        status_txt = l_clean
                        break
                if not status_txt and len(lines) > 3:
                    status_txt = _clean_dialog_text(lines[-1]).strip()
                if status_txt:
                    self._set_prop("bridge.search_status_line", status_txt)
        except Exception:
            pass

    def _start_toggle_watcher(self):
        self._watcher_stop = False
        def _watch():
            win = xbmcgui.Window(10000)
            mon = xbmc.Monitor()
            while not getattr(self, '_watcher_stop', False) and not getattr(self, '_canceled', False) and not mon.abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
                try:
                    if win.getProperty("bridge.autoplay_toggle_click") == "true":
                        win.setProperty("bridge.autoplay_toggle_click", "")
                        _handle_autoplay_toggle_event(self._dlg)
                except Exception:
                    pass
                if mon.waitForAbort(0.05) or _BG_TASK_ABORT_EVENT.is_set():
                    break
        t = threading.Thread(target=_watch, daemon=True)
        t.name = "BridgeAutoplayToggleWatcher"
        t.start()

    def iscanceled(self):
        try:
            if xbmcgui.Window(10000).getProperty("bridge.search_canceled") == "true":
                self._canceled = True
                return True
        except: pass
        if self._canceled:
            return True
        if not self._dlg:
            return False
        if isinstance(self._dlg, xbmcgui.DialogProgress):
            try: return self._dlg.iscanceled()
            except: return self._canceled
        return bool(getattr(self._dlg, "is_canceled", False))

    def close(self):
        self._watcher_stop = True
        dlg = self._dlg
        self._dlg = None
        if dlg:
            try:
                dlg.close()
            except Exception:
                pass


class _AutoplayProgressWindow(xbmcgui.WindowXMLDialog):
    PROGRESS_CTRL = 20
    CANCEL_BTN = 200
    AUTOPLAY_BTN = 250

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.is_canceled = False
        self._last_toggle_time = 0

    def _update_autoplay_ui(self, is_active=None):
        try:
            if is_active is None:
                is_active = (_bridge_addon.getSetting('autoplay_enabled') == 'true')
            xbmcgui.Window(10000).setProperty("bridge.autoplay_toggle_active", "true" if is_active else "false")
            lbl = "[COLOR FF00FF7F]●[/COLOR] [B]AUTO PLAY[/B]" if is_active else "[COLOR FFFF3333]●[/COLOR] [B]AUTO PLAY[/B]"
            xbmcgui.Window(10000).setProperty("bridge.autoplay_toggle_label", lbl)
            try:
                btn = self.getControl(self.AUTOPLAY_BTN)
                if btn:
                    btn.setLabel(lbl)
            except Exception:
                pass
        except Exception:
            pass

    def toggle_autoplay(self):
        _handle_autoplay_toggle_event(self)

    def onInit(self):
        self.is_canceled = False
        self._update_autoplay_ui()
        try:
            self.setFocusId(self.CANCEL_BTN)
            btn = self.getControl(self.CANCEL_BTN)
            if btn: self.setFocus(btn)
        except Exception:
            pass
        try:
            xbmc.executebuiltin("SetFocus(200)")
        except:
            pass

    def onAction(self, action):
        try:
            aid = action.getId() if hasattr(action, 'getId') else action
            if aid in (9, 10, 92, 110, 13, 216, 247):
                self.is_canceled = True
                try: xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
                except: pass
                self.close()
                return
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == self.AUTOPLAY_BTN:
            return
        if control_id == self.CANCEL_BTN:
            self.is_canceled = True
            try: xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
            except: pass
            self.close()

    def onControl(self, control):
        cid = None
        try: cid = control.getId() if hasattr(control, 'getId') else control
        except: pass
        if cid == self.AUTOPLAY_BTN:
            return
        if cid == self.CANCEL_BTN:
            self.is_canceled = True
            try: xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
            except: pass
            self.close()


class _AutoplayProgressDialog(object):
    """Controlador nativo para el diálogo de reproducción automática exclusivo (autoplay.xml)."""

    def __init__(self, target_title="", poster_url="", fanart_url="", extra_info="", meta=None, season=None, episode=None):
        self.target_title = target_title or ""
        self.poster_url = poster_url or ""
        self.fanart_url = fanart_url or ""
        self.extra_info = extra_info or ""
        self.meta = meta or {}
        self._dlg = None
        self._canceled = False

        # Extraer temporada y episodio con resolución jerárquica
        s_val = season
        e_val = episode
        if s_val is None and self.meta and isinstance(self.meta, dict):
            s_val = self.meta.get('season')
        if e_val is None and self.meta and isinstance(self.meta, dict):
            e_val = self.meta.get('episode')
        if s_val is None:
            try: s_val = globals().get('season') or get_param('season')
            except Exception: pass
        if e_val is None:
            try: e_val = globals().get('episode') or get_param('episode')
            except Exception: pass

        self.episode_label = ""
        try:
            if s_val is not None and e_val is not None and str(s_val).strip() and str(e_val).strip() and str(s_val).strip() not in ('None', '_') and str(e_val).strip() not in ('None', '_'):
                s_int = int(str(s_val).strip())
                e_int = int(str(e_val).strip())
                self.episode_label = "S%02dE%02d" % (s_int, e_int)
        except Exception:
            self.episode_label = ""

    def _set_prop(self, k, v):
        try:
            xbmcgui.Window(10000).setProperty(k, str(v if v is not None else ''))
        except Exception:
            pass

    def create(self, heading="", line1="", line2="", line3=""):
        try:
            self._set_prop("bridge.autoplay_canceled", "false")
            self._canceled = False
            skin_dir = "Default"
            xml_file = "autoplay.xml"
            addon_path = _bridge_addon.getAddonInfo("path")
            self._dlg = _AutoplayProgressWindow(xml_file, addon_path, skin_dir, "1080i")

            self._set_prop("bridge.autoplay_title", _safe_str(self.target_title))
            self._set_prop("bridge.autoplay_episode_label", _safe_str(self.episode_label))
            if self.episode_label:
                self._set_prop("bridge.autoplay_episode_display", "  •  [COLOR yellow][B]" + self.episode_label + "[/B][/COLOR]")
            else:
                self._set_prop("bridge.autoplay_episode_display", "")
            self._set_prop("bridge.autoplay_poster", _safe_str(self.poster_url))
            self._set_prop("bridge.autoplay_fanart", _safe_str(self.fanart_url))
            self._set_prop("bridge.autoplay_extra", _safe_str(_get_single_genre(self.extra_info) or self.extra_info))
            self._set_prop("bridge.autoplay_status", _safe_str(line1 or "Iniciando reproducción..."))
            self._set_prop("bridge.autoplay_server", "")
            self._set_prop("bridge.autoplay_quality", "")
            self._set_prop("bridge.autoplay_language", "")
            self._set_prop("bridge.autoplay_channel", "")
            _cur_auto = (_bridge_addon.getSetting('autoplay_enabled') == 'true')
            self._set_prop("bridge.autoplay_toggle_click", "")
            self._set_prop("bridge.autoplay_toggle_active", "true" if _cur_auto else "false")
            self._set_prop("bridge.autoplay_toggle_label", "[COLOR FF00FF7F]●[/COLOR] [B]AUTO PLAY[/B]" if _cur_auto else "[COLOR FFFF3333]●[/COLOR] [B]AUTO PLAY[/B]")

            self._dlg.show()
            self._start_toggle_watcher()
            def _steal_focus_rad(d=self._dlg):
                for _ms in (0.04, 0.12, 0.25):
                    time.sleep(_ms)
                    try:
                        if d and not getattr(d, 'is_canceled', False):
                            d.setFocusId(200)
                            btn = d.getControl(200)
                            if btn: d.setFocus(btn)
                    except: pass
                    try: xbmc.executebuiltin("SetFocus(200)")
                    except: pass
            threading.Thread(target=_steal_focus_rad, daemon=True).start()
        except Exception as e:
            xbmc.log("Multi Bridge: error abriendo autoplay.xml: %s (fallback a DialogProgress)" % e, xbmc.LOGWARNING)
            self._dlg = xbmcgui.DialogProgress()
            self._dlg.create(heading or "Multi Bridge", line1, line2, line3)

    def set_episode(self, season=None, episode=None):
        try:
            if season is not None and episode is not None:
                s_int = int(str(season).strip())
                e_int = int(str(episode).strip())
                self.episode_label = "S%02dE%02d" % (s_int, e_int)
                self._set_prop("bridge.autoplay_episode_label", self.episode_label)
                self._set_prop("bridge.autoplay_episode_display", "  •  [COLOR yellow][B]" + self.episode_label + "[/B][/COLOR]")
        except Exception:
            pass

    def set_stream_info(self, server="", quality="", language="", channel="", status=""):
        try:
            if server: self._set_prop("bridge.autoplay_server", _safe_str(server).upper())
            if quality: self._set_prop("bridge.autoplay_quality", _safe_str(quality).upper())
            if language: self._set_prop("bridge.autoplay_language", _safe_str(language).upper())
            if channel: self._set_prop("bridge.autoplay_channel", _safe_str(channel))
            if status: self._set_prop("bridge.autoplay_status", _safe_str(status))
        except Exception:
            pass

    def update(self, pct, message=""):
        if not self._dlg:
            return
        if isinstance(self._dlg, xbmcgui.DialogProgress):
            try: self._dlg.update(int(pct), message or "")
            except: pass
            return

        try:
            p_ctrl = self._dlg.getControl(20)
            if p_ctrl:
                p_ctrl.setPercent(int(pct))
        except Exception:
            pass

        if message:
            clean_msg = _clean_dialog_text(str(message)).strip()
            if clean_msg:
                self._set_prop("bridge.autoplay_status", clean_msg)

    def _start_toggle_watcher(self):
        self._watcher_stop = False
        def _watch():
            win = xbmcgui.Window(10000)
            mon = xbmc.Monitor()
            while not getattr(self, '_watcher_stop', False) and not getattr(self, '_canceled', False) and not mon.abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
                try:
                    if win.getProperty("bridge.autoplay_toggle_click") == "true":
                        win.setProperty("bridge.autoplay_toggle_click", "")
                        _handle_autoplay_toggle_event(self._dlg)
                except Exception:
                    pass
                if mon.waitForAbort(0.05) or _BG_TASK_ABORT_EVENT.is_set():
                    break
        t = threading.Thread(target=_watch, daemon=True)
        t.name = "BridgeAutoplayToggleWatcher"
        t.start()

    def iscanceled(self):
        if self._canceled:
            return True
        if self._dlg:
            if isinstance(self._dlg, xbmcgui.DialogProgress):
                return self._dlg.iscanceled()
            if getattr(self._dlg, "is_canceled", False):
                self._canceled = True
                return True
        prop = xbmcgui.Window(10000).getProperty("bridge.autoplay_canceled")
        if prop == "true":
            self._canceled = True
            return True
        return False

    def close(self):
        self._watcher_stop = True
        if self._dlg:
            try:
                self._dlg.close()
            except Exception:
                pass
            self._dlg = None
        self._set_prop("bridge.autoplay_canceled", "false")


def _run_parallel_search_impl(engine='alfa'):
    if not _is_engine_installed(engine):
        xbmc.log("Multi Bridge: El motor %s no está instalado. Cancelando búsqueda." % engine, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Multi Bridge', 'El addon %s no está instalado' % engine.capitalize(), '', 3000)
        return [], None

    p_title = title or get_param('title') or get_param('title_es') or get_param('title_lat') or get_param('title_orig') or get_param('title_en') or ''
    p_showname = showname or get_param('showname') or ''
    p_year = year or get_param('year') or ''
    p_showyear = showyear or get_param('showyear') or ''
    p_season = season or get_param('season') or ''
    p_episode = episode or get_param('episode') or ''
    p_tmdb = tmdb_id or get_param('tmdb') or ''
    p_imdb = imdb_id or get_param('imdb') or ''

    is_series = bool(p_season and p_episode)
    if is_series and engine == 'alfa':
        xbmc.log("Multi Bridge: Alfa solo soporta películas. Cambiando motor a Balandro para series.", xbmc.LOGINFO)
        engine = 'balandro'
        if not _is_engine_installed('balandro'):
            xbmcgui.Dialog().ok('Multi Bridge', 'Para reproducir series se requiere tener instalado el addon Balandro.')
            return [], None

    if is_series:
        target_title = (p_showname or p_title or '').strip()
        target_year = p_showyear or p_year
        all_names = [t for t in [target_title, p_showname, title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_en or get_param('title_en'), title_orig or get_param('title_orig')] if t]
        # Extraer variantes entre parentesis para series (ej. "The Chosen (Los elegidos)" -> "The Chosen", "Los elegidos")
        for _n in list(all_names):
            if '(' in _n and ')' in _n:
                for inside in re.findall(r'\((.*?)\)', _n):
                    inside_clean = inside.strip()
                    if inside_clean and not re.match(r'^\d{4}$', inside_clean) and inside_clean not in all_names:
                        all_names.append(inside_clean)
                outside = re.sub(r'\(.*?\)', '', _n).strip()
                if outside and outside not in all_names:
                    all_names.append(outside)
        alt_terms = [t for t in all_names if t != target_title]
    else:
        target_title = (p_title or '').strip()
        target_year = p_year
        all_names = [t for t in [target_title, title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_en or get_param('title_en'), title_orig or get_param('title_orig')] if t]
        alt_terms = [t for t in [title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_orig or get_param('title_orig'), title_en or get_param('title_en')] if t and t != target_title]

    target_tmdb = p_tmdb
    target_imdb = p_imdb

    ch_data = load_channels_data()
    engine_channels = ch_data.get('channels', {}).get(engine, {})

    enabled_players = []
    for ch_id in sorted(engine_channels.keys(), key=lambda k: engine_channels[k].get('name', k).lower()):
        ch_info = engine_channels[ch_id]
        if is_series:
            if not ch_info.get('series'): continue
            if ch_info.get('series_disabled'): continue
        else:
            if not ch_info.get('movies'): continue
            if ch_info.get('movie_disabled'): continue
        enabled_players.append(ch_info)

    if not enabled_players: return [], None

    # PlanB (vitaminar) es el mas lento y valioso: arrancarlo primero en Alfa.
    if engine == 'alfa':
        try:
            _pb = [ch for ch in enabled_players if 'planb' in str(ch.get('channel', '')).lower() or 'planb' in str(ch.get('id', '')).lower()]
            _rest = [ch for ch in enabled_players if 'planb' not in str(ch.get('channel', '')).lower() and 'planb' not in str(ch.get('id', '')).lower()]
            if _pb:
                enabled_players = _pb + _rest
                xbmc.log('Multi Bridge: PlanB priorizado al inicio de la cola', xbmc.LOGINFO)
        except: pass

    # Respetar el ajuste del usuario (antes se recortaba a 18s aunque el
    # ajuste permite hasta 120s): en PCs lentos los canales necesitan mas.
    # Alfa necesita mas margen (vitaminar de PlanB tarda ~45s): suelo de 60s
    # solo en Alfa (Balandro queda con el ajuste del usuario tal cual).
    timeout_secs = min(120, max(10, _get_int_setting('search_timeout', 40)))
    if engine == 'alfa':
        timeout_secs = min(120, max(60, timeout_secs))
    if is_series:
        timeout_secs = min(122, timeout_secs + 2)
        xbmc.log('Multi Bridge: modo serie, timeout ajustado a %ds' % timeout_secs, xbmc.LOGINFO)
    max_search_workers = min(35, max(1, _get_int_setting('search_threads_max', 6)))

    total_channels = len(enabled_players)
    engine_name = 'Alfa' if engine == 'alfa' else 'Balandro'

    p_poster = poster or get_param('poster') or thumbnail or get_param('thumbnail') or get_param('thumb') or ''
    p_fanart = fanart or get_param('fanart') or ''
    if not p_poster:
        try: p_poster = xbmcgui.Window(10000).getProperty('TMDbHelper.ListItem.Poster') or xbmc.getInfoLabel('ListItem.Art(poster)') or xbmc.getInfoLabel('ListItem.Art(thumb)') or xbmc.getInfoLabel('ListItem.Thumb') or xbmc.getInfoLabel('Container.ListItem.Art(poster)')
        except: pass
    if not p_fanart:
        try: p_fanart = xbmcgui.Window(10000).getProperty('TMDbHelper.ListItem.Fanart') or xbmc.getInfoLabel('ListItem.Art(fanart)') or xbmc.getInfoLabel('Container.ListItem.Art(fanart)')
        except: pass
    if not p_poster and target_tmdb and str(target_tmdb).strip().isdigit():
        try:
            import urllib.request as _ureq
            import json as _json
            import ssl as _ssl
            _ctx = _ssl._create_unverified_context() if hasattr(_ssl, '_create_unverified_context') else None
            _api_k = "a1ab8b8669da03637a4b98fa39c39228"
            _t_type = "tv" if is_series else "movie"
            _u_art = f"https://api.themoviedb.org/3/{_t_type}/{target_tmdb}?api_key={_api_k}"
            _req = _ureq.Request(_u_art, headers={'User-Agent': 'Mozilla/5.0'})
            with _ureq.urlopen(_req, timeout=1.5, context=_ctx) as _resp:
                _dart = _json.loads(_resp.read().decode('utf-8'))
                _pp = _dart.get('poster_path')
                _bp = _dart.get('backdrop_path')
                if _pp: p_poster = f"https://image.tmdb.org/t/p/w500{_pp}"
                if _bp and not p_fanart: p_fanart = f"https://image.tmdb.org/t/p/w1280{_bp}"
        except Exception:
            pass

    dlg_display_title = target_title
    if is_series and p_season and p_episode:
        try:
            ep_tag = 'S%02dE%02d' % (int(p_season), int(p_episode))
        except (ValueError, TypeError):
            ep_tag = 'S%sE%s' % (p_season, p_episode)
        dlg_display_title = ('%s • %s' % (target_title, ep_tag)) if target_title else ep_tag

    p_dialog = _RadialSearchProgressDialog(target_title=dlg_display_title, poster_url=p_poster, fanart_url=p_fanart, engine=engine)
    p_dialog.create('Multi Bridge (%s)' % engine_name, 'Preparando busqueda en %d canales...' % total_channels)
    # Complementar titulos solo si faltan variantes en películas (en series el nombre ya está resuelto)
    try:
        _distinct = len(set([_safe_str(x).lower().strip() for x in all_names if x]))
        if target_tmdb and _distinct < 3:
            p_dialog.update(5, 'Obteniendo titulos TMDB...')
            fetched = _fetch_tmdb_titles(target_tmdb, is_series)
            xbmc.log(f"Multi Bridge: fetched TMDB titles for {target_tmdb}: {fetched}", xbmc.LOGINFO)
            for ft in fetched:
                if ft and ft not in all_names:
                    all_names.append(ft)
                if ft and ft != target_title and ft not in alt_terms:
                    alt_terms.append(ft)
            xbmc.log(f"Multi Bridge: run_parallel_search target_title='{target_title}' all_names={all_names} alt_terms={alt_terms}", xbmc.LOGINFO)
        else:
            xbmc.log(f"Multi Bridge: run_parallel_search (sin fetch) target_title='{target_title}' all_names={all_names} alt_terms={alt_terms}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Multi Bridge: fetch titles error: {e}", xbmc.LOGINFO)
    # Variantes con alias de traduccion (wolverine/lobezno...) para cazar
    # matches entre idiomas que el puntuador no puede unir solo.
    try:
        for _av in _alias_variants(all_names):
            if _av not in all_names:
                all_names.append(_av)
            if _av != target_title and _av not in alt_terms:
                alt_terms.append(_av)
    except Exception:
        pass
    p_dialog.update(0, 'Buscando en tus %d canales de %s...' % (total_channels, engine_name))

    # Pre-importar canales secuencialmente para evitar contencion de lock al inicio (acelera arranque)
    try:
        p_dialog.update(2, 'Preparando canales...')
        for ch_info in enabled_players:
            try:
                _ch = str(ch_info.get('channel') or ch_info.get('id') or '').strip().lower()
                if not _ch or _ch == 'search':
                    continue
                with _engine_lock:
                    _switch_engine_environment(engine)
                    __import__('channels.' + _ch, fromlist=[''])
            except:
                pass
            if xbmc.Monitor().abortRequested() or p_dialog.iscanceled():
                break
        xbmc.log(f"Multi Bridge: pre-import completado para {len(enabled_players)} canales", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Multi Bridge: pre-import error: {e}", xbmc.LOGINFO)

    _auto_verify = (_bridge_addon.getSetting('auto_verify_links') == 'true')
    pipeline_verifier = None
    if _auto_verify:
        try:
            pipeline_verifier = _PipelineLinkVerifier(engine=engine)
            pipeline_verifier.start()
        except Exception as e:
            xbmc.log("Multi Bridge: Error iniciando pipeline verifier: %s" % e, xbmc.LOGWARNING)
            pipeline_verifier = None

    results_dict = {}
    threads = []
    def _worker(ch_info):
        try:
            ch_key = ch_info.get('id') or ch_info.get('channel')
            it, links = _search_on_player(ch_info, engine, is_series, target_title, target_year, p_season, p_episode, all_names, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
            if it and links:
                results_dict[ch_key] = (it, links)
                if pipeline_verifier:
                    pipeline_verifier.feed(links)
        except Exception: pass

    for ch_info in enabled_players:
        threads.append(threading.Thread(target=_worker, args=(ch_info,), daemon=True))

    started_indices = set()
    completed_indices = set()
    finished_channels = []

    def clean_name(ch_info):
        if isinstance(ch_info, dict):
            return ch_info.get('name') or ch_info.get('channel') or ch_info.get('id') or ''
        n = str(ch_info).replace('.json', '')
        n = re.sub(r'^(Alfa|Balandro)-', '', n, flags=re.IGNORECASE)
        return re.sub(r'-(Series|Movies?)$', '', n, flags=re.IGNORECASE).strip()

    start_time = time.time()
    thread_start_times = {}
    if engine == 'alfa':
        channel_timeout = 25 if is_series else 20
    else:
        channel_timeout = 10 if is_series else 8
    i = 0
    while not xbmc.Monitor().abortRequested():
        now = time.time()
        active_cnt = len([idx for idx in started_indices if idx not in completed_indices and threads[idx].is_alive()])
        while i < len(threads) and active_cnt < max_search_workers:
            threads[i].start()
            started_indices.add(i)
            thread_start_times[i] = now
            active_cnt += 1
            i += 1

        for idx, ch_info in enumerate(enabled_players):
            if idx in started_indices and idx not in completed_indices:
                st = thread_start_times.get(idx, start_time)
                is_alive = threads[idx].is_alive()
                ch_key = ch_info.get('id') or ch_info.get('channel') if isinstance(ch_info, dict) else ch_info
                if engine == 'alfa':
                    if not is_alive:
                        completed_indices.add(idx)
                        found = ch_key in results_dict
                        finished_channels.append((clean_name(ch_info), found))
                elif not is_alive or (now - st > channel_timeout):
                    completed_indices.add(idx)
                    found = ch_key in results_dict
                    finished_channels.append((clean_name(ch_info), found))

        completed = len(completed_indices)
        if pipeline_verifier:
            pct = min(85, int((completed / float(total_channels)) * 85)) if total_channels else 85
        else:
            pct = int((completed / float(total_channels)) * 100) if total_channels else 100
        lines = []
        recent = finished_channels[-4:]
        for ch_name, found in recent:
            if found: lines.append('[COLOR lime][OK] %s[/COLOR]' % ch_name)
            else: lines.append('[COLOR grey][--] %s[/COLOR]' % ch_name)
        while len(lines) < 4: lines.append('')

        active_names = [clean_name(enabled_players[idx]) for idx in started_indices if idx not in completed_indices and threads[idx].is_alive()][:3]
        active_str = ', '.join(active_names) if active_names else 'Finalizando...'
        if pipeline_verifier:
            v_dir, v_tor, v_cap, v_act, v_q = pipeline_verifier.get_stats()
            v_parts = []
            if v_dir > 0:
                v_parts.append('[COLOR lime]%d funcionales[/COLOR]' % v_dir)
            if v_tor > 0:
                v_parts.append('[COLOR cyan]%d torrents[/COLOR]' % v_tor)
            if v_cap > 0:
                v_parts.append('[COLOR orange]%d captchas[/COLOR]' % v_cap)
            if v_act > 0 or v_q > 0:
                v_parts.append('[COLOR yellow]verificando (%d)[/COLOR]' % (v_act + v_q))
            v_tag = (' • ' + ' | '.join(v_parts)) if v_parts else ''
            if hasattr(p_dialog, 'set_metrics'):
                p_dialog.set_metrics(
                    completed_str='%d/%d' % (completed, total_channels),
                    n_dir=v_dir, n_tor=v_tor + v_cap, n_ver=v_act + v_q,
                    status_line=lines[0] or active_str
                )
            p_dialog.update(pct, '%s (%d/%d canales)%s\n%s\n%s\nBuscando: %s' % (target_title, completed, total_channels, v_tag, lines[0], lines[1], active_str))
        else:
            raw_dir = 0
            raw_tor = 0
            raw_cap = 0
            for _k, _val in list(results_dict.items()):
                if _val and len(_val) > 1 and _val[1]:
                    for _l in _val[1]:
                        if _is_torrent_link(_l):
                            raw_tor += 1
                        elif _is_web_captcha_server(_get_link_server_name(_l), _l):
                            raw_cap += 1
                        else:
                            raw_dir += 1
            if hasattr(p_dialog, 'set_metrics'):
                p_dialog.set_metrics(
                    completed_str='%d/%d' % (completed, total_channels),
                    n_dir=raw_dir, n_tor=raw_tor + raw_cap, n_ver=0,
                    status_line=lines[0] or active_str
                )
            r_parts = []
            if raw_dir > 0:
                r_parts.append('[COLOR lime]%d directos[/COLOR]' % raw_dir)
            if raw_tor > 0:
                r_parts.append('[COLOR cyan]%d torrents[/COLOR]' % raw_tor)
            if raw_cap > 0:
                r_parts.append('[COLOR orange]%d captchas[/COLOR]' % raw_cap)
            r_tag = (' • ' + ' | '.join(r_parts)) if r_parts else ''
            p_dialog.update(pct, '%s (%d/%d canales)%s\n%s\n%s\nBuscando: %s' % (target_title, completed, total_channels, r_tag, lines[0], lines[1], active_str))

        elapsed = now - start_time
        if completed >= total_channels or elapsed > timeout_secs:
            break

        if p_dialog.iscanceled():
            xbmc.log("Multi Bridge: búsqueda cancelada por el usuario", xbmc.LOGINFO)
            break
        time.sleep(0.1)

    if pipeline_verifier:
        if p_dialog.iscanceled():
            pipeline_verifier.global_stop.set()
        else:
            pipeline_verifier.finish_post_search(target_title=target_title, p_dialog=p_dialog)

    try:
        p_dialog.close()
    except: pass
    del p_dialog
    try:
        xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
    except: pass

    _is_user_canceled = False
    try:
        _is_user_canceled = (xbmcgui.Window(10000).getProperty("bridge.search_canceled") == "true")
    except: pass

    if not _is_user_canceled:
        try:
            xbmc.sleep(200)
        except:
            time.sleep(0.2)
        if not results_dict:
            _grace_start = time.time()
            while time.time() - _grace_start < 2.0:
                if results_dict or xbmc.Monitor().abortRequested() or (xbmcgui.Window(10000).getProperty("bridge.search_canceled") == "true"):
                    break
                time.sleep(0.1)

    all_links = []
    matched_item = None
    for ch_info in enabled_players:
        ch_key = ch_info.get('id') or ch_info.get('channel') if isinstance(ch_info, dict) else ch_info
        if ch_key in results_dict:
            it, links = results_dict[ch_key]
            if not matched_item and it: matched_item = it
            for lnk in links: all_links.append(lnk)

    global _PIPELINE_VERIFIED_SEARCH
    _PIPELINE_VERIFIED_SEARCH = False

    if pipeline_verifier:
        v_res = pipeline_verifier.get_results(fallback_links=all_links)
        if v_res and v_res is not all_links:
            all_links = v_res
            _PIPELINE_VERIFIED_SEARCH = True
            if matched_item:
                try: setattr(matched_item, '_pipeline_verified', True)
                except: pass
            xbmc.log("Multi Bridge: Pipeline verifier completado: %d enlaces funcionales listos" % len(all_links), xbmc.LOGINFO)
        else:
            xbmc.log("Multi Bridge: Pipeline verifier no obtuvo enlaces válidos, usando resultados brutos (%d)" % len(all_links), xbmc.LOGINFO)

    # Foto para el recolector tardio: que canales entraron y donde quedaron
    # los resultados de los hilos que sigan vivos tras el cierre.
    try:
        global _LAST_SEARCH_TOKEN, _LAST_MERGED_PFS, _LAST_RESULTS_DICT, _LAST_SEARCH_THREADS
        _LAST_MERGED_PFS = set(
            (ch.get('name') or ch.get('channel') or ch.get('id'))
            for ch in enabled_players
            if (ch.get('id') or ch.get('channel') if isinstance(ch, dict) else ch) in results_dict
        )
        _LAST_RESULTS_DICT = results_dict
        _LAST_SEARCH_TOKEN = (str(engine), str(target_tmdb or ''), str(p_season or ''), str(p_episode or ''), time.time())
        _LAST_SEARCH_THREADS = [
            ((ch.get('name') or ch.get('channel') or ch.get('id') or 'Canal'), threads[idx], (ch.get('id') or ch.get('channel') if isinstance(ch, dict) else ch))
            for idx, ch in enumerate(enabled_players)
            if idx in started_indices and threads[idx].is_alive()
        ]
    except: pass

    all_links = _filter_and_sort_links(all_links)
    return all_links, matched_item

def _append_late_links(engine, target_tmdb, season, episode, new_links, channel_name=''):
    """Anexa enlaces tardios a la cache (RAM + fichero) sin reordenar lo ya
    mostrado, y refresca el contenedor solo si nuestra lista sigue abierta.
    Devuelve el nº anexado (0 si la busqueda ya fue superada por otra)."""
    added = 0
    try:
        if not new_links:
            return 0
        tmdb_s = _norm_id_str(target_tmdb)
        sea_s = _norm_id_str(season)
        epi_s = _norm_id_str(episode)

        ram = _RAM_SEARCH_CACHE
        if ram:
            r_tmdb = _norm_id_str(ram.get('tmdb'))
            if tmdb_s and r_tmdb and r_tmdb != tmdb_s:
                return 0
            if sea_s and _norm_id_str(ram.get('season')) and _norm_id_str(ram.get('season')) != sea_s:
                return 0
            if epi_s and _norm_id_str(ram.get('episode')) and _norm_id_str(ram.get('episode')) != epi_s:
                return 0

        _sc = _read_search_cache_atomic()
        if not _sc or not isinstance(_sc, dict):
            return 0

        _meta = _sc.get('meta', {}) or {}
        sc_tmdb = _norm_id_str(_meta.get('tmdb'))
        if tmdb_s and sc_tmdb and sc_tmdb != tmdb_s:
            return 0
        if sea_s and _norm_id_str(_meta.get('season')) and _norm_id_str(_meta.get('season')) != sea_s:
            return 0
        if epi_s and _norm_id_str(_meta.get('episode')) and _norm_id_str(_meta.get('episode')) != epi_s:
            return 0

        # Si la búsqueda principal tenía activada la verificación automática de enlaces,
        # verificar también en segundo plano los enlaces tardíos antes de añadirlos
        if _bridge_addon.getSetting('auto_verify_links') == 'true' or _meta.get('verified_only'):
            try:
                xbmc.log("Multi Bridge: verificando %d enlaces tardíos en segundo plano..." % len(new_links), xbmc.LOGINFO)
                v_late = _verify_links_headless(new_links, engine=engine, p_dialog=None)
                if not v_late:
                    xbmc.log("Multi Bridge: ningún enlace tardío superó la verificación", xbmc.LOGINFO)
                    return 0
                new_links = v_late
            except Exception as _ve:
                xbmc.log("Multi Bridge: error verificando enlaces tardíos: %s" % _ve, xbmc.LOGWARNING)

        _cur = _sc.get('links', []) or []
        _have_urls = set()
        for _d in _cur:
            try:
                if isinstance(_d, dict):
                    u = str(_d.get('url') or '')
                    if u: _have_urls.add(u)
            except: pass

        _ser = []
        fresh_raw = []
        for _l in new_links:
            try:
                u = str(getattr(_l, 'url', '') or '')
                if u and u not in _have_urls:
                    _have_urls.add(u)
                    _d = _serialize_item(_l)
                    if _d:
                        _ser.append(_d)
                        fresh_raw.append(_l)
            except: pass

        if not _ser:
            return 0

        _sc['links'] = _cur + _ser
        if not _save_search_cache_atomic(_sc):
            return 0

        added = len(_ser)

        try:
            if ram and 'links' in ram:
                ram['links'].extend(fresh_raw)
                ram['time'] = time.time()
            elif ram is None:
                _store_ram_search_cache(_cur + fresh_raw, _deserialize_item(_sc.get('item'), engine), _sc.get('meta', {}), engine)
        except: pass

        if added:
            try:
                xbmc.log("Multi Bridge: recolector tardio +%d enlaces de %s (total %d)" % (added, channel_name or '?', len(_sc['links'])), xbmc.LOGINFO)
            except: pass

            # Pausa breve (150ms) para que el SO asiente la escritura de disco antes de invocar Container.Refresh
            try: time.sleep(0.15)
            except: pass

            # Refrescar el contenedor si la lista de enlaces está abierta
            try:
                if _in_own_list():
                    xbmc.executebuiltin('Container.Refresh')
            except Exception as _re:
                xbmc.log("Multi Bridge: error refrescando contenedor: %s" % _re, xbmc.LOGWARNING)

            # Mostrar la notificación toast al usuario tras refrescar
            try:
                _show_bridge_notification('Multi Bridge', '+%d enlaces de %s' % (added, channel_name or 'canal'), 3500)
            except: pass
    except Exception as _e:
        try: xbmc.log("Multi Bridge: _append_late_links error: %s" % _e, xbmc.LOGWARNING)
        except: pass
    return added

def _late_collect_worker(engine, target_tmdb, season, episode, token, deadline=25):
    """Espera hilos rezagados tras el cierre y anexa sus enlaces a la lista
    abierta. Se aborta si otra busqueda toma el relevo o al expirar deadline."""
    try:
        mon = xbmc.Monitor()
        t0 = time.time()
        done_pfs = set()
        if mon.waitForAbort(0.3):
            return
        while time.time() - t0 < deadline and not mon.abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
            try:
                if _LAST_SEARCH_TOKEN != token or mon.abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                    return
                avail_batch = []
                for pf_tuple in list(_LAST_SEARCH_THREADS):
                    if mon.abortRequested() or _BG_TASK_ABORT_EVENT.is_set(): return
                    try:
                        ch_name, th, ch_key = pf_tuple
                    except Exception:
                        continue
                    if ch_name in _LAST_MERGED_PFS or ch_name in done_pfs:
                        continue
                    if ch_key in _LAST_RESULTS_DICT:
                        try:
                            it, links = _LAST_RESULTS_DICT[ch_key]
                            if links:
                                avail_batch.append((ch_name, links, ch_name))
                            done_pfs.add(ch_name)
                        except Exception:
                            done_pfs.add(ch_name)
                    elif not th.is_alive():
                        done_pfs.add(ch_name)

                if avail_batch and not mon.abortRequested():
                    all_batch_links = []
                    channel_names = []
                    for pf, links, ch_name in avail_batch:
                        all_batch_links.extend(links)
                        if ch_name not in channel_names:
                            channel_names.append(ch_name)

                    if all_batch_links:
                        display_ch = ', '.join(channel_names[:3])
                        if len(channel_names) > 3:
                            display_ch += ' +%d más' % (len(channel_names) - 3)
                        _append_late_links(engine, target_tmdb, season, episode, all_batch_links, display_ch)

                # Terminar si no quedan hilos vivos pendientes
                try:
                    alive = False
                    for _pf_tuple in list(_LAST_SEARCH_THREADS):
                        try:
                            _ch_name, _th, _ = _pf_tuple
                            if _ch_name not in _LAST_MERGED_PFS and _ch_name not in done_pfs and _th.is_alive():
                                alive = True
                                break
                        except: pass
                    if not alive or mon.abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                        return
                except: return
            except: pass
            if mon.waitForAbort(0.5) or _BG_TASK_ABORT_EVENT.is_set():
                return
    except: pass

_LAST_SEARCH_THREADS = []

def _spawn_late_collector(engine, target_tmdb, season, episode):
    """Arranca el recolector tardio si quedaron hilos vivos tras el cierre o resultados pendientes."""
    try:
        token = _LAST_SEARCH_TOKEN
        if not token:
            return
        alive = False
        try:
            for _item in list(_LAST_SEARCH_THREADS):
                try:
                    _pf = _item[0]
                    _th = _item[1]
                    _ch_key = _item[2] if len(_item) > 2 else _pf
                    if _pf not in _LAST_MERGED_PFS:
                        if _th.is_alive() or (_ch_key in _LAST_RESULTS_DICT and _LAST_RESULTS_DICT[_ch_key][1]):
                            alive = True
                            break
                except: pass
        except: pass
        if not alive:
            return
        th = threading.Thread(target=_late_collect_worker, args=(engine, target_tmdb, season, episode, token), daemon=True)
        th.start()
        try:
            xbmc.log("Multi Bridge: recolector tardio activado (hilos rezagados en curso o pendientes)", xbmc.LOGINFO)
        except: pass
    except: pass

def run_parallel_search(engine='alfa'):
    global _search_in_progress, _PIPELINE_VERIFIED_SEARCH
    _search_in_progress = True
    _PIPELINE_VERIFIED_SEARCH = False
    _apply_silence_all()
    _was_locked = _is_search_process_running_global()
    if not _was_locked:
        _t = title or get_param('title') or showname or get_param('showname') or ''
        _acquire_search_lock_atomic(_t)
    try:
        return _run_parallel_search_impl(engine=engine)
    finally:
        _search_in_progress = False
        if not _was_locked:
            _release_search_lock_atomic()

# ---------------------------------------------------------
# Serialization and UI List Directory Display
# ---------------------------------------------------------
def _serialize_item(it):
    if not it: return None
    if isinstance(it, dict): return it
    d = {}
    dict_to_use = it.__dict__ if hasattr(it, '__dict__') else {}
    for k in dict_to_use:
        try:
            val = dict_to_use[k]
            if isinstance(val, (str, int, float, bool, list, dict, tuple)) or val is None: d[k] = val
        except: pass
    return d

def _deserialize_item(d, engine=None):
    if not d or not isinstance(d, dict): return None
    if not engine or engine not in ('alfa', 'balandro'):
        engine = 'balandro' if (_is_engine_installed('balandro') and not _is_engine_installed('alfa')) else 'alfa'
    mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
    if not mods:
        alt = 'balandro' if engine == 'alfa' else 'alfa'
        mods = _get_balandro_modules() if alt == 'balandro' else _get_alfa_modules()
    if not mods: return None
    Item = mods['Item']
    InfoLabels = mods['InfoLabels']
    it = Item()
    it.__dict__.update(d)
    for k, v in d.items():
        try: setattr(it, k, v)
        except: pass
    if 'infoLabels' in it.__dict__ and not isinstance(it.__dict__['infoLabels'], InfoLabels):
        try: it.__dict__['infoLabels'] = InfoLabels(it.__dict__['infoLabels'])
        except Exception: pass
    return it

def _deserialize_item_fast(Item, InfoLabels, d):
    """Igual que _deserialize_item pero con las clases ya resueltas: evita
    recargar los modulos del motor una vez por enlace al pintar la lista."""
    if not d or not isinstance(d, dict) or not Item: return None
    it = Item()
    it.__dict__.update(d)
    if 'infoLabels' in it.__dict__ and InfoLabels and not isinstance(it.__dict__['infoLabels'], InfoLabels):
        try: it.__dict__['infoLabels'] = InfoLabels(it.__dict__['infoLabels'])
        except Exception: pass
    return it

def _enrich_link_metadata(link, meta, matched_item=None):
    if not meta: meta = {}
    t_id = meta.get('tmdb') or _safe_get_item_attr(matched_item, 'tmdb_id') or ''
    i_id = meta.get('imdb') or _safe_get_item_attr(matched_item, 'imdb_id') or ''
    tv_id = meta.get('tvdb') or _safe_get_item_attr(matched_item, 'tvdb_id') or ''
    tr_id = meta.get('trakt') or _safe_get_item_attr(matched_item, 'trakt_id') or ''
    is_series = bool(meta.get('season') and meta.get('episode'))
    title_val = meta.get('title') or _safe_get_item_attr(matched_item, 'contentTitle') or _safe_get_item_attr(matched_item, 'title') or ''
    showname_val = meta.get('showname') or _safe_get_item_attr(matched_item, 'contentSerieName') or _safe_get_item_attr(matched_item, 'show') or ''
    year_val = meta.get('showyear' if is_series else 'year') or _safe_get_item_attr(matched_item, 'year') or ''
    plot_val = meta.get('plot') or _safe_get_item_attr(matched_item, 'plot') or ''
    tagline_val = meta.get('tagline') or _safe_get_item_attr(matched_item, 'tagline') or ''
    poster_val = meta.get('poster') or meta.get('thumbnail') or _safe_get_item_attr(matched_item, 'thumbnail') or ''
    fanart_val = meta.get('fanart') or _safe_get_item_attr(matched_item, 'fanart') or ''

    targets = []
    if link: targets.append(link)
    if matched_item and hasattr(matched_item, '__dict__'): targets.append(matched_item)
    if not targets: return

    for target in targets:
        if not hasattr(target, 'infoLabels') or not isinstance(getattr(target, 'infoLabels', None), dict):
            target.infoLabels = {}
        if is_series:
            target.contentType = 'episode'
            target.contentSerieName = showname_val
            target.show = showname_val
            try: target.contentSeason = int(meta.get('season'))
            except: pass
            try: target.contentEpisodeNumber = int(meta.get('episode'))
            except: pass
            target.contentTitle = title_val or showname_val
            target.infoLabels['mediatype'] = 'episode'
            target.infoLabels['tvshowtitle'] = showname_val
            try: target.infoLabels['season'] = int(meta.get('season'))
            except: pass
            try: target.infoLabels['episode'] = int(meta.get('episode'))
            except: pass
            target.infoLabels['title'] = '%s %sx%02d' % (showname_val, str(meta.get('season')), int(meta.get('episode')))
        else:
            target.contentType = 'movie'
            target.contentTitle = title_val
            target.infoLabels['mediatype'] = 'movie'
            target.infoLabels['title'] = title_val
        if t_id: target.infoLabels['tmdb_id'] = str(t_id); target.infoLabels['tmdb'] = str(t_id); target.infoLabels['code'] = str(t_id); target.tmdb_id = str(t_id)
        if i_id: target.infoLabels['imdb_id'] = str(i_id); target.infoLabels['imdbnumber'] = str(i_id); target.imdb_id = str(i_id)
        if tv_id: target.infoLabels['tvdb_id'] = str(tv_id); target.infoLabels['tvdb'] = str(tv_id); target.tvdb_id = str(tv_id)
        if tr_id: target.infoLabels['trakt_id'] = str(tr_id); target.infoLabels['trakt'] = str(tr_id); target.trakt_id = str(tr_id)
        if year_val:
            try: target.infoLabels['year'] = int(year_val); target.year = int(year_val)
            except: pass
        if plot_val: target.infoLabels['plot'] = plot_val; target.plot = plot_val
        if tagline_val: target.infoLabels['tagline'] = tagline_val; target.tagline = tagline_val
        ep_still = ''
        if is_series and t_id and meta.get('season') and meta.get('episode'):
            try: ep_still = _get_episode_still(t_id, meta.get('season'), meta.get('episode'))
            except Exception: ep_still = ''
        if is_series and (ep_still or meta.get('thumbnail')):
            ep_target_art = ep_still or meta.get('thumbnail')
            target.thumbnail = ep_target_art
            target.infoLabels['thumbnail'] = ep_target_art
            target.infoLabels['poster'] = ep_target_art
            target.infoLabels['still'] = ep_target_art
            if poster_val:
                target.infoLabels['tvshow.poster'] = poster_val
                target.infoLabels['season.poster'] = poster_val
        elif poster_val:
            target.thumbnail = poster_val
            target.infoLabels['poster'] = poster_val
            target.infoLabels['thumbnail'] = poster_val
        if fanart_val:
            target.fanart = fanart_val
            target.infoLabels['fanart'] = fanart_val
        clearlogo_val = meta.get('clearlogo') or ''
        if not clearlogo_val and t_id:
            clearlogo_val = _get_clearlogo(t_id, is_series)
        if clearlogo_val:
            target.clearlogo = clearlogo_val
            target.infoLabels['clearlogo'] = clearlogo_val
            target.infoLabels['logo'] = clearlogo_val
            if is_series:
                target.infoLabels['tvshow.clearlogo'] = clearlogo_val
                target.infoLabels['tvshow.logo'] = clearlogo_val
        genre_val = meta.get('genre') or ''
        if not genre_val and t_id:
            try:
                _g_list = _get_genres(t_id, is_series)
                if _g_list:
                    genre_val = " / ".join(_g_list)
            except Exception: pass
        if genre_val:
            target.genre = genre_val
            target.infoLabels['genre'] = genre_val
        director_val = _clean_single_director(meta.get('director'))
        if not director_val and t_id:
            try:
                _d_list = _get_directors(t_id, is_series)
                if _d_list:
                    director_val = _clean_single_director(_d_list[0])
            except Exception: pass
        if director_val:
            target.director = director_val
            target.infoLabels['director'] = director_val
            target.infoLabels['directors'] = [director_val]

def sync_tmdbhelper_playerstring(meta=None):
    """Sincroniza la propiedad de ventana TMDbHelper.PlayerInfoString para que
    el servicio de TMDb Helper y el scrobbler de Trakt reconozcan la reproducción,
    incluso cuando el reproductor en TMDb Helper tiene 'is_resolvable': 'false'."""
    if not meta:
        meta = {}
    t_id = str(meta.get('tmdb') or '')
    i_id = str(meta.get('imdb') or '')
    tv_id = str(meta.get('tvdb') or '')
    s_val = meta.get('season')
    e_val = meta.get('episode')
    is_series = bool(s_val and e_val)

    if not t_id and not i_id:
        return

    try:
        try: _int_tmdb = int(t_id)
        except: _int_tmdb = t_id

        p_dict = {
            'tmdb_type': 'episode' if is_series else 'movie',
            'tmdb_id': _int_tmdb if _int_tmdb else t_id,
        }
        if i_id:
            p_dict['imdb_id'] = i_id
        if tv_id:
            try: p_dict['tvdb_id'] = int(tv_id)
            except: p_dict['tvdb_id'] = tv_id
        if is_series:
            try: p_dict['season'] = int(s_val)
            except: p_dict['season'] = str(s_val)
            try: p_dict['episode'] = int(e_val)
            except: p_dict['episode'] = str(e_val)

        p_str = json.dumps(p_dict)
        xbmcgui.Window(10000).setProperty('TMDbHelper.PlayerInfoString', p_str)
        xbmc.log(f"Multi Bridge: TMDbHelper.PlayerInfoString sincronizado -> {p_str}", xbmc.LOGINFO)
        # Sincronizar IDs directamente para script.trakt (scrobbler global)
        try:
            _tr_ids = {}
            if t_id: _tr_ids['tmdb'] = int(t_id) if str(t_id).isdigit() else t_id
            if i_id: _tr_ids['imdb'] = i_id
            if tv_id: _tr_ids['tvdb'] = int(tv_id) if str(tv_id).isdigit() else tv_id
            _tr_val = str(meta.get('trakt') or '')
            if _tr_val: _tr_ids['trakt'] = int(_tr_val) if _tr_val.isdigit() else _tr_val
            if _tr_ids:
                _tr_json = json.dumps(_tr_ids)
                xbmcgui.Window(10000).setProperty('script.trakt.ids', _tr_json)
                xbmc.log("Multi Bridge: script.trakt.ids en Window(10000) sincronizado -> " + _tr_json, xbmc.LOGINFO)
        except Exception:
            pass

        _c_logo = meta.get('clearlogo') or ''
        if not _c_logo and t_id:
            try:
                _c_logo = _get_clearlogo(t_id, is_series)
            except Exception: pass
        if _c_logo:
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.ClearLogo', _c_logo)
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.CropImage', _c_logo)
                xbmcgui.Window(10000).setProperty('TMDbHelper.Player.ClearLogo', _c_logo)
                xbmcgui.Window(10000).setProperty('Player.Art(clearlogo)', _c_logo)
                xbmcgui.Window(10000).setProperty('MultiBridge.ClearLogo', _c_logo)
            except Exception: pass

        # Sincronizar etiquetas de reproduccion nativas para VideoPlayer (Trakt scrobbler y OSD de skins)
        try:
            w_sync = xbmcgui.Window(10000)
            _s_title = str(meta.get('title') or '')
            _s_show = str(meta.get('showname') or '')
            _s_year = str(meta.get('showyear' if is_series else 'year') or meta.get('year') or '')
            _s_plot = str(meta.get('plot') or '')
            _s_thumb = str(meta.get('poster') or meta.get('thumbnail') or '')

            if is_series:
                if _s_show: w_sync.setProperty('VideoPlayer.TVShowTitle', _s_show)
                if s_val: w_sync.setProperty('VideoPlayer.Season', str(s_val))
                if e_val: w_sync.setProperty('VideoPlayer.Episode', str(e_val))
                if _s_title: w_sync.setProperty('VideoPlayer.EpisodeName', _s_title)
                _disp_t = f"{_s_show} {int(s_val)}x{int(e_val):02d} - {_s_title}" if (_s_show and s_val and e_val and _s_title) else (_s_title or _s_show)
                w_sync.setProperty('VideoPlayer.Title', _disp_t)
            else:
                if _s_title: w_sync.setProperty('VideoPlayer.Title', _s_title)

            if _s_year: w_sync.setProperty('VideoPlayer.Year', _s_year)
            if _s_plot: w_sync.setProperty('VideoPlayer.Plot', _s_plot)
            if _s_thumb:
                w_sync.setProperty('VideoPlayer.Cover', _s_thumb)
                w_sync.setProperty('Player.Art(poster)', _s_thumb)
                w_sync.setProperty('Player.Art(thumb)', _s_thumb)
        except Exception:
            pass

        _c_genres = meta.get('genre') or ''
        if not _c_genres and t_id:
            try:
                _g_list = _get_genres(t_id, is_series)
                if _g_list:
                    _c_genres = " / ".join(_g_list)
            except Exception: pass
        if _c_genres:
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Genre', _c_genres)
                xbmcgui.Window(10000).setProperty('VideoPlayer.Genre', _c_genres)
                xbmcgui.Window(10000).setProperty('MultiBridge.Genre', _c_genres)
            except Exception: pass

        _c_director = _clean_single_director(meta.get('director'))
        if not _c_director and t_id:
            try:
                _d_list = _get_directors(t_id, is_series)
                if _d_list:
                    _c_director = _clean_single_director(_d_list[0])
            except Exception: pass
        if _c_director:
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Director', _c_director)
                xbmcgui.Window(10000).setProperty('VideoPlayer.Director', _c_director)
                xbmcgui.Window(10000).setProperty('MultiBridge.Director', _c_director)
            except Exception: pass

        _c_still = meta.get('thumbnail') or ''
        if is_series and t_id and s_val and e_val:
            try:
                _found_still = _get_episode_still(t_id, s_val, e_val)
                if _found_still:
                    _c_still = _found_still
            except Exception: pass
        if _c_still:
            try:
                xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Thumb', _c_still)
                xbmcgui.Window(10000).setProperty('TMDbHelper.Player.Thumb', _c_still)
                xbmcgui.Window(10000).setProperty('Player.Art(thumb)', _c_still)
                xbmcgui.Window(10000).setProperty('Player.Art(poster)', _c_still)
                xbmcgui.Window(10000).setProperty('VideoPlayer.Cover', _c_still)
                xbmcgui.Window(10000).setProperty('MultiBridge.EpisodeStill', _c_still)
            except Exception: pass
    except Exception as ex:
        xbmc.log(f"Multi Bridge: error sincronizando TMDbHelper.PlayerInfoString: {ex}", xbmc.LOGINFO)

def set_listitem_info(listitem, info=None, meta=None, skip_art=False):
    if info is None: info = {}
    if meta is None: meta = {}

    tmdb_id = str(info.get('tmdb_id') or info.get('tmdb') or meta.get('tmdb') or '')
    imdb_id = str(info.get('imdb_id') or info.get('imdb') or meta.get('imdb') or '')
    tvdb_id = str(info.get('tvdb_id') or info.get('tvdb') or meta.get('tvdb') or '')
    trakt_id = str(info.get('trakt_id') or info.get('trakt') or meta.get('trakt') or '')

    s_val = info.get('season') or meta.get('season')
    e_val = info.get('episode') or meta.get('episode')
    is_series = bool(s_val and e_val)

    title_val = str(info.get('title') or meta.get('title') or '')
    showname_val = str(info.get('tvshowtitle') or meta.get('showname') or '')
    year_val = info.get('year') or meta.get('showyear' if is_series else 'year') or meta.get('year')
    plot_val = str(info.get('plot') or meta.get('plot') or '')
    tagline_val = str(info.get('tagline') or meta.get('tagline') or '')
    poster_val = str(info.get('poster') or meta.get('poster') or info.get('thumbnail') or meta.get('thumbnail') or '')
    fanart_val = str(info.get('fanart') or meta.get('fanart') or '')
    thumb_val = str(info.get('thumbnail') or meta.get('thumbnail') or '')
    still_val = ''
    if is_series and tmdb_id and s_val and e_val:
        try:
            still_val = _get_episode_still(tmdb_id, s_val, e_val)
        except Exception:
            still_val = ''
        if still_val:
            thumb_val = still_val

    unique_dict = {}
    if tmdb_id:
        unique_dict['tmdb'] = str(tmdb_id)
        if is_series:
            unique_dict['tvshow.tmdb'] = str(tmdb_id)
    if imdb_id:
        unique_dict['imdb'] = str(imdb_id)
        if is_series:
            unique_dict['tvshow.imdb'] = str(imdb_id)
    if tvdb_id:
        unique_dict['tvdb'] = str(tvdb_id)
        if is_series:
            unique_dict['tvshow.tvdb'] = str(tvdb_id)
    if trakt_id:
        unique_dict['trakt'] = str(trakt_id)

    if tmdb_id: listitem.setProperty('tmdb_id', str(tmdb_id))
    if imdb_id: listitem.setProperty('imdb_id', str(imdb_id))
    if tvdb_id: listitem.setProperty('tvdb_id', str(tvdb_id))
    listitem.setProperty('tmdb_type', 'episode' if is_series else 'movie')

    trakt_payload = {}
    if tmdb_id: trakt_payload['tmdb'] = int(tmdb_id) if str(tmdb_id).isdigit() else tmdb_id
    if imdb_id: trakt_payload['imdb'] = imdb_id
    if tvdb_id: trakt_payload['tvdb'] = int(tvdb_id) if str(tvdb_id).isdigit() else tvdb_id
    if trakt_payload:
        listitem.setProperty('script.trakt.ids', json.dumps(trakt_payload))

    clearlogo_val = str(info.get('clearlogo') or meta.get('clearlogo') or get_param('clearlogo') or '')
    if clearlogo_val in ('_', 'None', 'none') or len(_safe_str(clearlogo_val)) > 1000:
        clearlogo_val = ''
    if not clearlogo_val and tmdb_id:
        clearlogo_val = _get_clearlogo(tmdb_id, is_series)

    art_dict = {}
    if not skip_art:
        ep_art = still_val or thumb_val
        if is_series and ep_art:
            art_dict['poster'] = ep_art
            art_dict['thumb'] = ep_art
            art_dict['icon'] = ep_art
            art_dict['still'] = ep_art
            art_dict['landscape'] = ep_art
            if poster_val:
                art_dict['tvshow.poster'] = poster_val
                art_dict['season.poster'] = poster_val
        else:
            if poster_val:
                art_dict['poster'] = poster_val
            if thumb_val:
                art_dict['thumb'] = thumb_val
                art_dict['icon'] = thumb_val
            elif poster_val:
                art_dict['thumb'] = poster_val
                art_dict['icon'] = poster_val
        if fanart_val:
            art_dict['fanart'] = fanart_val
        if clearlogo_val:
            art_dict['clearlogo'] = clearlogo_val
            art_dict['logo'] = clearlogo_val
            if is_series:
                art_dict['tvshow.clearlogo'] = clearlogo_val
                art_dict['tvshow.logo'] = clearlogo_val
    if art_dict:
        try: listitem.setArt(art_dict)
        except: pass

    effective_thumb = (still_val or thumb_val) if is_series else thumb_val
    if effective_thumb:
        listitem.setProperty('thumbnail', effective_thumb)
        listitem.setProperty('Art(thumb)', effective_thumb)
        if is_series:
            listitem.setProperty('poster', effective_thumb)
            listitem.setProperty('Art(poster)', effective_thumb)
            listitem.setProperty('still', effective_thumb)
            listitem.setProperty('Art(still)', effective_thumb)
            listitem.setProperty('landscape', effective_thumb)
            listitem.setProperty('Art(landscape)', effective_thumb)

    if is_series and (still_val or thumb_val):
        _win_still = still_val or thumb_val
        try:
            xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Thumb', _win_still)
            xbmcgui.Window(10000).setProperty('TMDbHelper.Player.Thumb', _win_still)
            xbmcgui.Window(10000).setProperty('Player.Art(thumb)', _win_still)
            xbmcgui.Window(10000).setProperty('Player.Art(poster)', _win_still)
            xbmcgui.Window(10000).setProperty('VideoPlayer.Cover', _win_still)
            xbmcgui.Window(10000).setProperty('MultiBridge.EpisodeStill', _win_still)
        except Exception:
            pass

    if clearlogo_val:
        listitem.setProperty('clearlogo', clearlogo_val)
        listitem.setProperty('Art(clearlogo)', clearlogo_val)
        listitem.setProperty('logo', clearlogo_val)
        listitem.setProperty('Art(logo)', clearlogo_val)
        if is_series:
            listitem.setProperty('tvshow.clearlogo', clearlogo_val)
            listitem.setProperty('Art(tvshow.clearlogo)', clearlogo_val)
        try:
            xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.ClearLogo', clearlogo_val)
            xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.CropImage', clearlogo_val)
            xbmcgui.Window(10000).setProperty('TMDbHelper.Player.ClearLogo', clearlogo_val)
            xbmcgui.Window(10000).setProperty('Player.Art(clearlogo)', clearlogo_val)
            xbmcgui.Window(10000).setProperty('MultiBridge.ClearLogo', clearlogo_val)
        except Exception:
            pass

    genre_list = []
    genre_raw = info.get('genre') or meta.get('genre') or get_param('genre') or ''
    if isinstance(genre_raw, list):
        genre_list = [str(g).strip() for g in genre_raw if str(g).strip() and str(g).strip() not in ('_', 'None')]
    elif isinstance(genre_raw, str) and genre_raw.strip() and genre_raw.strip() not in ('_', 'None'):
        if '/' in genre_raw:
            genre_list = [g.strip() for g in genre_raw.split('/') if g.strip()]
        elif ',' in genre_raw:
            genre_list = [g.strip() for g in genre_raw.split(',') if g.strip()]
        else:
            genre_list = [genre_raw.strip()]
    if not genre_list and tmdb_id:
        try:
            genre_list = _get_genres(tmdb_id, is_series)
        except Exception:
            genre_list = []

    genre_str = " / ".join(genre_list) if genre_list else ""
    if genre_str:
        listitem.setProperty('genre', genre_str)
        listitem.setProperty('Genre', genre_str)
        try:
            xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Genre', genre_str)
            xbmcgui.Window(10000).setProperty('VideoPlayer.Genre', genre_str)
            xbmcgui.Window(10000).setProperty('MultiBridge.Genre', genre_str)
        except Exception:
            pass

    director_val = _clean_single_director(info.get('director') or meta.get('director') or get_param('director'))
    if not director_val and tmdb_id:
        try:
            _d_list = _get_directors(tmdb_id, is_series)
            if _d_list:
                director_val = _clean_single_director(_d_list[0])
        except Exception:
            director_val = ""

    director_str = director_val or ""
    director_list = [director_str] if director_str else []
    if director_str:
        listitem.setProperty('director', director_str)
        listitem.setProperty('Director', director_str)
        try:
            xbmcgui.Window(10000).setProperty('TMDbHelper.ListItem.Director', director_str)
            xbmcgui.Window(10000).setProperty('VideoPlayer.Director', director_str)
            xbmcgui.Window(10000).setProperty('MultiBridge.Director', director_str)
        except Exception:
            pass

    media_type = info.get('mediatype') or ('episode' if is_series else 'movie')
    try:
        vt = listitem.getVideoInfoTag()
        if vt:
            if unique_dict:
                try: vt.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else ('imdb' if imdb_id else ''))
                except: pass
            if imdb_id:
                try: vt.setIMDbNumber(imdb_id)
                except: pass
            vt.setMediaType(media_type)
            if is_series and media_type == 'episode':
                if showname_val: vt.setTvShowTitle(showname_val)
                if title_val: vt.setTitle(title_val)
                elif showname_val and s_val and e_val:
                    try: vt.setTitle(f"{showname_val} {int(s_val)}x{int(e_val):02d}")
                    except: vt.setTitle(f"{showname_val} {s_val}x{e_val}")
                if s_val:
                    try: vt.setSeason(int(s_val))
                    except: pass
                if e_val:
                    try: vt.setEpisode(int(e_val))
                    except: pass
            else:
                if title_val: vt.setTitle(title_val)
            if plot_val: vt.setPlot(plot_val)
            if tagline_val:
                try: vt.setTagLine(tagline_val)
                except: pass
            if year_val:
                try: vt.setYear(int(year_val))
                except: pass
            if genre_list:
                try: vt.setGenres(genre_list)
                except: pass
            if director_list:
                try: vt.setDirectors(director_list)
                except: pass
            try:
                _sec_info = {}
                if genre_str: _sec_info['genre'] = genre_str
                if director_str: _sec_info['director'] = director_str
                if _sec_info: listitem.setInfo('video', _sec_info)
            except: pass
            return
    except: pass

    if unique_dict:
        try: listitem.setUniqueIDs(unique_dict, 'tmdb' if tmdb_id else 'imdb')
        except: pass
    legacy_info = dict(info)
    for bad_key in ('trakt', 'trakt_id', 'poster', 'tmdb', 'tvshow.tmdb', 'tvshow.imdb', 'tvshow.tvdb'):
        legacy_info.pop(bad_key, None)
    if 'mediatype' not in legacy_info:
        legacy_info['mediatype'] = media_type
    if title_val and 'title' not in legacy_info:
        legacy_info['title'] = title_val
    if is_series and media_type == 'episode' and showname_val and 'tvshowtitle' not in legacy_info:
        legacy_info['tvshowtitle'] = showname_val
    if s_val and 'season' not in legacy_info:
        try: legacy_info['season'] = int(s_val)
        except: pass
    if e_val and 'episode' not in legacy_info:
        try: legacy_info['episode'] = int(e_val)
        except: pass
    if year_val and 'year' not in legacy_info:
        try: legacy_info['year'] = int(year_val)
        except: pass
    if plot_val and 'plot' not in legacy_info:
        legacy_info['plot'] = plot_val
    if tagline_val and 'tagline' not in legacy_info:
        legacy_info['tagline'] = tagline_val
    if genre_str and 'genre' not in legacy_info:
        legacy_info['genre'] = genre_str
    if director_str and 'director' not in legacy_info:
        legacy_info['director'] = director_str
    try: listitem.setInfo('video', legacy_info)
    except: pass

VIEW_MODE_FILE = os.path.join(BRIDGE_DATA_PATH, 'saved_view_mode.json')

def _get_saved_view_mode():
    """Obtiene el ID de vista guardado por el usuario o detectado desde la base de datos de Kodi."""
    # 1. Archivo persistente del addon
    try:
        if os.path.exists(VIEW_MODE_FILE):
            with open(VIEW_MODE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                vid = int(data.get('view_id', 0))
                if 45 <= vid <= 650:
                    return vid
    except Exception:
        pass

    # 2. Base de datos ViewModes de Kodi (recuperar la última vista que usó el usuario)
    try:
        import sqlite3
        db_dir = xbmcvfs.translatePath('special://userdata/Database/')
        if os.path.exists(db_dir):
            db_files = sorted([f for f in os.listdir(db_dir) if f.startswith('ViewModes') and f.endswith('.db')], reverse=True)
            if db_files:
                db_path = os.path.join(db_dir, db_files[0])
                conn = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=1.0)
                cur = conn.cursor()
                cur.execute("SELECT viewMode FROM view WHERE path LIKE 'plugin://plugin.video.bridge.multi/?view=list_links%' ORDER BY idView DESC LIMIT 10")
                rows = cur.fetchall()
                conn.close()
                for r in rows:
                    if r and r[0]:
                        vid = r[0] & 0xFFFF
                        if 45 <= vid <= 650 and vid != 50:
                            _save_view_mode(vid)
                            return vid
                if rows and rows[0] and rows[0][0]:
                    vid = rows[0][0] & 0xFFFF
                    if 45 <= vid <= 650:
                        return vid
    except Exception as e:
        xbmc.log(f"Multi Bridge: _get_saved_view_mode db error: {e}", xbmc.LOGDEBUG)

    # 3. Default según el skin activo si nada se ha guardado
    skin_id = ''
    try: skin_id = str(xbmc.getSkinDir() or '').lower()
    except: pass
    return 50

def _save_view_mode(view_id):
    """Guarda la vista elegida por el usuario para todas las futuras búsquedas."""
    try:
        if not os.path.exists(BRIDGE_DATA_PATH):
            os.makedirs(BRIDGE_DATA_PATH)
        with open(VIEW_MODE_FILE, 'w', encoding='utf-8') as f:
            json.dump({'view_id': int(view_id)}, f)
        xbmc.log(f"Multi Bridge: Vista persistente guardada -> {view_id}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Multi Bridge: _save_view_mode error: {e}", xbmc.LOGWARNING)

def _in_own_list():
    """True solo si la ventana activa es nuestra lista de enlaces.
    Evita aplicar nuestra vista a otros contenedores (ej. TMDb Helper)."""
    try:
        if not xbmc.getCondVisibility("Window.IsVisible(10025)"):
            return False
        folder = xbmc.getInfoLabel("Container.FolderPath") or ''
        return "plugin.video.bridge.multi" in folder and "view=list_links" in folder
    except Exception:
        return False

def _apply_saved_view_mode():
    """Aplica la vista guardada por el usuario en la lista de resultados."""
    view_id = _get_saved_view_mode()
    if not view_id:
        return

    def _apply_delayed():
        _mon2 = xbmc.Monitor()
        for delay in (50, 150, 300, 600, 1000):
            xbmc.sleep(delay)
            if _mon2.abortRequested():
                return
            try:
                # Si el usuario ya salio de nuestra lista (ej. volvio a
                # TMDb Helper), no tocar la vista del otro contenedor.
                if not _in_own_list():
                    break
                xbmc.executebuiltin("Container.SetViewMode(%d)" % view_id)
            except Exception:
                pass

    try:
        # Solo aplicar de inmediato si ya estamos en nuestra lista (ej.
        # refresco); si no, el hilo retardado lo hara al aparecer.
        if _in_own_list():
            try:
                xbmc.executebuiltin("Container.SetViewMode(%d)" % view_id)
            except Exception:
                pass
        t = threading.Thread(target=_apply_delayed)
        t.daemon = True
        t.start()
    except Exception:
        pass

def _start_view_mode_monitor():
    """Hilo en segundo plano que detecta en tiempo real si el usuario cambia de vista para recordarla siempre."""
    def _monitor():
        mon = xbmc.Monitor()
        # Esperar a que la ventana de enlaces cargue en pantalla
        for _ in range(15):
            if mon.abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                return
            if mon.waitForAbort(0.2) or _BG_TASK_ABORT_EVENT.is_set():
                return
            if xbmc.getCondVisibility("Window.IsVisible(10025)"):
                break

        current_saved = _get_saved_view_mode()

        # Monitorear activamente mientras el usuario navegue en la ventana de enlaces (hasta 3 minutos)
        for _ in range(360):
            if mon.abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
                return
            if mon.waitForAbort(0.5) or _BG_TASK_ABORT_EVENT.is_set():
                return
            try:
                if not xbmc.getCondVisibility("Window.IsVisible(10025)"):
                    break
                folder = xbmc.getInfoLabel("Container.FolderPath")
                if "plugin.video.bridge.multi" not in folder or "view=list_links" not in folder:
                    break
                focus_id = xbmcgui.Window(10025).getFocusId()
                if 45 <= focus_id <= 650 and focus_id != current_saved:
                    current_saved = focus_id
                    _save_view_mode(focus_id)
            except Exception:
                pass

        # Respaldo al salir: revisar si Kodi guardó un cambio en su base de datos ViewModes
        try:
            import sqlite3
            db_dir = xbmcvfs.translatePath('special://userdata/Database/')
            if os.path.exists(db_dir):
                db_files = sorted([f for f in os.listdir(db_dir) if f.startswith('ViewModes') and f.endswith('.db')], reverse=True)
                if db_files:
                    db_path = os.path.join(db_dir, db_files[0])
                    conn = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=1.0)
                    cur = conn.cursor()
                    cur.execute("SELECT viewMode FROM view WHERE path LIKE 'plugin://plugin.video.bridge.multi/?view=list_links%' ORDER BY idView DESC LIMIT 1")
                    row = cur.fetchone()
                    conn.close()
                    if row and row[0]:
                        vid = row[0] & 0xFFFF
                        if 45 <= vid <= 650 and vid != current_saved:
                            _save_view_mode(vid)
        except Exception:
            pass

    try:
        t = threading.Thread(target=_monitor)
        t.daemon = True
        t.start()
    except Exception:
        pass

_clearlogo_cache = {}

def _get_clearlogo(tmdb_id, is_series=False):
    """Obtiene de forma instantánea el clearlogo de la base de datos local de TMDb Helper o caché en RAM."""
    if not tmdb_id:
        return ''
    _id_str = str(tmdb_id).strip()
    if not _id_str.isdigit():
        return ''

    _cache_key = f"{'tv' if is_series else 'movie'}.{_id_str}"
    if _cache_key in _clearlogo_cache:
        return _clearlogo_cache[_cache_key]

    logo_url = ''
    # 1. Búsqueda instantánea en SQLite local de TMDb Helper (ItemDetails.db)
    try:
        tmdb_base = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/')
        db_files = []
        if os.path.exists(tmdb_base):
            for root, _, files in os.walk(tmdb_base):
                for fn in files:
                    if fn.lower() == 'itemdetails.db':
                        db_files.append(os.path.join(root, fn))

        pref_id = f"tv.{_id_str}" if is_series else f"movie.{_id_str}"
        alt_id  = f"movie.{_id_str}" if is_series else f"tv.{_id_str}"

        for db_path in db_files:
            try:
                conn = sqlite3.connect(db_path, timeout=1.0)
                cur = conn.cursor()
                cur.execute(
                    "SELECT icon, iso_language FROM art WHERE type = 'logos' AND (parent_id = ? OR parent_id = ?) "
                    "ORDER BY (CASE WHEN parent_id = ? THEN 1 ELSE 0 END) DESC, "
                    "(CASE WHEN iso_language = 'es' THEN 2 WHEN iso_language = 'en' THEN 1 ELSE 0 END) DESC, "
                    "rating DESC, votes DESC LIMIT 1;",
                    (pref_id, alt_id, pref_id)
                )
                row = cur.fetchone()
                conn.close()
                if row and row[0]:
                    icon = row[0].strip()
                    if icon.startswith('/'):
                        logo_url = f"https://image.tmdb.org/t/p/original{icon}"
                    elif icon.startswith('http'):
                        logo_url = icon
                    break
            except Exception:
                pass
    except Exception as e:
        xbmc.log(f"Multi Bridge: _get_clearlogo db error: {e}", xbmc.LOGDEBUG)

    # 2. Fallback opcional a API TMDb si la base local aún no lo tiene
    if not logo_url:
        try:
            import urllib.request, ssl
            media_endpoint = 'tv' if is_series else 'movie'
            api_url = f"https://api.themoviedb.org/3/{media_endpoint}/{_id_str}/images?api_key=a07324c669cac4d96789197134ce272b"
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            ctx = ssl._create_unverified_context()
            with urllib.request.urlopen(req, timeout=1.5, context=ctx) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                logos = data.get('logos', [])
                if logos:
                    best_fp = None
                    for lg in logos:
                        if lg.get('iso_639_1') == 'es':
                            best_fp = lg.get('file_path'); break
                    if not best_fp:
                        for lg in logos:
                            if lg.get('iso_639_1') == 'en':
                                best_fp = lg.get('file_path'); break
                    if not best_fp and logos:
                        best_fp = logos[0].get('file_path')
                    if best_fp:
                        logo_url = f"https://image.tmdb.org/t/p/original{best_fp}"
        except Exception:
            pass

    _clearlogo_cache[_cache_key] = logo_url
    return logo_url

_genres_cache = {}

def _get_genres(tmdb_id, is_series=False):
    """Obtiene de forma instantánea la lista de géneros en español de la base de datos local de TMDb Helper o caché en RAM."""
    if not tmdb_id:
        return []
    _id_str = str(tmdb_id).strip()
    if not _id_str.isdigit():
        return []

    _cache_key = f"{'tv' if is_series else 'movie'}.{_id_str}"
    if _cache_key in _genres_cache:
        return list(_genres_cache[_cache_key])

    genres_list = []
    # 1. Búsqueda instantánea en SQLite local de TMDb Helper (ItemDetails.db)
    try:
        tmdb_base = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/')
        db_files = []
        if os.path.exists(tmdb_base):
            for root, _, files in os.walk(tmdb_base):
                for fn in files:
                    if fn.lower() == 'itemdetails.db':
                        db_files.append(os.path.join(root, fn))

        pref_id = f"tv.{_id_str}" if is_series else f"movie.{_id_str}"
        alt_id  = f"movie.{_id_str}" if is_series else f"tv.{_id_str}"

        for db_path in db_files:
            try:
                conn = sqlite3.connect(db_path, timeout=1.0)
                cur = conn.cursor()
                cur.execute(
                    "SELECT name FROM genre WHERE parent_id = ? OR parent_id = ? "
                    "ORDER BY (CASE WHEN parent_id = ? THEN 1 ELSE 0 END) DESC, rowid ASC;",
                    (pref_id, alt_id, pref_id)
                )
                rows = cur.fetchall()
                conn.close()
                if rows:
                    for r in rows:
                        if r and r[0] and r[0].strip() and r[0].strip() not in genres_list:
                            genres_list.append(r[0].strip())
                    if genres_list:
                        break
            except Exception:
                pass
    except Exception as e:
        xbmc.log(f"Multi Bridge: _get_genres db error: {e}", xbmc.LOGDEBUG)

    # 2. Fallback opcional a API TMDb si la base local aún no lo tiene
    if not genres_list:
        try:
            import urllib.request, ssl
            media_endpoint = 'tv' if is_series else 'movie'
            api_url = f"https://api.themoviedb.org/3/{media_endpoint}/{_id_str}?api_key=a07324c669cac4d96789197134ce272b&language=es-MX"
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            ctx = ssl._create_unverified_context()
            with urllib.request.urlopen(req, timeout=1.5, context=ctx) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                raw_genres = data.get('genres', [])
                if not raw_genres:
                    api_url_es = f"https://api.themoviedb.org/3/{media_endpoint}/{_id_str}?api_key=a07324c669cac4d96789197134ce272b&language=es-ES"
                    req_es = urllib.request.Request(api_url_es, headers={'User-Agent': 'Mozilla/5.0'})
                    with urllib.request.urlopen(req_es, timeout=1.5, context=ctx) as resp_es:
                        data_es = json.loads(resp_es.read().decode('utf-8'))
                        raw_genres = data_es.get('genres', [])
                for g in raw_genres:
                    gn = g.get('name')
                    if gn and gn.strip() and gn.strip() not in genres_list:
                        genres_list.append(gn.strip())
        except Exception:
            pass

    _genres_cache[_cache_key] = list(genres_list)
    return genres_list

def _get_single_genre(genre_val):
    """Extrae estrictamente un solo género (el principal), descartando
    géneros adicionales si vienen concatenados con /, coma, barra vertical u otros."""
    if not genre_val:
        return ''
    if isinstance(genre_val, dict):
        g = genre_val.get('genre') or genre_val.get('Genre') or ''
        if not g and genre_val.get('tmdb'):
            try:
                g_list = _get_genres(genre_val.get('tmdb'), bool(genre_val.get('season') and genre_val.get('episode')))
                if g_list:
                    g = g_list[0]
            except Exception:
                pass
        genre_val = g
    if isinstance(genre_val, (list, tuple, set)):
        for item in genre_val:
            cleaned = _get_single_genre(item)
            if cleaned:
                return cleaned
        return ''
    if not isinstance(genre_val, str):
        genre_val = str(genre_val or '')

    # Limpiar tags de formato de Kodi [COLOR...], [B], etc.
    genre_val = re.sub(r'\[/?COLOR.*?\]', '', genre_val, flags=re.IGNORECASE)
    genre_val = re.sub(r'\[/?[BI]\]', '', genre_val, flags=re.IGNORECASE)

    # Dividir por separadores comunes (/ , | • ; – — -)
    parts = re.split(r'[/,|•;–—\-]', genre_val)
    for p in parts:
        clean = p.strip()
        if clean and clean.lower() not in ('none', 'null', '_', 'unknown', 'desconocido', 'n/a'):
            if clean.islower():
                clean = clean.capitalize()
            return clean
    return ''

_directors_cache = {}

def _clean_single_director(director_val):
    """Limpia y extrae estrictamente un solo nombre (el director o creador principal),
    descartando directores adicionales si vienen concatenados con / o ,."""
    if not director_val:
        return ''
    if isinstance(director_val, (list, tuple, set)):
        for item in director_val:
            cleaned = _clean_single_director(item)
            if cleaned:
                return cleaned
        return ''
    if isinstance(director_val, str):
        val = director_val.strip()
        if not val or val.lower() in ('_', 'none', 'unknown', 'null', 'n/a'):
            return ''
        if '/' in val:
            val = val.split('/')[0].strip()
        if ',' in val:
            val = val.split(',')[0].strip()
        if not val or val.lower() in ('_', 'none', 'unknown', 'null', 'n/a'):
            return ''
        return val
    return ''

def _get_directors(tmdb_id, is_series=False):
    """Obtiene de forma instantánea el director o creador principal de la base de datos local de TMDb Helper o caché en RAM."""
    if not tmdb_id:
        return []
    _id_str = str(tmdb_id).strip()
    if not _id_str.isdigit():
        return []

    _cache_key = f"{'tv' if is_series else 'movie'}.{_id_str}"
    if _cache_key in _directors_cache:
        return list(_directors_cache[_cache_key])

    directors_list = []
    # 1. Búsqueda instantánea en SQLite local de TMDb Helper (ItemDetails.db)
    try:
        tmdb_base = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/')
        db_files = []
        if os.path.exists(tmdb_base):
            for root, _, files in os.walk(tmdb_base):
                for fn in files:
                    if fn.lower() == 'itemdetails.db':
                        db_files.append(os.path.join(root, fn))

        pref_id = f"tv.{_id_str}" if is_series else f"movie.{_id_str}"
        alt_id  = f"movie.{_id_str}" if is_series else f"tv.{_id_str}"

        for db_path in db_files:
            try:
                conn = sqlite3.connect(db_path, timeout=1.0)
                cur = conn.cursor()
                cur.execute(
                    "SELECT p.name, c.role FROM crewmember c JOIN person p ON c.tmdb_id = p.tmdb_id "
                    "WHERE (c.parent_id = ? OR c.parent_id = ?) AND (c.role = 'Director' OR c.role = 'Creator' OR c.department = 'Directing') "
                    "ORDER BY (CASE WHEN c.parent_id = ? THEN 1 ELSE 0 END) DESC, "
                    "(CASE WHEN c.role = 'Director' THEN 2 WHEN c.role = 'Creator' THEN 1 ELSE 0 END) DESC, "
                    "c.rowid ASC LIMIT 1;",
                    (pref_id, alt_id, pref_id)
                )
                rows = cur.fetchall()
                conn.close()
                if rows:
                    for r in rows:
                        d_name = _clean_single_director(r[0])
                        if d_name:
                            directors_list.append(d_name)
                            break
                    if directors_list:
                        break
            except Exception:
                pass
    except Exception as e:
        xbmc.log(f"Multi Bridge: _get_directors db error: {e}", xbmc.LOGDEBUG)

    # 2. Fallback opcional a API TMDb si la base local aún no lo tiene
    if not directors_list:
        try:
            import urllib.request, ssl
            media_endpoint = 'tv' if is_series else 'movie'
            api_url = f"https://api.themoviedb.org/3/{media_endpoint}/{_id_str}?api_key=a07324c669cac4d96789197134ce272b&append_to_response=credits"
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            ctx = ssl._create_unverified_context()
            with urllib.request.urlopen(req, timeout=1.5, context=ctx) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if is_series:
                    for c in data.get('created_by', []):
                        cn = _clean_single_director(c.get('name'))
                        if cn:
                            directors_list.append(cn)
                            break
                if not directors_list:
                    raw_crew = data.get('credits', {}).get('crew', []) or data.get('crew', [])
                    for cr in raw_crew:
                        if cr.get('job') == 'Director' or (not is_series and cr.get('department') == 'Directing'):
                            dn = _clean_single_director(cr.get('name'))
                            if dn:
                                directors_list.append(dn)
                                break
        except Exception:
            pass

    if directors_list:
        directors_list = [_clean_single_director(directors_list[0])]
    directors_list = [d for d in directors_list if d]
    _directors_cache[_cache_key] = list(directors_list)
    return directors_list

_episode_still_cache = {}

def _get_episode_still(tmdb_id, season, episode):
    """Obtiene de forma instantánea la miniatura/still (16:9) del episodio
    desde la base de datos local SQLite de TMDb Helper (ItemDetails.db) o caché en RAM,
    con fallback a la API de TMDb si aún no estuviera en caché local."""
    if not tmdb_id or season is None or episode is None:
        return ''
    _id_str = str(tmdb_id).strip()
    if not _id_str.isdigit():
        return ''
    try:
        s_int = int(season)
        e_int = int(episode)
    except (ValueError, TypeError):
        return ''

    _cache_key = f"tv.{_id_str}.{s_int}.{e_int}"
    if _cache_key in _episode_still_cache:
        return _episode_still_cache[_cache_key]

    still_url = ''
    # 1. Búsqueda instantánea en SQLite local de TMDb Helper (ItemDetails.db)
    try:
        tmdb_base = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/')
        db_files = []
        if os.path.exists(tmdb_base):
            for root, _, files in os.walk(tmdb_base):
                for fn in files:
                    if fn.lower() == 'itemdetails.db':
                        db_files.append(os.path.join(root, fn))

        parent_key = f"tv.{_id_str}.{s_int}.{e_int}"
        for db_path in db_files:
            try:
                conn = sqlite3.connect(db_path, timeout=1.0)
                cur = conn.cursor()
                cur.execute(
                    "SELECT icon FROM art WHERE type = 'stills' AND parent_id = ? "
                    "ORDER BY rating DESC, votes DESC LIMIT 1;",
                    (parent_key,)
                )
                row = cur.fetchone()
                conn.close()
                if row and row[0]:
                    icon = row[0].strip()
                    if icon.startswith('/'):
                        still_url = f"https://image.tmdb.org/t/p/w780{icon}"
                    elif icon.startswith('http'):
                        still_url = icon
                    break
            except Exception:
                pass
    except Exception as e:
        xbmc.log(f"Multi Bridge: _get_episode_still db error: {e}", xbmc.LOGDEBUG)

    # 2. Fallback a API TMDb si la base local aún no lo tiene
    if not still_url:
        try:
            import urllib.request, ssl
            api_url = f"https://api.themoviedb.org/3/tv/{_id_str}/season/{s_int}/episode/{e_int}?api_key=a07324c669cac4d96789197134ce272b&language=es-ES"
            req = urllib.request.Request(api_url, headers={'User-Agent': 'Mozilla/5.0'})
            ctx = ssl._create_unverified_context()
            with urllib.request.urlopen(req, timeout=1.5, context=ctx) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                sp = data.get('still_path')
                if sp:
                    still_url = f"https://image.tmdb.org/t/p/w780{sp}"
        except Exception:
            pass

    _episode_still_cache[_cache_key] = still_url
    return still_url

def _verify_remaining_preloaded_impl():
    """Verifica los enlaces restantes de una sesión precargada que aún no habían sido comprobados,
    añadiendo los enlaces funcionales a la lista actual y refrescando el contenedor."""
    c = _read_search_cache_atomic()
    if not c or not isinstance(c, dict):
        xbmcgui.Dialog().notification('Multi Bridge', 'No hay enlaces en caché', '', 2500)
        return

    unverified_raw = c.get('unverified_links', [])
    if not unverified_raw:
        xbmcgui.Dialog().notification('Multi Bridge', 'No hay más enlaces pendientes', '', 2500)
        return

    engine = c.get('engine', 'balandro') or 'balandro'
    meta = c.get('meta', {}) or {}
    matched_item = _deserialize_item(c.get('item'), engine)

    unverified_items = [_deserialize_item(l, engine) for l in unverified_raw]
    unverified_items = [l for l in unverified_items if l is not None]

    if not unverified_items:
        c['unverified_links'] = []
        c['is_preloaded_session'] = False
        _save_search_cache_atomic(c)
        return

    p_diag = xbmcgui.DialogProgress()
    p_diag.create('Multi Bridge', 'Comprobando disponibilidad de servidores restantes...')
    newly_verified = _verify_links_headless(unverified_items, engine=engine, p_dialog=p_diag)
    try: p_diag.close()
    except Exception: pass

    curr_raw = c.get('links', [])
    curr_items = [_deserialize_item(l, engine) for l in curr_raw]
    curr_items = [l for l in curr_items if l is not None]

    combined = list(curr_items)
    added_count = 0
    if newly_verified:
        for nv in newly_verified:
            nv_url = getattr(nv, 'url', None)
            if not nv_url or not any(getattr(ci, 'url', None) == nv_url for ci in combined):
                combined.append(nv)
                added_count += 1

    combined = _filter_and_sort_links(combined)

    c['links'] = [_serialize_item(l) for l in combined]
    c['unverified_links'] = []
    c['is_preloaded_session'] = False
    _save_search_cache_atomic(c)
    _store_ram_search_cache(combined, matched_item, meta, engine)

    if added_count > 0:
        xbmcgui.Dialog().notification('Multi Bridge', '%d enlaces adicionales verificados' % added_count, xbmcgui.NOTIFICATION_INFO, 2500)
    else:
        xbmcgui.Dialog().notification('Multi Bridge', 'Ningún enlace adicional superó la verificación', '', 2500)

    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def show_links_as_directory():
    """Redirecciona siempre a la ventana personalizada flotante para 0% carga de CPU."""
    global _search_in_progress, _links_view_active
    _search_in_progress = False
    _links_view_active = True
    _apply_silence_all()
    show_floating_links_dialog()
    if handle >= 0:
        try:
            xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        except Exception:
            pass
# ---------------------------------------------------------
# Playback Handler (Native Delegates for Alfa & Balandro)
# ---------------------------------------------------------

def _resolve_link_to_listitem(link, engine, matched_item=None, allow_captcha=False):
    """Resolve *link* to a playable ListItem by intercepting the engine's setResolvedUrl.

    Does NOT consume the real Kodi plugin handle — the interception captures the
    ListItem (with the direct stream URL) and returns it to the caller.

    Returns (True, listitem) on success, (False, None) on failure.
    """
    if not link: return False, None

    prep = _prepare_playable_link(link, engine=engine)
    if not prep:
        return False, None

    if not getattr(prep, 'url', '') and not getattr(prep, 'video_urls', None):
        return False, None

    if _is_web_captcha_server(getattr(prep, 'server', ''), prep):
        if not allow_captcha:
            return False, None
        li = _capture_web_captcha_listitem(prep, meta=getattr(matched_item, 'infoLabels', None) if matched_item else None)
        if li:
            return True, li
        return False, None

    _resolved_li = [None]
    _result       = [False]

    import xbmcplugin as _xp
    _orig_sru = getattr(_xp, 'setResolvedUrl', None)

    def _capture(h, succeeded, listitem):
        if succeeded and listitem:
            _resolved_li[0] = listitem
            _result[0]      = True
        else:
            if not _result[0]:
                _result[0] = False

    def _cap_ok(*args, **kwargs):
        return True

    def _cap_notif(*args, **kwargs):
        return True

    def _cap_sel(heading="", options=None, *args, **kwargs):
        if options and isinstance(options, (list, tuple)):
            best_idx = 0
            best_score = -1
            for idx, opt in enumerate(options):
                score = _stream_quality_score(opt)
                if score > best_score:
                    best_score = score
                    best_idx = idx
            return best_idx
        return 0

    try:    _xp.setResolvedUrl = _capture
    except: pass

    try:
        if engine == 'balandro':
            mods = _get_balandro_modules()
            if not mods: return False, None
            pt = mods['platformtools']
            parent = matched_item or prep
            _orig_ok = getattr(pt, 'dialog_ok', None)
            _orig_notif = getattr(pt, 'dialog_notification', None)
            _orig_sel = getattr(pt, 'dialog_select', None)
            try:
                pt.dialog_ok = _cap_ok
                pt.dialog_notification = _cap_notif
                pt.dialog_select = _cap_sel
                sys.argv[1] = '1'
                res = pt.play_video(prep, parent, autoplay=False)
                if res is True and _resolved_li[0] is not None:
                    _result[0] = True
            finally:
                if _orig_ok is not None:
                    try: pt.dialog_ok = _orig_ok
                    except: pass
                if _orig_notif is not None:
                    try: pt.dialog_notification = _orig_notif
                    except: pass
                if _orig_sel is not None:
                    try: pt.dialog_select = _orig_sel
                    except: pass
        else:  # alfa
            mods = _get_alfa_modules()
            if not mods: return False, None
            pt = mods['platformtools']
            _orig_ok = getattr(pt, 'dialog_ok', None)
            _orig_notif = getattr(pt, 'dialog_notification', None)
            _orig_sel = getattr(pt, 'dialog_select', None)
            try:
                pt.dialog_ok = _cap_ok
                pt.dialog_notification = _cap_notif
                pt.dialog_select = _cap_sel
                sys.argv[1] = '1'
                pt.play_video(prep, autoplay=True)
            finally:
                if _orig_ok is not None:
                    try: pt.dialog_ok = _orig_ok
                    except: pass
                if _orig_notif is not None:
                    try: pt.dialog_notification = _orig_notif
                    except: pass
                if _orig_sel is not None:
                    try: pt.dialog_select = _orig_sel
                    except: pass
    except Exception as _ex:
        xbmc.log('Multi Bridge _resolve_link error: ' + str(_ex), xbmc.LOGINFO)
        _result[0] = False
    finally:
        if _orig_sru is not None:
            try:    _xp.setResolvedUrl = _orig_sru
            except: pass

    if _result[0] and _resolved_li[0] is not None:
        return True, _resolved_li[0]
    return False, None


def _autoplay_with_fallback(links, handle, engine, matched_item=None,
                            monitor_secs=180, max_attempts=999, tmdb_for_list=None,
                            meta=None, seek_to_time=0, resume_media_key='',
                            resume_title=''):
    """Try non-torrent links in order until one verifiably plays.

    While autoplay runs, list_links is opened in the background (if tmdb_for_list
    is provided) so the user can choose a different link (e.g. a torrent) after
    stopping the current playback.

    Torrents are filtered out of the autoplay queue — they only appear in list_links.
    The Kodi plugin handle is dismissed with setResolvedUrl(False) at the start.
    Actual playback uses xbmc.Player().play() independently of the handle.
    """
    if not meta:
        _cf = _read_search_cache_atomic()
        if _cf and isinstance(_cf, dict):
            meta = _cf.get('meta', {}) or {}

    if not links:
        _absorb = xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(handle, False, _absorb)
        return False

    # ── Filter torrents and manual captcha servers ──────────────────────────
    normal_links = [l for l in links if not _is_torrent_link(l) and not _is_web_captcha_server(_get_link_server_name(l), l)]
    if not normal_links:
        _absorb = xbmcgui.ListItem()
        try: xbmcplugin.setResolvedUrl(handle, False, _absorb)
        except: pass
        if links and tmdb_for_list:
            _ts = int(time.time())
            _lu = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (str(tmdb_for_list), _ts)
            if meta and meta.get('season') and meta.get('episode'):
                _lu += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
            _open_links_view(_lu)
        return False

    # ── Dismiss handle early (suppress Kodi error dialog via guardian) ─────
    _guard_stop = [False]
    def _suppress():
        for _ in range(30):
            if _guard_stop[0]: break
            try:
                xbmc.executebuiltin('Dialog.Close(okdialog,true)')
                xbmc.executebuiltin('Dialog.Close(error,true)')
            except: pass
            time.sleep(0.1)
    _gt = threading.Thread(target=_suppress, daemon=True)
    _gt.start()

    _absorb = xbmcgui.ListItem()
    try:    xbmcplugin.setResolvedUrl(handle, False, _absorb)
    except: pass
    xbmc.sleep(300)
    _guard_stop[0] = True
    try: _gt.join(timeout=0.5)
    except: pass

    # ── Abrir list_links en segundo plano ──────────────────────────────────
    # Se carga detrás del reproductor; cuando el usuario detiene el video
    # list_links se abrirá en el momento correcto: cuando el usuario diga "No"
    # o cuando se agoten todos los enlaces (ver más abajo).

    player    = xbmc.Player()
    total_att = min(len(normal_links), max_attempts)
    _cancelled_by_user = False
    _monitor_started = False
    _want_resume = (seek_to_time or 0) > 10
    # Tiempo por servidor leido del ajuste (antes fijo 12s ignorando ajustes)
    _resolve_timeout = _get_int_setting('autoplay_resolve_timeout', 12)
    if _resolve_timeout < 5: _resolve_timeout = 5
    if _resolve_timeout > 120: _resolve_timeout = 120
    _resolve_steps = int(_resolve_timeout * 10)



    # Mapa de idioma interno → nombre legible para el usuario
    _LANG_NAMES = {
        'lat': 'Latino', 'latino': 'Latino',
        'esp': 'Castellano', 'castellano': 'Castellano', 'es': 'Castellano',
        'vose': 'VOSE', 'sub': 'VOSE', 'subtitulado': 'VOSE',
        'eng': 'Inglés', 'en': 'Inglés',
        'por': 'Portugués', 'pt': 'Portugués',
    }

    for idx, link in enumerate(normal_links[:total_att]):
        server   = _safe_str(getattr(link, 'server',   '') or '').capitalize() or 'Servidor'
        lang_raw = _safe_str(getattr(link, 'language', '') or '').strip()
        ch       = _safe_str(getattr(link, 'channel', '') or getattr(link, 'channel_name', '') or '')
        lang_lbl = _format_language(link)
        lang_colored = _format_language_display(lang_raw, colored=True)
        cand_qual = _format_quality(link)
        qual_part = ('  •  [COLOR gold]%s[/COLOR]' % cand_qual) if (cand_qual and cand_qual != 'N/A') else ''
        _label = '[B][COLOR gold]%s[/COLOR][/B]  •  %s%s' % (server, lang_colored, qual_part)

        xbmc.log('Multi Bridge autoplay [%d/%d] → %s %s (%s)' % (
            idx+1, total_att, server, lang_raw, ch), xbmc.LOGINFO)

        # ── Step 1: Resolve ────────────────────────────────────────────────
        _t_title = meta.get('title') or resume_title or getattr(link, 'title', '') or 'Multi Bridge'
        _single_g = _get_single_genre(meta) or ('%s' % (meta.get('year') or ''))
        _extra_tag = _single_g or ('%d/%d' % (idx+1, total_att))
        _prog = _AutoplayProgressDialog(
            target_title=_t_title,
            poster_url=meta.get('poster') or meta.get('thumbnail') or '',
            fanart_url=meta.get('fanart') or '',
            extra_info=_extra_tag,
            meta=meta
        )
        _prog.create('[COLOR gold][B]Multi Bridge[/B][/COLOR]  •  [COLOR white]AUTOPLAY[/COLOR]', 'Iniciando reproducción...')
        _prog.set_stream_info(server=server, quality=cand_qual or '1080p', language=lang_raw or 'Latino', channel='', status='Iniciando reproducción...')
        _prog.update(10)

        _res_done  = [None]
        _res_li    = [None]
        def _do_resolve(lnk=link):
            ok, li = _resolve_link_to_listitem(lnk, engine, matched_item)
            _res_done[0] = ok
            _res_li[0]   = li

        _rt = threading.Thread(target=_do_resolve, daemon=True)
        _rt.start()

        cancelled = False
        for _s in range(_resolve_steps):
            if _prog.iscanceled():
                cancelled = True
                break
            if _res_done[0] is not None:
                break
            xbmc.sleep(100)
            _pct = min(10 + int(_s * 85.0 / _resolve_steps), 95)
            _prog.update(_pct, 'Iniciando reproducción...')

        _rt.join(timeout=1)

        if cancelled:
            try: _prog.close()
            except: pass
            xbmc.log('Multi Bridge autoplay: usuario canceló resolución', xbmc.LOGINFO)
            _cancelled_by_user = True
            break

        if not _res_done[0] or _res_li[0] is None:
            try: _prog.close()
            except: pass
            xbmc.log('Multi Bridge autoplay [%d/%d] %s no resolvió, siguiente...' % (
                idx+1, total_att, server), xbmc.LOGINFO)
            continue

        # Extract media URL
        _media_url = ''
        try:    _media_url = _res_li[0].getPath()
        except: pass
        is_ok, real_res = _check_stream_url_playable(_media_url, server_name=server, timeout=3.0)
        if not _media_url or not is_ok:
            try: _prog.close()
            except: pass
            xbmc.log('Multi Bridge autoplay [%d/%d] %s URL vacía o stream no funcional, siguiente...' % (
                idx+1, total_att, server), xbmc.LOGINFO)
            continue

        if real_res and not _is_cam_quality(link):
            link.real_quality = real_res
            link.quality = real_res
            try: _res_li[0].setInfo('video', {'quality': real_res})
            except: pass

        _qual_show = _format_quality(link)
        _qual_colored = ('  •  [COLOR springgreen]%s[/COLOR]' % _qual_show) if (_qual_show and _qual_show != 'N/A') else ''
        _label_play = '[B][COLOR gold]%s[/COLOR][/B]  •  %s%s' % (server, lang_colored, _qual_colored)

        # ── Step 2: Start playback ─────────────────────────────────────────
        _prog.update(90, '[%d/%d] Iniciando %s...' % (idx+1, total_att, _label_play))
        try:
            _prog.close()
        except: pass
        try:
            sync_tmdbhelper_playerstring(meta)
            if _res_li[0] is not None:
                _media_url = _ensure_playback_headers_on_item(_res_li[0], server_name=server, page_url=getattr(link, 'url', '') or '') or _res_li[0].getPath() or _media_url
                set_listitem_info(_res_li[0], meta=meta)
            player.play(_media_url, _res_li[0])
        except Exception as _pe:
            xbmc.log('Multi Bridge autoplay Player.play error: ' + str(_pe), xbmc.LOGINFO)
            continue

        # ── Step 3: Monitor 3 min reales de reloj ────────────────────────────
        mon_w = xbmc.Monitor()
        started = _wait_for_playback_progress(
            player=player,
            mon=mon_w,
            timeout=15.0,
            seek_to_time=0.0,
            server_name=server
        )
        user_stopped_early = mon_w.abortRequested()

        if user_stopped_early:
            _cancelled_by_user = True
            break

        if not started:
            xbmc.log('Multi Bridge autoplay [%d/%d] %s nunca arrancó / fallo de códec (15s)' % (
                idx+1, total_att, server), xbmc.LOGINFO)
            _stop_player_cleanly(player)

            _restore_dialog_noblock()

            remaining = total_att - (idx + 1)
            _srv_lang = server + ((' [%s]' % lang_lbl) if lang_lbl else '')
            if remaining > 0:
                _show_bridge_notification('Multi Bridge · Autoplay', 'Enlace no disponible · Probando siguiente...', 3000)
            continue

        xbmc.log('Multi Bridge autoplay [%d/%d] %s arrancó, verificando duración y monitoreando 3 min reales...' % (
            idx+1, total_att, server), xbmc.LOGINFO)

        _is_s_fb = bool((meta or {}).get('season') and (meta or {}).get('episode'))
        _rt_bad, _exp_m, _act_m = _is_playing_wrong_runtime(player, (meta or {}).get('tmdb'), is_series=_is_s_fb)
        if _rt_bad:
            xbmc.log('Multi Bridge autoplay [%d/%d] %s descartado por duración incompatible (TMDb %d min vs archivo %d min)' % (
                idx+1, total_att, server, _exp_m, _act_m), xbmc.LOGWARNING)
            _record_session_failed_link(link, media_key=resume_media_key, meta=meta)
            _stop_player_cleanly(player)
            _restore_dialog_noblock()
            if total_att - (idx + 1) > 0:
                _show_bridge_notification('Multi Bridge · Autoplay', 'Película incorrecta (%d min vs %d min) · Probando siguiente...' % (_act_m, _exp_m), 3000)
            continue



        # Arrancar el monitor de bookmarks + reanudar AL INICIO de cada
        # reproduccion (no al final): asi el salto a reanudar ocurre a los
        # segundos y los bookmarks se guardan desde el principio.
        # Cada intento usa el punto guardado MAS RECIENTE (releido aqui):
        # el 1.º el que elegiste en el dialogo, los siguientes el que se
        # guardo mientras veias el anterior. (El monitor anterior termina
        # solo al detenerse su video.)
        try:
            _rk = resume_media_key or _get_media_key(meta, matched_item)
            _rt = resume_title or str((meta or {}).get('title') or (meta or {}).get('showname') or '')
            if _monitor_started and _want_resume:
                _sk = 0
                try:
                    _is_s2 = bool((meta or {}).get('season') and (meta or {}).get('episode'))
                    _bm2 = get_bookmark(_rk, tmdb_id=(meta or {}).get('tmdb'), is_series=_is_s2,
                                        season=(meta or {}).get('season'), episode=(meta or {}).get('episode'))
                    if _bm2 and float(_bm2.get('resume_time', 0)) > 10:
                        _sk = float(_bm2.get('resume_time', 0))
                except: pass
            elif not _monitor_started:
                _sk = seek_to_time
            else:
                _sk = 0
            start_playback_monitor(_rk, title_str=_rt, seek_to_time=_sk, current_link_index=idx, meta=meta)
        except Exception as _se:
            xbmc.log('Multi Bridge autoplay monitor inicio error: %s' % _se, xbmc.LOGINFO)
        _monitor_started = True

        mon_start       = time.time()
        user_declined   = False   # usuario dijo "No": parar y volver
        link_failed     = False   # usuario dijo "Si": continuar con siguiente
        _ver_enlaces    = False   # boton personalizado: abrir lista de enlaces

        while time.time() - mon_start < monitor_secs:
            if xbmc.Monitor().abortRequested():
                user_declined = True
                break

            if xbmc.Monitor().waitForAbort(1.0):
                user_declined = True
                break

            if not player.isPlaying():
                elapsed = time.time() - mon_start
                xbmc.log('Multi Bridge autoplay [%d/%d] %s se detuvo a %.1fs reales' % (
                    idx+1, total_att, server, elapsed), xbmc.LOGINFO)

                # Asegurar dialogo real SIN cerrojos (nunca puede bloquearse aqui)
                xbmc.log('Multi Bridge autoplay: restaurando dialogo real sin cerrojos...', xbmc.LOGINFO)
                _restore_dialog_noblock()

                # Esperar a que la ventana de vídeo de Kodi termine de cerrarse
                xbmc.sleep(600)

                xbmc.log('Multi Bridge autoplay: reproduccion detenida por usuario, cerrando.', xbmc.LOGINFO)
                user_declined = True
                break   # salir del while

        if user_declined:
            _cancelled_by_user = True
            try: player.stop()
            except: pass
            try: xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            except: pass
            xbmc.log('Multi Bridge autoplay: usuario detuvo → abriendo list_links', xbmc.LOGINFO)
            break

        if _ver_enlaces:
            # Abrir list_links para que el usuario elija enlace manualmente
            if tmdb_for_list:
                _ts = int(time.time())
                _lu = ('plugin://plugin.video.bridge.multi/?view=list_links'
                       '&tmdb=%s&t=%s' % (str(tmdb_for_list), _ts))
                if meta and meta.get('season') and meta.get('episode'):
                    _lu += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
                xbmc.log('Multi Bridge autoplay: ver enlaces → abriendo list_links', xbmc.LOGINFO)
                xbmc.executebuiltin('Dialog.Close(all,true)')
                xbmc.sleep(200)
                _open_links_view(_lu)
            return False

        if link_failed:
            try: player.stop()
            except: pass
            try: xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            except: pass
            for _ in range(30):
                try:
                    if not player.isPlaying():
                        break
                except: break
                xbmc.sleep(100)
            xbmc.sleep(600)
            continue   # → siguiente enlace

        # ── 60 s reales transcurridos con reproducción activa → ÉXITO ────────
        xbmc.log('Multi Bridge autoplay [%d/%d] %s verificado OK tras 3 min reales' % (
            idx+1, total_att, server), xbmc.LOGINFO)
        return True


    # ── Todos los intentos agotados ────────────────────────────────────────
    try: player.stop()
    except: pass
    try: xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except: pass

    if not player.isPlaying():
        if tmdb_for_list:
            _ts = int(time.time())
            _lu = ('plugin://plugin.video.bridge.multi/?view=list_links'
                   '&tmdb=%s&t=%s' % (str(tmdb_for_list), _ts))
            if meta and meta.get('season') and meta.get('episode'):
                _lu += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
            if _cancelled_by_user:
                xbmc.log('Multi Bridge autoplay: cancelado por usuario → abriendo list_links', xbmc.LOGINFO)
            else:
                xbmc.log('Multi Bridge autoplay: enlaces agotados → abriendo list_links', xbmc.LOGINFO)
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.sleep(200)
            _open_links_view(_lu)
        else:
            xbmcgui.Dialog().notification(
                'Multi Bridge',
                'Ningún enlace pudo reproducirse (%d intentos)' % total_att,
                '', 5000)
    return False



def _ensure_playback_headers_on_item(listitem, server_name="", page_url=""):
    """Solución GLOBAL para todos los servidores:
    Asegura que el ListItem y su URL contengan las cabeceras HTTP necesarias (User-Agent de navegador,
    Referer del servidor/página y verifypeer=false), evitando errores 403 Forbidden y 'Error opening file'
    de cualquier CDN (Doodstream, Streamtape, Voe, Mixdrop, Uqload, etc.).
    Garantiza que la URL final tenga estrictamente UN SOLO pipe '|' y cabeceras sin duplicados ni pipes residuales.
    Inyecta mimetype video/mp4 en ListItem para reproducción fluida en Android MediaCodec y ffmpeg.
    """
    if not listitem:
        return ""
    try:
        path = listitem.getPath()
        if not path or not path.startswith(('http://', 'https://')):
            return path or ""

        import urllib.parse
        raw_headers = {}
        if '|' in path:
            pipe_segments = path.split('|')
            base_url = pipe_segments[0]
            for seg in pipe_segments[1:]:
                for kv in seg.split('&'):
                    if '=' in kv:
                        k, v = kv.split('=', 1)
                        clean_k = urllib.parse.unquote_plus(k.strip()).split('|')[0].strip()
                        clean_v = urllib.parse.unquote_plus(v.strip()).split('|')[0].strip()
                        if clean_k and clean_v:
                            raw_headers[clean_k] = clean_v
        else:
            base_url = path

        # Normalizar claves de cabeceras de forma insensible a mayúsculas
        canonical_hdrs = {}
        for k, v in raw_headers.items():
            canonical_hdrs[k.strip().lower()] = (k.strip(), v.strip())

        # 1. User-Agent de navegador universal estándar
        if 'user-agent' not in canonical_hdrs:
            canonical_hdrs['user-agent'] = ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')

        # 2. Referer adecuado para el servidor o CDN
        srv_lower = (server_name or '').lower()
        bu_lower = base_url.lower()

        if 'referer' not in canonical_hdrs:
            ref = ''
            if page_url and page_url.startswith(('http://', 'https://')):
                ref = page_url.split('|')[0].strip()
            elif 'dood' in srv_lower or 'cloudatacdn' in bu_lower or 'ds2play' in srv_lower or 'playmogo' in bu_lower:
                ref = 'https://playmogo.com/'
            elif 'streamtape' in srv_lower or 'tapecontent' in bu_lower:
                ref = 'https://streamtape.com/'
            elif 'voe' in srv_lower:
                ref = 'https://voe.sx/'
            elif 'mixdrop' in srv_lower:
                ref = 'https://mixdrop.co/'
            elif 'uqload' in srv_lower:
                ref = 'https://uqload.io/'
            elif 'vidmoly' in srv_lower:
                ref = 'https://vidmoly.to/'
            elif 'filelions' in srv_lower:
                ref = 'https://filelions.to/'
            elif 'goodstream' in srv_lower:
                ref = 'https://goodstream.uno/'
            elif 'okru' in srv_lower or 'ok.ru' in srv_lower or 'okcdn.ru' in bu_lower or 'odnoklassniki' in bu_lower:
                ref = 'https://ok.ru/'
            else:
                parsed = urllib.parse.urlparse(base_url)
                if parsed.scheme and parsed.netloc:
                    ref = f"{parsed.scheme}://{parsed.netloc}/"

            if ref:
                canonical_hdrs['referer'] = ('Referer', ref)

        # 3. verifypeer=false para CDNs con certificados SSL específicos en Android
        if 'verifypeer' not in canonical_hdrs:
            canonical_hdrs['verifypeer'] = ('verifypeer', 'false')

        # 4. Mimetype e información de contenedor para Android MediaCodec
        is_hls_dash = ('.m3u8' in bu_lower) or ('.mpd' in bu_lower)
        if not is_hls_dash:
            try:
                listitem.setMimeType('video/mp4')
                listitem.setProperty('mimetype', 'video/mp4')
            except Exception:
                pass

        # Reconstruir pipe con cabeceras completas limpias
        final_hdrs = {orig_k: val for orig_k, val in canonical_hdrs.values()}
        pipe_parts = [f"{urllib.parse.quote_plus(k)}={urllib.parse.quote_plus(v)}" for k, v in final_hdrs.items()]
        safe_path = base_url + '|' + '&'.join(pipe_parts)
        listitem.setPath(safe_path)

        # Si es stream HLS/DASH, inyectar también a inputstream.adaptive
        if is_hls_dash:
            raw_hdr_str = '&'.join([f"{k}={v}" for k, v in final_hdrs.items()])
            try:
                listitem.setProperty('inputstream.adaptive.manifest_headers', raw_hdr_str)
                listitem.setProperty('inputstream.adaptive.stream_headers', raw_hdr_str)
            except Exception:
                pass
        return safe_path
    except Exception as e:
        xbmc.log(f"Multi Bridge _ensure_playback_headers_on_item error: {e}", xbmc.LOGWARNING)
        try:
            return listitem.getPath()
        except Exception:
            return ""


def _stop_player_cleanly(player=None):
    """Detiene el reproductor de Kodi, limpia la lista de reproducción y espera a que
    CVideoPlayer y el sink de audio (XAudio/AudioTrack/ALSA) liberen sus hilos antes de continuar."""
    if player is None:
        player = xbmc.Player()
    try:
        if xbmc.getCondVisibility("Player.Paused"):
            try: player.pause()
            except Exception: pass
            xbmc.sleep(50)
    except Exception:
        pass
    try:
        if player.isPlaying() or xbmc.getCondVisibility("Player.HasMedia"):
            player.stop()
    except Exception:
        pass
    try:
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception:
        pass
    mon = xbmc.Monitor()
    for _ in range(60):  # máx 3.0s esperando cierre limpio
        try:
            if not player.isPlaying() and not xbmc.getCondVisibility("Player.HasMedia"):
                break
        except Exception:
            break
        if mon.waitForAbort(0.05):
            break
    xbmc.sleep(250)


def _wait_for_playback_progress(player=None, mon=None, timeout=12.0, seek_to_time=0.0, server_name="", ignore_file=None):
    """Espera a que Kodi inicie la reproducción y verifica PROGRESIÓN REAL de reloj/fotogramas.

    Protege contra falsos positivos donde `player.isPlayingVideo()` devuelve True pero el
    códec de vídeo está fallando (ej. CBitstreamConverter::Convert error en Android MediaCodec
    o FFmpeg/XAudio colgado en Windows, reloj estancado en 0.0s sin fotogramas ni audio válido).

    Retorna True solo si el vídeo arranca y el reloj de reproducción avanza efectivamente.
    Retorna False si expira el tiempo, se abre diálogo de error de Kodi, el reproductor cae,
    o el tiempo se queda estancado (codec freeze).
    """
    if player is None:
        player = xbmc.Player()
    if mon is None:
        mon = xbmc.Monitor()

    t_start = time.time()
    effective_timeout = max(10.0, min(float(timeout or 14.0), 22.0))
    had_loading = False
    idle_count = 0

    while time.time() - t_start < effective_timeout:
        if mon.abortRequested():
            return False

        # Detección inmediata de diálogo modal de error de Kodi ("Uno o más elementos fallaron...")
        if _is_kodi_modal_dialog_open():
            try:
                xbmc.executebuiltin('Dialog.Close(okdialog,true)')
                xbmc.executebuiltin('Dialog.Close(10100,true)')
            except Exception:
                pass
            xbmc.log("Multi Bridge Watchdog: diálogo modal de error de Kodi detectado [%s] -> descartando" % server_name, xbmc.LOGINFO)
            return False

        # Comprobar si el vídeo ya abrió demuxer y levantó el hilo de reproducción
        if player.isPlayingVideo():
            if ignore_file:
                try:
                    _cur_pf = player.getPlayingFile() or ''
                except Exception:
                    _cur_pf = ''
                if _cur_pf and _cur_pf == ignore_file and (time.time() - t_start) < 3.5:
                    xbmc.sleep(100)
                    continue
            # STREAM ABIERTO: Verificar avance real del reloj de reproducción
            t_first_playing = time.time()
            t_chk_start = t_first_playing
            initial_t = -1.0
            max_stall_time = 3.5     # límite sin buffering
            max_abs_stall_time = 5.5 # límite absoluto incluso si Player.Buffering parpadea
            cur_t = -1.0

            while (time.time() - t_chk_start) < max_stall_time and (time.time() - t_first_playing) < max_abs_stall_time:
                if mon.abortRequested():
                    return False
                if _is_kodi_modal_dialog_open():
                    try:
                        xbmc.executebuiltin('Dialog.Close(okdialog,true)')
                        xbmc.executebuiltin('Dialog.Close(10100,true)')
                    except Exception:
                        pass
                    return False
                if not player.isPlayingVideo():
                    xbmc.log("Multi Bridge Watchdog: el reproductor se cerró repentinamente tras iniciar [%s]" % server_name, xbmc.LOGINFO)
                    return False

                try:
                    cur_t = float(player.getTime())
                except Exception:
                    cur_t = -1.0

                if initial_t < 0 and cur_t >= 0.0:
                    initial_t = cur_t

                # Criterio universal de progreso real: reloj >= 0.35s y con avance medible >= 0.20s
                if cur_t >= 0.35 and (initial_t < 0 or (cur_t - initial_t) >= 0.20):
                    if ignore_file:
                        try:
                            xbmc.executebuiltin('Dialog.Close(seekbar,true)')
                            xbmc.executebuiltin('Dialog.Close(videoosd,true)')
                            xbmc.executebuiltin('Dialog.Close(fullscreeninfo,true)')
                        except Exception:
                            pass
                    return True

                # Si Kodi está buffereando activamente, extender margen hasta max_abs_stall_time (nunca infinito)
                try:
                    if xbmc.getCondVisibility("Player.Buffering"):
                        t_chk_start = time.time()
                except Exception:
                    pass

                xbmc.sleep(150)

            # Si el bucle de verificación de progreso expiró sin avance real:
            xbmc.log("Multi Bridge Watchdog: fallo de decodificación o freeze de códec detectado (isPlayingVideo=True pero getTime()=%.2fs tras %.1fs) [%s]" % (
                cur_t, time.time() - t_first_playing, server_name), xbmc.LOGWARNING)
            return False

        # Estado de carga / buffering
        is_loading = False
        try:
            if player.isPlaying():
                is_loading = True
            elif (
                xbmc.getCondVisibility("Player.Buffering") or
                xbmc.getCondVisibility("Player.HasMedia") or
                xbmc.getCondVisibility("Player.HasVideo") or
                xbmc.getCondVisibility("Player.HasAudio")
            ):
                is_loading = True
        except Exception:
            is_loading = False

        if is_loading:
            had_loading = True
            idle_count = 0
            # Si Kodi está cargando activamente, dar margen extra (hasta 26s máx)
            if time.time() - t_start > (effective_timeout - 4):
                effective_timeout = min(effective_timeout + 2.0, 26.0)
        elif had_loading:
            idle_count += 1
            if idle_count >= 5 and (time.time() - t_start > 2.0):
                xbmc.log("Multi Bridge Watchdog: stream se detuvo prematuramente (EOF/fallo demuxer) [%s]" % server_name, xbmc.LOGINFO)
                return False

        if mon.waitForAbort(0.2):
            return False

    return False



_BG_COLLECTOR_TOKEN = 0
_BG_COLLECTOR_LOCK = threading.Lock()
_BG_COLLECTOR_RUNNING = False

def _fast_autoplay_background_collector(engine, meta, matched_item_holder, playing_link, enabled_players, started_indices, results_dict, results_lock, all_found_links, search_params, initial_links, collector_token=0):
    global _BG_COLLECTOR_RUNNING
    with _BG_COLLECTOR_LOCK:
        _BG_COLLECTOR_RUNNING = True
    try:
        _fast_autoplay_background_collector_impl(engine, meta, matched_item_holder, playing_link, enabled_players, started_indices, results_dict, results_lock, all_found_links, search_params, initial_links, collector_token)
    finally:
        with _BG_COLLECTOR_LOCK:
            _BG_COLLECTOR_RUNNING = False

def _fast_autoplay_background_collector_impl(engine, meta, matched_item_holder, playing_link, enabled_players, started_indices, results_dict, results_lock, all_found_links, search_params, initial_links, collector_token=0):
    """Continúa la búsqueda de TODOS los canales restantes en segundo plano
    y verifica todos los enlaces de forma suave (bajo consumo CPU), actualizando la
    caché de sesión para que al pausar (¿Cambiar enlace?) o detener el vídeo estén todos disponibles."""
    mon = xbmc.Monitor()
    xbmc.log("Multi Bridge Fast Autoplay: recolector en segundo plano iniciado para completar búsqueda total...", xbmc.LOGINFO)

    (is_series, target_title, target_year, p_season, p_episode, all_names, alt_terms, p_tmdb, p_imdb) = search_params

    orig_sock_to = socket.getdefaulttimeout()
    socket.setdefaulttimeout(5.0)

    # Función para ejecutar canales que no se iniciaron en la fase instantánea
    def _bg_ch_worker(ch_info):
        if mon.abortRequested() or collector_token != _BG_COLLECTOR_TOKEN or _BG_TASK_ABORT_EVENT.is_set():
            return
        try:
            ch_key = ch_info.get('id') or ch_info.get('channel')
            with silenced_dialogs():
                it, links = _search_on_player(
                    ch_info, engine, is_series, target_title, target_year,
                    p_season, p_episode, all_names, alt_terms=alt_terms,
                    target_tmdb=p_tmdb, target_imdb=p_imdb
                )
            if links and not mon.abortRequested() and not _BG_TASK_ABORT_EVENT.is_set() and collector_token == _BG_COLLECTOR_TOKEN:
                links = _filter_discarded_links(links)
                if links:
                    for l in links:
                        try: l.bridge_engine = engine
                        except: pass
                    with results_lock:
                        results_dict[ch_key] = (it, links)
                        if not matched_item_holder[0] and it:
                            matched_item_holder[0] = it
                        all_found_links.extend(links)
        except Exception:
            pass

    # Identificar canales pendientes
    remaining_channels = [
        ch for idx, ch in enumerate(enabled_players)
        if idx not in started_indices
    ]
    bg_threads = []
    for ch_info in remaining_channels:
        bg_threads.append(threading.Thread(target=_bg_ch_worker, args=(ch_info,), daemon=True))

    max_bg_workers = 4 # Concurrencia suave para 0 impacto en CPU durante reproducción
    active_workers = []
    i_rem = 0
    deadline = time.time() + 45.0

    try:
        while time.time() < deadline and not mon.abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
            if collector_token != _BG_COLLECTOR_TOKEN:
                xbmc.log('Multi Bridge Fast Autoplay BgCollector: nueva sesion activa, cancelando recolector previo.', xbmc.LOGINFO)
                return
            active_workers = [t for t in active_workers if t.is_alive()]
            while i_rem < len(bg_threads) and len(active_workers) < max_bg_workers:
                th = bg_threads[i_rem]
                th.start()
                active_workers.append(th)
                i_rem += 1

            if i_rem >= len(bg_threads) and len(active_workers) == 0:
                break
            if mon.waitForAbort(0.25):
                return

        if mon.abortRequested() or _BG_TASK_ABORT_EVENT.is_set():
            return
    finally:
        for _th in active_workers:
            try:
                if _th.is_alive():
                    _th.join(0.15)
            except Exception: pass
        try:
            socket.setdefaulttimeout(orig_sock_to or 10.0)
        except Exception: pass

    xbmc.log("Multi Bridge Fast Autoplay: búsqueda de todos los canales completada en segundo plano. Recolectando enlaces...", xbmc.LOGINFO)

    # Recolectar todos los enlaces de todos los canales
    all_links = []
    with results_lock:
        for ch_key, data in results_dict.items():
            it, ch_links = data
            if ch_links:
                all_links.extend(ch_links)

    if not all_links:
        all_links = list(initial_links)

    seen = set()
    dedup = []
    for l in all_links:
        u = getattr(l, 'url', None) or id(l)
        if u not in seen:
            seen.add(u)
            dedup.append(l)

    # Filtrar y ordenar según preferencias del usuario (Idioma, Calidad, Servidores)
    sorted_links = _filter_and_sort_links(dedup)

    auto_verify = (_bridge_addon.getSetting('auto_verify_links') == 'true')
    hide_captcha = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
    try:
        setattr(playing_link, '_bridge_verified', True)
    except Exception:
        pass

    p_url = _safe_str(getattr(playing_link, 'url', '') or '')
    verified_links = []
    pending_unverified = []

    if auto_verify and xbmc.Player().isPlayingVideo():
        # Vídeo en reproducción activa: NO meter enlaces directos sin verificar en 'links'.
        # Torrents y captchas (si no están ocultos) se envían directamente sin verificarse ni contar al límite;
        # solo los directos normales entran en 'unverified_links' para Fase 1.
        xbmc.log("Multi Bridge Fast Autoplay: vídeo en reproducción activa, delegando directos a Fase 1 (torrents y captchas pasan directo)." , xbmc.LOGINFO)
        for l in sorted_links:
            l_url = _safe_str(getattr(l, 'url', '') or '')
            if (l_url and p_url and l_url == p_url) or l == playing_link:
                continue
            if _is_torrent_link(l):
                verified_links.append(l)
            elif _is_web_captcha_server(_get_link_server_name(l), l):
                if not hide_captcha:
                    verified_links.append(l)
            elif getattr(l, '_bridge_verified', False):
                verified_links.append(l)
            else:
                pending_unverified.append(l)
    elif auto_verify:
        xbmc.log("Multi Bridge Fast Autoplay: verificando %d enlaces en segundo plano suavemente..." % len(sorted_links), xbmc.LOGINFO)
        with silenced_dialogs():
            try:
                v_res = _verify_links_headless(sorted_links, engine=engine, p_dialog=None)
                verified_links = v_res if v_res else []
            except Exception as _ve:
                xbmc.log("Multi Bridge Fast Autoplay: error verificando en segundo plano: %s" % _ve, xbmc.LOGWARNING)
                verified_links = [l for l in sorted_links if _is_torrent_link(l) or getattr(l, '_bridge_verified', False)]
    else:
        verified_links = sorted_links

    # Enlace en reproducción siempre en índice 0
    final_links = [playing_link]
    for l in verified_links:
        l_url = _safe_str(getattr(l, 'url', '') or '')
        if (l_url and p_url and l_url == p_url) or l == playing_link:
            continue
        final_links.append(l)

    if collector_token != _BG_COLLECTOR_TOKEN:
        xbmc.log('Multi Bridge Fast Autoplay BgCollector: sesion superada por otra busqueda, omitiendo guardado de cache.', xbmc.LOGINFO)
        return
    meta_copy = dict(meta)
    meta_copy['verified_only'] = bool(auto_verify)
    try:
        _store_ram_search_cache(final_links, matched_item_holder[0], meta_copy, engine, unverified_links=pending_unverified)
        _save_search_cache_atomic({
            'item': _serialize_item(matched_item_holder[0]),
            'links': [_serialize_item(l) for l in final_links],
            'unverified_links': [_serialize_item(l) for l in pending_unverified],
            'meta': meta_copy,
            'engine': engine,
            'is_preloaded_session': bool(pending_unverified),
            'cache_ver': 2
        })
        xbmc.log("Multi Bridge Fast Autoplay: caché actualizada (%d verificados/activos, %d pendientes de verificación en Fase 1)" % (
            len(final_links), len(pending_unverified)), xbmc.LOGINFO)
        if _in_own_list():
            xbmc.executebuiltin('Container.Refresh')
    except Exception as _ce:
        xbmc.log("Multi Bridge Fast Autoplay: error guardando caché: %s" % _ce, xbmc.LOGWARNING)


def _fast_autoplay_search_and_play(engine, handle, cached_links=None, cached_item=None):
    """Ejecuta la busqueda de canales y reproduce de forma instantanea tan pronto
    como el primer canal devuelva enlaces y el primer enlace preferente funcione.
    En segundo plano y con bajo consumo de CPU, se completa la busqueda del resto de
    canales y la verificacion total para nutrir el dialogo de pausa y la lista."""
    xbmcgui.Window(10000).setProperty('bridge.in_autoplay', 'true')
    global _BG_COLLECTOR_TOKEN
    with _BG_COLLECTOR_LOCK:
        _BG_COLLECTOR_TOKEN += 1
        my_collector_token = _BG_COLLECTOR_TOKEN
    p_title = title or get_param('title') or get_param('title_es') or get_param('title_lat') or get_param('title_orig') or get_param('title_en') or ''
    p_showname = showname or get_param('showname') or ''
    p_year = year or get_param('year') or ''
    p_showyear = showyear or get_param('showyear') or ''
    p_season = season or get_param('season') or ''
    p_episode = episode or get_param('episode') or ''
    p_tmdb = tmdb_id or get_param('tmdb') or ''
    p_imdb = imdb_id or get_param('imdb') or ''
    p_tvdb = tvdb_id or get_param('tvdb') or ''
    p_trakt = trakt_id or get_param('trakt') or ''

    is_series = bool(p_season and p_episode)
    if is_series and engine == 'alfa':
        engine = 'balandro'

    p_poster = poster or get_param('poster') or thumbnail or get_param('thumbnail') or get_param('thumb') or ''
    p_fanart = fanart or get_param('fanart') or ''
    if not p_poster:
        try: p_poster = xbmcgui.Window(10000).getProperty('TMDbHelper.ListItem.Poster') or xbmc.getInfoLabel('ListItem.Art(poster)') or ''
        except: pass
    if not p_fanart:
        try: p_fanart = xbmcgui.Window(10000).getProperty('TMDbHelper.ListItem.Fanart') or xbmc.getInfoLabel('ListItem.Art(fanart)') or ''
        except: pass

    p_genre = (genre if genre and genre not in ('_', 'None') else '') or (get_param('genre') if get_param('genre') not in ('_', 'None', None) else '') or ''
    if not p_genre:
        try: p_genre = xbmc.getInfoLabel('ListItem.Genre') or ''
        except: pass

    meta = {
        'tmdb': p_tmdb, 'imdb': p_imdb, 'tvdb': p_tvdb, 'trakt': p_trakt,
        'title': p_title or ((p_showname if is_series else '') or ''),
        'year': p_showyear if is_series else p_year,
        'season': p_season, 'episode': p_episode,
        'showname': p_showname, 'showyear': p_showyear,
        'plot': plot or get_param('plot') or '',
        'director': _clean_single_director(director) or _clean_single_director(get_param('director')) or '',
        'tagline': tagline or get_param('tagline') or '',
        'poster': p_poster,
        'fanart': p_fanart,
        'thumbnail': thumbnail or get_param('thumbnail') or p_poster or '',
        'clearlogo': (clearlogo if clearlogo and clearlogo not in ('_', 'None') else '') or (get_param('clearlogo') if get_param('clearlogo') not in ('_', 'None', None) else '') or '',
        'genre': p_genre,
        'verified_only': False, 'engine': engine
    }

    if is_series:
        target_title = (p_showname or p_title or '').strip()
        target_year = p_showyear or p_year
        all_names = [t for t in [target_title, p_showname, title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_en or get_param('title_en'), title_orig or get_param('title_orig')] if t]
        for _n in list(all_names):
            if '(' in _n and ')' in _n:
                for inside in re.findall(r'\((.*?)\)', _n):
                    inside_clean = inside.strip()
                    if inside_clean and not re.match(r'^\d{4}$', inside_clean) and inside_clean not in all_names:
                        all_names.append(inside_clean)
                outside = re.sub(r'\(.*?\)', '', _n).strip()
                if outside and outside not in all_names:
                    all_names.append(outside)
        alt_terms = [t for t in all_names if t != target_title]
    else:
        target_title = (p_title or '').strip()
        target_year = p_year
        all_names = [t for t in [target_title, title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_en or get_param('title_en'), title_orig or get_param('title_orig')] if t]
        alt_terms = [t for t in [title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_orig or get_param('title_orig'), title_en or get_param('title_en')] if t and t != target_title]

    # Complementar variantes de título desde TMDb también en Fast Autoplay (ej. 'La Odisea' + 'The Odyssey')
    try:
        _distinct_fa = len(set([_safe_str(x).lower().strip() for x in all_names if x]))
        if p_tmdb and _distinct_fa < 3:
            _fetched_fa = _fetch_tmdb_titles(p_tmdb, is_series)
            for _ft in (_fetched_fa or []):
                if _ft and _ft not in all_names:
                    all_names.append(_ft)
                if _ft and _ft != target_title and _ft not in alt_terms:
                    alt_terms.append(_ft)
        for _av in _alias_variants(all_names):
            if _av and _av not in all_names:
                all_names.append(_av)
            if _av and _av != target_title and _av not in alt_terms:
                alt_terms.append(_av)
    except Exception:
        pass

    # ── Reproducción instantánea desde CACHÉ si está disponible ──────────────
    if not cached_links:
        try:
            r_cache = _get_ram_search_cache(target_tmdb=p_tmdb, target_season=p_season, target_episode=p_episode)
            if r_cache and r_cache.get('links'):
                c_meta = r_cache.get('meta', {}) or {}
                if _is_same_media_item(c_meta, meta):
                    cached_links = [l for l in r_cache['links'] if l is not None and getattr(l, 'url', None)]
                    if not cached_item:
                        cached_item = r_cache.get('matched_item')
                    if cached_links:
                        xbmc.log("Multi Bridge Fast Autoplay: reutilizando %d enlaces desde caché RAM" % len(cached_links), xbmc.LOGINFO)
            if not cached_links and os.path.exists(SEARCH_CACHE_FILE):
                _c_data = _read_search_cache_atomic()
                if _c_data and isinstance(_c_data, dict):
                    c_meta = _c_data.get('meta', {}) or {}
                    if _is_same_media_item(c_meta, meta):
                        raw_links = [l for l in _c_data.get('links', []) if isinstance(l, dict) and l.get('url')]
                        if raw_links:
                            c_eng = _c_data.get('engine', engine) or engine
                            cached_links = [_deserialize_item(l, c_eng) for l in raw_links]
                            cached_links = [l for l in cached_links if l is not None and getattr(l, 'url', None)]
                            if not cached_item and _c_data.get('item'):
                                cached_item = _deserialize_item(_c_data.get('item'), c_eng)
                            if cached_links:
                                xbmc.log("Multi Bridge Fast Autoplay: reutilizando %d enlaces desde caché de disco" % len(cached_links), xbmc.LOGINFO)
        except Exception as _ce:
            xbmc.log("Multi Bridge Fast Autoplay: error leyendo caché previa: %s" % _ce, xbmc.LOGWARNING)

    cached_failed_urls = set()
    if cached_links:
        sorted_cached = _filter_and_sort_links(cached_links)
        normal_cached = [
            l for l in sorted_cached
            if not _is_torrent_link(l) and not _is_web_captcha_server(_get_link_server_name(l), l)
        ]
        if normal_cached:
            xbmc.log("Multi Bridge Fast Autoplay: evaluando %d enlaces en caché..." % len(normal_cached), xbmc.LOGINFO)
            _extra_info = _get_single_genre(meta) or ('%s' % (meta.get('year') or ''))
            p_dialog_c = _AutoplayProgressDialog(
                target_title=target_title,
                poster_url=meta.get('poster') or '',
                fanart_url=meta.get('fanart') or '',
                extra_info=_extra_info,
                meta=meta
            )
            p_dialog_c.create('[COLOR gold][B]Multi Bridge[/B][/COLOR]  •  [COLOR white]AUTOPLAY[/COLOR]', 'Iniciando reproducción...')
            p_dialog_c.update(25)

            handle_absorbed = False
            resume_prompted = False
            seek_to_time = 0
            cached_play_attempts = 0
            max_cached_play_attempts = 3
            player = xbmc.Player()
            mon = xbmc.Monitor()

            for cand in normal_cached:
                if cached_play_attempts >= max_cached_play_attempts:
                    break
                if p_dialog_c and p_dialog_c.iscanceled():
                    xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
                    try: p_dialog_c.close()
                    except: pass
                    if not handle_absorbed and handle >= 0:
                        try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                        except: pass
                    return False

                cand_u_key = _safe_str(getattr(cand, 'url', '')) or str(id(cand))
                srv_name = _get_link_server_name(cand)
                lang_raw = _format_language(cand)
                cand_qual = _format_quality(cand)
                if p_dialog_c:
                    try:
                        p_dialog_c.set_stream_info(
                            server=srv_name,
                            quality=cand_qual or '1080p',
                            language=lang_raw or 'Latino',
                            channel='',
                            status='Iniciando reproducción...'
                        )
                    except Exception: pass
                    try: p_dialog_c.update(60)
                    except Exception: pass

                _res_box = [False, None]
                def _do_res_cached(c=cand):
                    with silenced_dialogs():
                        try:
                            _r_ok, _r_li = _resolve_link_to_listitem(c, engine, cached_item)
                            _res_box[0] = _r_ok
                            _res_box[1] = _r_li
                        except: pass

                _th_c = threading.Thread(target=_do_res_cached, daemon=True)
                _th_c.start()
                cand_timeout = max(10.0, float(_get_int_setting('autoplay_resolve_timeout', 12)))
                res_start = time.time()
                while _th_c.is_alive() and (time.time() - res_start) < cand_timeout:
                    if p_dialog_c and p_dialog_c.iscanceled():
                        xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
                        try: p_dialog_c.close()
                        except: pass
                        if not handle_absorbed and handle >= 0:
                            try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                            except: pass
                        return False
                    xbmc.sleep(100)
                _th_c.join(timeout=0.2)

                ok, li = _res_box[0], _res_box[1]
                if not ok or not li:
                    cached_failed_urls.add(cand_u_key)
                    continue

                m_url = ''
                try: m_url = li.getPath()
                except: pass
                is_ok, real_res = _check_stream_url_playable(m_url, server_name=srv_name, timeout=3.0)
                if not m_url or not is_ok:
                    cached_failed_urls.add(cand_u_key)
                    xbmc.log("Multi Bridge Fast Autoplay (Caché): candidato %s no superó verificación de stream" % srv_name, xbmc.LOGINFO)
                    continue

                if real_res and not _is_cam_quality(cand):
                    cand.real_quality = real_res
                    cand.quality = real_res
                    try: li.setInfo('video', {'quality': real_res})
                    except: pass
                _ensure_playback_headers_on_item(li, server_name=srv_name, page_url=getattr(cand, 'url', '') or '')
                try:
                    fast_url = li.getPath() or m_url
                except Exception:
                    fast_url = m_url
                if not fast_url:
                    cached_failed_urls.add(cand_u_key)
                    continue

                if p_dialog_c:
                    q_show = _format_quality(cand)
                    lang_fmt = _format_language(cand)
                    try:
                        p_dialog_c.set_stream_info(
                            server=srv_name,
                            quality=q_show or '1080p',
                            language=lang_fmt or 'Latino',
                            channel='',
                            status='Iniciando reproducción...'
                        )
                        p_dialog_c.update(100)
                    except Exception: pass
                    try: p_dialog_c.close(); del p_dialog_c
                    except: pass
                    p_dialog_c = None
                    try: xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
                    except: pass

                if not handle_absorbed:
                    handle_absorbed = True
                    _guard_stop = [False]
                    def _suppress():
                        for _ in range(30):
                            if _guard_stop[0]: break
                            try:
                                xbmc.executebuiltin('Dialog.Close(okdialog,true)')
                                xbmc.executebuiltin('Dialog.Close(error,true)')
                            except: pass
                            time.sleep(0.1)
                    _gt = threading.Thread(target=_suppress, daemon=True)
                    _gt.start()

                    _absorb = xbmcgui.ListItem()
                    try: xbmcplugin.setResolvedUrl(int(handle), False, _absorb)
                    except: pass
                    xbmc.sleep(250)
                    _guard_stop[0] = True
                    try: _gt.join(timeout=0.5)
                    except: pass

                if cached_item:
                    _enrich_link_metadata(cand, meta, cached_item)
                media_key = _get_media_key(meta, cand)

                if not resume_prompted:
                    resume_prompted = True
                    is_s = bool(meta.get('season') and meta.get('episode'))
                    bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s,
                                      season=meta.get('season'), episode=meta.get('episode'))
                    if bm:
                        r_time = float(bm.get('resume_time', 0))
                        if r_time > 10:
                            mins = int(r_time // 60); secs = int(r_time % 60)
                            hrs = mins // 60; mins = mins % 60
                            time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
                            t_title = meta.get('title') or getattr(cached_item, 'title', '') or 'este video'
                            ans = _ask_resume_dialog(t_title, time_str, media_key=media_key)
                            if ans == 'cancel':
                                xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
                                return False
                            elif ans == 'resume':
                                seek_to_time = r_time
                            elif ans == 'restart':
                                seek_to_time = 0

                sync_tmdbhelper_playerstring(meta)
                set_listitem_info(li, meta=meta)
                if seek_to_time > 10:
                    li.setProperty('StartOffset', str(seek_to_time))
                    li.setProperty('ResumeTime', str(seek_to_time))
                    try:
                        vt = li.getVideoInfoTag()
                        if vt: vt.setResumePoint(float(seek_to_time))
                    except Exception: pass

                cached_play_attempts += 1
                xbmc.log("Multi Bridge Fast Autoplay: ¡Iniciando reproducción instantánea desde CACHÉ con %s! (intento %d/%d)" % (
                    srv_name, cached_play_attempts, max_cached_play_attempts), xbmc.LOGINFO)
                player.play(fast_url, li)

                watchdog_timeout = _get_int_setting('autoplay_resolve_timeout', 12)
                if watchdog_timeout < 10: watchdog_timeout = 10
                if watchdog_timeout > 16: watchdog_timeout = 16

                video_started = _wait_for_playback_progress(
                    player=player, mon=mon,
                    timeout=watchdog_timeout,
                    seek_to_time=seek_to_time,
                    server_name=srv_name
                )
                if mon.abortRequested():
                    return True

                if video_started and player.isPlayingVideo() and not _is_kodi_modal_dialog_open():
                    _rt_bad_c, _exp_c, _act_c = _is_playing_wrong_runtime(player, p_tmdb, is_series=is_series)
                    if _rt_bad_c:
                        xbmc.log("Multi Bridge Fast Autoplay: candidato en caché [%s] descartado por duración incompatible (TMDb %d min vs archivo %d min)" % (srv_name, _exp_c, _act_c), xbmc.LOGWARNING)
                        cached_failed_urls.add(cand_u_key)
                        _record_session_failed_link(cand, media_key=media_key, meta=meta)
                        _stop_player_cleanly(player)
                        continue
                    xbmc.log("Multi Bridge Fast Autoplay: ¡Reproducción desde caché confirmada [%s]!" % srv_name, xbmc.LOGINFO)
                    try: setattr(cand, '_bridge_verified', True)
                    except Exception: pass
                    final_cached = [cand] + [l for l in cached_links if getattr(l, 'url', None) != getattr(cand, 'url', None)]
                    _prev_unverified = []
                    try:
                        _rc = _get_ram_search_cache(target_tmdb=p_tmdb, target_season=p_season, target_episode=p_episode)
                        if _rc and isinstance(_rc, dict) and _rc.get('unverified_links'):
                            _prev_unverified = list(_rc.get('unverified_links') or [])
                        elif os.path.exists(SEARCH_CACHE_FILE):
                            _dc = _read_search_cache_atomic()
                            if _dc and isinstance(_dc, dict) and _dc.get('unverified_links'):
                                _prev_unverified = [_deserialize_item(x, engine) if isinstance(x, dict) else x for x in (_dc.get('unverified_links') or [])]
                                _prev_unverified = [x for x in _prev_unverified if x and getattr(x, 'url', None)]
                    except Exception:
                        _prev_unverified = []
                    _rem_unv = [l for l in _prev_unverified if getattr(l, 'url', None) != getattr(cand, 'url', None)]
                    meta_c = dict(meta)
                    meta_c['verified_only'] = (_bridge_addon.getSetting('auto_verify_links') == 'true')
                    try:
                        _store_ram_search_cache(final_cached, cached_item, meta_c, engine, unverified_links=_rem_unv)
                        _save_search_cache_atomic({
                            'item': _serialize_item(cached_item),
                            'links': [_serialize_item(l) for l in final_cached],
                            'unverified_links': [_serialize_item(l) for l in _rem_unv],
                            'meta': meta_c,
                            'engine': engine,
                            'is_preloaded_session': bool(_rem_unv),
                            'cache_ver': 2
                        })
                    except Exception: pass
                    try:
                        xbmc.executebuiltin('Dialog.Close(busydialog,true)')
                        xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
                    except Exception: pass
                    start_playback_monitor(media_key, title_str=meta.get('title', ''), seek_to_time=seek_to_time, current_link_index=0, meta=meta)
                    wait_for_playback_monitor()
                    return True

                xbmc.log("Multi Bridge Fast Autoplay: candidato en caché [%s] falló al arrancar -> limpiando y probando siguiente..." % srv_name, xbmc.LOGWARNING)
                cached_failed_urls.add(cand_u_key)
                _record_session_failed_link(cand, media_key=media_key, meta=meta)
                _stop_player_cleanly(player)

            if p_dialog_c:
                try: p_dialog_c.close(); del p_dialog_c
                except: pass
                try: xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
                except: pass
            xbmc.log("Multi Bridge Fast Autoplay: enlaces en caché no arrancaron en Kodi, continuando con búsqueda en canales...", xbmc.LOGINFO)

    ch_data = load_channels_data()
    engine_channels = ch_data.get('channels', {}).get(engine, {})
    enabled_players = []
    for ch_id in sorted(engine_channels.keys(), key=lambda k: engine_channels[k].get('name', k).lower()):
        ch_info = engine_channels[ch_id]
        if is_series:
            if not ch_info.get('series'): continue
            if ch_info.get('series_disabled'): continue
        else:
            if not ch_info.get('movies'): continue
            if ch_info.get('movie_disabled'): continue
        enabled_players.append(ch_info)

    if not enabled_players:
        return False

    # Priorizar canales reconocidos como rapidos para obtener el primer enlace casi de inmediato
    if engine == 'balandro':
        _fast_order = ['cuevana2', 'homecine', 'pelispanda', 'lamovie', 'areshd', 'pelispediais', 'hdfull']
        def _ch_prio(c):
            cid = str(c.get('channel') or c.get('id') or '').lower()
            for idx, f in enumerate(_fast_order):
                if f in cid: return idx
            return 99
        enabled_players = sorted(enabled_players, key=_ch_prio)
    elif engine == 'alfa':
        _fast_order = ['planb', 'cinecalidad', 'dontorrent', 'hdfull']
        def _ch_prio(c):
            cid = str(c.get('channel') or c.get('id') or '').lower()
            for idx, f in enumerate(_fast_order):
                if f in cid: return idx
            return 99
        enabled_players = sorted(enabled_players, key=_ch_prio)

    total_channels = len(enabled_players)
    _extra_info = _get_single_genre(meta) or ('%s' % (meta.get('year') or ''))
    p_dialog = _AutoplayProgressDialog(
        target_title=target_title,
        poster_url=meta.get('poster') or '',
        fanart_url=meta.get('fanart') or '',
        extra_info=_extra_info,
        meta=meta
    )
    p_dialog.create('[COLOR gold][B]Multi Bridge[/B][/COLOR]  •  [COLOR white]AUTOPLAY[/COLOR]', 'Iniciando reproducción...')
    p_dialog.update(5)

    results_dict = {}
    results_lock = threading.Lock()
    all_found_links = []
    matched_item_holder = [None]
    channel_event = threading.Event()

    def _ch_worker(ch_info):
        try:
            ch_key = ch_info.get('id') or ch_info.get('channel')
            with silenced_dialogs():
                it, links = _search_on_player(
                    ch_info, engine, is_series, target_title, target_year,
                    p_season, p_episode, all_names, alt_terms=alt_terms,
                    target_tmdb=p_tmdb, target_imdb=p_imdb
                )
            if links:
                links = _filter_discarded_links(links)
                if links:
                    for l in links:
                        try: l.bridge_engine = engine
                        except: pass
                    with results_lock:
                        results_dict[ch_key] = (it, links)
                        if not matched_item_holder[0] and it:
                            matched_item_holder[0] = it
                        all_found_links.extend(links)
                    channel_event.set()
        except Exception:
            pass

    threads = []
    for ch_info in enabled_players:
        threads.append(threading.Thread(target=_ch_worker, args=(ch_info,), daemon=True))

    max_search_workers = min(35, max(1, _get_int_setting('search_threads_max', 6)))
    started_indices = set()
    completed_indices = set()
    thread_start_times = {}
    start_time = time.time()
    timeout_secs = min(60, max(10, _get_int_setting('search_timeout', 40)))

    tested_urls = set(cached_failed_urls)
    fast_link = None
    fast_li = None
    fast_url = ''

    i_ch = 0
    mon = xbmc.Monitor()

    while not mon.abortRequested():
        now = time.time()
        active_cnt = len([idx for idx in started_indices if idx not in completed_indices and threads[idx].is_alive()])
        while i_ch < len(threads) and active_cnt < max_search_workers:
            threads[i_ch].start()
            started_indices.add(i_ch)
            thread_start_times[i_ch] = now
            active_cnt += 1
            i_ch += 1

        for idx in list(started_indices):
            if idx not in completed_indices and not threads[idx].is_alive():
                completed_indices.add(idx)

        completed = len(completed_indices)
        pct = int((completed / float(total_channels)) * 100) if total_channels else 100

        if p_dialog.iscanceled():
            xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
            try: p_dialog.close()
            except: pass
            if handle >= 0:
                try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                except: pass
            return False

        p_dialog.update(min(pct, 85), 'Buscando servidores...')

        all_done = (completed >= total_channels) or ((time.time() - start_time) >= 12.0)

        # Comprobar si hay nuevos enlaces para probar
        with results_lock:
            current_batch = list(all_found_links)

        if current_batch:
            # Ordenar segun preferencias estrictas del usuario (Idioma, Calidad, Servidores)
            sorted_cand = _filter_and_sort_links(current_batch)
            normal_cand = [
                l for l in sorted_cand
                if not _is_torrent_link(l)
                and not _is_web_captcha_server(_get_link_server_name(l), l)
                and (_safe_str(getattr(l, 'url', '')) or str(id(l))) not in tested_urls
            ]

            b_prefs = _get_filter_prefs()

            for cand in normal_cand:
                if not _is_preferred_lang_candidate(cand, b_prefs, all_done=all_done):
                    continue

                link_key = _safe_str(getattr(cand, 'url', '')) or str(id(cand))
                tested_urls.add(link_key)
                cand_u = getattr(cand, 'url', None)

                srv_name = _get_link_server_name(cand)
                lang_raw = _format_language(cand)
                cand_qual = _format_quality(cand)
                try:
                    p_dialog.set_stream_info(
                        server=srv_name,
                        quality=cand_qual or '1080p',
                        language=lang_raw or 'Latino',
                        channel='',
                        status='Iniciando reproducción...'
                    )
                except Exception:
                    pass
                p_dialog.update(min(pct, 90), 'Iniciando reproducción...')

                _res_box = [False, None]
                def _do_res(c=cand):
                    with silenced_dialogs():
                        try:
                            _r_ok, _r_li = _resolve_link_to_listitem(c, engine, matched_item_holder[0])
                            _res_box[0] = _r_ok
                            _res_box[1] = _r_li
                        except: pass

                _th_res = threading.Thread(target=_do_res, daemon=True)
                _th_res.start()
                cand_timeout = max(12.0, float(_get_int_setting('autoplay_resolve_timeout', 12)))
                res_start = time.time()
                while _th_res.is_alive() and (time.time() - res_start) < cand_timeout:
                    if p_dialog.iscanceled():
                        xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
                        try: p_dialog.close()
                        except: pass
                        if handle >= 0:
                            try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                            except: pass
                        return False
                    xbmc.sleep(150)
                _th_res.join(timeout=0.2)
                ok, li = _res_box[0], _res_box[1]

                if ok and li:
                    m_url = ''
                    try: m_url = li.getPath()
                    except: pass
                    is_ok, real_res = _check_stream_url_playable(m_url, server_name=srv_name, timeout=3.0)
                    if m_url and is_ok:
                        if real_res and not _is_cam_quality(cand):
                            cand.real_quality = real_res
                            cand.quality = real_res
                            try: li.setInfo('video', {'quality': real_res})
                            except: pass
                        # Asegurar cabeceras de reproduccion en el listitem
                        _ensure_playback_headers_on_item(li, server_name=srv_name, page_url=cand_u or '')
                        fast_link = cand
                        fast_li = li
                        fast_url = li.getPath()
                        q_show = _format_quality(cand)
                        lang_fmt = _format_language(cand)
                        try:
                            p_dialog.set_stream_info(
                                server=srv_name,
                                quality=q_show or '1080p',
                                language=lang_fmt or 'Latino',
                                channel='',
                                status='Iniciando reproducción...'
                            )
                        except Exception:
                            pass
                        p_dialog.update(100, 'Iniciando reproducción...')
                        break
                    else:
                        xbmc.log("Multi Bridge Fast Autoplay: candidato %s no superó verificación de stream (bloqueado/caído)" % srv_name, xbmc.LOGINFO)

                if p_dialog.iscanceled():
                    try: p_dialog.close()
                    except: pass
                    return False

        if fast_link:
            break

        # Actualizar recuento de canales completados y tiempo real
        now = time.time()
        for idx in list(started_indices):
            if idx not in completed_indices and not threads[idx].is_alive():
                completed_indices.add(idx)
        completed = len(completed_indices)

        # Comprobar si hay nuevos enlaces descubiertos que todavia no se han probado
        with results_lock:
            has_untested = any(
                not _is_torrent_link(l)
                and not _is_web_captcha_server(_get_link_server_name(l), l)
                and (_safe_str(getattr(l, 'url', '')) or str(id(l))) not in tested_urls
                for l in all_found_links
            )

        if has_untested:
            # Continuar en el bucle para probar de inmediato los nuevos enlaces que acaban de llegar
            continue

        elapsed = now - start_time
        if (completed >= total_channels and not has_untested) or elapsed > timeout_secs:
            break

        channel_event.wait(timeout=0.25)
        channel_event.clear()

    # Cerrar dialogo de progreso
    try: p_dialog.close(); del p_dialog
    except: pass
    try: xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
    except: pass

    if not fast_link or not fast_li or not fast_url:
        xbmc.log("Multi Bridge Fast Autoplay: no se encontro enlace rapido funcional en los canales. Evaluando fallback...", xbmc.LOGINFO)
        with results_lock:
            fallback_batch = list(all_found_links)
        if fallback_batch:
            _auto_v_fb = (_bridge_addon.getSetting('auto_verify_links') == 'true')
            if _auto_v_fb:
                with silenced_dialogs():
                    _hc_fb = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
                    _fb_bypass = [l for l in fallback_batch if _is_torrent_link(l) or (not _hc_fb and _is_web_captcha_server(_get_link_server_name(l), l))]
                    try:
                        _v_fb = _verify_links_headless(fallback_batch, engine=engine, p_dialog=None)
                        fallback_batch = _filter_and_sort_links(_v_fb if _v_fb else _fb_bypass)
                    except Exception:
                        fallback_batch = _filter_and_sort_links(_fb_bypass)
            else:
                fallback_batch = _filter_and_sort_links(fallback_batch)
            meta_fb = dict(meta)
            meta_fb['verified_only'] = _auto_v_fb
            try:
                _store_ram_search_cache(fallback_batch, matched_item_holder[0], meta_fb, engine)
                _save_search_cache_atomic({
                    'item': _serialize_item(matched_item_holder[0]),
                    'links': [_serialize_item(l) for l in fallback_batch],
                    'meta': meta_fb,
                    'engine': engine,
                    'cache_ver': 2
                })
            except Exception: pass

            # Si el usuario no cancelo explicitamente, abrir la lista normal de enlaces (ej. si solo habia captchas o fallaron los directos)
            if xbmcgui.Window(10000).getProperty("bridge.autoplay_canceled") != "true":
                xbmc.log("Multi Bridge Fast Autoplay: no hubo directo reproducible pero hay enlaces disponibles -> abriendo lista", xbmc.LOGINFO)
                if handle >= 0:
                    try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                    except: pass
                _cur_tmdb = str(meta.get('tmdb') or tmdb_id or get_param('tmdb') or '')
                _ts = int(time.time())
                _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
                if meta.get('season') and meta.get('episode'):
                    _win_url += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
                xbmcgui.Window(10000).clearProperty('bridge.in_autoplay')
                _open_links_view(_win_url)
                return True

        xbmcgui.Window(10000).clearProperty('bridge.in_autoplay')
        return False

    # Descartar handle de plugin con guardian para suprimir cualquier dialogo de error espurio de Kodi
    _guard_stop = [False]
    def _suppress():
        for _ in range(30):
            if _guard_stop[0]: break
            try:
                xbmc.executebuiltin('Dialog.Close(okdialog,true)')
                xbmc.executebuiltin('Dialog.Close(error,true)')
            except: pass
            time.sleep(0.1)
    _gt = threading.Thread(target=_suppress, daemon=True)
    _gt.start()

    _absorb = xbmcgui.ListItem()
    try: xbmcplugin.setResolvedUrl(int(handle), False, _absorb)
    except: pass
    xbmc.sleep(250)
    _guard_stop[0] = True
    try: _gt.join(timeout=0.5)
    except: pass

    # Comprobar punto de reanudacion
    if matched_item_holder[0]:
        _enrich_link_metadata(fast_link, meta, matched_item_holder[0])
    media_key = _get_media_key(meta, fast_link)
    is_s = bool(meta.get('season') and meta.get('episode'))
    bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s,
                      season=meta.get('season'), episode=meta.get('episode'))
    seek_to_time = 0
    if bm:
        r_time = float(bm.get('resume_time', 0))
        if r_time > 10:
            mins = int(r_time // 60); secs = int(r_time % 60)
            hrs = mins // 60; mins = mins % 60
            time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
            t_title = meta.get('title') or getattr(matched_item_holder[0], 'title', '') or 'este video'
            ans = _ask_resume_dialog(t_title, time_str, media_key=media_key)
            if ans == 'cancel':
                xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "true")
                try: p_dialog.close()
                except: pass
                if handle >= 0:
                    try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                    except: pass
                return False
            elif ans == 'resume':
                seek_to_time = r_time
            elif ans == 'restart':
                seek_to_time = 0

    # Aplicar metadatos completos para Trakt, TMDb Helper y reproductor
    sync_tmdbhelper_playerstring(meta)
    set_listitem_info(fast_li, meta=meta)
    if seek_to_time > 10:
        fast_li.setProperty('StartOffset', str(seek_to_time))
        fast_li.setProperty('ResumeTime', str(seek_to_time))
        try:
            vt = fast_li.getVideoInfoTag()
            vt.setResumePoint(float(seek_to_time))
        except Exception:
            pass

    try: setattr(fast_link, '_bridge_verified', True)
    except Exception: pass
    # Guardar cache inicial de sesion con fast_link verificado + torrents/captchas directos,
    # y dejar únicamente los enlaces directos normales sin verificar en unverified_links (Opción 3)
    with results_lock:
        init_batch = list(all_found_links)
    _hide_cap_init = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
    _auto_v_init = (_bridge_addon.getSetting('auto_verify_links') == 'true')
    ready_initial = [fast_link]
    pending_initial = []
    for _il in init_batch:
        if getattr(_il, 'url', None) == getattr(fast_link, 'url', None):
            continue
        if _is_torrent_link(_il):
            ready_initial.append(_il)
        elif _is_web_captcha_server(_get_link_server_name(_il), _il):
            if not _hide_cap_init:
                ready_initial.append(_il)
        elif not _auto_v_init or getattr(_il, '_bridge_verified', False):
            ready_initial.append(_il)
        else:
            pending_initial.append(_il)
    ready_initial = _filter_and_sort_links(ready_initial)
    initial_links = list(ready_initial) + list(pending_initial)
    meta['verified_only'] = _auto_v_init
    _store_ram_search_cache(ready_initial, matched_item_holder[0], meta, engine, unverified_links=pending_initial)
    _save_search_cache_atomic({
        'item': _serialize_item(matched_item_holder[0]),
        'links': [_serialize_item(l) for l in ready_initial],
        'unverified_links': [_serialize_item(l) for l in pending_initial],
        'meta': meta,
        'engine': engine,
        'is_preloaded_session': bool(pending_initial),
        'cache_ver': 2
    })

    # ── VIGILANTE DE REPRODUCCIÓN (Watchdog sin colisiones) ───────────────────
    # Iniciar reproducción inicial y supervisar que realmente empiece en Kodi.
    # Si hace timeout o el servidor cae sin llegar a reproducir, cambia automáticamente
    # al siguiente mejor enlace verificado sin colisiones de reproductor ni esperas prematuras.
    # Notificaciones toast desactivadas por preferencia de usuario (la ventana de reproducción directa ya es suficiente)

    # Iniciar reproductor de Kodi
    xbmc.log("Multi Bridge Fast Autoplay: ¡Iniciando reproducción instantánea con %s!" % _get_link_server_name(fast_link), xbmc.LOGINFO)
    player = xbmc.Player()
    player.play(fast_url, fast_li)

    search_params = (is_series, target_title, target_year, p_season, p_episode, all_names, alt_terms, p_tmdb, p_imdb)
    # Lanzar el recolector en segundo plano para completar los demás canales suavemente
    global _BG_COLLECTOR_RUNNING
    with _BG_COLLECTOR_LOCK:
        _BG_COLLECTOR_RUNNING = True
    th_bg = threading.Thread(
        target=_fast_autoplay_background_collector,
        args=(engine, meta, matched_item_holder, fast_link, enabled_players, started_indices, results_dict, results_lock, all_found_links, search_params, initial_links, my_collector_token),
        daemon=True
    )
    th_bg.name = "FastAutoplayBgCollector"
    _register_bg_thread(th_bg)
    try:
        th_bg.start()
    except Exception:
        with _BG_COLLECTOR_LOCK:
            _BG_COLLECTOR_RUNNING = False
        raise

    # Bucle de supervisión del vigilante
    active_link = fast_link
    current_attempt = 1
    max_watchdog_attempts = 4

    while current_attempt <= max_watchdog_attempts:
        mon = xbmc.Monitor()
        watchdog_timeout = float(_get_int_setting('autoplay_resolve_timeout', 15))
        if watchdog_timeout < 10: watchdog_timeout = 10.0
        if watchdog_timeout > 18: watchdog_timeout = 18.0

        active_srv_name = _get_link_server_name(active_link)

        # Usar watchdog con verificación de progreso real de reloj
        # (protege contra freeze de códec en cualquier SO donde isPlayingVideo()=True pero getTime() no avanza)
        video_started = _wait_for_playback_progress(
            player=player, mon=mon,
            timeout=watchdog_timeout,
            seek_to_time=seek_to_time,
            server_name=active_srv_name
        )
        user_aborted = mon.abortRequested()

        if user_aborted:
            _BG_TASK_ABORT_EVENT.set()
            return True

        if video_started and not _is_kodi_modal_dialog_open():
            _rt_bad_w, _exp_w, _act_w = _is_playing_wrong_runtime(player, p_tmdb, is_series=is_series)
            if _rt_bad_w:
                xbmc.log("Multi Bridge Fast Autoplay Watchdog: [%s] descartado por duración incompatible (TMDb %d min vs archivo %d min)" % (
                    _get_link_server_name(active_link), _exp_w, _act_w), xbmc.LOGWARNING)
            else:
                xbmc.log("Multi Bridge Fast Autoplay Watchdog: ¡Reproducción confirmada con éxito [%s]!" % _get_link_server_name(active_link), xbmc.LOGINFO)
                try:
                    xbmc.executebuiltin('Dialog.Close(busydialog,true)')
                    xbmc.executebuiltin('Dialog.Close(extendedbusydialog,true)')
                    xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
                except Exception: pass
                # Iniciar monitor de reproducción SOLO tras confirmar progreso real (evita colisiones en arranque/cierre)
                start_playback_monitor(media_key, title_str=meta.get('title', ''), seek_to_time=seek_to_time, current_link_index=0, meta=meta)
                wait_for_playback_monitor()
                return True

        # C) Si llegó aquí, transcurrió el timeout o falló la decodificación (servidor caído / freeze)
        xbmc.log("Multi Bridge Fast Autoplay Watchdog: enlace [%s] no inició (timeout/servidor caído). Intento %d de %d..." % (
            _get_link_server_name(active_link), current_attempt, max_watchdog_attempts), xbmc.LOGWARNING)

        _record_session_failed_link(active_link, media_key=media_key, meta=meta)
        # 1. Limpieza rigurosa previa al siguiente intento (garantiza 0 colisiones en CVideoPlayer/XAudio/MediaCodec)
        _stop_player_cleanly(player)

        current_attempt += 1
        if current_attempt > max_watchdog_attempts:
            xbmc.log("Multi Bridge Fast Autoplay Watchdog: límite de intentos alcanzado.", xbmc.LOGINFO)
            break

        # 2. Buscar el siguiente mejor enlace verificado/disponible
        candidate_pool = []
        with results_lock:
            for _k, (_it, _ch_links) in results_dict.items():
                if _ch_links:
                    candidate_pool.extend(_ch_links)
        if not candidate_pool:
            candidate_pool = list(initial_links)

        # Descartar los enlaces ya probados, torrents y captchas que requieren navegador
        filtered_candidates = [
            l for l in candidate_pool
            if (_safe_str(getattr(l, 'url', '')) or str(id(l))) not in tested_urls
            and not _is_torrent_link(l)
            and not _is_web_captcha_server(_get_link_server_name(l), l)
        ]

        # Ordenar según preferencias de idioma y calidad
        sorted_next = _filter_and_sort_links(filtered_candidates)

        next_resolved_link = None
        next_resolved_li = None
        next_resolved_url = ''

        for cand in sorted_next:
            cand_key = _safe_str(getattr(cand, 'url', '')) or str(id(cand))
            tested_urls.add(cand_key)
            with silenced_dialogs():
                ok, li = _resolve_link_to_listitem(cand, engine, matched_item_holder[0])
            if ok and li and li.getPath():
                m_url = li.getPath()
                is_ok, real_res = _check_stream_url_playable(m_url, server_name=_get_link_server_name(cand), timeout=3.0)
                if is_ok:
                    if real_res and not _is_cam_quality(cand):
                        cand.real_quality = real_res
                        cand.quality = real_res
                        try: li.setInfo('video', {'quality': real_res})
                        except: pass
                    _ensure_playback_headers_on_item(li, server_name=_get_link_server_name(cand), page_url=getattr(cand, 'url', '') or '')
                    next_resolved_link = cand
                    next_resolved_li = li
                    # BUG FIX: usar la URL actualizada del listitem DESPUÉS de sanitizar cabeceras
                    try:
                        next_resolved_url = li.getPath() or m_url
                    except Exception:
                        next_resolved_url = m_url
                    break

        if not next_resolved_link or not next_resolved_url:
            xbmc.log("Multi Bridge Fast Autoplay Watchdog: no se encontraron más enlaces viables.", xbmc.LOGINFO)
            break

        # 3. Preparar reproducción del nuevo enlace limpio
        active_link = next_resolved_link
        sync_tmdbhelper_playerstring(meta)
        set_listitem_info(next_resolved_li, meta=meta)
        if seek_to_time > 10:
            next_resolved_li.setProperty('StartOffset', str(seek_to_time))
            next_resolved_li.setProperty('ResumeTime', str(seek_to_time))
            try:
                vt = next_resolved_li.getVideoInfoTag()
                if vt: vt.setResumePoint(float(seek_to_time))
            except Exception: pass

        # Actualizar caché de sesión colocando el nuevo enlace en el índice 0
        try:
            try: setattr(active_link, '_bridge_verified', True)
            except Exception: pass
            _rem_unverified = [l for l in pending_initial if getattr(l, 'url', None) != getattr(active_link, 'url', None)]
            _store_ram_search_cache([active_link], matched_item_holder[0], meta, engine, unverified_links=_rem_unverified)
            _save_search_cache_atomic({
                'item': _serialize_item(matched_item_holder[0]),
                'links': [_serialize_item(active_link)],
                'unverified_links': [_serialize_item(l) for l in _rem_unverified],
                'meta': meta,
                'engine': engine,
                'is_preloaded_session': bool(_rem_unverified),
                'cache_ver': 2
            })
        except Exception: pass

        # Iniciar reproducción del nuevo enlace
        xbmc.log("Multi Bridge Fast Autoplay Watchdog: reproduciendo automáticamente siguiente enlace: %s" % _get_link_server_name(active_link), xbmc.LOGINFO)
        _show_bridge_notification('Multi Bridge · Autoplay', 'Enlace no disponible · Probando siguiente...', 3000)
        player.play(next_resolved_url, next_resolved_li)

    # Si se agotaron los intentos sin exito, abrir lista de enlaces para el usuario y gestionar fallback
    if not player.isPlayingVideo():
        _BG_TASK_ABORT_EVENT.set()
        xbmc.log("Multi Bridge Fast Autoplay: ningun enlace arranco en autoplay rapido", xbmc.LOGINFO)
        xbmcgui.Window(10000).clearProperty('bridge.in_autoplay')
        _cur_tmdb = str(meta.get('tmdb') or '')
        if _cur_tmdb:
            _ts = int(time.time())
            _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
            if meta.get('season') and meta.get('episode'):
                _win_url += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
            _open_links_view(_win_url)
        return True

    xbmcgui.Window(10000).clearProperty('bridge.in_autoplay')
    return True

def _autoplay_link(link, handle, engine, matched_item=None):
    """Resolve *link* and tell Kodi to play it via setResolvedUrl(handle, True, ...).

    This is the CORRECT approach for autoplay: we hold the Kodi plugin handle open,
    resolve the server URL in the background, then hand the resolved ListItem back to
    Kodi.  No setResolvedUrl(False) / xbmc.Player().play() hack needed.

    Returns True if playback was handed off to Kodi, False on failure.
    """
    if not link: return False

    # ── Torrent → cliente configurado en Balandro (con enriquecimiento TMDb) ─
    if _is_torrent_link(link):
        _absorb = xbmcgui.ListItem()
        torrent_url, _fail_detail = _resolve_torrent_url(link, engine=engine)
        _tl = (torrent_url or '').strip()
        if not (_tl.startswith('magnet:') or _tl.endswith('.torrent')):
            xbmc.log('Multi Bridge autoplay: torrent no reproducible (%s)' % (_fail_detail or 'sin URL'), xbmc.LOGINFO)
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            return False
        xbmcplugin.setResolvedUrl(handle, False, _absorb)
        return _play_torrent_link(_tl, matched_item=matched_item, meta=_read_search_cache_atomic().get('meta', {}) or getattr(link, 'meta', None))


    server_name = (_safe_str(getattr(link, 'server', '') or '').strip().capitalize()
                   or 'servidor')

    # ── Balandro engine ────────────────────────────────────────────────────
    if engine == 'balandro':
        mods = _get_balandro_modules()
        if not mods:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            return False

        platformtools = mods['platformtools']
        parent = matched_item if matched_item else link

        _resolved_li = [None]
        _result      = [None]   # True=ok, False=fail, 'cancel'=user cancelled

        def _do_resolve():
            import xbmcplugin as _xp
            _orig = getattr(_xp, 'setResolvedUrl', None)

            def _capture(h, succeeded, listitem):
                if succeeded:
                    _resolved_li[0] = listitem
                    _result[0] = True
                else:
                    _result[0] = False

            try:    _xp.setResolvedUrl = _capture
            except: pass

            try:
                sys.argv[1] = str(handle)
                # autoplay=True → skip Balandro's internal player-selector dialog
                platformtools.play_video(link, parent, autoplay=True)
                if _result[0] is None:
                    _result[0] = False
            except Exception as _ex:
                xbmc.log('Multi Bridge _autoplay_link Balandro error: ' + str(_ex), xbmc.LOGINFO)
                _result[0] = False
            finally:
                if _orig is not None:
                    try:    _xp.setResolvedUrl = _orig
                    except: pass

        _t = threading.Thread(target=_do_resolve, daemon=True)
        _t.start()

        # Esperar resolucion con spinner nativo (max 30 s)
        try:
            for _step in range(300):
                if _result[0] is not None:
                    break
                xbmc.sleep(100)
        finally:
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog,true)')
                xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
                xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
            except Exception:
                pass
        _t.join(timeout=2)

        if _result[0] is True and _resolved_li[0] is not None:
            xbmc.log('Multi Bridge _autoplay_link: setResolvedUrl True via %s' % server_name,
                     xbmc.LOGINFO)
            _ensure_playback_headers_on_item(_resolved_li[0], server_name=server_name, page_url=getattr(link, 'url', ''))
            xbmcplugin.setResolvedUrl(handle, True, _resolved_li[0])
            return True
        else:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            if _result[0] != 'cancel':
                xbmcgui.Dialog().notification(
                    'Multi Bridge',
                    '[B]%s[/B] no pudo reproducirse' % server_name,
                    '', 4000)
            return False

    # ── Alfa engine ────────────────────────────────────────────────────────
    else:
        mods = _get_alfa_modules()
        if not mods:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            return False
        platformtools = mods['platformtools']
        try:
            sys.argv[1] = str(handle)
            # Alfa's play_video calls setResolvedUrl(handle, True, ...) internally
            platformtools.play_video(link)
            return True
        except Exception as _e:
            _absorb = xbmcgui.ListItem()
            xbmcplugin.setResolvedUrl(handle, False, _absorb)
            xbmcgui.Dialog().notification(
                'Multi Bridge', 'Error al reproducir: ' + str(_e)[:60], '', 3500)
            return False


def _clean_dialog_text(text):
    """Limpia etiquetas Kodi y HTML para mostrar texto legible en diálogos."""
    if not text:
        return ""
    t = str(text).replace('<br/>', '\n').replace('<br>', '\n')
    t = re.sub(r'\[/?COLOR.*?\]', '', t)
    t = re.sub(r'\[/?B\]', '', t)
    t = re.sub(r'\[/?I\]', '', t)
    t = re.sub(r'<[^>]+>', '', t)
    return t.strip()



def _capture_web_captcha_listitem(link, meta=None, seek_to_time=0):
    page_url = getattr(link, 'url', '') or ''
    if not page_url:
        return None

    page_url = page_url.split('|')[0]

    addon_path = ADDON_PATH if ADDON_PATH else xbmcvfs.translatePath(_bridge_addon.getAddonInfo('path'))
    lib_path = os.path.join(addon_path, 'resources', 'lib')
    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)

    try:
        from bridge_capture import capture_stream
    except Exception as ie:
        xbmc.log(f"Multi Bridge: Error importando bridge_capture: {ie}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Multi Bridge', 'Error al cargar módulo de captura', '', 3500)
        return None

    icon_path = os.path.join(addon_path, 'icon.png')
    if not os.path.exists(icon_path):
        icon_path = os.path.expandvars(r'%APPDATA%\Kodi\addons\plugin.video.bridge.multi\icon.png')
    xbmcgui.Dialog().notification(
        "Multi Bridge - Captcha",
        "Resuelve el captcha en la ventana flotante...",
        icon_path,
        5000
    )

    # Ventana de diálogo con barra de progreso y tiempo límite considerable
    total_timeout = 180
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create(
        'Multi Bridge — Verificación Humana (Captcha)',
        'Abriendo ventana flotante para resolver captcha...\nResuelve el captcha en la ventana del navegador.\nEl vídeo se reproducirá automáticamente al finalizar.'
    )

    monitor = xbmc.Monitor()
    data = capture_stream(
        page_url,
        timeout=total_timeout,
        app_mode=True,
        load_adblock=True,
        progress_dialog=p_dialog,
        monitor=monitor
    )

    try:
        p_dialog.close()
    except Exception:
        pass
    xbmc.sleep(120)

    if not data or data.get("status") != "ok":
        msg = data.get("message", "Error al capturar el video") if isinstance(data, dict) else "No se capturó el stream de video"
        xbmc.log(f"Multi Bridge: Captura captcha fallida: {msg}", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Multi Bridge', msg[:60], '', 4000)
        return None

    # Stream capturado correctamente
    stream_url = data.get("url")
    headers = data.get("headers", {})
    mime_type = data.get("mime_type", "")

    if "/dash/" in stream_url.lower() and not stream_url.lower().endswith(".mpd"):
        clean_base = stream_url.split("?")[0].rsplit("/", 1)[0]
        query = ("?" + stream_url.split("?", 1)[1]) if "?" in stream_url else ""
        stream_url = f"{clean_base}/manifest.mpd{query}"

    ua = headers.get("user-agent") or headers.get("User-Agent") or ""
    ref = headers.get("referer") or headers.get("Referer") or ""
    cookie = headers.get("cookie") or headers.get("Cookie") or ""

    pipe_args = []
    if ua:
        pipe_args.append(f"User-Agent={urllib.parse.quote(ua)}")
    if ref:
        pipe_args.append(f"Referer={urllib.parse.quote(ref)}")
    if cookie:
        pipe_args.append(f"Cookie={urllib.parse.quote(cookie)}")

    playback_url = stream_url
    if pipe_args:
        playback_url += "|" + "&".join(pipe_args)

    item = xbmcgui.ListItem(path=playback_url)
    headers_str = "&".join(pipe_args)
    is_dash = ".mpd" in stream_url.lower() or "dash" in mime_type.lower() or "/dash/" in stream_url.lower()
    is_hls = ".m3u8" in stream_url.lower() or "mpegurl" in mime_type.lower()

    if is_dash:
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        if headers_str:
            item.setProperty('inputstream.adaptive.manifest_headers', headers_str)
            item.setProperty('inputstream.adaptive.stream_headers', headers_str)
        item.setMimeType('application/dash+xml')
        item.setContentLookup(False)
    elif is_hls:
        item.setProperty('inputstream', 'inputstream.adaptive')
        item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        if headers_str:
            item.setProperty('inputstream.adaptive.manifest_headers', headers_str)
            item.setProperty('inputstream.adaptive.stream_headers', headers_str)
        item.setMimeType('application/vnd.apple.mpegurl')
        item.setContentLookup(False)
    else:
        item.setMimeType('video/mp4')
        item.setContentLookup(False)

    item.setProperty('IsPlayable', 'true')
    sync_tmdbhelper_playerstring(meta)
    if meta:
        set_listitem_info(item, meta=meta)

    if seek_to_time > 0:
        item.setProperty('StartOffset', str(float(seek_to_time)))
        item.setProperty('ResumeTime', str(float(seek_to_time)))
        try:
            vt = item.getVideoInfoTag()
            if vt: vt.setResumePoint(float(seek_to_time))
        except Exception: pass
    else:
        item.setProperty('StartOffset', '0')

    return item


def _resolve_and_play_web_captcha(link, meta=None, seek_to_time=0):
    item = _capture_web_captcha_listitem(link, meta=meta, seek_to_time=seek_to_time)
    if not item:
        return False
    playback_url = item.getPath()
    xbmc.Player().play(playback_url, item)
    return True


def sync_captcha_servers():
    try:
        balandro_dir = balandro_path if (balandro_path and os.path.isdir(balandro_path)) else xbmcvfs.translatePath('special://home/addons/plugin.video.balandro')
        if not os.path.isdir(balandro_dir):
            balandro_dir = os.path.expandvars(r'%APPDATA%\Kodi\addons\plugin.video.balandro')
        balandro_servers = os.path.join(balandro_dir, 'servers')
        balandro_channels = os.path.join(balandro_dir, 'channels')
        if not os.path.isdir(balandro_servers):
            return

        addon_path = ADDON_PATH if ADDON_PATH else xbmcvfs.translatePath(_bridge_addon.getAddonInfo('path'))
        import shutil

        # 1. Sincronizar conectores de servidores protegidos (Powvideo y Streamplay)
        for srv in ('powvideo', 'streamplay'):
            json_file = os.path.join(balandro_servers, f'{srv}.json')
            src_json = os.path.join(addon_path, 'resources', 'servers', f'{srv}.json')
            src_py = os.path.join(addon_path, 'resources', 'servers', f'{srv}.py')
            dst_py = os.path.join(balandro_servers, f'{srv}.py')
            need_patch = False
            if not os.path.exists(json_file):
                need_patch = True
            else:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        content = f.read()
                        if '"active": false' in content.lower() or 'Requiere' not in content:
                            need_patch = True
                except Exception:
                    need_patch = True

            if need_patch and os.path.exists(src_json):
                try: shutil.copy2(src_json, json_file)
                except Exception: pass

            if os.path.exists(src_py):
                try: shutil.copy2(src_py, dst_py)
                except Exception: pass
            xbmc.log(f"Multi Bridge: Servidor protegido ({srv.capitalize()}) sincronizado en Balandro", xbmc.LOGINFO)

        # 2. Asegurar proveedores Powvideo (1) y Streamplay (2) en hdfull.py
        hdfull_file = os.path.join(balandro_channels, 'hdfull.py')
        if os.path.exists(hdfull_file):
            with open(hdfull_file, 'r', encoding='utf-8', errors='ignore') as f:
                h_content = f.read()
            mod_h = False
            if '"1": {"t": "s", "d": "https://powvideo.org/%s"}' not in h_content:
                if 'provs = {' in h_content:
                    h_content = h_content.replace(
                        'provs = {\n',
                        'provs = {\n             "1": {"t": "s", "d": "https://powvideo.org/%s"},\n'
                    )
                    mod_h = True
            if '"2": {"t": "s", "d": "https://straemplay.org/%s"}' not in h_content:
                if 'provs = {' in h_content:
                    h_content = h_content.replace(
                        'provs = {\n',
                        'provs = {\n             "2": {"t": "s", "d": "https://straemplay.org/%s"},\n'
                    )
                    mod_h = True
            if mod_h:
                with open(hdfull_file, 'w', encoding='utf-8') as f:
                    f.write(h_content)
                xbmc.log("Multi Bridge: HdFull provs sincronizado con Powvideo y Streamplay", xbmc.LOGINFO)

        # 3. Desbloquear canales de Balandro que descartan powvideo o streamplay con continue
        if os.path.isdir(balandro_channels):
            for fname in os.listdir(balandro_channels):
                if not fname.endswith('.py'): continue
                fpath = os.path.join(balandro_channels, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    if ('powvideo' in content or 'streamplay' in content) and 'continue' in content:
                        lines = content.splitlines()
                        mod = False
                        new_lines = []
                        for line in lines:
                            is_target = any(k in line for k in ('/powvideo.', 'powvideo', '/streamplay.', 'streamplay'))
                            if is_target and 'continue' in line and not line.strip().startswith('#'):
                                new_lines.append('            # MB_UNBLOCKED: ' + line.strip())
                                mod = True
                            else:
                                new_lines.append(line)
                        if mod:
                            with open(fpath, 'w', encoding='utf-8') as f:
                                f.write('\n'.join(new_lines) + '\n')
                except Exception:
                    pass
    except Exception as e:
        xbmc.log(f"Multi Bridge: Error sincronizando servidores en Balandro: {e}", xbmc.LOGWARNING)


def _prepare_clean_switch_transition():
    """Prepara una transición limpia y sin congelo al cambiar de enlace en caliente.
    - En Android o al salir de streams remotos HTTP/HTTPS: limpia la playlist primero y detiene
      el reproductor sin demora extra para que VideoFullScreen y los subtítulos reinicien abajo.
    - Si el stream saliente es un proxy local (127.0.0.1/localhost, ej. Mega/Torrest): mantiene
      el reproductor sin stop() en PC para evitar bloqueos CCurlFile::Stat de 50s, cerrando OSD/SeekBar."""
    p = xbmc.Player()
    try:
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        xbmc.executebuiltin('Dialog.Close(seekbar,true)')
        xbmc.executebuiltin('Dialog.Close(fullscreeninfo,true)')
    except Exception:
        pass
    if bool(xbmc.getCondVisibility('System.Platform.Android')):
        _android_stop_playback_if_active()
        return
    prev_pf = ''
    try:
        if p.isPlaying():
            prev_pf = (p.getPlayingFile() or '').strip().lower()
    except Exception:
        prev_pf = ''
    is_local_proxy = prev_pf.startswith(('http://127.0.0.1', 'http://localhost', 'https://127.0.0.1', 'https://localhost'))
    if is_local_proxy:
        try:
            if xbmc.getCondVisibility("Player.Paused"):
                p.pause()
                for _ in range(5):
                    if not xbmc.getCondVisibility("Player.Paused"):
                        break
                    xbmc.sleep(30)
        except Exception:
            pass
        return
    try:
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
    except Exception:
        pass
    try:
        if p.isPlaying() or xbmc.getCondVisibility("Player.HasMedia"):
            p.stop()
            for _ in range(40):
                if not p.isPlaying() and not xbmc.getCondVisibility("Player.HasMedia"):
                    break
                xbmc.sleep(30)
    except Exception:
        pass


def _play_link_safely(link, engine='alfa', matched_item=None, meta=None, is_switch=False, seek_to_time=0, start_beginning=False):

    if not link: return False

    if not meta:
        _cf = _read_search_cache_atomic()
        if _cf and isinstance(_cf, dict):
            meta = _cf.get('meta', {}) or {}

    # 1. Enlace Torrent → cliente configurado en Balandro (con enriquecimiento TMDb)
    if _is_torrent_link(link):
        _ch_dbg = _safe_str(getattr(link, 'channel', '') or '')
        torrent_url, _fail_detail = _resolve_torrent_url(link, engine=engine)
        _tl = (torrent_url or '').strip()
        if not (_tl.startswith('magnet:') or _tl.endswith('.torrent')):
            msg = _fail_detail or 'Enlace torrent sin URL reproducible'
            xbmc.log("Multi Bridge: torrent %s no reproducible: %s" % (_ch_dbg, msg), xbmc.LOGWARNING)
            xbmcgui.Dialog().notification('Multi Bridge', msg, '', 4000)
            return False
        res = _play_torrent_link(_tl, matched_item=matched_item, meta=meta)
        return res

    # 2. Preparar enlace (resolver canal.play y data_url)
    prepared = _prepare_playable_link(link, engine=engine)
    if not prepared:
        xbmcgui.Dialog().notification('Multi Bridge', 'No se pudo preparar el enlace', '', 3000)
        return False

    server_name = (_safe_str(getattr(prepared, 'server', '') or getattr(link, 'server', '') or '').strip().capitalize()
                   or 'Servidor')

    has_url = bool(getattr(prepared, 'url', None))
    has_video_urls = bool(getattr(prepared, 'video_urls', None))

    if not has_url and not has_video_urls:
        xbmc.log(f"Multi Bridge: enlace sin URL para {server_name}", xbmc.LOGINFO)
        xbmcgui.Dialog().notification('Multi Bridge', f'{server_name} — No se encontró URL reproducible', '', 3500)
        return False

    # 2.5 Servidor web con verificación humana / Captcha (ej. Powvideo)
    if _is_web_captcha_server(server_name, prepared):
        return _resolve_and_play_web_captcha(prepared, meta=meta, seek_to_time=seek_to_time)

    # 3. Reproductor según el motor
    # ── Balandro: ventana de progreso de conexión, timeout (15s) y aviso de fallo ──
    if engine == 'balandro':
        mods = _get_balandro_modules()
        if not mods: return False

        platformtools = mods['platformtools']
        parent = matched_item if matched_item else prepared

        import xbmcplugin as _xp
        _resolved_li = [None]
        _result = [None]   # True=éxito, False=fallo, 'cancel'=cancelado por usuario
        _fail_reason = ['']

        def _cap_sru(h, succeeded, listitem):
            if succeeded and listitem:
                _resolved_li[0] = listitem
                _result[0] = True
            else:
                if _result[0] is None:
                    _result[0] = False

        def _cap_ok(heading="", message="", *args):
            txt = str(message or heading or '')
            if txt and not _fail_reason[0]:
                _fail_reason[0] = txt
            return True

        def _cap_notif(heading="", message="", *args, **kwargs):
            txt = str(message or heading or '')
            if txt and not _fail_reason[0]:
                _fail_reason[0] = txt
            return True

        def _cap_sel(heading="", options=None, *args, **kwargs):
            if options and isinstance(options, (list, tuple)):
                best_idx = 0
                best_score = -1
                for idx, opt in enumerate(options):
                    score = _stream_quality_score(opt)
                    if score > best_score:
                        best_score = score
                        best_idx = idx
                return best_idx
            return 0

        def _do_resolve():
            _orig_sru = getattr(_xp, 'setResolvedUrl', None)
            _orig_ok = getattr(platformtools, 'dialog_ok', None)
            _orig_notif = getattr(platformtools, 'dialog_notification', None)
            _orig_sel = getattr(platformtools, 'dialog_select', None)

            try:
                _xp.setResolvedUrl = _cap_sru
                platformtools.dialog_ok = _cap_ok
                platformtools.dialog_notification = _cap_notif
                platformtools.dialog_select = _cap_sel
                sys.argv[1] = str(handle)
                xbmc.log(f"Multi Bridge: conectando a {server_name} en Balandro (url={str(getattr(prepared, 'url', ''))[:60]})", xbmc.LOGINFO)
                res = platformtools.play_video(prepared, parent, autoplay=False)
                if res is True and _resolved_li[0] is not None:
                    _result[0] = True
                elif res is False:
                    _result[0] = False
                elif _result[0] is None:
                    _result[0] = False
            except Exception as _ex:
                xbmc.log(f"Multi Bridge: error en play_video Balandro: {_ex}", xbmc.LOGINFO)
                if not _fail_reason[0]:
                    _fail_reason[0] = str(_ex)
                _result[0] = False
            finally:
                if _orig_sru is not None:
                    try: _xp.setResolvedUrl = _orig_sru
                    except: pass
                if _orig_ok is not None:
                    try: platformtools.dialog_ok = _orig_ok
                    except: pass
                if _orig_notif is not None:
                    try: platformtools.dialog_notification = _orig_notif
                    except: pass
                if _orig_sel is not None:
                    try: platformtools.dialog_select = _orig_sel
                    except: pass

        _t = threading.Thread(target=_do_resolve, daemon=True)
        _t.start()

        _timeout_steps = 150  # 15s
        try:
            for _step in range(_timeout_steps):
                if _result[0] is not None:
                    break
                xbmc.sleep(100)
        finally:
            try:
                xbmc.executebuiltin('Dialog.Close(busydialog,true)')
                xbmc.executebuiltin('Dialog.Close(busydialognocancel,true)')
                xbmc.executebuiltin('Dialog.Close(progressdialog,true)')
            except Exception:
                pass
        _t.join(timeout=1.0)

        if _result[0] == 'cancel':
            xbmc.log(f"Multi Bridge: conexión a {server_name} cancelada", xbmc.LOGINFO)
            return False

                # Fallback universal ResolveUrl si el motor principal falló
        if (_result[0] is not True or _resolved_li[0] is None) and xbmc.getCondVisibility('System.HasAddon("script.module.resolveurl")'):
            try:
                page_url = getattr(prepared, 'url', '') or getattr(link, 'url', '')
                if page_url:
                    import resolveurl
                    if resolveurl.HostedMediaFile(page_url).valid_url():
                        xbmc.log(f"Multi Bridge: fallback universal ResolveUrl para {server_name}...", xbmc.LOGINFO)
                        _res_url = resolveurl.resolve(page_url)
                        if _res_url:
                            _resolved_li[0] = xbmcgui.ListItem(path=_res_url)
                            _result[0] = True
                            xbmc.log(f"Multi Bridge: ResolveUrl resolvió {server_name} con éxito!", xbmc.LOGINFO)
            except Exception as _re_e:
                xbmc.log(f"Multi Bridge fallback ResolveUrl error: {_re_e}", xbmc.LOGINFO)

        if _result[0] is True and _resolved_li[0] is not None:
            _ensure_playback_headers_on_item(_resolved_li[0], server_name=server_name, page_url=getattr(prepared, 'url', '') or getattr(link, 'url', ''))
            media_url = ''
            try: media_url = _resolved_li[0].getPath()
            except: pass
            if media_url:
                xbmc.log(f"Multi Bridge: reproduciendo {server_name} con éxito (url={media_url[:60]})", xbmc.LOGINFO)
                q_from_url = _detect_resolution_from_text(media_url)
                if q_from_url:
                    try:
                        prepared.real_quality = q_from_url
                        prepared.quality = q_from_url
                        link.real_quality = q_from_url
                        link.quality = q_from_url
                        _update_link_real_quality_in_cache(None, q_from_url, link_obj=link)
                    except Exception:
                        pass
                if _resolved_li[0] is not None:
                    set_listitem_info(_resolved_li[0], meta=meta)
                    try:
                        _resolved_li[0].setContentLookup(False)
                        _resolved_li[0].setProperty('IsPlayable', 'true')
                    except Exception:
                        pass
                    if seek_to_time > 0:
                        _resolved_li[0].setProperty('StartOffset', str(float(seek_to_time)))
                        _resolved_li[0].setProperty('ResumeTime', str(float(seek_to_time)))
                        try:
                            vt = _resolved_li[0].getVideoInfoTag()
                            if vt: vt.setResumePoint(float(seek_to_time))
                        except Exception: pass
                    else:
                        _resolved_li[0].setProperty('StartOffset', '0')
                        _resolved_li[0].setProperty('ResumeTime', '0')
                        try:
                            vt = _resolved_li[0].getVideoInfoTag()
                            if vt: vt.setResumePoint(0.0)
                        except Exception: pass
                if handle > 0 and not is_switch:
                    xbmcplugin.setResolvedUrl(handle, True, _resolved_li[0])
                else:
                    if is_switch:
                        _prepare_clean_switch_transition()
                    sync_tmdbhelper_playerstring(meta)
                    xbmc.Player().play(media_url, _resolved_li[0])
                return True
            else:
                xbmc.log(f"Multi Bridge: {server_name} resolvió pero no proporcionó la ruta final del vídeo", xbmc.LOGWARNING)
                if handle > 0 and not is_switch:
                    try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                    except: pass
                dlg = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)()
                dlg.ok(
                    'Multi Bridge — Error de Reproducción',
                    f'El servidor [B][COLOR gold]{server_name}[/COLOR][/B] resolvió pero no proporcionó la ruta final del vídeo.'
                )
                return False

        if handle > 0 and not is_switch:
            try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
            except: pass

        if _result[0] is None:
            xbmc.log(f"Multi Bridge: timeout conectando a {server_name} tras 15s", xbmc.LOGINFO)
            dlg = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)()
            dlg.ok(
                'Multi Bridge — Tiempo de Espera Agotado',
                f'El servidor [B][COLOR gold]{server_name}[/COLOR][/B] no respondió a tiempo (15 segundos).\n\n'
                f'[COLOR red][B]Causa:[/B][/COLOR] Tiempo de espera agotado.\n'
                f'El servidor puede estar caído, saturado o bloqueando la conexión.'
            )
            return False

        raw_reason = _fail_reason[0].strip()
        clean_reason = _clean_dialog_text(raw_reason)
        if not clean_reason:
            clean_reason = 'El vídeo ya no existe, el enlace está caído o el servidor no responde.'

        xbmc.log(f"Multi Bridge: fallo reproduciendo {server_name}: {clean_reason}", xbmc.LOGINFO)
        dlg = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)()
        dlg.ok(
            'Multi Bridge — Fallo del Servidor',
            f'No se pudo reproducir en el servidor [B][COLOR gold]{server_name}[/COLOR][/B].\n\n'
            f'[COLOR red][B]Motivo:[/B][/COLOR] {clean_reason}'
        )
        return False

    # ── Alfa: reproducción 100% nativa sin ventanas personalizadas ────────
    # Alfa gestiona su propia ventana nativa de progreso "Conectando con [Servidor]..."
    # y sus propios diálogos de fallo de forma independiente.
    else:
        mods = _get_alfa_modules()
        if not mods: return False
        platformtools = mods['platformtools']
        try:
            if is_switch:
                _prepare_clean_switch_transition()
            sys.argv[1] = '-1' if is_switch else str(handle)
            _enrich_link_metadata(prepared, meta, matched_item)
            sync_tmdbhelper_playerstring(meta)

            # Limpiar video_urls para que Alfa resuelva de forma fresca con su ventana nativa de progreso
            prepared.video_urls = []

            xbmc.log(f"Multi Bridge: reproduciendo {server_name} en Alfa (url={str(getattr(prepared, 'url', ''))[:60]})", xbmc.LOGINFO)

            orig_select = getattr(platformtools, 'dialog_select', None)
            def _smart_alfa_select(heading="", options=None, *args, **kwargs):
                if options and isinstance(options, (list, tuple)):
                    # Contar opciones de vídeo ("Ver el vídeo ...")
                    video_opts = []
                    for i, opt in enumerate(options):
                        opt_str = str(opt).lower()
                        if 'ver el video' in opt_str or 'ver el vídeo' in opt_str or 'reproducir' in opt_str:
                            video_opts.append(i)

                    # Si hay varias resoluciones, mostrar la ventana nativa de Alfa
                    if len(video_opts) > 1:
                        if orig_select:
                            return orig_select(heading, options, *args, **kwargs)
                        return (_KODI_ORIG_DIALOG or xbmcgui.Dialog)().select(heading, options)

                    # Si solo hay una resolución, iniciar directamente
                    if len(video_opts) == 1:
                        return video_opts[0]
                    return 0

                if orig_select:
                    return orig_select(heading, options, *args, **kwargs)
                return 0

            try:
                platformtools.dialog_select = _smart_alfa_select
                platformtools.play_video(prepared, force_direct=True)
                try:
                    _pl_cur = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                    _pl_pos = _pl_cur.getposition()
                    if 0 <= _pl_pos < _pl_cur.size():
                        _cur_li = _pl_cur[_pl_pos]
                        if _cur_li is not None:
                            set_listitem_info(_cur_li, meta=meta)
                except Exception:
                    pass
            finally:
                if orig_select:
                    platformtools.dialog_select = orig_select

            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            if pl.size() > 0 or xbmc.Player().isPlaying() or xbmc.getCondVisibility("Player.HasMedia"):
                return True

            for _ in range(20):
                if xbmc.Player().isPlaying() or xbmc.getCondVisibility("Player.HasMedia") or pl.size() > 0:
                    return True
                xbmc.sleep(100)

            return True
        except Exception as e:
            xbmc.log(f"Multi Bridge: error en play_video Alfa: {e}", xbmc.LOGINFO)
            _show_bridge_notification('Multi Bridge', f'{server_name} — Error: {str(e)[:60]}', 3500)
            return False

def verify_and_filter_links():
    links = []
    matched_item = None
    meta = {}
    engine = 'alfa'
    cache = _read_search_cache_atomic()
    if cache and isinstance(cache, dict):
        try:
            engine = cache.get('engine', 'alfa') or 'alfa'
            links = [_deserialize_item(lnk, engine) for lnk in cache.get('links', [])]
            links = [l for l in links if l is not None]
            matched_item = _deserialize_item(cache.get('item'), engine)
            meta = cache.get('meta', {}) or {}
        except: pass

    if not links: return
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('Multi Bridge', 'Verificando disponibilidad de enlaces...')
    verified_links = _verify_links_headless(links, engine=engine, p_dialog=p_dialog)
    try: p_dialog.close()
    except: pass

    if not verified_links:
        xbmcgui.Dialog().ok('Multi Bridge', 'No se encontraron enlaces funcionales.')
        return

    verified_links = _filter_and_sort_links(verified_links)
    meta['verified_only'] = True
    try:
        _store_ram_search_cache(verified_links, matched_item, meta, engine)
        _save_search_cache_atomic({
            'item': _serialize_item(matched_item),
            'links': [_serialize_item(l) for l in verified_links],
            'meta': meta,
            'engine': engine
        })
    except: pass
    _open_links_view()
    xbmc.executebuiltin('Container.Refresh')

# ---------------------------------------------------------
# Player Manager & Migration / Cloud Update Tools
# ---------------------------------------------------------
class _DeviceSelectDialog(xbmcgui.WindowXMLDialog):
    BTN_PC = 100
    BTN_ANDROID = 200

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.selected = None

    def onInit(self):
        try:
            is_android = bool(xbmc.getCondVisibility('System.Platform.Android'))
            target_id = self.BTN_ANDROID if is_android else self.BTN_PC
            self.setFocusId(target_id)
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId == self.BTN_PC:
            self.selected = 'pc'
            self.close()
        elif controlId == self.BTN_ANDROID:
            self.selected = 'android'
            self.close()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (10, 92):
            is_android = bool(xbmc.getCondVisibility('System.Platform.Android'))
            self.selected = 'android' if is_android else 'pc'
            self.close()


def prompt_first_run_device(addon=None, force=False):
    if addon is None:
        addon = _bridge_addon
    try:
        if not force and addon.getSetting('first_install_setup_done') == 'true':
            return
        addon.setSetting('hide_captcha_links', 'false')
        addon.setSetting('first_install_setup_done', 'true')
        xbmc.log("Multi Bridge: Configuracion inicial automatica completada (Captchas activos en PC y Android)", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Multi Bridge: Error en configuracion inicial automatica: {e}", xbmc.LOGWARNING)


def check_first_run_device():
    try:
        if _bridge_addon.getSetting('first_install_setup_done') != 'true':
            prompt_first_run_device(_bridge_addon)
    except Exception:
        pass


_migration_checked_flag = False

def check_and_run_migration():
    global _migration_checked_flag
    if _migration_checked_flag:
        return
    try:
        if xbmcgui.Window(10000).getProperty('MultiBridge_MigrationDone') == 'true':
            _migration_checked_flag = True
            return
    except Exception:
        pass
    if not os.path.exists(TMDB_PLAYERS_PATH):
        try: os.makedirs(TMDB_PLAYERS_PATH)
        except: pass

    # 1. Asegurar el player maestro (1) Multi Bridge en TMDb Helper
    master_file = os.path.join(TMDB_PLAYERS_PATH, '(1)MultiBusqueda.json')
    master_movie_url = 'executebuiltin://RunPlugin("plugin://plugin.video.bridge.multi/?action=play&title={es-MX_title}&year={year}&title_es={es-ES_title}&title_lat={es-MX_title}&tmdb={tmdb}&imdb={imdb}&tvdb={tvdb}&trakt={trakt}&plot={plot}&plot_lat={es-MX_plot}&plot_es={es-ES_plot}&tagline={tagline}&tagline_lat={es-MX_tagline}&tagline_es={es-ES_tagline}&director={director}&title_en={en_title}&title_orig={originaltitle}&poster={poster}&fanart={fanart}&thumbnail={thumbnail}&clearlogo={clearlogo}")'
    master_ep_url = 'executebuiltin://RunPlugin("plugin://plugin.video.bridge.multi/?action=play&title={es-MX_showname}&season={season}&episode={episode}&showname={showname}&showyear={showyear}&title_es={es-ES_showname}&title_lat={es-MX_showname}&tmdb={tmdb}&imdb={imdb}&tvdb={tvdb}&trakt={trakt}&plot={plot}&plot_lat={es-MX_plot}&plot_es={es-ES_plot}&tagline={tagline}&tagline_lat={es-MX_tagline}&tagline_es={es-ES_tagline}&director={director}&title_en={en_showname}&title_orig={original_name}&poster={poster}&fanart={fanart}&thumbnail={thumbnail}&clearlogo={clearlogo}")'

    master_data = {
        "name": "(1) Multi Bridge",
        "plugin": "plugin.video.bridge.multi",
        "priority": 100,
        "is_resolvable": "false",
        "assert": {
            "play_movie": ["title", "year"],
            "play_episode": ["showname", "season", "episode"]
        },
        "play_movie": master_movie_url,
        "play_episode": master_ep_url,
        "is_folder": "false"
    }

    need_write_master = True
    if os.path.exists(master_file):
        try:
            with open(master_file, 'r', encoding='utf-8') as f:
                cur_master = json.load(f)
            if cur_master == master_data:
                need_write_master = False
        except Exception:
            pass

    if need_write_master:
        try:
            with open(master_file, 'w', encoding='utf-8') as f:
                json.dump(master_data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            xbmc.log("Multi Bridge: error guardando master player: %s" % e, xbmc.LOGWARNING)

    # 2. Asegurar que channels.json existe internamente en Multi Bridge (userdata)
    if not os.path.exists(CHANNELS_JSON_FILE):
        channels_data = {'version': 1, 'channels': {'alfa': {}, 'balandro': {}}}
        # Si existen players antiguos en TMDB_PLAYERS_PATH, migrarlos a channels.json
        for fname in os.listdir(TMDB_PLAYERS_PATH):
            if not fname.endswith('.json') or fname.startswith('(1)'): continue
            fpath = os.path.join(TMDB_PLAYERS_PATH, fname)
            try:
                with open(fpath, 'r', encoding='utf-8') as f: p_data = json.load(f)
                engine = 'alfa' if fname.lower().startswith('alfa-') else 'balandro'
                clean = fname[:-5]
                prefix = 'Alfa-' if engine == 'alfa' else 'Balandro-'
                if clean.lower().startswith(prefix.lower()):
                    clean = clean[len(prefix):]
                is_series = False
                if clean.lower().endswith('-series'):
                    clean = re.sub(r'-series$', '', clean, flags=re.IGNORECASE)
                    is_series = True
                elif 'play_episode' in p_data and 'play_movie' not in p_data:
                    is_series = True
                ch_id = clean.lower().strip()

                pm = p_data.get('play_movie') or p_data.get('play_episode')
                url = pm[0] if isinstance(pm, list) and pm else (pm if isinstance(pm, str) else '')
                embedded_ch = ''
                if 'url=plugin://' in url:
                    sub = url.split('url=plugin://')[1].split('&')[0]
                    if '?' in sub:
                        q = sub.split('?', 1)[1]
                        try:
                            dec = json.loads(urllib.parse.unquote(base64.b64decode(urllib.parse.unquote(q)).decode('utf-8')))
                            embedded_ch = dec.get('channel')
                        except: pass
                elif 'channel=' in url:
                    m = re.search(r'channel=([^&]+)', url)
                    if m: embedded_ch = m.group(1)

                actual_ch = embedded_ch.lower().strip() if embedded_ch else ch_id
                entry = channels_data['channels'][engine].setdefault(ch_id, {
                    'id': ch_id,
                    'name': clean.strip(),
                    'channel': actual_ch,
                    'engine': engine,
                    'movies': False,
                    'series': False,
                    'movie_disabled': False,
                    'series_disabled': False,
                    'play_movie': None,
                    'play_episode': None
                })
                dis = str(p_data.get('disabled', '')).lower() in ('true', '1') or p_data.get('disabled') is True
                if is_series or 'play_episode' in p_data:
                    entry['series'] = True
                    entry['series_disabled'] = dis
                    if 'play_episode' in p_data: entry['play_episode'] = p_data['play_episode']
                if not is_series or 'play_movie' in p_data:
                    entry['movies'] = True
                    entry['movie_disabled'] = dis
                    if 'play_movie' in p_data: entry['play_movie'] = p_data['play_movie']
            except Exception: pass
        save_channels_data(channels_data)

    # 3. Limpieza de TMDb Helper: eliminar todos los players individuales
    # TMDb Helper unicamente debe tener (1)MultiBusqueda.json
    try:
        for fname in os.listdir(TMDB_PLAYERS_PATH):
            if not fname.endswith('.json') or fname.startswith('(1)MultiBusqueda'):
                continue
            fn_low = fname.lower()
            if fn_low.startswith('alfa-') or fn_low.startswith('balandro-') or fn_low.startswith('(1)alfa') or fn_low.startswith('(1)balandro'):
                try:
                    fpath = os.path.join(TMDB_PLAYERS_PATH, fname)
                    if os.path.exists(fpath):
                        os.remove(fpath)
                except Exception: pass
    except Exception as e:
        xbmc.log("Multi Bridge: error limpiando players de TMDb Helper: %s" % e, xbmc.LOGWARNING)
    _migration_checked_flag = True
    try:
        xbmcgui.Window(10000).setProperty('MultiBridge_MigrationDone', 'true')
    except Exception:
        pass

def _channel_display_name(base, channel):
    """Nombre visible del canal (ej. 'Gnula'). Lee su descriptor si existe,
    si no usa el id tal cual."""
    try:
        with open(os.path.join(base, 'channels', channel + '.json'), 'r', encoding='utf-8') as f:
            name = json.load(f).get('name', '')
        if name:
            return str(name)
    except Exception:
        pass
    return channel

def check_orphan_players():
    """Arranque de Kodi: muestra una ventana SOLO si algun canal apunta a un
    descriptor que no existe en Balandro/Alfa. Si todos existen, no muestra nada.
    Se puede desactivar con el ajuste startup_orphan_check."""
    try:
        try:
            if _bridge_addon.getSetting('startup_orphan_check') != 'true':
                return
        except Exception:
            pass

        ch_data = load_channels_data()
        channels_dict = ch_data.get('channels', {})
        missing = []

        for engine in ('alfa', 'balandro'):
            # Si el addon no está instalado en Kodi, no comprobar si sus canales existen
            if not _is_engine_installed(engine):
                xbmc.log('Multi Bridge: %s no está instalado, omitiendo comprobación de canales.' % engine.capitalize(), xbmc.LOGINFO)
                continue

            base = balandro_path if engine == 'balandro' else alfa_path
            channels_dir = os.path.join(base, 'channels')
            if not os.path.isdir(channels_dir):
                continue

            try:
                avail = [x.lower() for x in os.listdir(channels_dir)]
            except Exception:
                avail = []

            for ch_id, ch_info in channels_dict.get(engine, {}).items():
                if ch_info.get('movie_disabled') and ch_info.get('series_disabled'):
                    continue
                actual_ch = str(ch_info.get('channel') or ch_id).strip().lower()
                exists = (actual_ch + '.py') in avail
                if not exists and engine == 'alfa' and actual_ch in ('planb', 'plan_b'):
                    try:
                        libfiles = [x.lower() for x in os.listdir(os.path.join(base, 'lib'))]
                    except Exception:
                        libfiles = []
                    exists = any(x.startswith('planb') and x.endswith('.py') for x in libfiles)
                if not exists:
                    missing.append((ch_info.get('name', ch_id), actual_ch, engine))

        if not missing:
            xbmc.log('Multi Bridge: todos los canales configurados existen en Balandro/Alfa', xbmc.LOGINFO)
            return
        xbmc.log('Multi Bridge: canales no encontrados: %s' % ['%s (canal "%s" no existe en %s)' % t for t in missing], xbmc.LOGWARNING)
        try:
            mon = xbmc.Monitor()
            if not mon.waitForAbort(8):
                msg_lines = []
                for name, channel, engine in missing[:12]:
                    msg_lines.append('%s: no existe en %s' % (name, engine))
                if len(missing) > 12:
                    msg_lines.append('... y %d mas' % (len(missing) - 12))
                engines = sorted(set(e for _, _, e in missing))
                if len(engines) == 1:
                    url = 'plugin://plugin.video.bridge.multi/?view=list_players&engine=%s' % engines[0]
                else:
                    url = 'plugin://plugin.video.bridge.multi/?view=home'
                go = xbmcgui.Dialog().yesno('Multi Bridge: canal no existente',
                                            'Estos canales configurados no existen en sus respectivos addons:\n%s' % '\n'.join(msg_lines),
                                            nolabel='Cerrar', yeslabel='Ir al gestor')
                if go:
                    xbmc.executebuiltin('ActivateWindow(videos,"%s",return)' % url)
        except Exception as e:
            xbmc.log('Multi Bridge: no se pudo mostrar aviso de no existentes: %s' % e, xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('Multi Bridge: check_orphan_players error: %s' % e, xbmc.LOGWARNING)

# ---------------------------------------------------------
# Player Management Menus
# ---------------------------------------------------------
def _format_regional_datetime(dt):
    """Formatea fecha y hora respetando estrictamente la configuración regional de Kodi
    (fecha corta y reloj de 12h AM/PM o 24h).
    """
    if not dt:
        return ''

    # 1. Formato de fecha según región de Kodi
    date_str = ''
    try:
        dfmt = xbmc.getRegion('dateshort')
        if dfmt:
            if '%' in dfmt:
                date_str = dt.strftime(dfmt)
            else:
                conv = dfmt.replace('YYYY', '%Y').replace('yyyy', '%Y').replace('MM', '%m').replace('mm', '%m').replace('DD', '%d').replace('dd', '%d')
                date_str = dt.strftime(conv)
    except Exception:
        pass
    if not date_str:
        date_str = dt.strftime('%d/%m/%Y')

    # 2. Formato de hora según región de Kodi (12h AM/PM o 24h)
    time_str = ''
    try:
        tfmt = xbmc.getRegion('time')
        if tfmt:
            if '%' in tfmt:
                clean_tf = tfmt.replace(':%S', '').replace(':%s', '').replace('%H%H', '%H')
                time_str = dt.strftime(clean_tf).strip()
            else:
                conv = tfmt.replace(':ss', '').replace(':SS', '').replace('ss', '').replace('SS', '')
                conv = conv.replace('HH', '%H').replace('hh', '%I').replace('h', '%I').replace('mm', '%M').replace('xx', '%p').replace('XX', '%p')
                time_str = dt.strftime(conv).strip()
    except Exception:
        pass

    if not time_str:
        try:
            tf = str(xbmc.getRegion('timeformat')).lower()
            if '12' in tf:
                time_str = dt.strftime('%I:%M %p').lstrip('0')
            elif '24' in tf:
                time_str = dt.strftime('%H:%M')
        except Exception:
            pass

    if not time_str:
        time_str = dt.strftime('%H:%M')

    return '%s a las %s' % (date_str, time_str)

def _get_last_cloud_import_datetime():
    """Devuelve (datetime_obj, total_count) de la última importación desde la nube.
    Verifica primero 'last_sync' dentro de channels.json y como respaldo en CLOUD_SYNC_FILE.
    Nunca usa mtime de archivo porque se actualiza en cada inicio o cambio de ajustes.
    """
    ch_data = load_channels_data()
    tot_channels = len(ch_data.get('channels', {}).get('alfa', {})) + len(ch_data.get('channels', {}).get('balandro', {}))

    # 1. Prioridad: campo persistente 'last_sync' dentro de channels.json
    sync_data = ch_data.get('last_sync')
    if isinstance(sync_data, dict):
        ts = sync_data.get('timestamp')
        tot = sync_data.get('total', 0)
        if ts:
            try:
                return datetime.datetime.fromtimestamp(ts), (tot or tot_channels)
            except Exception:
                pass

    # 2. Respaldo: archivo cloud_sync_info.json
    if os.path.exists(CLOUD_SYNC_FILE):
        try:
            with open(CLOUD_SYNC_FILE, 'r', encoding='utf-8') as f:
                d = json.load(f)
            ts = d.get('timestamp')
            tot = d.get('total', 0)
            if ts:
                return datetime.datetime.fromtimestamp(ts), (tot or tot_channels)
        except Exception:
            pass

    return None, tot_channels

def show_continue_watching():
    if handle < 0: return
    cw_data = load_continue_watching_data()
    valid_items = []
    for mk, rec in (cw_data or {}).items():
        if isinstance(rec, dict) and rec.get('interrupted'):
            resume_t = float(rec.get('resume_time') or 0)
            total_t = float(rec.get('total_time') or 0)
            # Descartar si alcanzó el 80% o está marcado como completado
            if total_t > 0 and (resume_t / total_t >= 0.80):
                continue
            if is_item_completed(mk):
                continue
            valid_items.append((mk, rec))

    # Ordenar cronológicamente descendente por el último latido (los más recientes primero)
    valid_items.sort(key=lambda x: float(x[1].get('last_heartbeat') or 0), reverse=True)

    if not valid_items:
        xbmcplugin.setContent(handle, 'videos')
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        return

    for mk, rec in valid_items:
        is_series = bool(rec.get('is_series') or (rec.get('season') and rec.get('episode')))
        tmdb_id_val = str(rec.get('tmdb') or '')
        imdb_id_val = str(rec.get('imdb') or '')
        season_val = rec.get('season')
        episode_val = rec.get('episode')
        title_val = rec.get('title') or ''
        showname_val = rec.get('showname') or ''
        year_val = str(rec.get('year') or '')
        resume_t = float(rec.get('resume_time') or 0)
        total_t = float(rec.get('total_time') or 0)

        mins = int(resume_t // 60); secs = int(resume_t % 60); hrs = mins // 60; mins = mins % 60
        time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))

        if is_series:
            s_num = int(season_val) if (season_val is not None and str(season_val).isdigit()) else 1
            e_num = int(episode_val) if (episode_val is not None and str(episode_val).isdigit()) else 1
            show_name = _strip_emojis_and_symbols(showname_val or title_val)
            ep_name = _strip_emojis_and_symbols(title_val if (title_val and title_val != show_name) else '')
            if ep_name:
                item_label = f"{show_name} - {s_num}x{e_num:02d} - {ep_name}"
            else:
                item_label = f"{show_name} - {s_num}x{e_num:02d}"

            target_url = 'plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type=tv'
            if tmdb_id_val:
                target_url += f'&tmdb_id={tmdb_id_val}'
            elif imdb_id_val:
                target_url += f'&imdb_id={imdb_id_val}'
            else:
                target_url += f'&query={uparse.quote_plus(show_name)}'
            target_url += f'&season={s_num}&episode={e_num}'
        else:
            clean_title = _strip_emojis_and_symbols(title_val) or 'Película'
            item_label = clean_title
            if year_val:
                item_label += f' ({year_val})'

            target_url = 'plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type=movie'
            if tmdb_id_val:
                target_url += f'&tmdb_id={tmdb_id_val}'
            elif imdb_id_val:
                target_url += f'&imdb_id={imdb_id_val}'
            else:
                target_url += f'&query={uparse.quote_plus(clean_title)}'

        li = xbmcgui.ListItem(label=item_label)
        try:
            li.setLabel2(f"Interrumpido en {time_str}")
        except Exception:
            pass

        poster_art = rec.get('poster') or rec.get('thumbnail') or 'DefaultVideo.png'
        fanart_art = rec.get('fanart') or ''
        clearlogo_art = rec.get('clearlogo') or ''
        art_dict = {
            'poster': poster_art,
            'thumb': poster_art,
            'icon': poster_art,
            'fanart': fanart_art,
            'clearlogo': clearlogo_art,
            'landscape': fanart_art or poster_art,
            'banner': fanart_art or poster_art
        }
        li.setArt(art_dict)

        display_plot = f"[COLOR gold][B]Interrumpido en {time_str}[/B][/COLOR]"

        genre_val = rec.get('genre') or ''
        if not genre_val and tmdb_id_val:
            try:
                _g_list = _get_genres(tmdb_id_val, is_series)
                if _g_list:
                    genre_val = " / ".join(_g_list)
            except Exception: pass
        if genre_val:
            li.setProperty('genre', genre_val)
            li.setProperty('Genre', genre_val)

        director_val = _clean_single_director(rec.get('director'))
        if not director_val and tmdb_id_val:
            try:
                _d_list = _get_directors(tmdb_id_val, is_series)
                if _d_list:
                    director_val = _clean_single_director(_d_list[0])
            except Exception: pass
        if director_val:
            li.setProperty('director', director_val)
            li.setProperty('Director', director_val)

        try:
            vt = li.getVideoInfoTag()
            if vt:
                vt.setMediaType('episode' if is_series else 'movie')
                vt.setTitle(title_val or item_label)
                if is_series:
                    if showname_val: vt.setTvShowTitle(showname_val)
                    vt.setSeason(int(season_val) if (season_val is not None and str(season_val).isdigit()) else 1)
                    vt.setEpisode(int(episode_val) if (episode_val is not None and str(episode_val).isdigit()) else 1)
                if year_val and str(year_val).isdigit():
                    vt.setYear(int(year_val))
                vt.setPlot(display_plot)
                if resume_t > 0 and total_t > 0:
                    vt.setResumePoint(resume_t, total_t)
                uids = {}
                if tmdb_id_val: uids['tmdb'] = tmdb_id_val
                if imdb_id_val: uids['imdb'] = imdb_id_val
                if rec.get('tvdb'): uids['tvdb'] = str(rec['tvdb'])
                if rec.get('trakt'): uids['trakt'] = str(rec['trakt'])
                if uids:
                    vt.setUniqueIDs(uids)
                if genre_val:
                    try:
                        vt.setGenres([g.strip() for g in genre_val.split('/') if g.strip()])
                    except Exception: pass
                if director_val:
                    try:
                        vt.setDirectors([director_val])
                    except Exception: pass
        except Exception:
            pass

        info_video = {
            'title': title_val or item_label,
            'plot': display_plot,
            'mediatype': 'episode' if is_series else 'movie'
        }
        if director_val:
            info_video['director'] = director_val
        if is_series and showname_val:
            info_video['tvshowtitle'] = showname_val
        if is_series and season_val is not None:
            try: info_video['season'] = int(season_val)
            except: pass
        if is_series and episode_val is not None:
            try: info_video['episode'] = int(episode_val)
            except: pass
        if year_val and str(year_val).isdigit():
            try: info_video['year'] = int(year_val)
            except: pass
        if total_t > 0:
            info_video['duration'] = int(total_t)
        try:
            li.setInfo('video', info_video)
        except Exception:
            pass

        if total_t > 0 and resume_t > 0:
            pct = int((resume_t / total_t) * 100.0)
            li.setProperty('PercentPlayed', str(pct))
            li.setProperty('ResumeTime', str(resume_t))
            li.setProperty('TotalTime', str(total_t))

        rm_url = 'plugin://plugin.video.bridge.multi/?action=remove_continue_watching&media_key=%s' % uparse.quote_plus(mk)
        cl_url = 'plugin://plugin.video.bridge.multi/?action=clear_all_continue_watching'
        li.addContextMenuItems([
            ('[COLOR red]Quitar de Continuar viendo[/COLOR]', 'RunPlugin(%s)' % rm_url),
            ('[COLOR orange]Limpiar todo Continuar viendo[/COLOR]', 'RunPlugin(%s)' % cl_url),
        ])

        xbmcplugin.addDirectoryItem(handle, target_url, li, isFolder=False)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle, succeeded=True)

def show_player_manager_home():
    if handle < 0: return
    alfa_icon = os.path.join(alfa_path, 'resources', 'icon.png')
    if not os.path.exists(alfa_icon): alfa_icon = 'DefaultFolder.png'

    balandro_icon = os.path.join(balandro_path, 'icon.png')
    if not os.path.exists(balandro_icon): balandro_icon = 'DefaultFolder.png'

    last_dt, tot_channels = _get_last_cloud_import_datetime()
    if last_dt:
        dt_formatted = _format_regional_datetime(last_dt)
        cloud_plot = (
            'Descargar y sincronizar todos los canales de Alfa y Balandro desde GitHub.\n\n'
            '[COLOR lime][B]Última importación:[/B][/COLOR] %s' % dt_formatted
        )
        if tot_channels > 0:
            cloud_plot += '\n[COLOR grey]Canales configurados: %d[/COLOR]' % tot_channels
    else:
        cloud_plot = (
            'Descargar y sincronizar todos los canales de Alfa y Balandro desde GitHub.\n\n'
            '[COLOR orange][B]Última importación:[/B] Aún no se ha realizado ninguna importación.[/COLOR]'
        )

    cw_data = load_continue_watching_data()
    cw_valid_count = sum(1 for mk, rec in (cw_data or {}).items() if isinstance(rec, dict) and rec.get('interrupted') and not (float(rec.get('total_time') or 0) > 0 and (float(rec.get('resume_time') or 0) / float(rec.get('total_time') or 1) >= 0.80)) and not is_item_completed(mk))
    cw_badge = (' (%d)' % cw_valid_count) if cw_valid_count > 0 else ''
    cw_plot = (
        'Películas y episodios cuya reproducción fue interrumpida abruptamente (corte de luz, congelamiento o cierre de Kodi).\n\n'
        '[COLOR gold]Al seleccionarlo, TMDb Helper buscará de nuevo en los canales y continuará desde el punto exacto guardado.[/COLOR]'
    )

    alfa_ok = _is_engine_installed('alfa')
    bal_ok = _is_engine_installed('balandro')
    alfa_title_str = 'Gestor de Canales de Alfa (Películas)' if alfa_ok else 'Gestor de Canales de Alfa [COLOR red](No instalado)[/COLOR]'
    bal_title_str = 'Gestor de Canales de Balandro' if bal_ok else 'Gestor de Canales de Balandro [COLOR red](No instalado)[/COLOR]'

    items = [
        ('Continuar', 'Continuar viendo%s' % cw_badge, 'plugin://plugin.video.bridge.multi/?view=continue_watching', 'DefaultInProgressShows.png', True,
         cw_plot),
        ('Alfa', alfa_title_str, 'plugin://plugin.video.bridge.multi/?view=list_players&engine=alfa', alfa_icon, True,
         'Administrar, activar o desactivar canales de Alfa para búsquedas en Multi Bridge.'),
        ('Balandro', bal_title_str, 'plugin://plugin.video.bridge.multi/?view=list_players&engine=balandro', balandro_icon, True,
         'Administrar, activar o desactivar canales de Balandro (Películas y Series).'),
        ('Crear', 'Añadir Canal (Asistente)', 'plugin://plugin.video.bridge.multi/?view=create_player', 'DefaultAddSource.png', False,
         'Asistente guiado paso a paso para añadir nuevos canales disponibles a Multi Bridge.'),
        ('Nube', 'Importar / Actualizar Canales desde la Nube', 'plugin://plugin.video.bridge.multi/?view=update_cloud', 'DefaultNetwork.png', False,
         cloud_plot),
        ('Ajustes', 'Ajustes del Addon', 'plugin://plugin.video.bridge.multi/?view=settings', 'DefaultAddonProgram.png', False,
         'Configurar opciones del addon, orden de servidores, calidades, idiomas y repositorio de GitHub.'),
    ]
    for tag, title_str, item_url, icon, is_f, plot_str in items:
        li = xbmcgui.ListItem(label='[B][COLOR deepskyblue][%s][/COLOR] [COLOR white]%s[/COLOR][/B]' % (tag, title_str))
        li.setArt({'thumb': icon, 'icon': icon, 'poster': icon, 'banner': icon})
        try:
            vt = li.getVideoInfoTag()
            if vt:
                vt.setTitle(title_str)
                vt.setPlot(plot_str)
                vt.setMediaType('video')
        except Exception:
            pass
        try:
            li.setInfo('video', {'title': title_str, 'plot': plot_str})
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle, item_url, li, isFolder=is_f)
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)

def _get_channel_group_data(engine='alfa'):
    ch_data = load_channels_data()
    return ch_data.get('channels', {}).get(engine, {})

def _get_channel_icon_and_info(channel_id, engine='alfa'):
    """Obtiene el icono original y la información de un canal directamente desde la ruta de su addon
    (Alfa o Balandro), sin descargar ni almacenar ninguna imagen en Multi Bridge.
    Soporta URLs remotas y rutas locales de forma nativa.
    """
    addon_path = alfa_path if engine == 'alfa' else balandro_path
    ch_dir = os.path.join(addon_path, 'channels')

    ch_json = os.path.join(ch_dir, channel_id + '.json')
    if not os.path.exists(ch_json) and os.path.exists(ch_dir):
        for f in os.listdir(ch_dir):
            if f.lower() == (channel_id + '.json').lower():
                ch_json = os.path.join(ch_dir, f)
                break

    # Si no existe por nombre directo, buscar por coincidencia parcial en channels
    if not os.path.exists(ch_json) and os.path.exists(ch_dir):
        for f in os.listdir(ch_dir):
            if f.endswith('.json') and (f.lower().startswith(channel_id.lower()) or channel_id.lower().startswith(f[:-5].lower())):
                ch_json = os.path.join(ch_dir, f)
                break

    icon = None
    title = ''
    plot = ''

    if os.path.exists(ch_json):
        try:
            with open(ch_json, 'r', encoding='utf-8', errors='ignore') as f:
                ch_data = json.load(f)
            title = ch_data.get('name') or ''
            plot = ch_data.get('notes') or ''

            thumb = ch_data.get('thumbnail') or ch_data.get('banner') or ''
            if thumb:
                if thumb.startswith('http://') or thumb.startswith('https://'):
                    icon = thumb
                else:
                    local_thumb = os.path.join(addon_path, 'resources', 'media', 'channels', 'thumb', thumb)
                    if os.path.exists(local_thumb):
                        icon = local_thumb
                    else:
                        local_thumb2 = os.path.join(addon_path, 'resources', 'media', 'channels', thumb)
                        if os.path.exists(local_thumb2):
                            icon = local_thumb2

            if not plot:
                langs = [str(l).upper() for l in ch_data.get('language', [])]
                cats = [str(c).capitalize() for c in ch_data.get('categories', [])]
                parts = []
                if langs: parts.append('Idiomas: ' + ', '.join(langs))
                if cats: parts.append('Categorías: ' + ', '.join(cats))
                if parts: plot = ' | '.join(parts)
        except:
            pass

    if not icon:
        for ext in ('.jpg', '.png', '.jpeg'):
            cand_thumb = os.path.join(addon_path, 'resources', 'media', 'channels', 'thumb', channel_id + ext)
            if os.path.exists(cand_thumb):
                icon = cand_thumb
                break

    if not icon:
        for cand_icon in (os.path.join(addon_path, 'resources', 'icon.png'), os.path.join(addon_path, 'icon.png')):
            if os.path.exists(cand_icon):
                icon = cand_icon
                break

    if not icon:
        icon = 'DefaultFolder.png'

    return icon, title, plot

def show_players_list(engine='alfa'):
    if handle < 0: return
    channels = _get_channel_group_data(engine=engine)
    if not channels:
        xbmcplugin.endOfDirectory(handle); return

    for norm_key in sorted(channels.keys(), key=lambda x: channels[x].get('name', x).lower()):
        info = channels[norm_key]
        name = info.get('name', norm_key)
        has_movie = bool(info.get('movies'))
        has_series = bool(info.get('series'))
        has_both = has_movie and has_series
        m_dis = bool(info.get('movie_disabled'))
        s_dis = bool(info.get('series_disabled'))

        if has_both:
            if not m_dis and not s_dis:
                status_icon = '[COLOR lime]●[/COLOR]'
                type_str = '[COLOR deepskyblue]Películas[/COLOR] + [COLOR gold]Series[/COLOR]'
            elif m_dis and s_dis:
                status_icon = '[COLOR red]●[/COLOR]'
                type_str = '[COLOR gray]Desactivado[/COLOR]'
            elif not m_dis and s_dis:
                status_icon = '[COLOR orange]●[/COLOR]'
                type_str = '[COLOR deepskyblue]Películas[/COLOR] [COLOR gray]| Series Desactivadas[/COLOR]'
            else:
                status_icon = '[COLOR orange]●[/COLOR]'
                type_str = '[COLOR gold]Series[/COLOR] [COLOR gray]| Películas Desactivadas[/COLOR]'
        elif has_movie:
            if not m_dis:
                status_icon = '[COLOR lime]●[/COLOR]'
                type_str = '[COLOR deepskyblue]Solo Películas[/COLOR]'
            else:
                status_icon = '[COLOR red]●[/COLOR]'
                type_str = '[COLOR gray]Desactivado (Películas)[/COLOR]'
        else:
            if not s_dis:
                status_icon = '[COLOR lime]●[/COLOR]'
                type_str = '[COLOR gold]Solo Series[/COLOR]'
            else:
                status_icon = '[COLOR red]●[/COLOR]'
                type_str = '[COLOR gray]Desactivado (Series)[/COLOR]'

        lbl = '%s  [B]%s[/B]   [%s]' % (status_icon, name, type_str)
        opt_url = 'plugin://plugin.video.bridge.multi/?view=player_options&channel=%s&engine=%s' % (norm_key, engine)
        li = xbmcgui.ListItem(label=lbl)

        actual_ch = str(info.get('channel') or norm_key).strip().lower()
        icon, ch_title, ch_plot = _get_channel_icon_and_info(actual_ch, engine=engine)

        li.setArt({
            'thumb': icon,
            'icon': icon,
            'poster': icon,
            'banner': icon
        })

        display_title = ch_title if ch_title else name
        desc_plot = ch_plot if ch_plot else ('Canal de %s' % engine.capitalize())

        try:
            vt = li.getVideoInfoTag()
            if vt:
                vt.setTitle(display_title)
                vt.setPlot(desc_plot)
                vt.setMediaType('video')
        except Exception:
            pass
        try:
            li.setInfo('video', {'title': display_title, 'plot': desc_plot})
        except Exception:
            pass

        xbmcplugin.addDirectoryItem(handle, opt_url, li, isFolder=False)

    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.endOfDirectory(handle)

def show_player_options(channel_key, engine='alfa'):
    if not channel_key: return
    dialog = xbmcgui.Dialog()

    ch_data = load_channels_data()
    engine_channels = ch_data.setdefault('channels', {}).setdefault(engine, {})

    clean_key = str(channel_key).lower().replace('.json', '')
    prefix = 'alfa-' if engine == 'alfa' else 'balandro-'
    if clean_key.startswith(prefix):
        clean_key = clean_key[len(prefix):]
    clean_key = re.sub(r'-series$', '', clean_key, flags=re.IGNORECASE).strip()

    info = engine_channels.get(clean_key)
    if not info:
        for k, v in engine_channels.items():
            if str(v.get('name', '')).lower() == clean_key or str(v.get('channel', '')).lower() == clean_key:
                clean_key = k
                info = v
                break

    if not info:
        return

    name = info.get('name', clean_key)
    has_movie = bool(info.get('movies'))
    has_series = bool(info.get('series'))
    has_both = has_movie and has_series
    m_dis = bool(info.get('movie_disabled'))
    s_dis = bool(info.get('series_disabled'))

    if has_both:
        opt_movie = ('[COLOR red]Desactivar[/COLOR] Películas' if not m_dis else '[COLOR lime]Activar[/COLOR] Películas')
        opt_series = ('[COLOR red]Desactivar[/COLOR] Series' if not s_dis else '[COLOR lime]Activar[/COLOR] Series')
        both_active = (not m_dis and not s_dis)
        opt_all = ('[COLOR red]Desactivar Todo[/COLOR] (Películas y Series)' if both_active else '[COLOR lime]Activar Todo[/COLOR] (Películas y Series)')
        opt_delete = '[COLOR red]Eliminar Canal[/COLOR]'
        opt_back = 'Volver'

        options = [opt_movie, opt_series, opt_all, opt_delete, opt_back]
        sel = dialog.select('Canal: %s' % name, options)

        if sel == 0:
            info['movie_disabled'] = not m_dis
            save_channels_data(ch_data)
            dialog.notification('Multi Bridge', 'Películas de %s %s' % (name, 'desactivadas' if not m_dis else 'activadas'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 1:
            info['series_disabled'] = not s_dis
            save_channels_data(ch_data)
            dialog.notification('Multi Bridge', 'Series de %s %s' % (name, 'desactivadas' if not s_dis else 'activadas'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 2:
            new_val = both_active
            info['movie_disabled'] = new_val
            info['series_disabled'] = new_val
            save_channels_data(ch_data)
            dialog.notification('Multi Bridge', '%s %s' % (name, 'desactivado' if new_val else 'activado'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 3:
            if dialog.yesno('Eliminar Canal', '¿Seguro que deseas eliminar el canal %s?' % name):
                if clean_key in engine_channels:
                    del engine_channels[clean_key]
                save_channels_data(ch_data)
                dialog.notification('Multi Bridge', '%s eliminado' % name, '', 2000)
                xbmc.executebuiltin('Container.Refresh')

    else:
        target_type = 'Películas' if has_movie else 'Series'
        is_dis = m_dis if has_movie else s_dis

        opt_toggle = ('[COLOR red]Desactivar[/COLOR] %s' % target_type if not is_dis else '[COLOR lime]Activar[/COLOR] %s' % target_type)
        opt_delete = '[COLOR red]Eliminar Canal[/COLOR]'
        opt_back = 'Volver'

        options = [opt_toggle, opt_delete, opt_back]
        sel = dialog.select('Canal: %s (%s)' % (name, target_type), options)

        if sel == 0:
            if has_movie:
                info['movie_disabled'] = not m_dis
            else:
                info['series_disabled'] = not s_dis
            save_channels_data(ch_data)
            dialog.notification('Multi Bridge', '%s (%s) %s' % (name, target_type, 'desactivado' if not is_dis else 'activado'), '', 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif sel == 1:
            if dialog.yesno('Eliminar Canal', '¿Seguro que deseas eliminar el canal %s?' % name):
                if clean_key in engine_channels:
                    del engine_channels[clean_key]
                save_channels_data(ch_data)
                dialog.notification('Multi Bridge', '%s eliminado' % name, '', 2000)
                xbmc.executebuiltin('Container.Refresh')

def _detect_channel_capabilities(engine, channel_id, mods_path):
    ch_json = os.path.join(mods_path, 'channels', channel_id + '.json')
    supports_movies = True
    supports_series = False
    if os.path.exists(ch_json):
        try:
            with open(ch_json, 'r', encoding='utf-8') as f:
                d = json.load(f)
            cats = [str(c).lower() for c in d.get('categories', [])]
            stypes = [str(s).lower() for s in d.get('search_types', [])]
            if cats or stypes:
                supports_movies = ('movie' in cats or 'movie' in stypes or 'all' in stypes)
                supports_series = ('tvshow' in cats or 'tvshow' in stypes or 'series' in cats)
        except: pass
    if not supports_series:
        ch_py = os.path.join(mods_path, 'channels', channel_id + '.py')
        if os.path.exists(ch_py):
            try:
                with open(ch_py, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                supports_series = bool('episodios' in content or 'temporadas' in content or 'search_type == "tvshow"' in content)
            except: pass
    return supports_movies, supports_series

def _add_channel_to_json(engine, channel_id, is_series=False, also_movies=False):
    ch_data = load_channels_data()
    engine_channels = ch_data.setdefault('channels', {}).setdefault(engine, {})
    ch_clean = channel_id.lower().strip()

    addon_path = alfa_path if engine == 'alfa' else balandro_path
    display_name = _channel_display_name(addon_path, ch_clean)
    if not display_name or display_name == ch_clean:
        display_name = channel_id.capitalize()

    if ch_clean not in engine_channels:
        engine_channels[ch_clean] = {
            'id': ch_clean,
            'name': display_name,
            'channel': ch_clean,
            'engine': engine,
            'movies': False,
            'series': False,
            'movie_disabled': False,
            'series_disabled': False,
            'play_movie': None,
            'play_episode': None
        }

    entry = engine_channels[ch_clean]
    if also_movies:
        entry['movies'] = True
        entry['movie_disabled'] = False
        entry['series'] = True
        entry['series_disabled'] = False
    elif is_series:
        entry['series'] = True
        entry['series_disabled'] = False
    else:
        entry['movies'] = True
        entry['movie_disabled'] = False

    save_channels_data(ch_data)
    return display_name

def create_player_wizard():
    alfa_ok = _is_engine_installed('alfa')
    bal_ok = _is_engine_installed('balandro')

    if not alfa_ok and not bal_ok:
        xbmcgui.Dialog().ok('Multi Bridge', 'No se encontró ni Alfa ni Balandro instalado.')
        return

    dialog = xbmcgui.Dialog()
    if alfa_ok and not bal_ok:
        engine = 'alfa'
    elif bal_ok and not alfa_ok:
        engine = 'balandro'
    else:
        engine_choice = dialog.select('¿Para qué addon deseas añadir el canal?', ['Alfa (Solo Películas)', 'Balandro'])
        if engine_choice < 0: return
        engine = 'alfa' if engine_choice == 0 else 'balandro'

    mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
    if not mods:
        dialog.ok('Multi Bridge', 'El addon %s no está instalado o disponible.' % engine.capitalize())
        return

    channels_dir = os.path.join(mods['path'], 'channels')
    if not os.path.exists(channels_dir): return
    available = []
    for f in sorted(os.listdir(channels_dir)):
        if f.endswith('.py') and not f.startswith('__'):
            ch_id = f.replace('.py', '')
            available.append(ch_id)

    sel_ch = dialog.select('Selecciona Canal de %s' % engine.capitalize(), [c.capitalize() for c in available])
    if sel_ch < 0: return
    chosen_id = available[sel_ch]
    ch_clean = chosen_id.capitalize()

    supports_movies, supports_series = _detect_channel_capabilities(engine, chosen_id, mods['path'])

    created_name = ''
    if engine == 'balandro' and supports_series:
        if supports_movies:
            opts = [
                'Habilitar Ambos (Películas y Series)',
                'Solo Películas',
                'Solo Series',
                'Cancelar'
            ]
            choice = dialog.select('El canal %s también soporta Series' % ch_clean, opts)
            if choice == 0:
                created_name = _add_channel_to_json(engine, chosen_id, is_series=True, also_movies=True)
            elif choice == 1:
                created_name = _add_channel_to_json(engine, chosen_id, is_series=False)
            elif choice == 2:
                created_name = _add_channel_to_json(engine, chosen_id, is_series=True)
            else:
                return
        else:
            created_name = _add_channel_to_json(engine, chosen_id, is_series=True)
    else:
        created_name = _add_channel_to_json(engine, chosen_id, is_series=False)

    if created_name:
        dialog.ok('Multi Bridge', '¡Canal %s añadido con éxito a Multi Bridge!' % created_name)

def update_players_from_cloud():
    """Descarga e importa el archivo channels.json desde el repositorio de GitHub (01xKeven/Players-Multi),
    realiza un merge inteligente respetando canales desactivados por el usuario, y asegura que TMDb Helper
    contenga únicamente (1)MultiBusqueda.json.
    """
    dialog = xbmcgui.Dialog()
    repo_url = _bridge_addon.getSetting('cloud_repo_url') if _bridge_addon else ''
    if not repo_url or not repo_url.strip():
        repo_url = 'https://github.com/01xKeven/Players-Multi'

    confirm = dialog.yesno(
        'Multi Bridge — Nube',
        '¿Deseas descargar y actualizar los canales desde la Nube (GitHub)?\n\n'
        '[COLOR deepskyblue]Repositorio:[/COLOR] %s\n'
        '[COLOR gold]Aviso:[/COLOR] Se actualizará la lista de canales interna (channels.json).' % repo_url
    )
    if not confirm:
        return

    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create('Multi Bridge — Nube', 'Conectando con GitHub...')
    p_dialog.update(10, 'Descargando channels.json desde GitHub...')

    clean_repo = repo_url.strip().rstrip('/')
    if clean_repo.startswith('https://github.com/'):
        clean_repo = clean_repo[len('https://github.com/'):]
    elif clean_repo.startswith('http://github.com/'):
        clean_repo = clean_repo[len('http://github.com/'):]

    token = _bridge_addon.getSetting('github_token').strip() if _bridge_addon else ''
    headers = {'User-Agent': 'Mozilla/5.0'}
    if token:
        headers['Authorization'] = 'token %s' % token

    raw_candidates = [
        'https://raw.githubusercontent.com/%s/master/channels.json' % clean_repo,
        'https://raw.githubusercontent.com/%s/main/channels.json' % clean_repo,
    ]

    remote_json_bytes = None
    download_error = ''

    for u in raw_candidates:
        if p_dialog.iscanceled():
            p_dialog.close()
            return
        try:
            xbmc.log('Multi Bridge Nube: intentando descargar ' + u, xbmc.LOGINFO)
            req = urllib.request.Request(u, headers=headers)
            with urllib.request.urlopen(req, timeout=20) as resp:
                if resp.status == 200:
                    remote_json_bytes = resp.read()
                    break
        except Exception as e:
            download_error = str(e)
            xbmc.log('Multi Bridge Nube: error descargando ' + u + ': ' + str(e), xbmc.LOGWARNING)

    # Fallback to ZIP if raw fails
    if not remote_json_bytes:
        import zipfile, io
        zip_candidates = [
            'https://github.com/%s/archive/refs/heads/master.zip' % clean_repo,
            'https://github.com/%s/archive/refs/heads/main.zip' % clean_repo,
            'https://codeload.github.com/%s/zip/refs/heads/master' % clean_repo,
        ]
        for u in zip_candidates:
            if p_dialog.iscanceled():
                p_dialog.close()
                return
            try:
                xbmc.log('Multi Bridge Nube: intentando descargar zip ' + u, xbmc.LOGINFO)
                req = urllib.request.Request(u, headers=headers)
                with urllib.request.urlopen(req, timeout=20) as resp:
                    if resp.status == 200:
                        zf = zipfile.ZipFile(io.BytesIO(resp.read()))
                        for zi in zf.infolist():
                            if zi.filename.endswith('channels.json'):
                                remote_json_bytes = zf.read(zi.filename)
                                break
                        if remote_json_bytes:
                            break
            except Exception as e:
                download_error = str(e)
                xbmc.log('Multi Bridge Nube: error en fallback zip: ' + str(e), xbmc.LOGWARNING)

    if not remote_json_bytes:
        try: p_dialog.close()
        except: pass
        dialog.ok(
            'Multi Bridge — Error en Nube',
            'No se pudo descargar channels.json desde GitHub.\n\n'
            '[COLOR red]Detalle:[/COLOR] %s\n'
            'Verifica tu conexión o el repositorio: %s' % (download_error or 'Descarga fallida', repo_url)
        )
        return

    p_dialog.update(60, 'Procesando y sincronizando canales...')

    try:
        remote_data = json.loads(remote_json_bytes.decode('utf-8'))
    except Exception as e:
        try: p_dialog.close()
        except: pass
        dialog.ok('Multi Bridge — Error', 'El archivo channels.json remoto no es JSON válido: ' + str(e))
        return

    local_data = load_channels_data()
    local_channels = local_data.setdefault('channels', {})
    remote_channels = remote_data.get('channels', {})

    alfa_count = 0
    balandro_count = 0

    for eng in ('alfa', 'balandro'):
        rem_eng = remote_channels.get(eng, {})
        loc_eng = local_channels.setdefault(eng, {})
        for ch_id, r_info in rem_eng.items():
            if ch_id in loc_eng:
                # Conservar preferencias locales de desactivado
                r_info['movie_disabled'] = loc_eng[ch_id].get('movie_disabled', False)
                r_info['series_disabled'] = loc_eng[ch_id].get('series_disabled', False)
            loc_eng[ch_id] = r_info
            if eng == 'alfa':
                alfa_count += 1
            else:
                balandro_count += 1

    total_count = alfa_count + balandro_count
    sync_payload = {
        'timestamp': int(datetime.datetime.now().timestamp()),
        'iso': datetime.datetime.now().isoformat(),
        'total_alfa': alfa_count,
        'total_balandro': balandro_count,
        'total': total_count
    }
    local_data['last_sync'] = sync_payload
    save_channels_data(local_data)

    try:
        with open(CLOUD_SYNC_FILE, 'w', encoding='utf-8') as _cf:
            json.dump(sync_payload, _cf, indent=4)
    except Exception as e:
        xbmc.log('Multi Bridge Nube: error guardando sync_info: ' + str(e), xbmc.LOGWARNING)

    p_dialog.update(90, 'Verificando y limpiando carpeta de TMDb Helper...')
    try:
        check_and_run_migration()
    except Exception:
        pass

    try: p_dialog.close()
    except: pass

    dialog.ok(
        'Multi Bridge — Nube',
        '¡Sincronización de la Nube completada!\n\n'
        '• [B][COLOR deepskyblue]Canales Alfa:[/COLOR][/B] %d sincronizados\n'
        '• [B][COLOR gold]Canales Balandro:[/COLOR][/B] %d sincronizados\n'
        '• [B][COLOR lime]Total actualizados:[/COLOR][/B] %d canales\n\n'
        'Los canales internos de Multi Bridge han sido actualizados con éxito y TMDb Helper se mantiene limpio.' % (alfa_count, balandro_count, total_count)
    )
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass

# ---------------------------------------------------------
# Custom Engine Picker Dialog (ventana personalizada)
# ---------------------------------------------------------
class _EnginePickerDialog(xbmcgui.WindowDialog):
    ACTION_MOVE_LEFT   = 1
    ACTION_MOVE_RIGHT  = 2
    ACTION_SELECT_ITEM = 7
    ACTION_PREVIOUS_MENU = 10
    ACTION_NAV_BACK    = 92
    ACTION_MOUSE_MOVE  = 107

    def __init__(self, alfa_icon_path, balandro_icon_path):
        super().__init__()
        self.selected = -1
        self.selected_link = None          # -1 = cancelado
        self.current  = 0           # 0=Alfa 1=Balandro
        self._alfa_icon  = alfa_icon_path
        self._bal_icon   = balandro_icon_path
        self._alfa_hls   = []
        self._bal_hls    = []
        self._alfa_img_id = -1
        self._bal_img_id  = -1
        try:
            self._build()
        except Exception as e:
            xbmc.log('BridgeMulti EnginePickerDialog build error: ' + str(e), xbmc.LOGWARNING)

    @staticmethod
    def _white():
        # Textura blanca integrada del skin Estuary de Kodi (no requiere archivo propio)
        import xbmcvfs
        candidates = [
            'special://xbmc/addons/skin.estuary/media/white-diffuse.png',
            'special://xbmc/addons/skin.estuary/media/Colours/white.png',
            'special://xbmcbin/addons/skin.estuary/media/white-diffuse.png',
        ]
        for c in candidates:
            if xbmcvfs.exists(c):
                return c
        # Fallback: crear un PNG blanco 1x1 en memoria temporal
        import tempfile, struct, zlib
        _png = (b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01'
                b'\x08\x02\x00\x00\x00\x90wS\xde\x00\x00\x00\x0cIDATx\x9cc\xf8\xff\xff'
                b'\x3f\x00\x05\xfe\x02\xfe\xdc\xccY\xe7\x00\x00\x00\x00IEND\xaeB`\x82')
        _tmp = os.path.join(tempfile.gettempdir(), 'bm_white.png')
        try:
            if not os.path.exists(_tmp):
                with open(_tmp, 'wb') as _f: _f.write(_png)
        except: pass
        return _tmp


    def _build(self):
        W = self.getWidth()
        H = self.getHeight()

        # ----- dimensiones del dialogo -----
        dw, dh = 660, 340
        dx = (W - dw) // 2
        dy = (H - dh) // 2
        border = 4
        white  = self._white()

        # Borde dorado exterior
        self.addControl(xbmcgui.ControlImage(
            dx, dy, dw, dh, white, colorDiffuse='FFCFA82C'))

        # Fondo oscuro interior (negro puro)
        self.addControl(xbmcgui.ControlImage(
            dx+border, dy+border, dw-border*2, dh-border*2,
            white, colorDiffuse='FF000000'))

        # Titulo
        self.addControl(xbmcgui.ControlLabel(
            dx, dy+14, dw, 36,
            '[B]¿Con qué addon deseas buscar?[/B]',
            font='font13', textColor='FFCFA82C', alignment=6))

        # Línea separadora dorada
        self.addControl(xbmcgui.ControlImage(
            dx+30, dy+56, dw-60, 2, white, colorDiffuse='55CFA82C'))

        # ----- opciones: iconos centrados horizontalmente -----
        icon_sz  = 148
        gap      = 100
        total_w  = icon_sz*2 + gap
        opt1_x   = dx + (dw - total_w) // 2
        opt2_x   = opt1_x + icon_sz + gap
        icon_y   = dy + 76

        # --- Alfa ---
        alfa_img = xbmcgui.ControlImage(opt1_x, icon_y, icon_sz, icon_sz, self._alfa_icon)
        self.addControl(alfa_img)
        self._alfa_img_id = alfa_img.getId()

        self.addControl(xbmcgui.ControlLabel(
            opt1_x, icon_y+icon_sz+6, icon_sz, 32,
            '[B]Alfa[/B]', font='font13',
            textColor='FFFFFFFF', alignment=6))

        # --- Balandro ---
        bal_img = xbmcgui.ControlImage(opt2_x, icon_y, icon_sz, icon_sz, self._bal_icon)
        self.addControl(bal_img)
        self._bal_img_id = bal_img.getId()

        self.addControl(xbmcgui.ControlLabel(
            opt2_x, icon_y+icon_sz+6, icon_sz, 32,
            '[B]Balandro[/B]', font='font13',
            textColor='FFFFFFFF', alignment=6))

        # ----- highlight dorado (4 lados como borde) -----
        hl_mg  = 8
        hl_sz  = icon_sz + hl_mg*2
        thick  = 3
        GOLD   = 'FFCFA82C'

        def make_hl(ox, oy):
            return [
                xbmcgui.ControlImage(ox-hl_mg,           oy-hl_mg,           hl_sz,  thick, white, colorDiffuse=GOLD),
                xbmcgui.ControlImage(ox-hl_mg,           oy+icon_sz+hl_mg-thick, hl_sz,  thick, white, colorDiffuse=GOLD),
                xbmcgui.ControlImage(ox-hl_mg,           oy-hl_mg,           thick, hl_sz, white, colorDiffuse=GOLD),
                xbmcgui.ControlImage(ox+icon_sz+hl_mg-thick, oy-hl_mg,       thick, hl_sz, white, colorDiffuse=GOLD),
            ]

        self._alfa_hls = make_hl(opt1_x, icon_y)
        self._bal_hls  = make_hl(opt2_x, icon_y)

        for c in self._alfa_hls + self._bal_hls:
            self.addControl(c)

        # Hint
        self.addControl(xbmcgui.ControlLabel(
            dx, dy+dh-34, dw, 28,
            '[COLOR=888888][← →] Navegar    [OK] Confirmar    [Atrás] Cancelar[/COLOR]',
            font='font12', textColor='FF888888', alignment=6))

        self._update_highlight()

    def _update_highlight(self):
        for c in self._alfa_hls:
            c.setVisible(self.current == 0)
        for c in self._bal_hls:
            c.setVisible(self.current == 1)

    def onAction(self, action):
        aid = action.getId()
        if aid in (self.ACTION_PREVIOUS_MENU, self.ACTION_NAV_BACK):
            self.selected = -1
            self.close()
        elif aid == self.ACTION_MOVE_LEFT:
            self.current = 0
            self._update_highlight()
        elif aid == self.ACTION_MOVE_RIGHT:
            self.current = 1
            self._update_highlight()
        elif aid == self.ACTION_SELECT_ITEM:
            self.selected = self.current
            self.close()

    def onClick(self, control_id):
        if control_id == self._alfa_img_id:
            self.selected = 0
            self.close()
        elif control_id == self._bal_img_id:
            self.selected = 1
            self.close()


def _show_engine_picker():
    """Muestra la ventana personalizada de seleccion de motor.
    Devuelve 'alfa', 'balandro' o None si se cancela."""
    alfa_ok = _is_engine_installed('alfa')
    bal_ok  = _is_engine_installed('balandro')

    if not alfa_ok and not bal_ok:
        xbmcgui.Dialog().ok('Multi Bridge', 'No se encontró ni Alfa ni Balandro instalados.\nInstala al menos uno de ellos para buscar contenido.')
        return None

    if alfa_ok and not bal_ok:
        return 'alfa'

    if bal_ok and not alfa_ok:
        return 'balandro'

    try:
        _ch_info = load_channels_data().get('channels', {})
        _a_has = any(c.get('movies') and not c.get('movie_disabled') for c in _ch_info.get('alfa', {}).values())
        _b_has = any(c.get('movies') and not c.get('movie_disabled') for c in _ch_info.get('balandro', {}).values())
        if _a_has and not _b_has:
            return 'alfa'
        if _b_has and not _a_has:
            return 'balandro'
    except Exception:
        pass

    try:
        alfa_addon = xbmcaddon.Addon('plugin.video.alfa')
        alfa_icon  = os.path.join(alfa_addon.getAddonInfo('path'), 'resources', 'icon.png')
        if not os.path.exists(alfa_icon):
            alfa_icon = alfa_addon.getAddonInfo('icon') or ''
    except Exception:
        alfa_icon = ''

    try:
        bal_addon  = xbmcaddon.Addon('plugin.video.balandro')
        bal_icon   = os.path.join(bal_addon.getAddonInfo('path'), 'icon.png')
        if not os.path.exists(bal_icon):
            bal_icon = bal_addon.getAddonInfo('icon') or ''
    except Exception:
        bal_icon = ''

    try:
        dlg = _EnginePickerDialog(alfa_icon, bal_icon)
        dlg.doModal()
        sel = dlg.selected
        del dlg
    except Exception as e:
        xbmc.log('BridgeMulti _show_engine_picker error: ' + str(e), xbmc.LOGWARNING)
        # Fallback al dialogo nativo de Kodi si algo falla
        fb = xbmcgui.Dialog().select(
            '¿Dónde deseas buscar?',
            ['[B][COLOR gold]Alfa[/COLOR][/B]', '[B][COLOR deepskyblue]Balandro[/COLOR][/B]'])
        return ('alfa' if fb == 0 else 'balandro') if fb >= 0 else None

    if sel < 0:
        return None
    return 'alfa' if sel == 0 else 'balandro'


# ---------------------------------------------------------
# Siguiente Episodio: Detección y Reproducción
# ---------------------------------------------------------
_NEXT_EPISODE_CACHE = {}
_PRELOADED_NEXT_EPISODE_CACHE = {}

def _get_preloaded_next_episode(meta):
    if not meta: return None
    tmdb_id = str(meta.get('tmdb') or meta.get('tmdb_id') or '')
    next_ep = _get_next_episode_info(meta)
    if not next_ep: return None
    next_s = next_ep.get('season')
    next_e = next_ep.get('episode')
    cache_key = '%s_S%02dE%02d' % (tmdb_id, int(next_s), int(next_e))
    entry = _PRELOADED_NEXT_EPISODE_CACHE.get(cache_key)
    if entry and entry.get('links'):
        valid_instant = [
            l for l in entry.get('links', [])
            if not _is_torrent_link(l) and not _is_web_captcha_server(_get_link_server_name(l), l)
        ]
        if valid_instant:
            entry_copy = dict(entry)
            entry_copy['links'] = valid_instant
            return entry_copy
    return None

def _run_phase1_current_episode_verification(meta, my_token, p, mon):
    """FASE 1: Continúa la verificación pasiva y con bajo consumo de CPU de los enlaces faltantes
    del capítulo actual en segundo plano, reclasificando y ordenando estrictamente según las
    preferencias del usuario (Idioma, Calidad, Servidores) para nutrir el OSD y el menú de pausa."""
    global _BG_COLLECTOR_RUNNING

    # Si hay un recolector de Fast Autoplay activo para este capítulo, esperar a que culmine
    while _BG_COLLECTOR_RUNNING:
        if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
            return
        if mon.waitForAbort(0.5):
            return

    unverified_list = []
    curr_verified = []
    matched_item = None
    engine = 'balandro'

    cur_tmdb = _norm_id_str(meta.get('tmdb'))
    cur_season = _norm_id_str(meta.get('season'))
    cur_ep = _norm_id_str(meta.get('episode'))

    ram = _get_ram_search_cache()
    if ram and isinstance(ram, dict):
        r_meta = ram.get('meta') or {}
        r_tmdb = _norm_id_str(r_meta.get('tmdb') or meta.get('tmdb'))
        r_season = _norm_id_str(r_meta.get('season') or meta.get('season'))
        r_ep = _norm_id_str(r_meta.get('episode') or meta.get('episode'))

        matches = True
        if cur_tmdb and r_tmdb and cur_tmdb != r_tmdb: matches = False
        if cur_season and r_season and cur_season != r_season: matches = False
        if cur_ep and r_ep and cur_ep != r_ep: matches = False

        if matches:
            unverified_list = list(ram.get('unverified_links') or [])
            curr_verified = list(ram.get('links') or [])
            matched_item = ram.get('matched_item')
            engine = ram.get('engine', 'balandro') or 'balandro'

    if not unverified_list:
        disk_cache = _read_search_cache_atomic()
        if disk_cache and isinstance(disk_cache, dict):
            d_meta = disk_cache.get('meta') or {}
            d_tmdb = _norm_id_str(d_meta.get('tmdb') or meta.get('tmdb'))
            d_season = _norm_id_str(d_meta.get('season') or meta.get('season'))
            d_ep = _norm_id_str(d_meta.get('episode') or meta.get('episode'))

            matches = True
            if cur_tmdb and d_tmdb and cur_tmdb != d_tmdb: matches = False
            if cur_season and d_season and cur_season != d_season: matches = False
            if cur_ep and d_ep and cur_ep != d_ep: matches = False

            if matches and disk_cache.get('unverified_links'):
                engine = disk_cache.get('engine', 'balandro') or 'balandro'
                unverified_raw = disk_cache.get('unverified_links') or []
                verified_raw = disk_cache.get('links') or []
                unverified_list = [_deserialize_item(x, engine) if isinstance(x, dict) else x for x in unverified_raw]
                unverified_list = [x for x in unverified_list if x and getattr(x, 'url', None)]
                if not curr_verified:
                    curr_verified = [_deserialize_item(x, engine) if isinstance(x, dict) else x for x in verified_raw]
                    curr_verified = [x for x in curr_verified if x and getattr(x, 'url', None)]
                if not matched_item:
                    matched_item = _deserialize_item(disk_cache.get('item'), engine) if isinstance(disk_cache.get('item'), dict) else disk_cache.get('item')

    def _reload_cache_state():
        nonlocal unverified_list, curr_verified, matched_item, engine
        _unv = []
        _ver = list(curr_verified)
        _eng = engine
        _mi = matched_item
        ram2 = _get_ram_search_cache()
        if ram2:
            r_meta2 = ram2.get('meta') or {}
            r_tmdb2 = _norm_id_str(r_meta2.get('tmdb') or meta.get('tmdb'))
            r_season2 = _norm_id_str(r_meta2.get('season') or meta.get('season'))
            r_ep2 = _norm_id_str(r_meta2.get('episode') or meta.get('episode'))
            m2 = True
            if cur_tmdb and r_tmdb2 and cur_tmdb != r_tmdb2: m2 = False
            if cur_season and r_season2 and cur_season != r_season2: m2 = False
            if cur_ep and r_ep2 and cur_ep != r_ep2: m2 = False
            if m2:
                _eng = ram2.get('engine', _eng) or _eng
                _unv = list(ram2.get('unverified_links') or [])
                if ram2.get('links'):
                    _ver = list(ram2.get('links') or [])
                if not _mi:
                    _mi = ram2.get('matched_item')
        if not _unv:
            dc2 = _read_search_cache_atomic()
            if dc2 and isinstance(dc2, dict):
                d_meta2 = dc2.get('meta') or {}
                d_tmdb2 = _norm_id_str(d_meta2.get('tmdb') or meta.get('tmdb'))
                d_season2 = _norm_id_str(d_meta2.get('season') or meta.get('season'))
                d_ep2 = _norm_id_str(d_meta2.get('episode') or meta.get('episode'))
                m2 = True
                if cur_tmdb and d_tmdb2 and cur_tmdb != d_tmdb2: m2 = False
                if cur_season and d_season2 and cur_season != d_season2: m2 = False
                if cur_ep and d_ep2 and cur_ep != d_ep2: m2 = False
                if m2:
                    _eng = dc2.get('engine', _eng) or _eng
                    _unv = [_deserialize_item(x, _eng) if isinstance(x, dict) else x for x in (dc2.get('unverified_links') or [])]
                    _unv = [x for x in _unv if x and getattr(x, 'url', None)]
                    if dc2.get('links') and not _ver:
                        _ver = [_deserialize_item(x, _eng) if isinstance(x, dict) else x for x in (dc2.get('links') or [])]
                        _ver = [x for x in _ver if x and getattr(x, 'url', None)]
                    if not _mi:
                        _mi = _deserialize_item(dc2.get('item'), _eng) if isinstance(dc2.get('item'), dict) else dc2.get('item')
        unverified_list = _unv
        curr_verified = _ver
        matched_item = _mi
        engine = _eng

    def _wait_bg_collector(max_wait=45.0):
        t0 = time.time()
        while _BG_COLLECTOR_RUNNING and (time.time() - t0) < max_wait:
            if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                return False
            if mon.waitForAbort(0.25):
                return False
        return True

    if not unverified_list and _BG_COLLECTOR_RUNNING:
        if not _wait_bg_collector():
            return
        _reload_cache_state()

    if not unverified_list:
        xbmc.log("Multi Bridge Pipeline [Fase 1]: No hay enlaces pendientes por verificar para el capítulo actual.", xbmc.LOGINFO)
        return

    # Filtrar y ordenar candidatos pendientes según preferencias del usuario antes de verificar
    unverified_list = _filter_and_sort_links(unverified_list)
    xbmc.log("Multi Bridge Pipeline [Fase 1]: Iniciando verificación pasiva de %d enlace(s) faltante(s) del capítulo actual..." % len(unverified_list), xbmc.LOGINFO)

    # Identificar enlace actualmente en reproducción para preservar su selección en OSD
    global _current_playing_link_index
    playing_url = None
    playing_uid = None
    try:
        cur_p_idx_str = xbmcgui.Window(10000).getProperty('BridgeMulti.CurrentPlayingIndex')
        if cur_p_idx_str and cur_p_idx_str.isdigit():
            cur_idx = int(cur_p_idx_str)
            if 0 <= cur_idx < len(curr_verified):
                playing_link = curr_verified[cur_idx]
                playing_url = getattr(playing_link, 'url', None)
                playing_uid = _get_link_unique_id(playing_link)
    except Exception:
        pass

    max_func_limit = _get_int_setting('verify_max_functional', 12)
    if max_func_limit < 0:
        max_func_limit = 0
    hide_captcha = (_bridge_addon.getSetting('hide_captcha_links') == 'true')

    def _count_direct_verified(lst):
        cnt = 0
        for _item in (lst or []):
            if not _is_torrent_link(_item) and not _is_web_captcha_server(_get_link_server_name(_item), _item):
                cnt += 1
        return cnt

    def _persist_phase1_state(rem_list):
        nonlocal curr_verified
        sorted_verified = _filter_and_sort_links(curr_verified)
        curr_verified = sorted_verified
        if playing_uid or playing_url:
            new_p_idx = -1
            for i, l in enumerate(sorted_verified):
                if playing_uid and _get_link_unique_id(l) == playing_uid:
                    new_p_idx = i
                    break
                if playing_url and getattr(l, 'url', None) == playing_url:
                    new_p_idx = i
                    break
            if new_p_idx >= 0:
                _current_playing_link_index = new_p_idx
                try:
                    xbmcgui.Window(10000).setProperty('BridgeMulti.CurrentPlayingIndex', str(new_p_idx))
                except Exception:
                    pass
        meta_copy = dict(meta)
        meta_copy['verified_only'] = True
        try:
            _store_ram_search_cache(curr_verified, matched_item, meta_copy, engine, unverified_links=rem_list)
            _save_search_cache_atomic({
                'item': _serialize_item(matched_item),
                'links': [_serialize_item(l) for l in curr_verified],
                'unverified_links': [_serialize_item(l) for l in rem_list],
                'meta': meta_copy,
                'engine': engine,
                'is_preloaded_session': bool(rem_list),
                'cache_ver': 2
            })
            if _in_own_list():
                xbmc.executebuiltin('Container.Refresh')
        except Exception as _save_e:
            xbmc.log("Multi Bridge Pipeline [Fase 1]: Error guardando caché incremental: %s" % str(_save_e), xbmc.LOGWARNING)

    def _run_verification_pass(cand_items):
        nonlocal curr_verified
        if not cand_items:
            return
        rem_unv = list(cand_items)
        q_verify = []
        direct_bypass_added = False
        for cand in cand_items:
            cand_url = _safe_str(getattr(cand, 'url', '') or '')
            if cand_url and cand_url in existing_urls:
                if cand in rem_unv:
                    rem_unv.remove(cand)
                continue
            if _is_torrent_link(cand):
                try: cand.bridge_engine = engine
                except Exception: pass
                curr_verified.append(cand)
                if cand_url:
                    existing_urls.add(cand_url)
                if cand in rem_unv:
                    rem_unv.remove(cand)
                direct_bypass_added = True
            elif _is_web_captcha_server(_get_link_server_name(cand), cand):
                if not hide_captcha:
                    try: cand.bridge_engine = engine
                    except Exception: pass
                    curr_verified.append(cand)
                    if cand_url:
                        existing_urls.add(cand_url)
                    direct_bypass_added = True
                if cand in rem_unv:
                    rem_unv.remove(cand)
            else:
                q_verify.append(cand)

        if direct_bypass_added:
            _persist_phase1_state(rem_unv)

        batch_size = 3
        idx_q = 0
        while idx_q < len(q_verify):
            if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                xbmc.log("Multi Bridge Pipeline [Fase 1]: Interrumpido por cambio de reproducción o detención del reproductor", xbmc.LOGINFO)
                if mon.abortRequested() or _SHUTDOWN_REQUESTED:
                    abort_all_network_sockets()
                return False

            # Pausar la verificación en segundo plano si el diálogo modal o menú de enlaces está abierto
            while _floating_dialog_active or _is_dialog_active_global():
                if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                    return False
                if mon.waitForAbort(0.5):
                    return False

            if max_func_limit > 0 and _count_direct_verified(curr_verified) >= max_func_limit:
                xbmc.log("Multi Bridge Pipeline [Fase 1]: Límite de enlaces funcionales alcanzado (%d). Finalizando verificación." % max_func_limit, xbmc.LOGINFO)
                break

            batch = q_verify[idx_q:idx_q + batch_size]
            idx_q += batch_size

            verified_batch = []
            try:
                with silenced_dialogs():
                    verified_batch = _verify_links_headless(batch, engine=engine, p_dialog=None) or []
            except Exception as _ve:
                xbmc.log("Multi Bridge Pipeline [Fase 1]: Error verificando lote: %s" % str(_ve), xbmc.LOGDEBUG)
                verified_batch = []

            for c_done in batch:
                if c_done in rem_unv:
                    rem_unv.remove(c_done)

            added_names = []
            limit_hit = False
            for verified_cand in verified_batch:
                v_url = _safe_str(getattr(verified_cand, 'url', '') or '')
                if v_url and v_url in existing_urls:
                    continue
                is_tor_v = _is_torrent_link(verified_cand)
                is_cap_v = _is_web_captcha_server(_get_link_server_name(verified_cand), verified_cand)
                if is_cap_v and hide_captcha:
                    continue
                if not is_tor_v and not is_cap_v:
                    if max_func_limit > 0 and _count_direct_verified(curr_verified) >= max_func_limit:
                        limit_hit = True
                        continue
                    try: setattr(verified_cand, '_bridge_verified', True)
                    except Exception: pass
                try:
                    verified_cand.bridge_engine = engine
                except Exception:
                    pass
                curr_verified.append(verified_cand)
                if v_url:
                    existing_urls.add(v_url)
                if not is_tor_v and not is_cap_v:
                    added_names.append(_get_link_server_name(verified_cand))

            if added_names:
                _persist_phase1_state(rem_unv)
                xbmc.log("Multi Bridge Pipeline [Fase 1]: %d enlace(s) directo(s) verificado(s) añadidos (%s). Directos: %d%s | Total en lista: %d" % (
                    len(added_names), ', '.join(added_names), _count_direct_verified(curr_verified),
                    ('/%d' % max_func_limit) if max_func_limit > 0 else '', len(curr_verified)
                ), xbmc.LOGINFO)

            if limit_hit or (max_func_limit > 0 and _count_direct_verified(curr_verified) >= max_func_limit):
                xbmc.log("Multi Bridge Pipeline [Fase 1]: Límite de enlaces funcionales alcanzado (%d). Finalizando verificación." % max_func_limit, xbmc.LOGINFO)
                break

            # Micro-pausa pasiva para mantener la CPU y ancho de banda suaves
            if mon.waitForAbort(0.15) or _BG_TASK_ABORT_EVENT.is_set() or not p.isPlayingVideo():
                if mon.abortRequested() or _SHUTDOWN_REQUESTED:
                    abort_all_network_sockets()
                return False
        return True

    existing_urls = {_safe_str(getattr(v, 'url', '')) for v in curr_verified if getattr(v, 'url', None)}
    if not _run_verification_pass(unverified_list):
        return

    # Si el recolector en segundo plano de Fast Autoplay aún estaba buscando otros canales,
    # esperar a que termine y verificar también los enlaces directos restantes que haya encontrado.
    if _BG_COLLECTOR_RUNNING and (max_func_limit <= 0 or _count_direct_verified(curr_verified) < max_func_limit):
        if not _wait_bg_collector():
            return
        _reload_cache_state()
        for _cv in curr_verified:
            _cu = _safe_str(getattr(_cv, 'url', '') or '')
            if _cu:
                existing_urls.add(_cu)
        extra_unv = _filter_and_sort_links(unverified_list) if unverified_list else []
        if extra_unv:
            if not _run_verification_pass(extra_unv):
                return

    # Fin de Fase 1: guardar estado definitivo limpio
    _persist_phase1_state([])
    xbmc.log("Multi Bridge Pipeline [Fase 1]: Completada con éxito. %d enlaces totales verificados y listos." % len(curr_verified), xbmc.LOGINFO)


def _run_phase2_next_episode_preloader(meta, my_token, p, mon):
    """FASE 2: Busca en segundo plano enlaces del siguiente capítulo con bajo consumo en CPU y RAM.
    Verifica los enlaces y guarda en memoria los 3 primeros respetando las preferencias del usuario."""
    # Esperar suavemente al menos 8 segundos de reproducción para dar estabilidad
    start_real_time = time.time()
    while (time.time() - start_real_time) < 8.0:
        if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo():
            return
        if mon.waitForAbort(0.5):
            return

    next_ep = _get_next_episode_info(meta)
    if not next_ep:
        xbmc.log("Multi Bridge Pipeline [Fase 2]: No hay siguiente episodio disponible para precargar", xbmc.LOGINFO)
        return

    tmdb_id = str(meta.get('tmdb') or meta.get('tmdb_id') or '')
    next_s = int(next_ep.get('season'))
    next_e = int(next_ep.get('episode'))
    cache_key = '%s_S%02dE%02d' % (tmdb_id, next_s, next_e)

    if cache_key in _PRELOADED_NEXT_EPISODE_CACHE and _PRELOADED_NEXT_EPISODE_CACHE[cache_key].get('links'):
        xbmc.log("Multi Bridge Pipeline [Fase 2]: Episodio %s ya precargado en memoria" % cache_key, xbmc.LOGINFO)
        return

    xbmc.log("Multi Bridge Pipeline [Fase 2]: Iniciando búsqueda en segundo plano de %s..." % cache_key, xbmc.LOGINFO)

    next_meta = dict(meta)
    next_meta['season'] = next_s
    next_meta['episode'] = next_e
    next_meta['title'] = next_ep.get('title') or (next_meta.get('showname', '') + (' S%02dE%02d' % (next_s, next_e)))
    try:
        _next_st = _get_episode_still(tmdb_id, next_s, next_e)
        if _next_st:
            next_meta['thumbnail'] = _next_st
    except Exception:
        pass

    # Resolver metadatos específicos del nuevo episodio
    try:
        _res_meta = _resolve_localized_metadata(
            tmdb_id=tmdb_id,
            is_series=True,
            season=next_s,
            episode=next_e,
            title_param=meta.get('showname') or meta.get('title')
        )
        if _res_meta.get('plot'): next_meta['plot'] = _res_meta['plot']
        if _res_meta.get('title') and _res_meta.get('has_spanish'):
            next_meta['title'] = _res_meta['title']
    except Exception:
        pass

    target_title = (next_meta.get('showname') or next_meta.get('title') or '').strip()
    target_year = next_meta.get('showyear') or next_meta.get('year') or ''
    all_names = [t for t in [target_title, next_meta.get('showname'), next_meta.get('title')] if t]
    for _n in list(all_names):
        if '(' in _n and ')' in _n:
            for inside in re.findall(r'\((.*?)\)', _n):
                inside_clean = inside.strip()
                if inside_clean and not re.match(r'^\d{4}$', inside_clean) and inside_clean not in all_names:
                    all_names.append(inside_clean)
            outside = re.sub(r'\(.*?\)', '', _n).strip()
            if outside and outside not in all_names:
                all_names.append(outside)
    alt_terms = [t for t in all_names if t != target_title]

    ch_data = load_channels_data()
    engine_channels = ch_data.get('channels', {}).get('balandro', {})
    enabled_players = []
    for ch_id in sorted(engine_channels.keys(), key=lambda k: engine_channels[k].get('name', k).lower()):
        ch_info = engine_channels[ch_id]
        if not ch_info.get('series'): continue
        if ch_info.get('series_disabled'): continue
        enabled_players.append(ch_info)

    if not enabled_players:
        xbmc.log("Multi Bridge Pipeline [Fase 2]: No hay canales de series activos en Balandro", xbmc.LOGINFO)
        return

    all_found_links = []
    matched_item = None
    results_lock = threading.Lock()

    # Pre-importar canales con pausa
    for ch_info in enabled_players:
        if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo():
            return
        try:
            _ch = str(ch_info.get('channel') or ch_info.get('id') or '').strip().lower()
            if _ch and _ch != 'search':
                with _engine_lock:
                    _switch_engine_environment('balandro')
                    __import__('channels.' + _ch, fromlist=[''])
        except Exception:
            pass
        time.sleep(0.05)

    def _preload_channel_worker(ch_info):
        nonlocal matched_item
        if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
            return
        try:
            with silenced_dialogs():
                it, links = _search_on_player(
                    ch_info, 'balandro', True, target_title, target_year,
                    next_s, next_e, all_names, alt_terms=alt_terms,
                    target_tmdb=tmdb_id, target_imdb=next_meta.get('imdb')
                )
            if links:
                for l in links:
                    try: l.bridge_engine = 'balandro'
                    except: pass
                with results_lock:
                    if not matched_item and it:
                        matched_item = it
                    all_found_links.extend(links)
        except Exception:
            pass

    # Ejecutar búsqueda con baja concurrencia (máximo 2 hilos) y pausas
    orig_sock_p2 = socket.getdefaulttimeout()
    socket.setdefaulttimeout(5.0)
    active_threads = []
    try:
        for ch_info in enabled_players:
            if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                return
            while len([t for t in active_threads if t.is_alive()]) >= 2:
                if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                    return
                time.sleep(0.15)
            t = threading.Thread(target=_preload_channel_worker, args=(ch_info,), daemon=True)
            t.start()
            active_threads.append(t)
            time.sleep(0.1)

        wait_end = time.time() + 25.0
        while any(t.is_alive() for t in active_threads) and time.time() < wait_end:
            if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                if mon.abortRequested() or _SHUTDOWN_REQUESTED:
                    abort_all_network_sockets()
                return
            time.sleep(0.1)
    finally:
        if mon.abortRequested() or _SHUTDOWN_REQUESTED:
            abort_all_network_sockets()
        for _th in active_threads:
            try:
                if _th.is_alive():
                    _th.join(0.05)
            except Exception: pass
        try:
            socket.setdefaulttimeout(orig_sock_p2 or 10.0)
        except Exception: pass

    if not all_found_links or _BG_TASK_ABORT_EVENT.is_set() or mon.abortRequested():
        xbmc.log("Multi Bridge Pipeline [Fase 2]: No se encontraron enlaces para %s" % cache_key, xbmc.LOGINFO)
        return

    # Filtrar y ordenar enlaces según las preferencias del usuario (Idioma, Calidad, Servidores)
    sorted_links = _filter_and_sort_links(all_found_links)
    if not sorted_links or _BG_TASK_ABORT_EVENT.is_set() or mon.abortRequested():
        return

    # Para reproducción instantánea, únicamente evaluar enlaces directos sin captcha ni torrents
    instant_candidates = [
        c for c in sorted_links
        if not _is_torrent_link(c) and not _is_web_captcha_server(_get_link_server_name(c), c)
    ]

    # Verificar en segundo plano hasta encontrar 3 enlaces funcionales
    verified_top3 = []
    for cand in instant_candidates:
        if mon.abortRequested() or _get_global_monitor_token() != my_token or _BG_TASK_ABORT_EVENT.is_set():
            break
        if not p.isPlayingVideo():
            break
        if len(verified_top3) >= 3:
            break
        try:
            with silenced_dialogs():
                v_res = _verify_links_headless([cand], engine='balandro', p_dialog=None)
            if v_res and not _is_torrent_link(v_res[0]) and not _is_web_captcha_server(_get_link_server_name(v_res[0]), v_res[0]):
                verified_top3.append(v_res[0])
                xbmc.log("Multi Bridge Pipeline [Fase 2]: Enlace instantáneo verificado [%d/3]: %s" % (
                    len(verified_top3), _get_link_server_name(v_res[0])), xbmc.LOGINFO)
                _PRELOADED_NEXT_EPISODE_CACHE[cache_key] = {
                    'links': list(verified_top3),
                    'all_links': sorted_links,
                    'matched_item': matched_item,
                    'meta': next_meta,
                    'engine': 'balandro',
                    'next_ep': next_ep,
                    'time': time.time()
                }
                try:
                    xbmcgui.Window(10000).setProperty('BridgeMulti.PreloadedNextEpKey', str(cache_key))
                except Exception:
                    pass
        except Exception as _ve:
            xbmc.log("Multi Bridge Pipeline [Fase 2]: Error verificando enlace: %s" % str(_ve), xbmc.LOGDEBUG)
        time.sleep(0.1)

    if verified_top3:
        xbmc.log("Multi Bridge Pipeline [Fase 2]: ¡Listo! %d enlace(s) funcional(es) guardado(s) en memoria para reproducción instantánea de %s" % (
            len(verified_top3), cache_key), xbmc.LOGINFO)
    else:
        _PRELOADED_NEXT_EPISODE_CACHE.pop(cache_key, None)
        try:
            if xbmcgui.Window(10000).getProperty('BridgeMulti.PreloadedNextEpKey') == str(cache_key):
                xbmcgui.Window(10000).setProperty('BridgeMulti.PreloadedNextEpKey', '')
        except Exception:
            pass
        xbmc.log("Multi Bridge Pipeline [Fase 2]: Ningún enlace funcional encontrado para %s." % cache_key, xbmc.LOGINFO)


def _notify_preferred_captcha_if_needed(meta, my_token, p, mon):
    """En Fast Autoplay, tras revisar todos los enlaces directos, avisa durante la reproducción
    si no hubo ningún enlace directo de mayor prioridad idiomática pero sí existe un enlace Captcha
    en un idioma preferido (ej. Latino o Castellano cuando los directos solo están en VOSE)."""
    try:
        if xbmcgui.Window(10000).getProperty('bridge.in_autoplay') != 'true':
            return
        if _bridge_addon.getSetting('hide_captcha_links') == 'true':
            return
        if xbmcgui.Window(10000).getProperty('BridgeMulti.CaptchaNotifiedToken') == str(my_token):
            return
        if mon.abortRequested() or _get_global_monitor_token() != my_token or _BG_TASK_ABORT_EVENT.is_set():
            return
        if not p.isPlayingVideo():
            return

        # Si el recolector en segundo plano todavía está buscando canales, esperar a que concluya
        t_bg = time.time()
        while _BG_COLLECTOR_RUNNING and (time.time() - t_bg) < 45.0:
            if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                return
            if mon.waitForAbort(0.25):
                return

        # Esperar al menos 3 segundos desde el inicio de reproducción antes de mostrar el aviso
        try:
            start_ts = float(xbmcgui.Window(10000).getProperty('BridgeMulti.PlaybackStartTs') or '0')
        except Exception:
            start_ts = 0.0
        if start_ts <= 0.0:
            start_ts = time.time()
        while (time.time() - start_ts) < 3.0:
            if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo() or _BG_TASK_ABORT_EVENT.is_set():
                return
            if mon.waitForAbort(0.2):
                return

        cur_tmdb = _norm_id_str(meta.get('tmdb') if meta else '')
        cur_season = _norm_id_str(meta.get('season') if meta else '')
        cur_ep = _norm_id_str(meta.get('episode') if meta else '')

        links = []
        ram = _get_ram_search_cache(target_tmdb=cur_tmdb, target_season=cur_season, target_episode=cur_ep)
        if ram and ram.get('links'):
            links = list(ram.get('links') or [])
        else:
            dc = _read_search_cache_atomic()
            if dc and isinstance(dc, dict) and dc.get('links'):
                d_meta = dc.get('meta') or {}
                d_tmdb = _norm_id_str(d_meta.get('tmdb'))
                d_season = _norm_id_str(d_meta.get('season'))
                d_ep = _norm_id_str(d_meta.get('episode'))
                if (not cur_tmdb or not d_tmdb or cur_tmdb == d_tmdb) and \
                   (not cur_season or not d_season or cur_season == d_season) and \
                   (not cur_ep or not d_ep or cur_ep == d_ep):
                    eng = dc.get('engine', 'balandro') or 'balandro'
                    links = [_deserialize_item(x, eng) if isinstance(x, dict) else x for x in (dc.get('links') or [])]
                    links = [x for x in links if x and getattr(x, 'url', None)]

        if not links:
            return

        b_prefs = _get_filter_prefs()
        links = _filter_discarded_links(links, disc_list=b_prefs.get('servers_discarded', []))
        if not links:
            return

        p_lat = int(b_prefs.get('preferencia_idioma_lat', 1) or 0)
        p_esp = int(b_prefs.get('preferencia_idioma_esp', 2) or 0)
        p_vos = int(b_prefs.get('preferencia_idioma_vos', 3) or 0)

        def _lang_rank_label(it):
            l_str = (_safe_str(getattr(it, 'language', '')) + ' ' + _get_link_language_group(it)).upper()
            if 'LAT' in l_str:
                return p_lat, 'Latino'
            if 'ESP' in l_str or 'CAST' in l_str:
                return p_esp, 'Castellano'
            if 'VOS' in l_str or 'VO' in l_str or 'SUB' in l_str or 'ENG' in l_str:
                return p_vos, 'VOSE'
            return 0, ''

        best_direct_rank = 99
        captcha_cands = []
        sort_q = b_prefs.get('servers_sort_quality', 0)

        for l in links:
            if _is_torrent_link(l):
                continue
            rk, lbl = _lang_rank_label(l)
            if _is_web_captcha_server(_get_link_server_name(l), l):
                if rk > 0 and lbl:
                    captcha_cands.append((rk, lbl, _get_hierarchical_sort_key(l, b_prefs=b_prefs, sort_q=sort_q), l))
            else:
                if rk > 0 and rk < best_direct_rank:
                    best_direct_rank = rk

        if not captcha_cands:
            return

        captcha_cands.sort(key=lambda x: (x[0], x[2]))
        best_cap_rk, best_cap_lbl, _, best_cap_item = captcha_cands[0]

        if best_cap_rk >= best_direct_rank:
            return

        if mon.abortRequested() or _get_global_monitor_token() != my_token or _BG_TASK_ABORT_EVENT.is_set():
            return
        if not p.isPlayingVideo() or xbmcgui.Window(10000).getProperty('bridge.in_autoplay') != 'true':
            return

        cap_srv = (_get_link_server_name(best_cap_item) or 'Captcha').strip()
        try:
            xbmcgui.Window(10000).setProperty('BridgeMulti.CaptchaNotifiedToken', str(my_token))
        except Exception:
            pass
        xbmc.log("Multi Bridge Fast Autoplay: avisando Captcha en %s (%s) [cap_rank=%d < direct_rank=%d]" % (
            best_cap_lbl, cap_srv, best_cap_rk, best_direct_rank), xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            'Multi Bridge',
            'Enlace Captcha en %s disponible (%s)' % (best_cap_lbl, cap_srv),
            xbmcgui.NOTIFICATION_INFO,
            4500
        )
    except Exception as _cn_e:
        xbmc.log("Multi Bridge: error comprobando aviso captcha preferido: %s" % _cn_e, xbmc.LOGDEBUG)


def _start_playback_background_pipeline(meta, my_token):
    """Pipeline orquestador de dos fases en segundo plano:
    FASE 1: Verifica suavemente los enlaces pendientes del capítulo actual y actualiza el OSD y menú de pausa.
    FASE 2: Una vez terminada la Fase 1, precarga los enlaces del siguiente capítulo para reproducción instantánea."""
    p = xbmc.Player()
    mon = xbmc.Monitor()

    xbmc.log("Multi Bridge Pipeline: Iniciando orquestador de dos fases en segundo plano...", xbmc.LOGINFO)

    # Ejecutar FASE 1
    try:
        _run_phase1_current_episode_verification(meta, my_token, p, mon)
    except Exception as e:
        xbmc.log("Multi Bridge Pipeline: Error en Fase 1: %s" % str(e), xbmc.LOGWARNING)

    # Validar que la reproducción continúa activa antes de notificar captcha o pasar a Fase 2
    if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo():
        xbmc.log("Multi Bridge Pipeline: Descartado antes de Fase 2 (reproducción terminada o nueva sesión)", xbmc.LOGINFO)
        return

    _notify_preferred_captcha_if_needed(meta, my_token, p, mon)

    if mon.abortRequested() or _get_global_monitor_token() != my_token or not p.isPlayingVideo():
        return

    if _bridge_addon.getSetting('preload_next_episode') == 'false':
        xbmc.log("Multi Bridge Pipeline: Precarga de siguiente capítulo desactivada en ajustes.", xbmc.LOGINFO)
        return

    if not meta or not meta.get('season') or not meta.get('episode'):
        return

    # Ejecutar FASE 2
    try:
        _run_phase2_next_episode_preloader(meta, my_token, p, mon)
    except Exception as e:
        xbmc.log("Multi Bridge Pipeline: Error en Fase 2: %s" % str(e), xbmc.LOGWARNING)


def _start_next_episode_preloader(meta, my_token):
    """Wrapper de compatibilidad: redirige al pipeline unificado de dos fases."""
    _start_playback_background_pipeline(meta, my_token)

def _play_preloaded_episode(preloaded):
    """Reproduce instantáneamente el siguiente episodio usando los enlaces precargados.
    Intenta reproducir los 3 enlaces uno por uno si alguno falla, supervisando la reproducción
    y aplicando todos los metadatos necesarios para Trakt, TMDb Helper y el reproductor."""
    links = [
        l for l in preloaded.get('links', [])
        if not _is_torrent_link(l) and not _is_web_captcha_server(_get_link_server_name(l), l)
    ]
    meta = preloaded.get('meta', {})
    matched_item = preloaded.get('matched_item')
    engine = preloaded.get('engine', 'balandro')
    all_links = preloaded.get('all_links') or links
    next_ep = preloaded.get('next_ep') or {}

    if not links:
        return False

    player = xbmc.Player()
    try:
        if player.isPlayingVideo():
            player.stop()
    except Exception:
        pass
    xbmc.sleep(250)

    ep_label = 'S%02dE%02d' % (int(next_ep.get('season') or meta.get('season') or 1),
                               int(next_ep.get('episode') or meta.get('episode') or 1))
    if next_ep.get('title'):
        ep_label += ' - ' + str(next_ep.get('title'))

    try:
        badge_path = os.path.join(_bridge_addon.getAddonInfo('path'), 'resources', 'media', 'icon_rayo_badge.png')
    except Exception:
        badge_path = xbmcgui.NOTIFICATION_INFO

    try:
        xbmcgui.Dialog().notification('Multi Bridge', 'Reproducción instantánea: %s' % ep_label, badge_path, 2500)
    except Exception:
        _show_bridge_notification('Multi Bridge', 'Reproducción instantánea: %s' % ep_label, 2500, icon=badge_path)

    # Almacenar en caché únicamente los enlaces verificados (los 3 precargados + torrents)
    # y guardar los restantes en 'unverified_links' (Opción 3)
    try:
        initial_verified = list(links)
        for l in (all_links or []):
            if _is_torrent_link(l) and not any(getattr(l, 'url', None) and getattr(l, 'url', None) == getattr(iv, 'url', None) for iv in initial_verified):
                initial_verified.append(l)

        unverified_pending = [
            l for l in (all_links or [])
            if not any(getattr(l, 'url', None) and getattr(l, 'url', None) == getattr(iv, 'url', None) for iv in initial_verified)
            and not _is_torrent_link(l)
        ]

        _store_ram_search_cache(initial_verified, matched_item, meta, engine, unverified_links=unverified_pending)
        _save_search_cache_atomic({
            'item': _serialize_item(matched_item),
            'links': [_serialize_item(l) for l in initial_verified],
            'unverified_links': [_serialize_item(l) for l in unverified_pending],
            'meta': meta,
            'engine': engine,
            'is_preloaded_session': bool(unverified_pending)
        })
    except Exception:
        pass

    for idx, lnk in enumerate(links):
        srv = _get_link_server_name(lnk)
        xbmc.log("Multi Bridge Instant Play: Probando enlace [%d/%d] (%s)..." % (idx+1, len(links), srv), xbmc.LOGINFO)

        ok, li = _resolve_link_to_listitem(lnk, engine, matched_item)
        if not ok or not li:
            xbmc.log("Multi Bridge Instant Play: Enlace %d (%s) no resolvió URL" % (idx+1, srv), xbmc.LOGWARNING)
            continue

        media_url = ''
        try:
            media_url = li.getPath()
        except Exception:
            pass

        if not media_url:
            xbmc.log("Multi Bridge Instant Play: Enlace %d (%s) URL vacía" % (idx+1, srv), xbmc.LOGWARNING)
            continue

        try:
            media_url = _ensure_playback_headers_on_item(li, server_name=srv, page_url=getattr(lnk, 'url', '') or '') or li.getPath() or media_url
            sync_tmdbhelper_playerstring(meta)
            set_listitem_info(li, meta=meta)
            player.play(media_url, li)
        except Exception as pe:
            xbmc.log("Multi Bridge Instant Play: error en player.play: %s" % str(pe), xbmc.LOGWARNING)
            continue

        started = _wait_for_playback_progress(player=player, mon=xbmc.Monitor(), timeout=12.0, seek_to_time=0.0, server_name=srv)

        if started:
            xbmc.log("Multi Bridge Instant Play: ¡Reproducción exitosa en enlace %d (%s)!" % (idx+1, srv), xbmc.LOGINFO)
            sync_tmdbhelper_playerstring(meta)
            media_key = _get_media_key(meta, lnk)
            start_playback_monitor(media_key, title_str=meta.get('title', ''), current_link_index=idx, meta=meta)
            wait_for_playback_monitor()
            return True
        else:
            xbmc.log("Multi Bridge Instant Play: Enlace %d (%s) no arrancó dentro de 10s. Deteniendo..." % (idx+1, srv), xbmc.LOGWARNING)
            _stop_player_cleanly(player)

    xbmc.log("Multi Bridge Instant Play: Los enlaces precargados no pudieron iniciar reproducción", xbmc.LOGWARNING)
    return False

def _get_next_episode_info(meta):
    """Determina si existe un capítulo siguiente para la serie actual guiándose
    estrictamente por los episodios que TMDb Helper muestra (solo estrenados).
    Consulta la base de datos local SQLite de TMDb Helper filtrando por premiered <= hoy,
    o mediante la API de TMDb validando air_date <= hoy.
    Retorna dict con {'season': int, 'episode': int, 'title': str} o None si no hay siguiente.
    """
    if not meta or not isinstance(meta, dict):
        return None
    s_raw = meta.get('season')
    e_raw = meta.get('episode')
    if s_raw is None or e_raw is None:
        return None
    try:
        s = int(s_raw)
        e = int(e_raw)
    except (ValueError, TypeError):
        return None
    if s < 0 or e <= 0:
        return None

    tmdb_raw = meta.get('tmdb') or meta.get('tmdb_id')
    if not tmdb_raw:
        return None
    try:
        tmdb = int(tmdb_raw)
    except (ValueError, TypeError):
        return None

    cache_key = (tmdb, s, e)
    if cache_key in _NEXT_EPISODE_CACHE:
        return _NEXT_EPISODE_CACHE[cache_key]

    today = datetime.date.today().strftime('%Y-%m-%d')

    # 1. Comprobar en base de datos local SQLite de TMDb Helper
    try:
        import glob
        import sqlite3
        try:
            tmdb_dir = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.themoviedb.helper')
        except Exception:
            tmdb_dir = os.path.expandvars(r'%APPDATA%\Kodi\userdata\addon_data\plugin.video.themoviedb.helper')

        db_files = glob.glob(os.path.join(tmdb_dir, 'database_*', 'ItemDetails.db'))
        if db_files:
            conn = sqlite3.connect(db_files[0])
            cur = conn.cursor()

            # Mismo season, episodio + 1 estrenado (premiered <= hoy)
            cur.execute("""
                SELECT e.episode, s.season, e.title, e.premiered 
                FROM episode e 
                JOIN season s ON e.season_id = s.id 
                WHERE (e.tvshow_id = ? OR e.tvshow_id = ?) 
                  AND s.season = ? 
                  AND e.episode = ?
                  AND e.premiered IS NOT NULL 
                  AND e.premiered != '' 
                  AND e.premiered <= ?
            """, (f'tv.{tmdb}', str(tmdb), s, e + 1, today))
            row = cur.fetchone()
            if row:
                conn.close()
                res = {'season': int(row[1]), 'episode': int(row[0]), 'title': str(row[2] or '')}
                _NEXT_EPISODE_CACHE[cache_key] = res
                return res

            # Si el episodio e+1 existe en la BD pero no se ha estrenado aún (fecha futura):
            cur.execute("""
                SELECT e.episode, e.premiered 
                FROM episode e 
                JOIN season s ON e.season_id = s.id 
                WHERE (e.tvshow_id = ? OR e.tvshow_id = ?) 
                  AND s.season = ? 
                  AND e.episode = ?
            """, (f'tv.{tmdb}', str(tmdb), s, e + 1))
            future_ep = cur.fetchone()
            if future_ep:
                conn.close()
                _NEXT_EPISODE_CACHE[cache_key] = None
                return None

            # Siguiente temporada, episodio 1 estrenado (premiered <= hoy)
            cur.execute("""
                SELECT e.episode, s.season, e.title, e.premiered 
                FROM episode e 
                JOIN season s ON e.season_id = s.id 
                WHERE (e.tvshow_id = ? OR e.tvshow_id = ?) 
                  AND s.season = ? 
                  AND e.episode = 1
                  AND e.premiered IS NOT NULL 
                  AND e.premiered != '' 
                  AND e.premiered <= ?
            """, (f'tv.{tmdb}', str(tmdb), s + 1, today))
            row = cur.fetchone()
            if row:
                conn.close()
                res = {'season': int(row[1]), 'episode': int(row[0]), 'title': str(row[2] or '')}
                _NEXT_EPISODE_CACHE[cache_key] = res
                return res

            # Si existe temporada s+1 pero aún no estrenada:
            cur.execute("""
                SELECT e.episode, e.premiered 
                FROM episode e 
                JOIN season s ON e.season_id = s.id 
                WHERE (e.tvshow_id = ? OR e.tvshow_id = ?) 
                  AND s.season = ? 
                  AND e.episode = 1
            """, (f'tv.{tmdb}', str(tmdb), s + 1))
            future_s = cur.fetchone()
            if future_s:
                conn.close()
                _NEXT_EPISODE_CACHE[cache_key] = None
                return None

            conn.close()
    except Exception as _dbe:
        xbmc.log('Multi Bridge: error consultando ItemDetails.db: %s' % str(_dbe), xbmc.LOGDEBUG)

    # 2. Fallback mediante TMDb API (solo episodios con air_date <= hoy)
    try:
        import requests
        api_key = 'a07324c669cac4d96789197134ce272b'
        url = f"https://api.themoviedb.org/3/tv/{tmdb}/season/{s}?api_key={api_key}&language=es-ES"
        r = requests.get(url, timeout=3.0)
        if r.status_code == 200:
            data = r.json()
            for ep in data.get('episodes', []):
                if ep.get('episode_number') == e + 1:
                    air_date = ep.get('air_date')
                    if air_date and air_date <= today:
                        res = {'season': s, 'episode': e + 1, 'title': ep.get('name', '')}
                        _NEXT_EPISODE_CACHE[cache_key] = res
                        return res
                    else:
                        _NEXT_EPISODE_CACHE[cache_key] = None
                        return None

            # Si es final de temporada, verificar temporada siguiente
            show_url = f"https://api.themoviedb.org/3/tv/{tmdb}?api_key={api_key}&language=es-ES"
            r_show = requests.get(show_url, timeout=3.0)
            if r_show.status_code == 200:
                show_data = r_show.json()
                for szn in show_data.get('seasons', []):
                    if szn.get('season_number') == s + 1 and szn.get('episode_count', 0) > 0:
                        r_s_next = requests.get(f"https://api.themoviedb.org/3/tv/{tmdb}/season/{s + 1}?api_key={api_key}&language=es-ES", timeout=3.0)
                        if r_s_next.status_code == 200:
                            s_eps = r_s_next.json().get('episodes', [])
                            if s_eps:
                                air_date = s_eps[0].get('air_date')
                                if air_date and air_date <= today:
                                    res = {'season': s + 1, 'episode': 1, 'title': s_eps[0].get('name', '')}
                                    _NEXT_EPISODE_CACHE[cache_key] = res
                                    return res
                                else:
                                    _NEXT_EPISODE_CACHE[cache_key] = None
                                    return None
    except Exception as _apie:
        xbmc.log('Multi Bridge: error consultando TMDb API para siguiente episodio: %s' % str(_apie), xbmc.LOGDEBUG)

    _NEXT_EPISODE_CACHE[cache_key] = None
    return None


def _play_next_episode(meta, next_ep):
    """Inicia la reproducción del siguiente capítulo idéntico a invocarlo desde TMDb Helper,
    o reproducción instantánea si ya está precargado en memoria."""
    try:
        tmdb_id = meta.get('tmdb') or meta.get('tmdb_id') or ''
        next_s = next_ep.get('season')
        next_e = next_ep.get('episode')
        ep_title = next_ep.get('title') or ''

        # Comprobar si hay enlaces precargados en memoria para este episodio
        if tmdb_id and next_s is not None and next_e is not None:
            cache_key = '%s_S%02dE%02d' % (str(tmdb_id), int(next_s), int(next_e))
            preloaded = _PRELOADED_NEXT_EPISODE_CACHE.get(cache_key)
            if preloaded and preloaded.get('links'):
                valid_instant = [
                    l for l in preloaded.get('links', [])
                    if not _is_torrent_link(l) and not _is_web_captcha_server(_get_link_server_name(l), l)
                ]
                if valid_instant:
                    xbmc.log("Multi Bridge: Iniciando reproducción instantánea de siguiente episodio desde precarga (%s)" % cache_key, xbmc.LOGINFO)
                    preloaded_to_play = dict(preloaded)
                    preloaded_to_play['links'] = valid_instant
                    success = _play_preloaded_episode(preloaded_to_play)
                    if success:
                        return

        msg = 'S%02dE%02d' % (next_s, next_e)
        if ep_title:
            msg += ' - %s' % ep_title
        xbmcgui.Dialog().notification('Multi Bridge', 'Siguiente capítulo: %s' % msg, xbmcgui.NOTIFICATION_INFO, 2500)

        xbmc.sleep(200)

        if _is_addon_installed('plugin.video.themoviedb.helper') and tmdb_id:
            url = 'plugin://plugin.video.themoviedb.helper/?info=play&tmdb_type=episode&tmdb_id=%s&season=%s&episode=%s' % (
                str(tmdb_id), str(next_s), str(next_e)
            )
            xbmc.log('Multi Bridge: reproduciendo siguiente episodio vía TMDb Helper: %s' % url, xbmc.LOGINFO)
            xbmc.executebuiltin('PlayMedia("%s")' % url)
        else:
            showname = meta.get('showname') or meta.get('title') or ''
            url = 'plugin://plugin.video.bridge.multi/?action=play&tmdb=%s&season=%s&episode=%s&showname=%s&title=%s' % (
                str(tmdb_id), str(next_s), str(next_e),
                uparse.quote_plus(showname), uparse.quote_plus(showname)
            )
            xbmc.log('Multi Bridge: reproduciendo siguiente episodio vía Multi Bridge directo: %s' % url, xbmc.LOGINFO)
            xbmc.executebuiltin('RunPlugin("%s")' % url)
    except Exception as e:
        xbmc.log('Multi Bridge: error en _play_next_episode: %s' % str(e), xbmc.LOGERROR)


# ---------------------------------------------------------
# Custom Pause Prompt Dialog & Floating Links Dialog
# ---------------------------------------------------------

class _PausePromptDialog(xbmcgui.WindowXMLDialog):
    ACTION_MOVE_LEFT   = 1
    ACTION_MOVE_RIGHT  = 2
    ACTION_SELECT_ITEM = 7
    ACTION_PREVIOUS_MENU = 10
    ACTION_PAUSE       = 12
    ACTION_STOP        = 13
    ACTION_PLAY        = 68
    ACTION_PLAYER_PLAY = 79
    ACTION_NAV_BACK    = 92
    ACTION_MOUSE_LEFT_CLICK = 100
    ACTION_MOUSE_DOUBLE_CLICK = 103
    ACTION_MOUSE_MOVE       = 107
    ACTION_BACKSPACE   = 110

    def __new__(cls, *args, **kwargs):
        addon_path = _bridge_addon.getAddonInfo('path')
        return super(_PausePromptDialog, cls).__new__(cls, 'pause_prompt.xml', addon_path, 'Default', '1080i')

    def __init__(self, current_server_name="", current_quality="", meta=None, is_test=False, *args, **kwargs):
        self._is_closed = False
        self.selected = -1  # 0=No (continuar), 1=Abrir enlaces, 2=Siguiente capitulo, -1=Cerrar/Atras
        self.current = 0    # 0=No (continuar) por defecto a la izquierda
        self.server_name = current_server_name or "Actual"
        self.current_quality = current_quality or ""
        self.meta = meta or {}
        self.is_test = is_test
        self.next_ep = _get_next_episode_info(self.meta)
        self._btn_ids = []
        self._hl_ids = []
        self._control_map = {}
        self._btn_rects = []
        self._backdrop_id = 99
        self._pos_setting = str(_bridge_addon.getSetting('pause_prompt_position') or '1').strip()
        try:
            xbmcgui.Window(10000).setProperty('bridge.pp_pos', '0' if self._pos_setting == '0' else '1')
        except Exception:
            pass
        self._start_playback_watchdog()

    def _start_playback_watchdog(self):
        if getattr(self, "is_test", False): return
        def _watch():
            p = xbmc.Player()
            mon = xbmc.Monitor()
            while not getattr(self, '_is_closed', False) and not mon.abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
                if not p.isPlayingVideo():
                    if mon.waitForAbort(0.15) or _BG_TASK_ABORT_EVENT.is_set():
                        break
                    if not p.isPlayingVideo() and not getattr(self, '_is_closed', False):
                        self.selected = -1
                        try:
                            self.close()
                        except Exception:
                            pass
                        break
                if mon.waitForAbort(0.2) or _BG_TASK_ABORT_EVENT.is_set():
                    break
        t = threading.Thread(target=_watch, daemon=True)
        t.name = "PausePromptWatchdog"
        t.start()

    def onInit(self):
        try:
            self._build()
        except Exception as e:
            xbmc.log('BridgeMulti PausePromptDialog onInit error: ' + str(e), xbmc.LOGWARNING)

    def _build(self):
        try:
            W = int(self.getWidth() or 0)
            H = int(self.getHeight() or 0)
        except Exception:
            W, H = 0, 0
        if W <= 0:
            W = 1920
        if H <= 0:
            H = 1080

        # Ajustar el backdrop invisible exactamente al lienzo real de la ventana/pantalla
        try:
            bg_btn = self.getControl(self._backdrop_id)
            bg_btn.setPosition(0, 0)
            bg_btn.setWidth(W)
            bg_btn.setHeight(H)
        except Exception:
            pass

        # Deteccion equilibrada de Modo Compacto vs Tactil / Tablet / Móvil
        touch_setting = str(_bridge_addon.getSetting('pause_prompt_touch_mode') or '0').strip()
        is_touch = False
        if touch_setting == '1':    # Forzar tactil
            is_touch = True
        elif touch_setting == '2':  # Forzar compacto
            is_touch = False
        else:                       # 0 = Automatico
            try:
                is_pc = bool(
                    xbmc.getCondVisibility('System.Platform.Windows') or
                    xbmc.getCondVisibility('System.Platform.OSX') or
                    xbmc.getCondVisibility('System.Platform.Linux')
                )
                is_android = bool(xbmc.getCondVisibility('System.Platform.Android'))
                if is_android:
                    is_touch = True
                elif is_pc:
                    is_touch = False
                else:
                    is_touch = bool(xbmc.getCondVisibility('System.IsPhone'))
            except Exception:
                is_touch = False

        has_next = bool(getattr(self, 'next_ep', None))
        has_instant = False
        if has_next:
            tmdb_id = str(self.meta.get('tmdb') or '')
            next_s = self.next_ep.get('season')
            next_e = self.next_ep.get('episode')
            if tmdb_id and next_s is not None and next_e is not None:
                cache_key = '%s_S%02dE%02d' % (tmdb_id, int(next_s), int(next_e))
                if cache_key in _PRELOADED_NEXT_EPISODE_CACHE:
                    entry = _PRELOADED_NEXT_EPISODE_CACHE[cache_key]
                    valid_instant = [
                        l for l in (entry.get('links') or [])
                        if not _is_torrent_link(l) and not _is_web_captcha_server(_get_link_server_name(l), l)
                    ]
                    if valid_instant:
                        has_instant = True

        # Diseño proporcional adaptable a cualquier resolución, ventana o relación de aspecto
        # (4:3, 16:9, 16:10, 21:9 ultrawide, 720p, 1080p, 4K, ventanas pequeñas y vertical móvil)
        scale_h = H / 1080.0
        scale_w = W / 1920.0
        scale_ui = min(scale_h, max(scale_w, scale_h * 0.72)) if W < H else scale_h
        try:
            phys_w = int(xbmc.getInfoLabel('System.ScreenWidth') or 1920)
            phys_h = int(xbmc.getInfoLabel('System.ScreenHeight') or 1080)
        except Exception:
            phys_w, phys_h = 1920, 1080
        small_screen = (phys_h > 0 and phys_h <= 850) or (phys_w > 0 and phys_w <= 1400)

        # Preparar texto del encabezado antes de dimensionar la tarjeta para evitar cortes ("...")
        srv = (self.server_name or "Actual").strip()
        if srv.lower() in ('torrent', 'magnet'):
            srv = 'Torrent'
        elif len(srv) > 18:
            srv = srv[:17] + '..'

        qual_active = getattr(self, 'current_quality', '') or ''
        if not qual_active and hasattr(self, 'current_link') and self.current_link:
            qual_active = _format_quality(self.current_link)
        has_qual = bool(qual_active and qual_active != 'N/A')

        if is_touch:
            dh_ratio = 0.152
            dw_base = 530 if has_next else 475
            bh_base = 62
            pad_hitbox = max(10, int(round(18 * scale_ui)))
            gap = max(10, int(round(14 * scale_ui)))
        else:
            dh_ratio = 0.138 if small_screen else 0.132
            dw_base = (505 if small_screen else 490) if has_next else (455 if small_screen else 440)
            bh_base = 58 if small_screen else 54
            pad_hitbox = max(8, int(round(14 * scale_ui)))
            gap = max(10, int(round(12 * scale_ui)))

        max_dw = max(260, int(W * 0.94))
        max_dh = max(92, int(H * 0.30))
        dh = min(max_dh, max(92, int(round(H * dh_ratio))))
        dw = min(max_dw, max(280, int(round(dw_base * scale_ui))))
        bh = min(int(dh * 0.48), max(38, int(round(bh_base * scale_ui))))

        pad_x = max(14, int(round(dw * 0.036)))
        # Ancho mínimo requerido para que el encabezado completo con font12 nunca se recorte manteniendo tamaño mediano
        if has_qual:
            plain_hdr = '¿Cambiar enlace? | %s %s' % (srv, qual_active)
        else:
            plain_hdr = '¿Cambiar enlace? | %s' % srv
        char_px = 12.6 * scale_ui
        min_hdr_dw = int(round(len(plain_hdr) * char_px)) + pad_x * 2 + max(16, int(round(18 * scale_ui)))
        if min_hdr_dw > dw:
            dw = min(max_dw, min_hdr_dw)
        pad_x = max(14, int(round(dw * 0.036)))

        # En pantallas extremadamente estrechas (ej. móvil vertical), compactar prefijo si aún excediera el 94%
        max_label_chars = max(18, int((dw - pad_x * 2) / max(8.0, char_px)))
        prefix_txt = '¿Cambiar enlace?'
        if len(plain_hdr) > max_label_chars:
            prefix_txt = 'Cambiar enlace'
        if has_qual:
            plain_hdr_2 = '%s | %s %s' % (prefix_txt, srv, qual_active)
            if len(plain_hdr_2) > max_label_chars:
                avail_srv = max(6, max_label_chars - len(prefix_txt) - len(qual_active) - 5)
                if len(srv) > avail_srv:
                    srv = srv[:max(4, avail_srv - 2)] + '..'
            header_text = '[B][COLOR FFCFA82C]%s[/COLOR][/B] [COLOR FF666666]|[/COLOR] [COLOR FFDDDDDD]%s[/COLOR] [B][COLOR FFCFA82C]%s[/COLOR][/B]' % (prefix_txt, srv, qual_active)
        else:
            plain_hdr_2 = '%s | %s' % (prefix_txt, srv)
            if len(plain_hdr_2) > max_label_chars:
                avail_srv = max(6, max_label_chars - len(prefix_txt) - 4)
                if len(srv) > avail_srv:
                    srv = srv[:max(4, avail_srv - 2)] + '..'
            header_text = '[B][COLOR FFCFA82C]%s[/COLOR][/B] [COLOR FF666666]|[/COLOR] [COLOR FFDDDDDD]%s[/COLOR]' % (prefix_txt, srv)

        avail_w = max(200, dw - pad_x * 2)
        if has_next:
            btn_next_w = max(56, int(round(avail_w * 0.18)))
            btn_main_w = max(84, (avail_w - btn_next_w - gap * 2) // 2)
            btn_configs = [
                {'lbl': 'Continuar', 'w': btn_main_w, 'is_icon': False},
                {'lbl': 'Cambiar',   'w': btn_main_w, 'is_icon': False},
                {'lbl': '',          'w': btn_next_w, 'is_icon': True, 'instant': has_instant}
            ]
        else:
            btn_main_w = max(96, (avail_w - gap) // 2)
            btn_configs = [
                {'lbl': 'Continuar', 'w': btn_main_w, 'is_icon': False},
                {'lbl': 'Cambiar',   'w': btn_main_w, 'is_icon': False}
            ]

        iw = ih = max(18, int(round(bh * 0.54)))
        rw = max(18, int(round(bh * 0.52)))
        rh = max(22, int(round(bh * 0.58)))
        rx_offset = max(10, int(round(rw * 0.55)))
        ry_offset = max(6, int(round(rh * 0.30)))

        margin_x = max(12, int(round(W * 0.020)))
        dx = max(8, W - dw - margin_x)
        if self._pos_setting == '1':  # Inferior derecha
            margin_y = max(16, int(round(H * 0.045)))
            dy = max(8, H - dh - margin_y)
        else:  # Superior derecha (0)
            margin_y = max(14, int(round(H * 0.038)))
            dy = margin_y

        # Fondo y borde dorado con esquinas redondeadas (9-slice en pause_prompt.xml)
        for cid in (51, 52):
            try:
                c = self.getControl(cid)
                c.setPosition(dx, dy)
                c.setWidth(dw)
                c.setHeight(dh)
            except Exception:
                pass

        hdr_h = max(22, int(round(dh * 0.22)))
        hdr_y = dy + max(10, int(round(dh * 0.10)))
        try:
            hdr_lbl = self.getControl(53)
            hdr_lbl.setPosition(dx + pad_x, hdr_y)
            hdr_lbl.setWidth(dw - pad_x * 2)
            hdr_lbl.setHeight(hdr_h)
            hdr_lbl.setLabel(header_text)
        except Exception:
            pass

        total_w = sum(b['w'] for b in btn_configs) + gap * (len(btn_configs) - 1)
        bx = dx + (dw - total_w) // 2
        by = dy + dh - bh - max(16, int(round(dh * 0.14)))

        self._btn_ids = []
        self._hl_ids = []
        self._control_map = {}
        self._btn_rects = []

        cur_x = bx
        for i, cfg in enumerate(btn_configs):
            bw = cfg['w']
            btn_id = 100 + i
            dim_id = 200 + i
            hl_id = 300 + i

            self._btn_ids.append(btn_id)
            self._hl_ids.append(hl_id)
            self._control_map[btn_id] = i
            self._control_map[dim_id] = i
            self._control_map[hl_id] = i
            self._btn_rects.append((cur_x - pad_hitbox, by - pad_hitbox, cur_x + bw + pad_hitbox, by + bh + pad_hitbox, i))

            try:
                btn = self.getControl(btn_id)
                btn.setPosition(cur_x, by)
                btn.setWidth(bw)
                btn.setHeight(bh)
                btn.setLabel(cfg['lbl'])
                btn.setVisible(True)
            except Exception:
                pass

            m = 2
            for bid in (dim_id, hl_id):
                try:
                    b_img = self.getControl(bid)
                    b_img.setPosition(cur_x - m, by - m)
                    b_img.setWidth(bw + m * 2)
                    b_img.setHeight(bh + m * 2)
                    if bid == dim_id:
                        b_img.setVisible(True)
                except Exception:
                    pass

            if cfg['is_icon']:
                try:
                    icon_path = os.path.join(_bridge_addon.getAddonInfo('path'), 'resources', 'media', 'icon_next.png')
                except Exception:
                    icon_path = 'special://home/addons/plugin.video.bridge.multi/resources/media/icon_next.png'
                ix = cur_x + (bw - iw) // 2
                iy = by + (bh - ih) // 2
                try:
                    icon_ctrl = self.getControl(112)
                    icon_ctrl.setImage(icon_path)
                    icon_ctrl.setPosition(ix, iy)
                    icon_ctrl.setWidth(iw)
                    icon_ctrl.setHeight(ih)
                    icon_ctrl.setVisible(True)
                    self._control_map[112] = i
                except Exception:
                    pass

                if cfg.get('instant'):
                    try:
                        badge_path = os.path.join(_bridge_addon.getAddonInfo('path'), 'resources', 'media', 'icon_rayo_badge.png')
                    except Exception:
                        badge_path = 'special://home/addons/plugin.video.bridge.multi/resources/media/icon_rayo_badge.png'
                    rx = cur_x + bw - rx_offset
                    ry = by - ry_offset
                    try:
                        badge_ctrl = self.getControl(113)
                        badge_ctrl.setImage(badge_path)
                        badge_ctrl.setPosition(rx, ry)
                        badge_ctrl.setWidth(rw)
                        badge_ctrl.setHeight(rh)
                        badge_ctrl.setVisible(True)
                        self._control_map[113] = i
                    except Exception:
                        pass
                else:
                    try: self.getControl(113).setVisible(False)
                    except Exception: pass

            cur_x += bw + gap

        if not has_next:
            for hid in (102, 202, 302, 112, 113):
                try: self.getControl(hid).setVisible(False)
                except Exception: pass

        # Enlazar navegación direccional entre botones visibles
        try:
            n_btns = len(self._btn_ids)
            for idx_b, bid in enumerate(self._btn_ids):
                c_btn = self.getControl(bid)
                c_left = self.getControl(self._btn_ids[(idx_b - 1) % n_btns])
                c_right = self.getControl(self._btn_ids[(idx_b + 1) % n_btns])
                c_btn.controlLeft(c_left)
                c_btn.controlRight(c_right)
        except Exception:
            pass

        self._update_highlight()
        try:
            self.setFocusId(self._btn_ids[0])
        except Exception:
            pass

    def _update_highlight(self):
        for i, hl_id in enumerate(self._hl_ids):
            try:
                self.getControl(hl_id).setVisible(i == self.current)
            except Exception:
                pass
        if len(self._btn_ids) >= 3:
            try:
                self.getControl(112).setColorDiffuse('FFFFFFFF' if self.current == 2 else 'FFCCCCCC')
            except Exception:
                pass

    def onFocus(self, control_id):
        if control_id in self._btn_ids:
            idx = self._btn_ids.index(control_id)
            if idx != self.current:
                self.current = idx
                self._update_highlight()
        elif control_id in self._control_map:
            idx = self._control_map[control_id]
            if idx != self.current:
                self.current = idx
                self._update_highlight()

    def onAction(self, action):
        aid = action.getId()

        try:
            fid = self.getFocusId()
            if fid in self._btn_ids:
                idx = self._btn_ids.index(fid)
                if idx != self.current:
                    self.current = idx
                    self._update_highlight()
            elif fid in self._control_map:
                idx = self._control_map[fid]
                if idx != self.current:
                    self.current = idx
                    self._update_highlight()
        except Exception:
            pass

        if aid in (self.ACTION_PREVIOUS_MENU, self.ACTION_NAV_BACK, self.ACTION_BACKSPACE, self.ACTION_PAUSE, self.ACTION_PLAYER_PLAY, self.ACTION_PLAY, self.ACTION_STOP, 13):
            if aid in (self.ACTION_STOP, 13):
                try:
                    if xbmc.Player().isPlaying():
                        xbmc.Player().stop()
                except Exception:
                    pass
            self.selected = -1
            self.close()
        elif aid in (self.ACTION_MOVE_LEFT, self.ACTION_MOVE_RIGHT):
            # La navegación nativa <onleft>/<onright> y controlLeft/controlRight del XML
            # ya mueve el foco y dispara onFocus; solo aseguramos el foco si está fuera.
            try:
                fid = self.getFocusId()
                if fid in self._btn_ids:
                    idx = self._btn_ids.index(fid)
                    if idx != self.current:
                        self.current = idx
                        self._update_highlight()
                elif self._btn_ids:
                    self.setFocusId(self._btn_ids[self.current])
            except Exception:
                pass
        elif aid == self.ACTION_SELECT_ITEM:
            self.selected = self.current
            self.close()
        elif aid in (self.ACTION_MOUSE_LEFT_CLICK, self.ACTION_MOUSE_DOUBLE_CLICK, 100, 103, 501, 510):
            try:
                mx = int(action.getAmount1())
                my = int(action.getAmount2())
                if mx > 0 or my > 0:
                    for rx1, ry1, rx2, ry2, b_idx in self._btn_rects:
                        if rx1 <= mx <= rx2 and ry1 <= my <= ry2:
                            self.selected = b_idx
                            self.close()
                            return
            except Exception:
                pass

            try:
                xbmc.sleep(80)
            except: pass
            try:
                fid = self.getFocusId()
            except Exception:
                fid = -1

            if fid in self._control_map:
                self.selected = self._control_map[fid]
                self.close()
            elif fid in self._btn_ids:
                self.selected = self._btn_ids.index(fid)
                self.close()
            elif fid == getattr(self, '_backdrop_id', None):
                self.selected = 0
                self.close()

    def onClick(self, control_id):
        xbmc.log('BridgeMulti PausePromptDialog onClick: id=%s' % control_id, xbmc.LOGINFO)
        if control_id in self._control_map:
            self.selected = self._control_map[control_id]
        elif control_id in self._btn_ids:
            self.selected = self._btn_ids.index(control_id)
        elif control_id == getattr(self, '_backdrop_id', None):
            self.selected = 0
        else:
            self.selected = 0
        self.close()

    def close(self):
        if getattr(self, '_is_closed', False):
            return
        self._is_closed = True
        try:
            super().close()
        except Exception:
            pass


def show_resume_dialog(time_str, title_text=""):
    """Diálogo de reanudar 100% nativo de Kodi.
    Retorna:
      0: Continuar desde time_str
      1: Reiniciar
      -1: Cancelar (no reproducir nada)
    """
    try:
        dialog = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)()
        if hasattr(dialog, 'yesnocustom'):
            # Kodi nativo con 3 botones (DialogConfirm):
            # ret == 1 -> yeslabel ('Continuar')
            # ret == 0 -> nolabel ('Reiniciar')
            # ret == 2 -> customlabel ('Cancelar')
            # ret == -1 -> Cancelado / Atrás / ESC
            ret = dialog.yesnocustom(
                'Reanudar reproducción',
                '¿Deseas reanudar desde [COLOR gold]%s[/COLOR] o ver desde el principio?' % time_str,
                'Cancelar',
                'Reiniciar',
                'Continuar'
            )
            xbmc.log('Multi Bridge show_resume_dialog yesnocustom ret=%s' % str(ret), xbmc.LOGINFO)
            if ret == 1:
                return 0  # Continuar
            elif ret == 0:
                return 1  # Reiniciar
            else:
                return -1 # Cancelar (Atrás / ESC / botón Cancelar)
    except Exception as e:
        xbmc.log('Multi Bridge show_resume_dialog yesnocustom error: %s' % str(e), xbmc.LOGWARNING)

    # Fallback seguro con dialog.select
    try:
        dialog = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)()
        ret = dialog.select('Reanudar reproducción', ['Continuar (%s)' % time_str, 'Reiniciar'])
        xbmc.log('Multi Bridge show_resume_dialog select ret=%s' % str(ret), xbmc.LOGINFO)
        return ret
    except Exception as e:
        xbmc.log('Multi Bridge show_resume_dialog select error: %s' % str(e), xbmc.LOGWARNING)
        return -1


class _FloatingLinksDialog(xbmcgui.WindowXMLDialog):
    _QUALITY_ICONS = {
        '4K':    'flag4k.png',
        '1080p': 'flag1080p.png',
        '720p':  'flag720p.png',
        'SD':    'flagSD.png',
    }

    _CODEC_PATTERNS = [
        (re.compile(r'HEVC|[Xx]\.?265|[Hh]\.?265', re.I), 'HEVC'),
        (re.compile(r'[Xx]\.?264|[Hh]\.?264', re.I),       'x264'),
        (re.compile(r'AV1', re.I),                         'AV1'),
    ]

    _SOURCE_PATTERNS = [
        (re.compile(r'Remux', re.I),     'REMUX'),
        (re.compile(r'BluRay|BLU-RAY', re.I), 'BluRay'),
        (re.compile(r'BDRip|BRRip', re.I),   'BDRip'),
        (re.compile(r'WEB-DL|WEBDL', re.I),  'WEB-DL'),
        (re.compile(r'WEBRip', re.I),        'WebRip'),
        (re.compile(r'\bWEB\b', re.I),       'WEB-DL'),
        (re.compile(r'HDTV', re.I),          'HDTV'),
        (re.compile(r'HDRip', re.I),         'HDRip'),
        (re.compile(r'DVDRip', re.I),        'DVDRip'),
        (re.compile(r'DVDScr', re.I),        'DVDScr'),
        (re.compile(r'HDCAM|CAM|TeleSync|\bTS\b|\bTC\b', re.I), 'CAM/TS'),
    ]

    _HDR_PATTERNS = [
        (re.compile(r'HDR10\+', re.I),           'HDR10+'),
        (re.compile(r'HDR10', re.I),             'HDR10'),
        (re.compile(r'\bHDR\b', re.I),           'HDR'),
        (re.compile(r'\bSDR\b', re.I),           'SDR'),
        (re.compile(r'\bHLG\b', re.I),           'HLG'),
        (re.compile(r'Dolby[.\s]?Vision|\b(DV|DoVi)\b', re.I), 'DV'),
    ]

    _AUDIO_PATTERNS = [
        (re.compile(r'Atmos', re.I),                   'ATMOS'),
        (re.compile(r'TrueHD', re.I),                  'TrueHD'),
        (re.compile(r'DTS[\-\.]?HD(?:[\-\.]?MA)?', re.I), 'DTS-HD'),
        (re.compile(r'\bDTS\b', re.I),                 'DTS'),
        (re.compile(r'DDP\s?5[\. ]?1|DD\+\s?5[\. ]?1|EAC3\s?5[\. ]?1', re.I), 'DDP 5.1'),
        (re.compile(r'\bDDP\b|DD\+|EAC3', re.I),       'DDP'),
        (re.compile(r'DD\s?5[\. ]?1|AC3\s?5[\. ]?1', re.I), 'DD 5.1'),
        (re.compile(r'\bAC3\b|\bDD\b', re.I),          'AC3'),
        (re.compile(r'AAC\s?5[\. ]?1', re.I),          'AAC 5.1'),
        (re.compile(r'\bAAC\b', re.I),                 'AAC'),
        (re.compile(r'\bFLAC\b', re.I),                'FLAC'),
        (re.compile(r'6CH|\b5[\. ]?1\b', re.I),        '5.1'),
        (re.compile(r'2\.0|2CH', re.I),                '2.0'),
    ]

    def __new__(cls, *args, **kwargs):
        addon_path = _bridge_addon.getAddonInfo('path')
        return super(_FloatingLinksDialog, cls).__new__(cls, 'results.xml', addon_path, 'Default', '1080i')

    def __init__(self, links, current_index=0, meta=None, engine='alfa', is_playback=False, failed_links=None, initial_tab=None, offset=0, *args, **kwargs):
        self._is_closed = False
        self.all_links = [l for l in (links or []) if l is not None and getattr(l, 'url', None)]
        self.meta = meta or {}
        self.engine = engine or 'alfa'
        self.is_playback = is_playback
        self.selected = -1
        self.target_focus_idx = current_index if isinstance(current_index, int) else 0
        self.failed_links = set(failed_links or [])
        mk = _get_media_key(self.meta) if self.meta else None
        self.failed_signatures = _get_session_failed_signatures(media_key=mk, meta=self.meta)
        self.offset_count = offset
        self.active_tab = initial_tab if initial_tab is not None else 0
        self.active_filter = None
        self.last_cm_time = 0
        self._cm_open = False
        self.display_items = []

        # Separar directos, torrents y captchas para clasificacion e informacion
        self.direct_links = []
        self.torrent_links = []
        self.captcha_links = []
        for l in self.all_links:
            srv = _get_link_server_name(l).strip().lower()
            if srv == 'torrent' or _is_torrent_link(l):
                self.torrent_links.append(l)
            elif _is_web_captcha_server(srv, l):
                self.captcha_links.append(l)
            else:
                self.direct_links.append(l)

        # Enlace en reproduccion (identificado en la lista original ANTES de reordenar)
        self.playing_item = None
        if self.is_playback:
            for l in self.all_links:
                try: setattr(l, '_is_currently_playing', False)
                except Exception: pass

            target_idx = -1
            if 0 <= self.target_focus_idx < len(self.all_links):
                target_idx = self.target_focus_idx
            else:
                try:
                    c_idx_str = xbmcgui.Window(10000).getProperty('BridgeMulti.CurrentPlayingIndex')
                    if c_idx_str and c_idx_str.isdigit():
                        c_idx = int(c_idx_str)
                        if 0 <= c_idx < len(self.all_links):
                            target_idx = c_idx
                except Exception:
                    pass

            if 0 <= target_idx < len(self.all_links):
                self.playing_item = self.all_links[target_idx]
                try: setattr(self.playing_item, '_is_currently_playing', True)
                except Exception: pass

        # Respetar jerarquia: HTTP primero -> Captchas en su propia categoria -> Torrents debajo (y dentro de cada categoria: idioma, calidad, servidor)
        try:
            b_prefs = _get_filter_prefs()
            sort_q = b_prefs.get('servers_sort_quality', 0)
            self.all_links = sorted(self.all_links, key=lambda it: _get_hierarchical_sort_key(it, b_prefs=b_prefs, sort_q=sort_q))
        except Exception:
            pass

        # Despues de ordenar, actualizar target_focus_idx para enfocar exactamente el enlace en reproduccion
        if self.playing_item is not None and self.playing_item in self.all_links:
            self.target_focus_idx = self.all_links.index(self.playing_item)

        if self.is_playback:
            self._start_playback_watchdog()

    def _start_playback_watchdog(self):
        if getattr(self, "is_test", False): return
        def _watch():
            p = xbmc.Player()
            mon = xbmc.Monitor()
            while not getattr(self, '_is_closed', False) and not mon.abortRequested() and not _BG_TASK_ABORT_EVENT.is_set():
                if not p.isPlayingVideo():
                    if mon.waitForAbort(0.15) or _BG_TASK_ABORT_EVENT.is_set():
                        break
                    if not p.isPlayingVideo() and not getattr(self, '_is_closed', False):
                        self.selected = -1
                        try:
                            self.close()
                        except Exception:
                            pass
                        break
                if mon.waitForAbort(0.2) or _BG_TASK_ABORT_EVENT.is_set():
                    break
        t = threading.Thread(target=_watch, daemon=True)
        t.name = "FloatingLinksWatchdog"
        t.start()

    def onInit(self):
        self._set_window_properties()
        self._populate_list()
        try:
            self.setFocusId(2000)
            target_idx = 0
            if 0 <= self.target_focus_idx < len(self.all_links):
                target_lnk = self.all_links[self.target_focus_idx]
                if target_lnk in self.display_items:
                    target_idx = self.display_items.index(target_lnk)
            ctrl = self.getControl(2000)
            if ctrl and 0 <= target_idx < len(self.display_items):
                ctrl.selectItem(target_idx)
        except Exception:
            pass

    def _get_quality_bucket(self, lnk):
        # 1. Prioridad maxima: resolucion real confirmada por decodificador o verificacion tecnica
        real_q = _safe_str(getattr(lnk, 'real_quality', '') or getattr(lnk, 'real_res', '')).strip().upper()
        if real_q:
            if '4K' in real_q or '2160' in real_q: return '4K'
            if '1080' in real_q or 'FHD' in real_q: return '1080p'
            if '720' in real_q: return '720p'
            if '480' in real_q or '360' in real_q or '240' in real_q or 'SD' in real_q: return 'SD'

        # 2. Formato de calidad de Multi Bridge (contempla servidores como Okru, Streamwish, etc.)
        fq = _format_quality(lnk).upper()
        if '4K' in fq or '2160' in fq: return '4K'
        if '1080' in fq or 'FHD' in fq: return '1080p'
        if '720' in fq: return '720p'
        if '480' in fq or '360' in fq or '240' in fq or 'SD' in fq: return 'SD'

        # 3. Fallback de texto combinado
        qual = _safe_str(getattr(lnk, 'quality', '')).strip().upper()
        title_str = _safe_str(getattr(lnk, 'title', '')).strip().upper()
        url_str = _safe_str(getattr(lnk, 'url', '')).strip().upper()
        comb = qual + ' ' + title_str + ' ' + url_str
        if _has_4k_token(comb) or '2160' in comb or '4K' in qual:
            return '4K'
        if '1080' in comb or 'FHD' in comb or 'FULLHD' in comb:
            return '1080p'
        if '720' in comb or 'HD' in comb:
            return '720p'
        return 'SD' 

    def _set_window_properties(self):
        meta_title = self.meta.get('title') or self.meta.get('tvshowtitle') or title or showname or 'Multi Bridge'
        self.setProperty('bridge.title', _safe_str(meta_title))
        self.setProperty('bridge.fanart', _safe_str(self.meta.get('fanart') or fanart or ''))

        logo = self.meta.get('clearlogo') or clearlogo or ''
        if logo in ('_', 'None', 'none'): logo = ''
        if not logo:
            try: logo = xbmcgui.Window(10000).getProperty('MultiBridge.ClearLogo') or ''
            except Exception: pass
        if not logo:
            try: logo = xbmcgui.Window(10000).getProperty('Player.Art(clearlogo)') or ''
            except Exception: pass
        if not logo:
            try: logo = xbmcgui.Window(10000).getProperty('TMDbHelper.ListItem.ClearLogo') or ''
            except Exception: pass
        if not logo:
            t_id = self.meta.get('tmdb') or self.meta.get('tmdb_id') or tmdb_id
            if t_id:
                is_tv = bool(self.meta.get('season') and self.meta.get('episode'))
                try:
                    logo = _get_clearlogo(t_id, is_tv) or ''
                except Exception:
                    pass
        if not logo:
            try:
                logo = xbmc.getInfoLabel('ListItem.Art(clearlogo)') or xbmc.getInfoLabel('Player.Art(clearlogo)') or ''
            except Exception:
                pass
        self.setProperty('bridge.clearlogo', _safe_str(logo))

        season_val = self.meta.get('season') or season
        episode_val = self.meta.get('episode') or episode
        try:
            if season_val and episode_val:
                ep_txt = 'S%02dE%02d' % (int(season_val), int(episode_val))
                self.setProperty('bridge.episode_label', ep_txt)
                self.setProperty('bridge.episode_display', '  •  [COLOR yellow][B]%s[/B][/COLOR]' % ep_txt)
            else:
                self.setProperty('bridge.episode_label', '')
                self.setProperty('bridge.episode_display', '')
        except Exception:
            self.setProperty('bridge.episode_label', '')
            self.setProperty('bridge.episode_display', '')

        # Contadores por calidad
        c_4k, c_1080, c_720, c_sd = 0, 0, 0, 0
        for l in self.all_links:
            qb = self._get_quality_bucket(l)
            if qb == '4K': c_4k += 1
            elif qb == '1080p': c_1080 += 1
            elif qb == '720p': c_720 += 1
            else: c_sd += 1

        self.setProperty('bridge.count_4k', str(c_4k))
        self.setProperty('bridge.count_1080p', str(c_1080))
        self.setProperty('bridge.count_720p', str(c_720))
        self.setProperty('bridge.count_sd', str(c_sd))
        self.setProperty('bridge.total_results', str(len(self.all_links)))

        self.setProperty('bridge.color_4k', 'FFFF00FF')
        self.setProperty('bridge.color_1080p', 'FFDAA520')
        self.setProperty('bridge.color_720p', 'FF9932CC')
        self.setProperty('bridge.color_sd', 'FF6495ED')

        # Deteccion de idiomas presentes
        found_langs = set()
        for l in self.all_links:
            lg = _format_language(l)
            if lg:
                for sublg in lg.split('/'):
                    sublg = sublg.strip().upper()
                    if sublg: found_langs.add(sublg)
        if found_langs:
            ordered = []
            for preferred in ('LATINO', 'CASTELLANO', 'VOSE', 'INGLÉS', 'SUBTITULADO'):
                if preferred in found_langs:
                    ordered.append(preferred)
                    found_langs.remove(preferred)
            ordered.extend(sorted(list(found_langs)))
            self.setProperty('bridge.lang_text', 'AUDIO: ' + ' / '.join(ordered[:3]))
        else:
            self.setProperty('bridge.lang_text', '')

    def _extract_codec(self, name):
        for pattern, label in self._CODEC_PATTERNS:
            if pattern.search(name): return label
        return ''

    def _extract_source(self, name):
        for pattern, label in self._SOURCE_PATTERNS:
            if pattern.search(name): return label
        return ''

    def _extract_hdr(self, name):
        found = []
        for pattern, label in self._HDR_PATTERNS:
            if pattern.search(name) and label not in found:
                found.append(label)
        return found

    def _extract_audio(self, name):
        name_clean = name.replace('.', ' ').replace('_', ' ')
        found = []
        for pattern, label in self._AUDIO_PATTERNS:
            if pattern.search(name_clean):
                if not any(label in f or f in label for f in found):
                    found.append(label)
        return found

    def _populate_list(self):
        try:
            ctrl = self.getControl(2000)
            ctrl.reset()
        except Exception:
            ctrl = None

        meta_title = self.meta.get('title') or self.meta.get('tvshowtitle') or title or showname or 'Multi Bridge'
        global_poster = self.meta.get('poster') or poster or ''
        global_plot = self.meta.get('plot') or self.meta.get('plot_lat') or self.meta.get('plot_es') or plot or ''

        # Filtrado si esta activo
        if self.active_filter == 'filter_direct':
            filtered = [l for l in self.all_links if l in self.direct_links]
        elif self.active_filter == 'filter_torrent':
            filtered = [l for l in self.all_links if l in self.torrent_links]
        elif self.active_filter == 'filter_captcha':
            filtered = [l for l in self.all_links if l in self.captcha_links]
        elif self.active_filter == 'filter_4k':
            filtered = [l for l in self.all_links if self._get_quality_bucket(l) == '4K']
        elif self.active_filter == 'filter_1080p':
            filtered = [l for l in self.all_links if self._get_quality_bucket(l) == '1080p']
        elif self.active_filter == 'filter_720p':
            filtered = [l for l in self.all_links if self._get_quality_bucket(l) == '720p']
        elif self.active_filter == 'filter_sd':
            filtered = [l for l in self.all_links if self._get_quality_bucket(l) == 'SD']
        else:
            filtered = list(self.all_links)

        self.display_items = filtered
        items = []
        playing_matched = False

        for idx, lnk in enumerate(self.display_items):
            try:
                src_idx = self.all_links.index(lnk)
            except ValueError:
                src_idx = idx

            # Comprobar si es el enlace actualmente en reproduccion (estrictamente solo uno)
            is_curr_playing = False
            if self.is_playback and not playing_matched:
                if getattr(lnk, '_is_currently_playing', False) or (self.playing_item is not None and lnk is self.playing_item):
                    is_curr_playing = True
                    playing_matched = True

            # Comprobar si ha fallado
            sig = _get_link_unique_id(lnk)
            is_failed = bool(
                (lnk in self.failed_links) or
                getattr(lnk, 'bridge_failed', False) or
                (sig and sig in self.failed_signatures)
            )

            qb = self._get_quality_bucket(lnk)
            srv_name = _get_link_server_name(lnk) or ''
            is_torrent = (srv_name.lower() == 'torrent' or _is_torrent_link(lnk))
            is_captcha = _is_web_captcha_server(srv_name, lnk)
            type_label = 'TORRENT' if is_torrent else ('CAPTCHA' if is_captcha else 'HTTP')
            if is_failed:
                type_label = 'FALLIDO'

            # Colores base y estilo de tarjeta
            if is_failed:
                base_color = 'FFFF4444'
                hl_focus = '40FF3333'
                hl_dim = '20FF3333'
                title_color_focus = 'FFFF6666'
            elif is_curr_playing:
                base_color = 'FF00FF7F'  # SpringGreen vibrante para el enlace en reproduccion
                hl_focus = '4500FF7F'
                hl_dim = '2500FF7F'
                title_color_focus = 'FF00FF7F'
            elif is_torrent:
                base_color = 'FF00E5FF'  # Cyan electrico unico y distintivo para Torrents
                hl_focus = '3500E5FF'
                hl_dim = '1800E5FF'
                title_color_focus = 'FFE0FFFF'
            elif is_captcha:
                base_color = 'FFFFA500'  # Naranja distintivo para Captchas
                hl_focus = '35FFA500'
                hl_dim = '18FFA500'
                title_color_focus = 'FFFFD700'
            else:
                if qb == '4K': base_color = 'FFFF00FF'
                elif qb == '1080p': base_color = 'FFDAA520'
                elif qb == '720p': base_color = 'FF9932CC'
                else: base_color = 'FF6495ED'
                hl_focus = '35' + base_color[2:]
                hl_dim = '15' + base_color[2:]
                title_color_focus = 'FFCCCCFF'

            # Linea 1: Nombre
            raw_title = _safe_str(getattr(lnk, 'title', '')).strip()
            clean_title = re.sub(r'\[/?COLOR.*?\]', '', raw_title).strip()
            clean_title = re.sub(r'\[/?B\]', '', clean_title).strip()
            url_val = _safe_str(getattr(lnk, 'url', '')).strip()
            url_fn = url_val.split('|')[0].split('?')[0].rstrip('/').split('/')[-1] if url_val else ''

            if len(clean_title) < 5 or clean_title.lower() in ('directo', 'torrent', 'enlace', 'stream', 'reproducir'):
                if len(url_fn) > 5 and '.' in url_fn and not url_fn.lower().endswith(('.php', '.html', '.htm')):
                    clean_title = url_fn
                else:
                    clean_title = '%s - %s' % (meta_title, srv_name or 'Servidor')

            # Quitar etiqueta de resolucion redundante al final del titulo (ej. [1080P], (720p))
            clean_title = re.sub(r'(?i)\s*\[\s*(?:4k|uhd|2160p?|1080p?|720p?|480p?|sd|hd|fhd)\s*\]\s*$', '', clean_title).strip()
            clean_title = re.sub(r'(?i)\s*\(\s*(?:4k|uhd|2160p?|1080p?|720p?|480p?|sd|hd|fhd)\s*\)\s*$', '', clean_title).strip()

            if is_failed and not clean_title.startswith('[FALLIDO]'):
                clean_title = '[FALLIDO] ' + clean_title
            elif is_curr_playing and not clean_title.startswith('[EN REPRODUCCIÓN]'):
                clean_title = '[EN REPRODUCCIÓN] ' + clean_title
            if _is_web_captcha_server(srv_name, lnk):
                if '(CAPTCHA)' not in clean_title and '(REQUIERE CAPTCHA)' not in clean_title:
                    clean_title += ' [COLOR orange](CAPTCHA)[/COLOR]'

            # Linea 2: Metadatos estructurados
            parts = []

            # Badge destacado si esta en reproduccion
            if is_curr_playing:
                parts.append('[COLOR FF00FF7F][B]► EN REPRODUCCIÓN[/B][/COLOR]')

            # Tamano
            size_val = _safe_str(getattr(lnk, 'size', '') or getattr(lnk, 'filesize', '') or '').strip()
            if not size_val and hasattr(lnk, 'infoLabels') and isinstance(lnk.infoLabels, dict):
                size_val = _safe_str(lnk.infoLabels.get('size', '')).strip()
            if not size_val:
                m_sz = re.search(r'(\d+(?:\.\d+)?\s*(?:GB|MB|GiB|MiB))', raw_title + ' ' + url_val, re.I)
                if m_sz: size_val = m_sz.group(1).upper()
            if size_val and size_val != 'N/A':
                parts.append('[COLOR lime][B]%s[/B][/COLOR]' % size_val)

                        # Servidor
            if is_torrent:
                if srv_name and srv_name.lower() not in ('torrent', 'magnet', 'unknown', ''):
                    parts.append('[COLOR FF00E5FF][B]TORRENT (%s)[/B][/COLOR]' % srv_name.upper())
                else:
                    parts.append('[COLOR FF00E5FF][B]TORRENT[/B][/COLOR]')
            elif srv_name and srv_name.lower() not in ('directo', 'torrent', 'unknown', '', 'http'):
                parts.append('[COLOR FF00BFFF][B]%s[/B][/COLOR]' % srv_name.upper())
                if _is_web_captcha_server(srv_name, lnk):
                    parts.append('[COLOR orange][B](REQUIERE CAPTCHA)[/B][/COLOR]')
            else:
                parts.append('[COLOR FF00BFFF][B]HTTP[/B][/COLOR]')

            # Canal / Proveedor
            ch = _format_channel(lnk)
            if ch:
                parts.append('[COLOR FF7B68EE][B]%s[/B][/COLOR]' % ch)

            # Idioma
            lang = _format_language(lnk)
            if lang:
                lang_up = lang.upper()
                if 'LATINO' in lang_up:
                    parts.append('[COLOR yellow][B]LATINO[/B][/COLOR]')
                elif 'CAST' in lang_up or 'ESP' in lang_up:
                    parts.append('[COLOR gold][B]CASTELLANO[/B][/COLOR]')
                elif 'SUB' in lang_up or 'VOSE' in lang_up:
                    parts.append('[COLOR FF87CEEB][B]VOSE[/B][/COLOR]')
                elif 'ENG' in lang_up or 'ING' in lang_up:
                    parts.append('[COLOR white][B]INGLÉS[/B][/COLOR]')
                else:
                    parts.append('[COLOR yellow][B]%s[/B][/COLOR]' % lang)

            # Extension
            m_ext = re.search(r'\.(mkv|mp4|avi|ts)(?:\s|$|\?|\|)', raw_title + ' ' + url_val, re.I)
            if m_ext:
                parts.append('[COLOR FFCCCCFF][B]%s[/B][/COLOR]' % m_ext.group(1).upper())

            # Fuente de video (BluRay, WEB-DL, etc.)
            src_tag = self._extract_source(raw_title + ' ' + url_val)
            if src_tag:
                parts.append('[COLOR FF00FA9A][B]%s[/B][/COLOR]' % src_tag)

            # Codec
            cod = self._extract_codec(raw_title + ' ' + url_val)
            if cod:
                parts.append('[COLOR red][B]%s[/B][/COLOR]' % cod)

            # HDR / Dolby Vision
            for h in self._extract_hdr(raw_title + ' ' + url_val):
                parts.append('[COLOR FFFFCC00][B]%s[/B][/COLOR]' % h)

            # Audio
            for a in self._extract_audio(raw_title + ' ' + url_val):
                parts.append('[COLOR FFADFF2F][B]%s[/B][/COLOR]' % a)

            if is_failed:
                parts.append('[COLOR red][B][FALLIDO][/B][/COLOR]')

            info_line_colored = " | ".join(parts)
            info_line_unfocus = re.sub(r'\[/?COLOR.*?\]', '', info_line_colored)
            info_line_unfocus = re.sub(r'\[/?B\]', '', info_line_unfocus)

            # ListItem
            li = xbmcgui.ListItem(clean_title)
            li.setProperty('bridge.count', '%d.' % (idx + 1))
            li.setProperty('bridge.src_index', str(src_idx))
            li.setProperty('bridge.quality', qb)
            li.setProperty('bridge.type', type_label)
            li.setProperty('bridge.highlight', base_color)
            li.setProperty('bridge.highlight_dim', hl_dim)
            li.setProperty('bridge.highlight_focus', hl_focus)
            li.setProperty('bridge.is_playing', 'true' if is_curr_playing else 'false')
            li.setProperty('bridge.name', clean_title)
            li.setProperty('bridge.title_color_focus', title_color_focus)
            li.setProperty('bridge.info_line_unfocus', info_line_unfocus)
            li.setProperty('bridge.info_line_focus', info_line_colored)
            li.setProperty('bridge.poster', global_poster)
            li.setProperty('bridge.plot', global_plot)

            items.append(li)

        if ctrl and items:
            ctrl.addItems(items)

    def onClick(self, controlId):
        if controlId == 2000:
            try:
                ctrl = self.getControl(2000)
                item = ctrl.getSelectedItem() if ctrl else None
                if item:
                    # Si es el enlace que ya se esta reproduciendo, ignorar el clickeo
                    if self.is_playback:
                        is_playing_prop = (item.getProperty('bridge.is_playing') == 'true')
                        try:
                            s_idx = int(item.getProperty('bridge.src_index'))
                        except (ValueError, TypeError):
                            s_idx = -1
                        is_playing_idx = (self.playing_item is not None and 0 <= s_idx < len(self.all_links) and self.all_links[s_idx] is self.playing_item)
                        if is_playing_prop or is_playing_idx:
                            return
                        self.selected = s_idx
                        if 0 <= s_idx < len(self.all_links):
                            self.selected_link = self.all_links[s_idx]
                    else:
                        try:
                            self.selected = int(item.getProperty('bridge.src_index'))
                            if 0 <= self.selected < len(self.all_links):
                                self.selected_link = self.all_links[self.selected]
                        except (ValueError, TypeError):
                            self.selected = -1
            except Exception:
                self.selected = -1
            self.close()
        elif controlId == 3000:
            return

    def onAction(self, action):
        aid = action.getId()
        if aid in (117, 101, 11):  # Menu contextual / Info
            if getattr(self, '_cm_open', False):
                return
            if time.time() - self.last_cm_time < 0.8:
                return
            self._cm_open = True
            try:
                self.handle_context_menu()
            finally:
                self.last_cm_time = time.time()
                self._cm_open = False
            return

        if aid in (9, 10, 92, 110):  # Atras / ESC / Cancelar
            self.selected = -1
            self.close()
            return

        if aid in (13,):  # Stop
            if self.is_playback:
                try:
                    if xbmc.Player().isPlaying():
                        xbmc.Player().stop()
                except Exception:
                    pass
            self.selected = -1
            self.close()
            return

    def handle_context_menu(self):
        opts_items = [('[COLOR yellow]Forzar nueva búsqueda[/COLOR]', 'force_search')]
        other_eng_name = 'Balandro' if self.engine == 'alfa' else 'Alfa'
        other_eng_id = 'balandro' if self.engine == 'alfa' else 'alfa'
        is_series = bool(self.meta.get('season') and self.meta.get('episode'))
        if not (is_series and other_eng_id == 'alfa') and _is_engine_installed(other_eng_id):
            opts_items.append(('[COLOR orange]Buscar con %s[/COLOR]' % other_eng_name, 'other_engine'))

        is_already_verified = (
            _bridge_addon.getSetting('auto_verify_links') == 'true' or
            bool(self.meta.get('verified_only')) or
            not self.direct_links
        )
        if not is_already_verified:
            opts_items.append(('[COLOR deepskyblue]Verificar disponibilidad[/COLOR]', 'verify_links'))

        # Filtros rapidos
        opts_items.append(('[B]Filtrar: Solo HTTP[/B]', 'filter_direct'))
        opts_items.append(('[B]Filtrar: Solo Torrents[/B]', 'filter_torrent'))
        if self.captcha_links:
            opts_items.append(('[B]Filtrar: Solo Captchas[/B]', 'filter_captcha'))
        opts_items.append(('[B]Filtrar: Solo 4K[/B]', 'filter_4k'))
        opts_items.append(('[B]Filtrar: Solo 1080p[/B]', 'filter_1080p'))
        opts_items.append(('[B]Filtrar: Solo 720p[/B]', 'filter_720p'))
        opts_items.append(('[B]Filtrar: Solo SD[/B]', 'filter_sd'))
        if self.active_filter:
            opts_items.append(('[B][COLOR springgreen]Mostrar todos (Restablecer)[/COLOR][/B]', 'filter_reset'))

        sel = _KODI_ORIG_DIALOG().select('Multi Bridge — Opciones', [o[0] for o in opts_items])
        if sel < 0 or sel >= len(opts_items):
            return

        chosen_action = opts_items[sel][1]
        if chosen_action in ('force_search', 'other_engine', 'verify_links'):
            self.selected = chosen_action
            self.close()
        elif chosen_action == 'filter_reset':
            self.active_filter = None
            self._populate_list()
        else:
            self.active_filter = chosen_action
            self._populate_list()
        try:
            self.setFocusId(2000)
            ctrl = self.getControl(2000)
            if ctrl and self.display_items:
                ctrl.selectItem(0)
        except Exception:
            pass

    def close(self):
        if getattr(self, '_is_closed', False):
            return
        self._is_closed = True
        try:
            super(_FloatingLinksDialog, self).close()
        except Exception:
            try:
                super().close()
            except Exception:
                pass



def _load_cached_links_for_dialog(offset=0):
    _hide_cap = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
    def _clean_dialog_links(_lst):
        _res = _filter_discarded_links(_lst)
        if _hide_cap:
            _res = [l for l in _res if _is_torrent_link(l) or not _is_web_captcha_server(_get_link_server_name(l), l)]
        return _res

    # 1. RAM Cache instantáneo (0 ms, sin acceso a disco ni deserialización)
    try:
        ram = _get_ram_search_cache()
        if ram and ram.get('links'):
            c_links = [l for l in ram['links'] if l is not None and getattr(l, 'url', None)]
            if c_links:
                c_matched = ram.get('matched_item')
                c_meta = ram.get('meta', {}) or {}
                c_engine = ram.get('engine', 'alfa') or 'alfa'
                valid_links = _clean_dialog_links([l for l in c_links if len(_safe_str(getattr(l, 'url', ''))) <= 1500])
                if offset > 0 and offset < len(valid_links):
                    valid_links = valid_links[offset:]
                if valid_links:
                    xbmc.log("Multi Bridge: _load_cached_links_for_dialog RAM HIT -> %d enlaces (offset=%d)" % (len(valid_links), offset), xbmc.LOGINFO)
                    return valid_links, c_matched, c_meta, c_engine
    except Exception as _re:
        xbmc.log("Multi Bridge: _load_cached_links_for_dialog ram check error: %s" % _re, xbmc.LOGDEBUG)

    # 2. Fallback a archivo de caché en disco
    cache = _read_search_cache_atomic()
    if not cache or not isinstance(cache, dict):
        return [], None, {}, 'alfa'
    try:
        c_engine = cache.get('engine', 'alfa') or 'alfa'
        c_meta = cache.get('meta', {}) or {}

        raw_links = cache.get('links', []) or []
        raw_valid = [l for l in raw_links if isinstance(l, dict) and l.get('url') and len(_safe_str(l.get('url', ''))) <= 1500]
        if not raw_valid:
            return [], None, {}, c_engine
        if offset > 0 and offset < len(raw_valid):
            raw_valid = raw_valid[offset:]

        _d_mods = _get_alfa_modules() if c_engine == 'alfa' else _get_balandro_modules()
        if not _d_mods:
            alt_eng = 'balandro' if c_engine == 'alfa' else 'alfa'
            _d_mods = _get_balandro_modules() if alt_eng == 'balandro' else _get_alfa_modules()

        if _d_mods:
            _Item, _Info = _d_mods['Item'], _d_mods['InfoLabels']
            c_links = [_deserialize_item_fast(_Item, _Info, l) for l in raw_valid]
            c_matched = _deserialize_item_fast(_Item, _Info, cache.get('item'))
        else:
            c_links = [_deserialize_item(l, c_engine) for l in raw_valid]
            c_matched = _deserialize_item(cache.get('item'), c_engine)

        c_links = _clean_dialog_links([l for l in (c_links or []) if l is not None and getattr(l, 'url', None)])
        if c_links:
            for i, l in enumerate(c_links):
                if getattr(l, '_bridge_orig_idx', None) is None:
                    try: setattr(l, '_bridge_orig_idx', i + offset)
                    except Exception: pass
                _get_link_unique_id(l)
            try:
                b_prefs = _get_filter_prefs()
                sort_q = b_prefs.get('servers_sort_quality', 0)
                c_links = sorted(c_links, key=lambda it: _get_hierarchical_sort_key(it, b_prefs=b_prefs, sort_q=sort_q))
            except Exception: pass
            _store_ram_search_cache(c_links, c_matched, c_meta, c_engine)
        return c_links, c_matched, c_meta, c_engine
    except Exception as e:
        xbmc.log('Multi Bridge: _load_cached_links_for_dialog error: ' + str(e), xbmc.LOGINFO)
        return [], None, {}, 'alfa'


def _android_stop_playback_if_active():
    if not bool(xbmc.getCondVisibility('System.Platform.Android')):
        return
    try:
        p = xbmc.Player()
        if p.isPlaying() or xbmc.getCondVisibility("Player.HasMedia"):
            p.stop()
            try: xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            except Exception: pass
            for _ in range(60):
                if not p.isPlaying() and not xbmc.getCondVisibility("Player.HasMedia"):
                    break
                xbmc.sleep(50)
            xbmc.sleep(250)
    except Exception:
        pass


def _switch_to_link(chosen_idx, links, meta, matched_item=None, engine='alfa', force_cur_time=0.0, chosen_link=None):
    if chosen_link is not None:
        chosen = chosen_link
    elif links and 0 <= chosen_idx < len(links):
        chosen = links[chosen_idx]
    else:
        return False

    p = xbmc.Player()
    cur_time = 0.0
    total_time = 0.0
    prev_file = ''
    try:
        if p.isPlayingVideo():
            cur_time = float(p.getTime())
            total_time = float(p.getTotalTime())
            try: prev_file = p.getPlayingFile() or ''
            except Exception: prev_file = ''
    except Exception:
        pass
    if cur_time <= 0.0 and force_cur_time > 0.0:
        cur_time = float(force_cur_time)

    srv_name = _get_link_server_name(chosen)
    xbmc.log("Multi Bridge: cambio en caliente a enlace %d/%d (%s) en %.1fs" % (
        chosen_idx + 1, len(links), srv_name, cur_time), xbmc.LOGINFO)

    media_key = _get_media_key(meta, chosen)
    if cur_time > 2:
        try:
            save_bookmark(media_key, cur_time, total_time, title=meta.get('title', ''))
        except Exception:
            pass

    # En Android, detener el reproductor previo limpiamente antes de resolver el nuevo enlace
    # para liberar el decodificador de hardware (MediaCodec), el audio y la superficie antes de que
    # se abra el navegador para captcha o se configure el nuevo stream.
    # En PC (Windows Direct3D), mantener en pausa sin destruir el pipeline para cambio instantaneo.
    is_android_dev = bool(xbmc.getCondVisibility('System.Platform.Android'))
    if is_android_dev:
        _android_stop_playback_if_active()
    else:
        try:
            if p.isPlayingVideo() and not xbmc.getCondVisibility("Player.Paused"):
                p.pause()
        except Exception:
            pass

    # Preservar metadatos completos para TMDb Helper, Trakt y Kodi OSD
    _enrich_link_metadata(chosen, meta, matched_item)
    sync_tmdbhelper_playerstring(meta)

    try:
        xbmcgui.Dialog().notification('Multi Bridge', 'Cambiando a [B]%s[/B]...' % srv_name, '', 2500)
    except Exception:
        pass

    eng = getattr(chosen, 'bridge_engine', '') or engine or 'alfa'
    try:
        xbmcgui.Window(10000).setProperty('BridgeMulti.HotSwitching', 'true')
    except Exception:
        pass
    played = _play_link_safely(chosen, engine=eng, matched_item=matched_item, meta=meta, is_switch=True, seek_to_time=cur_time)
    if played in ('cancel', 'no_client'):
        return played
    if played:
        try:
            m_idx = links.index(chosen)
        except (ValueError, AttributeError):
            m_idx = chosen_idx
        start_playback_monitor(
            media_key, title_str=meta.get('title', ''), seek_to_time=cur_time,
            current_link_index=m_idx, meta=meta, old_playing_file=prev_file or None
        )
        return True
    return False


def _play_link_from_dialog(chosen_idx, links, meta, matched_item=None, engine='alfa', global_idx=None, chosen_link=None):
    _android_stop_playback_if_active()
    if chosen_link is not None:
        chosen = chosen_link
    elif links and 0 <= chosen_idx < len(links):
        chosen = links[chosen_idx]
    else:
        return False
    _enrich_link_metadata(chosen, meta, matched_item)
    sync_tmdbhelper_playerstring(meta)

    media_key = _get_media_key(meta, chosen)
    is_s = bool(meta.get('season') and meta.get('episode'))
    bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s, season=meta.get('season'), episode=meta.get('episode'))
    seek_to_time = 0
    start_beginning = False
    if bm:
        r_time = float(bm.get('resume_time', 0))
        if r_time > 10:
            mins = int(r_time // 60); secs = int(r_time % 60); hrs = mins // 60; mins = mins % 60
            time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
            _rsel = show_resume_dialog(time_str, meta.get('title', ''))
            if _rsel == 0:
                seek_to_time = r_time
            elif _rsel == 1:
                seek_to_time = 0
                start_beginning = True
                save_bookmark(media_key, 0, 0, title=meta.get('title', ''))
            elif _rsel is None or _rsel < 0:
                return 'cancel'

    eng = getattr(chosen, 'bridge_engine', '') or engine or 'alfa'
    played = _play_link_safely(chosen, engine=eng, matched_item=matched_item, meta=meta, is_switch=True, seek_to_time=seek_to_time, start_beginning=start_beginning)
    if played in ('cancel', 'no_client'):
        return played
    if played:
        mon_idx = global_idx if global_idx is not None else chosen_idx
        start_playback_monitor(media_key, title_str=meta.get('title', ''), seek_to_time=seek_to_time, current_link_index=mon_idx, meta=meta, force_beginning=start_beginning)
        return True
    return False


def _is_kodi_modal_dialog_open():
    """Detecta de forma fiable si Kodi tiene visible o activo el dialogo modal de error nativo (DialogOK: 10100)."""
    for cond in (
        "Window.IsVisible(10100)",
        "Window.IsActive(10100)",
        "Window.IsVisible(okdialog)",
        "Window.IsActive(okdialog)",
        "Window.IsVisible(dialogok)",
        "Window.IsActive(dialogok)",
    ):
        try:
            if xbmc.getCondVisibility(cond):
                return True
        except Exception:
            pass
    return False


def _wait_for_kodi_modal_dialog_to_dismiss(mon=None, max_wait=60.0):
    """Espera pacientemente a que el usuario presione Aceptar / OK / Cerrar en el dialogo de error de Kodi."""
    if mon is None:
        mon = xbmc.Monitor()
    t0 = time.time()
    saw = False
    if _is_kodi_modal_dialog_open():
        saw = True
        xbmc.log("Multi Bridge: detectada ventana de error / dialogo modal de Kodi. Esperando a que el usuario presione Aceptar...", xbmc.LOGINFO)
        while _is_kodi_modal_dialog_open():
            if mon.abortRequested() or (time.time() - t0) > max_wait:
                break
            xbmc.sleep(80)
        # Esperar a que la animacion de cierre del dialogo termine completamente en Kodi
        xbmc.sleep(250)
        xbmc.log("Multi Bridge: dialogo modal de Kodi cerrado por el usuario.", xbmc.LOGINFO)
    return saw


def _verify_playback_started(is_torrent=False, timeout=None, ignore_file=None):
    p = xbmc.Player()
    mon = xbmc.Monitor()
    if timeout is None:
        timeout = 40.0 if is_torrent else 25.0
    return _wait_for_playback_progress(player=p, mon=mon, timeout=timeout, server_name="ManualSwitch", ignore_file=ignore_file)
def show_floating_links_dialog(offset=0):
    global _search_in_progress, _links_view_active
    _search_in_progress = False
    _links_view_active = True
    _apply_silence_all()
    if _is_dialog_active_global():
        xbmc.log("Multi Bridge: show_floating_links_dialog omitido porque ya hay un diálogo activo", xbmc.LOGINFO)
        return False
    _set_dialog_active_global(True)
    try:
        return _show_floating_links_dialog_impl(offset=offset)
    finally:
        _set_dialog_active_global(False)
        _links_view_active = False
        _restore_silence_all()

def _show_floating_links_dialog_impl(offset=0):
    p = xbmc.Player()
    is_playing = False
    cur_playback_time = 0.0
    try:
        is_playing = p.isPlayingVideo()
        if is_playing:
            cur_playback_time = float(p.getTime())
    except Exception:
        pass

    if is_playing and not xbmc.getCondVisibility("Player.Paused"):
        try: p.pause()
        except: pass

    c_links, c_matched, c_meta, c_eng = _load_cached_links_for_dialog(offset=offset)
    if not c_links:
        _show_bridge_notification('Multi Bridge', 'No hay enlaces disponibles', 3000)
        return False

    media_key = _get_media_key(c_meta, c_links[0] if c_links else None)
    failed_signatures = _get_session_failed_signatures(media_key=media_key, meta=c_meta)
    failed_links = set()
    failed_indices = set()
    for idx, l in enumerate(c_links):
        sig = _get_link_unique_id(l)
        if getattr(l, 'bridge_failed', False) or (sig and sig in failed_signatures):
            failed_links.add(l)
            failed_indices.add(idx)
    last_tab = None
    curr_idx_prop = -1
    try:
        curr_idx_str = xbmcgui.Window(10000).getProperty('BridgeMulti.CurrentPlayingIndex')
        if curr_idx_str and curr_idx_str.isdigit():
            curr_idx_prop = int(curr_idx_str)
    except Exception:
        pass
    effective_playing_idx = curr_idx_prop if curr_idx_prop >= 0 else _current_playing_link_index
    next_suggested_idx = effective_playing_idx if (is_playing and 0 <= effective_playing_idx < len(c_links)) else 0
    was_playback = is_playing

    # Ajuste on_link_fail: 0 = Reabrir ventana con enlace marcado (Recomendado), 1 = Desactivado
    on_fail_setting = str(_bridge_addon.getSetting('on_link_fail') or '0').strip()

    while True:
        # Asegurar que ningun dialogo modal de error de Kodi este abierto antes de mostrar la lista
        if _is_kodi_modal_dialog_open():
            _wait_for_kodi_modal_dialog_to_dismiss(max_wait=60.0)

        # Si todos los enlaces disponibles han fallado, notificar y salir
        if len(failed_indices) >= len(c_links) and len(c_links) > 0:
            _show_bridge_notification('Multi Bridge', 'Todos los enlaces probados han fallado', 3500)
            _clear_session_failed_links(media_key)
            for _l in c_links:
                try: setattr(_l, 'bridge_failed', False)
                except Exception: pass
            if was_playback and xbmc.getCondVisibility("Player.Paused") and p.isPlayingVideo():
                try: p.pause()
                except: pass
            return False

        dlg = _FloatingLinksDialog(
            c_links,
            current_index=next_suggested_idx,
            meta=c_meta,
            engine=c_eng,
            is_playback=was_playback,
            failed_links=failed_links,
            initial_tab=last_tab,
            offset=offset
        )
        dlg.doModal()
        chosen_idx = dlg.selected
        chosen_link = getattr(dlg, 'selected_link', None)
        last_tab = dlg.active_tab
        del dlg
        xbmc.sleep(150)

        if chosen_idx == 'force_search':
            try:
                if p.isPlayingVideo():
                    p.stop()
            except Exception:
                pass
            _u = 'plugin://plugin.video.bridge.multi/?action=force_search'
            _t_id = str(c_meta.get('tmdb') or c_meta.get('tmdb_id') or '')
            _s = str(c_meta.get('season') or '')
            _e = str(c_meta.get('episode') or '')
            _t = str(c_meta.get('title') or '')
            _sn = str(c_meta.get('showname') or '')
            _y = str(c_meta.get('year') or '')
            _sy = str(c_meta.get('showyear') or '')
            _imdb = str(c_meta.get('imdb') or c_meta.get('imdb_id') or '')
            _eng = str(c_eng or c_meta.get('engine') or '')
            if _t_id: _u += '&tmdb=' + _t_id
            if _s and _e: _u += '&season=' + _s + '&episode=' + _e
            if _t: _u += '&title=' + uparse.quote_plus(_t)
            if _sn: _u += '&showname=' + uparse.quote_plus(_sn)
            if _y: _u += '&year=' + _y
            if _sy: _u += '&showyear=' + _sy
            if _imdb: _u += '&imdb=' + _imdb
            if _eng: _u += '&engine=' + _eng
            xbmc.executebuiltin('RunPlugin(%s)' % _u)
            return True

        if chosen_idx == 'verify_links':
            try:
                if p.isPlayingVideo():
                    p.stop()
            except Exception:
                pass
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.bridge.multi/?action=verify_links)')
            return True

        if chosen_idx == 'other_engine':
            try:
                if p.isPlayingVideo():
                    p.stop()
            except Exception:
                pass
            _other_engine = 'balandro' if c_eng == 'alfa' else 'alfa'
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.bridge.multi/?action=search_other_engine&engine=%s)' % _other_engine)
            return True

        if not (isinstance(chosen_idx, int) and chosen_idx >= 0):
            # El usuario canceló o presionó Atrás (cierre manual: limpiar fallidos para apertura limpia posterior)
            _clear_session_failed_links(media_key)
            for _l in c_links:
                try: setattr(_l, 'bridge_failed', False)
                except Exception: pass
            if was_playback and xbmc.getCondVisibility("Player.Paused") and p.isPlayingVideo():
                try: p.pause()
                except: pass
            return False

        # Intentar reproducir el enlace seleccionado
        if chosen_link is None:
            if isinstance(chosen_idx, int) and 0 <= chosen_idx < len(c_links):
                chosen_link = c_links[chosen_idx]
            else:
                continue
        srv_name = _get_link_server_name(chosen_link) or 'Servidor'
        is_tor = (srv_name.lower() == 'torrent' or _is_torrent_link(chosen_link))

        if was_playback:
            try:
                _prev_sw_file = p.getPlayingFile() if p.isPlayingVideo() else ''
            except Exception:
                _prev_sw_file = ''
            played = _switch_to_link(chosen_idx, c_links, c_meta, c_matched, engine=c_eng, force_cur_time=cur_playback_time, chosen_link=chosen_link)
        else:
            _prev_sw_file = ''
            played = _play_link_from_dialog(chosen_idx, c_links, c_meta, c_matched, engine=c_eng, global_idx=(chosen_idx + offset), chosen_link=chosen_link)

        if played in ('cancel', 'no_client'):
            continue

        playback_ok = False
        if played:
            playback_ok = _verify_playback_started(is_torrent=is_tor, ignore_file=_prev_sw_file or None)

        if playback_ok or p.isPlayingVideo():
            return True

        if on_fail_setting == '1':
            return False

        # Enlace fallido: si played fue False (o Kodi aun esta por lanzar DialogOK),
        # dar una ventana de gracia de hasta 1.5s para atrapar la apertura del cartel nativo
        if not played:
            for _chk in range(15):
                if _is_kodi_modal_dialog_open():
                    break
                xbmc.sleep(100)

        # Si el cartel de error de Kodi esta en pantalla, esperar pacientemente a que el usuario presione Aceptar
        if _is_kodi_modal_dialog_open():
            _wait_for_kodi_modal_dialog_to_dismiss(max_wait=60.0)

        # Enlace fallido: registrar y reabrir
        if chosen_link:
            failed_links.add(chosen_link)
            failed_indices.add(chosen_idx)
            _record_session_failed_link(chosen_link, index=chosen_idx, media_key=media_key, meta=c_meta)

        xbmc.log("Multi Bridge: enlace %d (%s) falló al reproducir. Reabriendo ventana..." % (chosen_idx + 1, srv_name), xbmc.LOGWARNING)

        # Buscar el siguiente enlace no fallido en la pestaña activa
        active_list = []
        for l in c_links:
            _s = _get_link_server_name(l).strip().lower()
            _t = (_s == 'torrent' or _is_torrent_link(l))
            if (last_tab == 1 and _t) or (last_tab != 1 and not _t):
                active_list.append(l)

        next_suggested_idx = chosen_idx + 1
        if chosen_link in active_list:
            cur_tab_pos = active_list.index(chosen_link)
            found_next = None
            for off in range(1, len(active_list)):
                cand = active_list[(cur_tab_pos + off) % len(active_list)]
                if cand not in failed_links:
                    found_next = c_links.index(cand)
                    break
            if found_next is not None:
                next_suggested_idx = found_next
            elif next_suggested_idx >= len(c_links):
                next_suggested_idx = 0
        elif next_suggested_idx >= len(c_links):
            next_suggested_idx = 0

        xbmc.sleep(100)


def _open_links_view(win_url=""):
    """Abre la ventana flotante personalizada instantanea (0% carga de CPU)."""
    global _search_in_progress, _links_view_active
    _search_in_progress = False
    _links_view_active = True
    _apply_silence_all()
    show_floating_links_dialog()
# ---------------------------------------------------------
# Main Execution Entry Point
# ---------------------------------------------------------
def main():
    global handle, original_argv, action, view, url, engine_param
    global plot, plot_lat, plot_es, tagline, tagline_lat, tagline_es
    global title, title_es, title_lat, title_en, title_orig
    global showname, year, showyear, season, episode
    global tmdb_id, imdb_id, tvdb_id, trakt_id
    global poster, fanart, thumbnail, director, clearlogo, genre

    # Re-sincronizar handle y parámetros en cada invocación (vital para reuselanguageinvoker a 0 ms)
    handle = -1
    if len(sys.argv) > 1 and sys.argv[1]:
        try: handle = int(sys.argv[1])
        except Exception: handle = -1
    original_argv = list(sys.argv)

    url = get_param('url')
    action = get_param('action')
    view = get_param('view')
    engine_param = get_param('engine')
    title = get_param('title')
    year = get_param('year')
    season = get_param('season')
    episode = get_param('episode')
    showname = get_param('showname')
    showyear = get_param('showyear')
    title_es = get_param('title_es')
    title_lat = get_param('title_lat')
    title_en = get_param('title_en')
    title_orig = get_param('title_orig')
    tmdb_id = get_param('tmdb')
    imdb_id = get_param('imdb')
    tvdb_id = get_param('tvdb')
    trakt_id = get_param('trakt')
    plot = get_param('plot')
    plot_lat = get_param('plot_lat')
    plot_es = get_param('plot_es')
    director = get_param('director')
    tagline = get_param('tagline')
    tagline_lat = get_param('tagline_lat')
    tagline_es = get_param('tagline_es')
    poster = get_param('poster')
    fanart = get_param('fanart')
    thumbnail = get_param('thumbnail') or get_param('thumb')
    clearlogo = get_param('clearlogo')
    genre = get_param('genre')

    if action not in ('switch_source', 'floating_links', 'play_single_link'):
        check_and_run_migration()
        check_first_run_device()

    if clearlogo in ('_', 'None', 'none'):
        clearlogo = ''
    if genre in ('_', 'None', 'none'):
        genre = ''


    if action in ('switch_source', 'floating_links'):
        try:
            xbmc.executebuiltin('Dialog.Close(busydialog, true)')
            xbmc.executebuiltin('Dialog.Close(busydialognocancel, true)')
        except Exception:
            pass
        _offset_str = get_param('offset')
        try: _offset = int(_offset_str) if _offset_str else 0
        except: _offset = 0
        show_floating_links_dialog(offset=_offset)
        return

    if action == 'remove_continue_watching':
        mk = get_param('media_key')
        if mk:
            remove_continue_watching_record(mk)
            xbmcgui.Dialog().notification('Multi Bridge', 'Elemento quitado', '', 2500)
            xbmc.executebuiltin('Container.Refresh')
        return

    if action == 'clear_all_continue_watching':
        if xbmcgui.Dialog().yesno('Continuar viendo', '¿Seguro que deseas vaciar toda la lista de Continuar viendo?'):
            clear_all_continue_watching()
            xbmcgui.Dialog().notification('Multi Bridge', 'Lista vaciada', '', 2500)
            xbmc.executebuiltin('Container.Refresh')
        return

    if action == 'verify_remaining_preloaded':
        _verify_remaining_preloaded_impl()
        return

    if action == 'configure_device':
        prompt_first_run_device(_bridge_addon, force=True)
        return

    if not action and not url:
        if not view or view == 'home': show_player_manager_home()
        elif view == 'continue_watching': show_continue_watching()
        elif view == 'list_players': show_players_list(engine_param or 'alfa')
        elif view in ('player_options', 'channel_options'): show_player_options(get_param('channel') or get_param('player'), engine_param or 'alfa')
        elif view == 'create_player': create_player_wizard()
        elif view == 'update_cloud': update_players_from_cloud()
        elif view == 'settings': _bridge_addon.openSettings(); (show_player_manager_home() if handle >= 0 else None)
        elif view == 'list_links':
            show_floating_links_dialog()
            if handle >= 0:
                try: xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
                except Exception: pass
        else: show_player_manager_home()
        return

    if action == 'search_other_engine':
        try:
            _p = xbmc.Player()
            if _p.isPlayingVideo():
                _p.stop()
        except Exception:
            pass

        _se_engine = get_param('engine') or 'alfa'

        # Cargar el cache e inyectar metadata
        _se_meta = {}
        _se_item = None
        try:
            _sc = _read_search_cache_atomic()
            if _sc and isinstance(_sc, dict):
                _se_meta = _sc.get('meta', {}) or {}
                _se_item = _deserialize_item(_sc.get('item'), _se_engine)
        except: pass

        _se_is_series = bool(season or get_param('season') or (_se_meta.get('season') and _se_meta.get('episode')))
        if _se_is_series and _se_engine == 'alfa':
            xbmcgui.Dialog().notification('Multi Bridge', 'Alfa solo está disponible para películas', '', 3500)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        def _g(k): return _se_meta.get(k) or ''

        title      = _g('title')      or title
        title_es   = _g('title_es')
        title_lat  = _g('title_lat')
        title_en   = _g('title_en')
        title_orig = _g('title_orig')
        showname   = _g('showname')   or showname
        year       = _g('year')       or year
        showyear   = _g('showyear')   or showyear
        season     = _g('season')     or season
        episode    = _g('episode')    or episode
        tmdb_id    = _g('tmdb')       or tmdb_id
        imdb_id    = _g('imdb')       or imdb_id
        tvdb_id    = _g('tvdb')       or tvdb_id
        trakt_id   = _g('trakt')      or trakt_id

        xbmc.log('Multi Bridge: search_other_engine=%s title=%s tmdb=%s' % (_se_engine, title, tmdb_id), xbmc.LOGINFO)

        _se_links, _se_matched = run_parallel_search(engine=_se_engine)

        _se_verified = (getattr(_se_matched, '_pipeline_verified', False) if _se_matched else False) or _PIPELINE_VERIFIED_SEARCH
        _auto_v = _bridge_addon.getSetting('auto_verify_links') == 'true'
        if _se_links and _auto_v and not _se_verified:
            _pv = xbmcgui.DialogProgress()
            _pv.create('Multi Bridge', 'Comprobando disponibilidad...')
            _vl = _verify_links_headless(_se_links, engine=_se_engine, p_dialog=_pv)
            try: _pv.close()
            except: pass
            if _vl:
                _se_links = _filter_and_sort_links(_vl)
            else:
                _hc_se = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
                _se_links = _filter_and_sort_links([l for l in _se_links if _is_torrent_link(l) or (not _hc_se and _is_web_captcha_server(_get_link_server_name(l), l))])
            _se_verified = True

        _se_meta2 = dict(_se_meta)
        _se_meta2['engine'] = _se_engine
        _se_meta2['verified_only'] = _se_verified

        if _se_matched:
            _enrich_link_metadata(None, _se_meta2, _se_matched)
        try:
            _store_ram_search_cache(_se_links or [], _se_matched, _se_meta2, _se_engine)
            _save_search_cache_atomic({
                'item': _serialize_item(_se_matched) if _se_matched else None,
                'links': [_serialize_item(l) for l in (_se_links or [])],
                'meta': _se_meta2,
                'engine': _se_engine,
                'cache_ver': 2
            })
        except: pass
        try:
            _spawn_late_collector(_se_engine, _se_meta2.get('tmdb'), _se_meta2.get('season'), _se_meta2.get('episode'))
        except: pass

        if not _se_links:
            _eng_name = 'Alfa' if _se_engine == 'alfa' else 'Balandro'
            xbmcgui.Dialog().notification('Multi Bridge', 'No se encontraron enlaces en %s' % _eng_name, '', 4000)
            xbmcplugin.endOfDirectory(handle, succeeded=False)
            return

        _ts2 = int(time.time())
        _win_url2 = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (str(tmdb_id or _g('tmdb') or ''), _ts2)
        if _se_meta2.get('season') and _se_meta2.get('episode'):
            _win_url2 += '&season=%s&episode=%s' % (_se_meta2['season'], _se_meta2['episode'])
        _open_links_view(_win_url2)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    if action == 'force_search':
        xbmc.log("Multi Bridge: 'Forzar nueva búsqueda' solicitado desde menú contextual", xbmc.LOGINFO)
        try:
            _p = xbmc.Player()
            if _p.isPlayingVideo():
                _p.stop()
        except Exception:
            pass
        _force_meta = {}
        _force_engine = get_param('engine') or 'alfa'
        try:
            _fc = _read_search_cache_atomic()
            if _fc and isinstance(_fc, dict):
                _force_meta = _fc.get('meta', {}) or {}
                _force_engine = _fc.get('engine', _force_engine) or _force_engine
        except Exception:
            pass

        # Invalida completamente toda la caché en memoria, propiedades de ventana y ficheros de disco
        global _RAM_SEARCH_CACHE, _LAST_SEARCH_CACHE_DATA, _LAST_SEARCH_CACHE_MTIME
        _RAM_SEARCH_CACHE = None
        _LAST_SEARCH_CACHE_DATA = None
        _LAST_SEARCH_CACHE_MTIME = 0
        try:
            xbmcgui.Window(10000).setProperty('MultiBridge.SearchCacheJson', '')
        except Exception:
            pass
        try:
            if os.path.exists(SEARCH_CACHE_FILE):
                os.remove(SEARCH_CACHE_FILE)
        except Exception:
            pass
        try:
            if os.path.exists(SEARCH_CACHE_FILE + '.bak'):
                os.remove(SEARCH_CACHE_FILE + '.bak')
        except Exception:
            pass

        def _g(k): return _force_meta.get(k) or get_param(k) or ''

        title      = _g('title')      or title
        title_es   = _g('title_es')
        title_lat  = _g('title_lat')
        title_en   = _g('title_en')
        title_orig = _g('title_orig')
        showname   = _g('showname')   or showname
        year       = _g('year')       or year
        showyear   = _g('showyear')   or showyear
        season     = _g('season')     or season
        episode    = _g('episode')    or episode
        tmdb_id    = _g('tmdb')       or tmdb_id
        imdb_id    = _g('imdb')       or imdb_id
        tvdb_id    = _g('tvdb')       or tvdb_id
        trakt_id   = _g('trakt')      or trakt_id
        plot       = _g('plot')       or plot
        tagline    = _g('tagline')    or tagline
        poster     = _g('poster')     or poster
        fanart     = _g('fanart')     or fanart
        thumbnail  = _g('thumbnail')  or thumbnail
        clearlogo  = _g('clearlogo')  or clearlogo
        genre      = _g('genre')      or genre
        director   = _g('director')   or director

        # Limpiar fallidos para este contenido
        _media_k = _get_media_key(_force_meta)
        if _media_k:
            _clear_session_failed_links(_media_k)

        eng = _force_engine or 'alfa'
        if bool(season and episode):
            eng = 'balandro'

        xbmc.log("Multi Bridge: Ejecutando búsqueda fresca para '%s' (motor=%s)" % (title, eng), xbmc.LOGINFO)
        _force_links, _force_matched = run_parallel_search(engine=eng)

        _force_verified = (getattr(_force_matched, '_pipeline_verified', False) if _force_matched else False) or _PIPELINE_VERIFIED_SEARCH
        _auto_v = _bridge_addon.getSetting('auto_verify_links') == 'true'
        if _force_links and _auto_v and not _force_verified:
            _pv = xbmcgui.DialogProgress()
            _pv.create('Multi Bridge', 'Comprobando disponibilidad...')
            _vl = _verify_links_headless(_force_links, engine=eng, p_dialog=_pv)
            try: _pv.close()
            except: pass
            if _vl:
                _force_links = _filter_and_sort_links(_vl)
            else:
                _hc_fr = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
                _force_links = _filter_and_sort_links([l for l in _force_links if _is_torrent_link(l) or (not _hc_fr and _is_web_captcha_server(_get_link_server_name(l), l))])
            _force_verified = True

        _force_meta2 = dict(_force_meta)
        _force_meta2['engine'] = eng
        _force_meta2['verified_only'] = _force_verified
        if _force_matched:
            _enrich_link_metadata(None, _force_meta2, _force_matched)

        try:
            _store_ram_search_cache(_force_links or [], _force_matched, _force_meta2, eng)
            _save_search_cache_atomic({
                'item': _serialize_item(_force_matched) if _force_matched else None,
                'links': [_serialize_item(l) for l in (_force_links or [])],
                'meta': _force_meta2,
                'engine': eng,
                'cache_ver': 2
            })
        except Exception:
            pass

        try:
            _spawn_late_collector(eng, _force_meta2.get('tmdb'), _force_meta2.get('season'), _force_meta2.get('episode'))
        except Exception:
            pass

        # Reabrir la ventana de lista de enlaces fresca
        _cur_tmdb = str(tmdb_id or _force_meta2.get('tmdb') or '')
        _ts = int(time.time())
        _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
        if _force_meta2.get('season') and _force_meta2.get('episode'):
            _win_url += '&season=%s&episode=%s' % (_force_meta2['season'], _force_meta2['episode'])
        _open_links_view(_win_url)
        if handle >= 0:
            try: xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
            except Exception: pass
        return

    if action == 'verify_links':
        verify_and_filter_links()
        return

    if action == 'play_single_link':
        _android_stop_playback_if_active()
        idx_str = get_param('index')
        eng = engine_param or 'alfa'
        try: idx = int(idx_str)
        except: idx = 0
        links = []
        matched_item = None
        meta = {}
        cache = _read_search_cache_atomic()
        if cache and isinstance(cache, dict):
            try:
                engine = cache.get('engine', 'alfa')
                # Clases resueltas una sola vez (no una por enlace)
                _d_mods = _get_alfa_modules() if engine == 'alfa' else _get_balandro_modules()
                if _d_mods:
                    _d_Item, _d_Info = _d_mods['Item'], _d_mods['InfoLabels']
                    links = [_deserialize_item_fast(_d_Item, _d_Info, lnk) for lnk in cache.get('links', [])]
                    matched_item = _deserialize_item_fast(_d_Item, _d_Info, cache.get('item'))
                else:
                    links = [_deserialize_item(lnk, engine) for lnk in cache.get('links', [])]
                    matched_item = _deserialize_item(cache.get('item'), engine)
                links = [l for l in links if l is not None]
                meta = cache.get('meta', {})
            except: pass

        if links and 0 <= idx < len(links):
            chosen = links[idx]
            try:
                xbmc.log("Multi Bridge: play click idx=%d/%d canal=%s server=%s url=%s data_url=%s" % (
                    idx, len(links), _safe_str(getattr(chosen, 'channel', '')),
                    _safe_str(getattr(chosen, 'server', '')),
                    _safe_str(getattr(chosen, 'url', '') or '')[:60],
                    'si' if _safe_str(getattr(chosen, 'data_url', '') or '') else 'no'), xbmc.LOGINFO)
            except: pass
            _enrich_link_metadata(chosen, meta, matched_item)
            media_key = _get_media_key(meta, chosen)
            is_s = bool(meta.get('season') and meta.get('episode'))
            bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s, season=meta.get('season'), episode=meta.get('episode'))
            seek_to_time = 0
            start_beginning = False
            if bm:
                r_time = float(bm.get('resume_time', 0))
                mins = int(r_time // 60); secs = int(r_time % 60); hrs = mins // 60; mins = mins % 60
                time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
                t_title = meta.get('title') or getattr(matched_item, 'title', '') or 'este vídeo'
                _rsel = show_resume_dialog(time_str, t_title)
                if _rsel == 0:
                    seek_to_time = r_time
                elif _rsel == 1:
                    seek_to_time = 0
                    start_beginning = True
                    save_bookmark(media_key, 0, 0, title=t_title)
                elif _rsel is None or _rsel < 0:
                    if handle >= 0:
                        try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                        except: pass
                    return

            played = _play_link_safely(chosen, engine=eng, matched_item=matched_item, meta=meta, seek_to_time=seek_to_time, start_beginning=start_beginning)
            if played in ('cancel', 'no_client'):
                return
            if played:
                start_playback_monitor(media_key, title_str=meta.get('title', ''), seek_to_time=seek_to_time, current_link_index=idx, meta=meta, force_beginning=start_beginning)
                wait_for_playback_monitor()
            else:
                if handle > 0:
                    try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                    except: pass
        else:
            if handle > 0:
                try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                except: pass
            _show_bridge_notification('Multi Bridge', 'Enlace no disponible', 3000)
        return

    def _play_action_impl(_tentative_title):
        global plot, plot_lat, plot_es, tagline, tagline_lat, tagline_es
        global title, title_es, title_lat, title_en, title_orig
        global showname, year, showyear, season, episode
        global tmdb_id, imdb_id, tvdb_id, trakt_id
        global poster, fanart, thumbnail, director, clearlogo, genre
        try:
            _prev_f = xbmc.getInfoLabel("Container.FolderPath") or ''
            if _prev_f and "plugin.video.bridge.multi" not in _prev_f:
                _bridge_addon.setSetting("last_caller_folder", _prev_f)
                try: xbmcgui.Window(10000).setProperty("MultiBridge.LastCallerFolder", _prev_f)
                except Exception: pass
                xbmc.log("Multi Bridge: last_caller_folder guardado -> " + _prev_f, xbmc.LOGINFO)
        except Exception:
            pass
  # Cerrar inmediatamente el diálogo "Elige Acción" de TMDb Helper que queda abierto
        # mientras nuestro plugin corre. Lo hacemos al inicio antes de cualquier búsqueda.
        try:
            xbmc.executebuiltin('Dialog.Close(10101,true)')
        except: pass
        try:
            if xbmc.Player().isPlaying(): xbmc.Player().stop()
        except: pass

        _s_check = season if season is not None and str(season).strip() != '' else get_param('season')
        _e_check = episode if episode is not None and str(episode).strip() != '' else get_param('episode')
        _is_s_play = bool(_s_check is not None and str(_s_check).strip() != '' and _e_check is not None and str(_e_check).strip() != '')

        # Comprobar si hay canales configurados al invocar desde TMDb Helper
        ch_data = load_channels_data()
        _all_alfa = ch_data.get('channels', {}).get('alfa', {})
        _all_bal = ch_data.get('channels', {}).get('balandro', {})
        if not _all_alfa and not _all_bal:
            opt = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)().yesno(
                'Multi Bridge — Sin Canales',
                'No hay ningún canal configurado en Multi Bridge.\n\n'
                'Para buscar y reproducir contenido debes importar los canales:\n'
                '1. Abre el add-on [B]Multi Bridge[/B]\n'
                '2. Entra en [B]Importar / Actualizar Canales desde la Nube[/B]\n'
                '3. Confirma la descarga desde GitHub\n\n'
                '¿Deseas descargar e importar los canales ahora mismo desde la Nube?'
            )
            if opt:
                try:
                    update_players_from_cloud()
                except Exception as _e:
                    xbmc.log("Multi Bridge: error al importar canales desde aviso: %s" % _e, xbmc.LOGWARNING)
                ch_data = load_channels_data()
                _all_alfa = ch_data.get('channels', {}).get('alfa', {})
                _all_bal = ch_data.get('channels', {}).get('balandro', {})
            if not _all_alfa and not _all_bal:
                return

        if _is_s_play:
            _bal_series = [c for c in _all_bal.values() if c.get('series') and not c.get('series_disabled')]
            if not _bal_series:
                opt_s = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)().yesno(
                    'Multi Bridge — Sin Canales de Series',
                    'No hay ningún canal de series activo en Balandro.\n\n'
                    '¿Deseas importar los canales de la Nube ahora mismo?'
                )
                if opt_s:
                    try:
                        update_players_from_cloud()
                    except Exception as _e:
                        xbmc.log("Multi Bridge: error importando canales: %s" % _e, xbmc.LOGWARNING)
                    ch_data = load_channels_data()
                    _all_bal = ch_data.get('channels', {}).get('balandro', {})
                    _bal_series = [c for c in _all_bal.values() if c.get('series') and not c.get('series_disabled')]
                if not _bal_series:
                    (_KODI_ORIG_DIALOG or xbmcgui.Dialog)().ok(
                        'Multi Bridge — Sin Canales de Series',
                        'Para ver series:\n1. Ve a [B]Multi Bridge > Gestor de Canales de Balandro[/B] y activa canales de series, o\n2. Usa [B]Importar / Actualizar Canales desde la Nube[/B].'
                    )
                    return
        else:
            _alfa_movies = [c for c in _all_alfa.values() if c.get('movies') and not c.get('movie_disabled')]
            _bal_movies = [c for c in _all_bal.values() if c.get('movies') and not c.get('movie_disabled')]
            if not _alfa_movies and not _bal_movies:
                opt_m = (_KODI_ORIG_DIALOG or xbmcgui.Dialog)().yesno(
                    'Multi Bridge — Sin Canales de Películas',
                    'No hay ningún canal de películas activo en Multi Bridge.\n\n'
                    '¿Deseas importar los canales de la Nube ahora mismo?'
                )
                if opt_m:
                    try:
                        update_players_from_cloud()
                    except Exception as _e:
                        xbmc.log("Multi Bridge: error importando canales: %s" % _e, xbmc.LOGWARNING)
                    ch_data = load_channels_data()
                    _all_alfa = ch_data.get('channels', {}).get('alfa', {})
                    _all_bal = ch_data.get('channels', {}).get('balandro', {})
                    _alfa_movies = [c for c in _all_alfa.values() if c.get('movies') and not c.get('movie_disabled')]
                    _bal_movies = [c for c in _all_bal.values() if c.get('movies') and not c.get('movie_disabled')]
                if not _alfa_movies and not _bal_movies:
                    (_KODI_ORIG_DIALOG or xbmcgui.Dialog)().ok(
                        'Multi Bridge — Sin Canales de Películas',
                        'Para ver películas:\n1. Ve a [B]Multi Bridge > Gestor de Canales[/B] y activa algún canal, o\n2. Usa [B]Importar / Actualizar Canales desde la Nube[/B].'
                    )
                    return
        _res_meta = _resolve_localized_metadata(
            tmdb_id=tmdb_id or get_param('tmdb'),
            is_series=_is_s_play,
            season=season or get_param('season'),
            episode=episode or get_param('episode'),
            plot_lat=plot_lat or get_param('plot_lat'),
            plot_es=plot_es or get_param('plot_es'),
            plot_param=plot or get_param('plot'),
            tagline_lat=tagline_lat or get_param('tagline_lat'),
            tagline_es=tagline_es or get_param('tagline_es'),
            tagline_param=tagline or get_param('tagline'),
            title_lat=title_lat or get_param('title_lat'),
            title_es=title_es or get_param('title_es'),
            title_param=title or get_param('title') or showname or get_param('showname')
        )
        if _res_meta.get('plot'):
            plot = _res_meta['plot']
        if _res_meta.get('tagline') is not None:
            tagline = _res_meta['tagline']
        if _res_meta.get('title') and _res_meta.get('has_spanish'):
            title = _res_meta['title']

        _init_meta = {
            'tmdb': tmdb_id or get_param('tmdb'),
            'imdb': imdb_id or get_param('imdb'),
            'tvdb': tvdb_id or get_param('tvdb'),
            'trakt': trakt_id or get_param('trakt'),
            'title': title or get_param('title') or get_param('title_es') or get_param('title_lat') or ((showname if (season and episode) else '') or ''),
            'year': (showyear or get_param('showyear')) if (season and episode) else (year or get_param('year')),
            'season': season or get_param('season'),
            'episode': episode or get_param('episode'),
            'showname': showname or get_param('showname'),
            'showyear': showyear or get_param('showyear'),
            'plot': plot,
            'tagline': tagline,
            'poster': poster or get_param('poster'),
            'fanart': fanart or get_param('fanart'),
            'thumbnail': thumbnail or get_param('thumbnail'),
            'clearlogo': (clearlogo if clearlogo and clearlogo not in ('_', 'None') else '') or (get_param('clearlogo') if get_param('clearlogo') not in ('_', 'None', None) else '') or _get_clearlogo(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode')))),
            'genre': (genre if genre and genre not in ('_', 'None') else '') or (get_param('genre') if get_param('genre') not in ('_', 'None', None) else '') or " / ".join(_get_genres(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode'))))),
            'director': _clean_single_director(director) or _clean_single_director(get_param('director')) or (_get_directors(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode')))) or [''])[0]
        }
        sync_tmdbhelper_playerstring(_init_meta)
        _update_search_lock_title(title or showname or _tentative_title)

        links = []
        matched_item = None
        meta = dict(_init_meta)

        # Reutilizar cache reciente si corresponde EXACTAMENTE al mismo contenido
        # (misma película o mismo episodio de serie con idéntica temporada y número de episodio)
        # Respetar tiempo configurable (por defecto 10 min = 600s, 0 = buscar siempre).
        # Si force_search=1 viene por parámetro, se omite la caché y se busca fresco.
        _force_search = get_param('force_search') in ('1', 'true', 'True')
        if _force_search:
            global _RAM_SEARCH_CACHE, _LAST_SEARCH_CACHE_DATA, _LAST_SEARCH_CACHE_MTIME
            _RAM_SEARCH_CACHE = None
            _LAST_SEARCH_CACHE_DATA = None
            _LAST_SEARCH_CACHE_MTIME = 0
            try:
                xbmcgui.Window(10000).setProperty('MultiBridge.SearchCacheJson', '')
                if os.path.exists(SEARCH_CACHE_FILE): os.remove(SEARCH_CACHE_FILE)
                if os.path.exists(SEARCH_CACHE_FILE + '.bak'): os.remove(SEARCH_CACHE_FILE + '.bak')
            except Exception: pass
        _cache_timeout_mins = _get_int_setting('cache_links_timeout', 10)
        _cache_max_age_secs = max(0, _cache_timeout_mins * 60)

        _use_cache = False
        _cached_payload = None
        try:
            if not _force_search and _cache_max_age_secs > 0 and os.path.exists(SEARCH_CACHE_FILE):
                import time as _time
                _mtime = os.path.getmtime(SEARCH_CACHE_FILE)
                _age = _time.time() - _mtime
                if _age < _cache_max_age_secs:
                    _c = _read_search_cache_atomic()
                    _c_meta = {}
                    _c_links = []
                    _cached_engine = 'alfa'
                    if _c and isinstance(_c, dict):
                        _c_meta = _c.get('meta', {}) or {}
                        _c_links = _c.get('links', [])
                        _cached_engine = _c.get('engine', 'alfa') or 'alfa'

                    _auto_v_chk = (_bridge_addon.getSetting('auto_verify_links') == 'true')
                    _stale_unverified_cache = (_auto_v_chk and _c and _c.get('cache_ver') != 2 and not _c_meta.get('verified_only'))
                    if _stale_unverified_cache:
                        xbmc.log("Multi Bridge: caché antigua sin cache_ver=2 descartada para exigir enlaces verificados.", xbmc.LOGINFO)
                    elif _c_links and _is_same_media_item(_c_meta, _init_meta):
                        _cur_def_eng = _get_int_setting('default_engine', 0)
                        if _is_s_play:
                            # Para series, Balandro es el único motor. Si la cache es de Balandro, es válida
                            if _cached_engine == 'balandro':
                                _use_cache = True
                                _cached_payload = _c
                                xbmc.log(f"Multi Bridge: cache reciente {_age:.1f}s para episodio serie ({_get_media_key(_init_meta)}), reutilizando sin nueva búsqueda", xbmc.LOGINFO)
                            else:
                                _use_cache = False
                        elif _cur_def_eng == 1 and _cached_engine != 'alfa':
                            _use_cache = False
                        elif _cur_def_eng == 2 and _cached_engine != 'balandro':
                            _use_cache = False
                        else:
                            _use_cache = True
                            _cached_payload = _c
                            xbmc.log(f"Multi Bridge: cache reciente {_age:.1f}s para {_get_media_key(_init_meta)}, reutilizando sin nueva búsqueda", xbmc.LOGINFO)
                    elif _c_links:
                        xbmc.log(f"Multi Bridge: cache descartada (pertenece a otro contenido: cache={_get_media_key(_c_meta)} vs actual={_get_media_key(_init_meta)}), buscando fresco", xbmc.LOGINFO)
        except Exception as _ce:
            xbmc.log(f"Multi Bridge: cache reciente error: {_ce}", xbmc.LOGINFO)
            _use_cache = False

        if _use_cache and _cached_payload:
            # Reutilizar cache reciente — respetar ajuste autoplay
            try:
                try:
                    xbmcgui.Dialog().notification('Multi Bridge', 'Enlaces en caché recuperados', xbmcgui.NOTIFICATION_INFO, 2500)
                except Exception:
                    pass
                _c = _cached_payload
                _cached_engine  = _c.get('engine', 'alfa') or 'alfa'
                _raw_c_links    = [l for l in _c.get('links', []) if isinstance(l, dict) and l.get('url')]
                _cached_links   = [_deserialize_item(l, _cached_engine) for l in _raw_c_links]
                _cached_links   = [l for l in _cached_links if l is not None and getattr(l, 'url', None)]
                if not _cached_links:
                    xbmc.log("Multi Bridge: cache reciente sin enlaces deserializables válidos, descartando", xbmc.LOGINFO)
                    _use_cache = False
                _cached_item    = _deserialize_item(_c.get('item'), _cached_engine)
                _cached_meta    = _c.get('meta', {})
                _cached_tmdb_v  = str(_c.get('meta', {}).get('tmdb') or '')
                _autoplay_cache = _bridge_addon.getSetting('autoplay_enabled') == 'true'

                if _autoplay_cache and _cached_links:
                    xbmc.log('Multi Bridge: cache reciente → autoplay instantáneo con %d enlaces' % len(_cached_links), xbmc.LOGINFO)
                    if _fast_autoplay_search_and_play(_cached_engine, handle, cached_links=_cached_links, cached_item=_cached_item):
                        return
                    if xbmcgui.Window(10000).getProperty("bridge.autoplay_canceled") == "true":
                        xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "")
                        xbmc.log("Multi Bridge: autoplay desde caché cancelado por el usuario, saliendo limpiamente.", xbmc.LOGINFO)
                        if handle >= 0:
                            try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                            except: pass
                        return

                else:
                    # Autoplay desactivado → abrir lista de enlaces
                    xbmc.log('Multi Bridge: cache reciente → abriendo list_links', xbmc.LOGINFO)
                    _ts3 = int(time.time())
                    _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cached_tmdb_v, _ts3)
                    if _cached_meta.get('season') and _cached_meta.get('episode'):
                        _win_url += '&season=%s&episode=%s' % (_cached_meta['season'], _cached_meta['episode'])
                    _open_links_view(_win_url)
                    return
            except Exception as _ce:
                xbmc.log('Multi Bridge: cache reciente error: ' + str(_ce), xbmc.LOGINFO)
                pass  # Si falla, continua con búsqueda normal

        if True:  # forzar fresco, no usar cache (si no es caso de doble busqueda)
            eng = 'alfa'
            def_engine = _get_int_setting('default_engine', 0)
            alfa_ok = _is_engine_installed('alfa')
            bal_ok  = _is_engine_installed('balandro')

            if _is_s_play:
                # Las series son exclusivas de Balandro (Alfa es solo para películas)
                if not bal_ok:
                    xbmcgui.Dialog().ok('Multi Bridge', 'Para reproducir series se requiere tener instalado el addon Balandro.')
                    return
                eng = 'balandro'
                xbmc.log("Multi Bridge: Contenido es serie/episodio y Alfa solo soporta películas. Usando Balandro automáticamente.", xbmc.LOGINFO)
            elif def_engine == 1:
                if alfa_ok:
                    eng = 'alfa'
                elif bal_ok:
                    xbmc.log("Multi Bridge: Motor Alfa no está instalado. Usando Balandro automáticamente.", xbmc.LOGINFO)
                    eng = 'balandro'
                else:
                    xbmcgui.Dialog().ok('Multi Bridge', 'El addon Alfa no está instalado.')
                    return
            elif def_engine == 2:
                if bal_ok:
                    eng = 'balandro'
                elif alfa_ok:
                    xbmc.log("Multi Bridge: Motor Balandro no está instalado. Usando Alfa automáticamente.", xbmc.LOGINFO)
                    eng = 'alfa'
                else:
                    xbmcgui.Dialog().ok('Multi Bridge', 'El addon Balandro no está instalado.')
                    return
            else:
                _picked = _show_engine_picker()
                if _picked is None:
                    return
                eng = _picked

            autoplay = _bridge_addon.getSetting('autoplay_enabled') == 'true'
            if autoplay:
                xbmc.log("Multi Bridge: autoplay activo -> iniciando reproduccion instantanea rapida...", xbmc.LOGINFO)
                if _fast_autoplay_search_and_play(eng, handle):
                    return

                if xbmcgui.Window(10000).getProperty("bridge.autoplay_canceled") == "true":
                    xbmcgui.Window(10000).setProperty("bridge.autoplay_canceled", "")
                    xbmc.log("Multi Bridge: autoplay cancelado por el usuario, saliendo limpiamente sin notificaciones.", xbmc.LOGINFO)
                    if handle >= 0:
                        try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                        except: pass
                    return

                if _bridge_addon.getSetting('autoplay_fallback_normal_search') != 'true':
                    xbmc.log("Multi Bridge: fallback a busqueda normal desactivado por ajuste de usuario", xbmc.LOGINFO)
                    _show_bridge_notification('Multi Bridge', 'Autoplay: no se encontraron enlaces reproducibles', 3000)
                    return

            _cached = None if _force_search else _read_search_cache_atomic()
            if not _force_search and _cached and isinstance(_cached, dict) and _cached.get('links'):
                _c_meta = _cached.get('meta', {}) or {}
                if _is_same_media_item(_c_meta, _init_meta):
                    _c_raw_links = [l for l in _cached.get('links', []) if isinstance(l, dict) and l.get('url')]
                    if _c_raw_links:
                        xbmc.log("Multi Bridge: reutilizando %d enlaces ya recolectados por canales..." % len(_c_raw_links), xbmc.LOGINFO)
                        _c_eng = _cached.get('engine', eng) or eng
                        links = [_deserialize_item(l, _c_eng) for l in _c_raw_links]
                        links = [l for l in links if l is not None and getattr(l, 'url', None)]
                        matched_item = _deserialize_item(_cached.get('item'), _c_eng) if _cached.get('item') else None
                    if not links:
                        links, matched_item = run_parallel_search(engine=eng)
                else:
                    links, matched_item = run_parallel_search(engine=eng)
            else:
                links, matched_item = run_parallel_search(engine=eng)
            verified_flag = (getattr(matched_item, '_pipeline_verified', False) if matched_item else False) or _PIPELINE_VERIFIED_SEARCH
            _auto_verify = _bridge_addon.getSetting('auto_verify_links') == 'true'
            xbmc.log(f"Multi Bridge: auto_verify_links={_auto_verify} engine={eng} links={len(links) if links else 0} pipeline_verified={verified_flag}", xbmc.LOGINFO)
            if links and _auto_verify and not verified_flag:
                v_links = _verify_links_headless(links, engine=eng, p_dialog=None)
                if v_links:
                    links = _filter_and_sort_links(v_links)
                else:
                    _hc = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
                    links = _filter_and_sort_links([l for l in links if _is_torrent_link(l) or (not _hc and _is_web_captcha_server(_get_link_server_name(l), l))])
                verified_flag = True

            meta = {
                'tmdb': tmdb_id or get_param('tmdb'), 'imdb': imdb_id or get_param('imdb'), 'tvdb': tvdb_id or get_param('tvdb'), 'trakt': trakt_id or get_param('trakt'),
                'title': title or get_param('title') or get_param('title_es') or get_param('title_lat') or ((showname if (season and episode) else '') or ''),
                'year': (showyear or get_param('showyear')) if (season and episode) else (year or get_param('year')),
                'season': season or get_param('season'), 'episode': episode or get_param('episode'), 'showname': showname or get_param('showname'), 'showyear': showyear or get_param('showyear'),
                'plot': plot or get_param('plot'),
                'director': _clean_single_director(director) or _clean_single_director(get_param('director')) or (_get_directors(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode')))) or [''])[0],
                'tagline': tagline or get_param('tagline'),
                'poster': poster or get_param('poster'), 'fanart': fanart or get_param('fanart'), 'thumbnail': (_get_episode_still(tmdb_id or get_param('tmdb'), season or get_param('season'), episode or get_param('episode')) if ((season or get_param('season')) and (episode or get_param('episode'))) else '') or thumbnail or get_param('thumbnail'),
                'clearlogo': (clearlogo if clearlogo and clearlogo not in ('_', 'None') else '') or (get_param('clearlogo') if get_param('clearlogo') not in ('_', 'None', None) else '') or _get_clearlogo(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode')))),
                'genre': (genre if genre and genre not in ('_', 'None') else '') or (get_param('genre') if get_param('genre') not in ('_', 'None', None) else '') or " / ".join(_get_genres(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode'))))),
                'verified_only': verified_flag, 'engine': eng
            }
            if matched_item:
                _enrich_link_metadata(None, meta, matched_item)
            try:
                _store_ram_search_cache(links or [], matched_item, meta, eng)
                _save_search_cache_atomic({
                    'item': _serialize_item(matched_item) if matched_item else None,
                    'links': [_serialize_item(l) for l in (links or [])],
                    'meta': meta,
                    'engine': eng,
                    'cache_ver': 2
                })
            except: pass
            try:
                _spawn_late_collector(eng, meta.get('tmdb'), meta.get('season'), meta.get('episode'))
            except: pass

        if not links:
            _offer_elementum_search(meta)
            return


        autoplay = _bridge_addon.getSetting('autoplay_enabled') == 'true'
        if autoplay:
            _enrich_link_metadata(links[0], meta, matched_item)
            media_key = _get_media_key(meta, links[0])
            is_s = bool(meta.get('season') and meta.get('episode'))
            bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s,
                              season=meta.get('season'), episode=meta.get('episode'))
            seek_to_time = 0
            if bm:
                r_time = float(bm.get('resume_time', 0))
                mins = int(r_time // 60); secs = int(r_time % 60)
                hrs = mins // 60; mins = mins % 60
                time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
                t_title = meta.get('title') or getattr(matched_item, 'title', '') or 'este video'
                ans = _ask_resume_dialog(t_title, time_str, media_key=media_key)
                if ans == 'cancel':
                    if handle >= 0:
                        try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                        except: pass
                    return
                elif ans == 'resume':
                    seek_to_time = r_time
                elif ans == 'restart':
                    seek_to_time = 0

            xbmc.log('Multi Bridge: autoplay con fallback, %d enlaces disponibles, motor=%s' % (
                len(links), meta.get('engine', 'alfa')), xbmc.LOGINFO)

            # Intenta TODOS los enlaces no-torrent con monitoreo de 3 min cada uno
            played = _autoplay_with_fallback(
                links, handle,
                engine       = meta.get('engine', 'alfa'),
                matched_item = matched_item,
                monitor_secs = 180,
                max_attempts = 999,
                tmdb_for_list= str(tmdb_id or meta.get('tmdb') or ''),
                meta         = meta, seek_to_time=seek_to_time,
                resume_media_key=media_key,
                resume_title=meta.get('title', ''))
            if not played and not xbmc.Player().isPlaying():
                if not _links_view_active:
                    _cur_tmdb = str(tmdb_id or get_param('tmdb') or meta.get('tmdb') or '')
                    _ts = int(time.time())
                    _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
                    if meta.get('season') and meta.get('episode'):
                        _win_url += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
                    _open_links_view(_win_url)
            return

        else:
            # Autoplay desactivado → abrir directamente la lista de enlaces
            _cur_tmdb = str(tmdb_id or get_param('tmdb') or meta.get('tmdb') or '')
            _ts = int(time.time())
            _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
            if meta.get('season') and meta.get('episode'):
                _win_url += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
            _open_links_view(_win_url)
            return

    if action == 'play':
        _tentative_title = (title or get_param('title') or get_param('title_es') or get_param('title_lat') or showname or get_param('showname') or 'Contenido')
        if not _acquire_search_lock_atomic(_tentative_title):
            running_title = _get_search_process_title_global() or _tentative_title
            msg = 'Ya hay una búsqueda en proceso'
            if running_title:
                msg += ' (%s)' % running_title
            msg += '. Por favor, espera a que finalice.'
            xbmc.log("Multi Bridge: Invocación duplicada interceptada. Ya hay un proceso activo: %s" % running_title, xbmc.LOGWARNING)
            try:
                xbmc.executebuiltin('Dialog.Close(10101,true)')
            except Exception:
                pass
            _show_bridge_notification('Multi Bridge', msg, 3500)
            if handle >= 0:
                try: xbmcplugin.endOfDirectory(handle, succeeded=False)
                except Exception: pass
            return

        try:
            _play_action_impl(_tentative_title)
        finally:
            _release_search_lock_atomic()
        return

    if url:
        search_item = None
        if 'action=search' in url:
            _is_s_url = bool((season or get_param('season')) and (episode or get_param('episode')))
            if _is_s_url:
                eng = 'balandro'
                xbmc.log("Multi Bridge: Búsqueda para serie en URL -> Balandro asignado automáticamente", xbmc.LOGINFO)
            else:
                eng = 'alfa'
                def_engine = _get_int_setting('default_engine', 0)
                if def_engine == 0:
                    _picked = _show_engine_picker()
                    if _picked is None:
                        xbmcplugin.endOfDirectory(handle, succeeded=False)
                        return
                    eng = _picked
                elif def_engine == 1: eng = 'alfa'
                elif def_engine == 2: eng = 'balandro'

            links, matched_item = run_parallel_search(engine=eng)
        else:
            is_alfa = 'alfa' in url.lower()
            is_series = bool((season or get_param('season')) and (episode or get_param('episode')))
            if is_alfa and is_series:
                xbmcgui.Dialog().notification('Multi Bridge', 'Alfa solo soporta películas', '', 3000)
                xbmcplugin.endOfDirectory(handle, succeeded=False)
                return

            eng = 'alfa' if is_alfa else 'balandro'
            mods = _get_alfa_modules() if is_alfa else _get_balandro_modules()
            ItemClass = mods['Item'] if mods else object
            raw_b64 = url.split('plugin://plugin.video.alfa/?')[-1].split('plugin://plugin.video.balandro/?')[-1].split('&')[0]
            raw_b64 = uparse.unquote(raw_b64)
            search_item = decode_base64_item(raw_b64, ItemClass)
            target_channel = getattr(search_item, 'channel', '')
            target_title = (showname or get_param('showname') if is_series else (title or get_param('title'))) or get_param('title_es') or get_param('title_lat') or get_param('title_orig') or get_param('title_en') or ''
            target_year = (showyear or get_param('showyear')) if is_series else (year or get_param('year'))
            target_tmdb = tmdb_id or get_param('tmdb')
            target_imdb = imdb_id or get_param('imdb')
            _res_meta_url = _resolve_localized_metadata(
                tmdb_id=target_tmdb,
                is_series=is_series,
                season=season or get_param('season'),
                episode=episode or get_param('episode'),
                plot_lat=plot_lat or get_param('plot_lat'),
                plot_es=plot_es or get_param('plot_es'),
                plot_param=plot or get_param('plot'),
                tagline_lat=tagline_lat or get_param('tagline_lat'),
                tagline_es=tagline_es or get_param('tagline_es'),
                tagline_param=tagline or get_param('tagline'),
                title_lat=title_lat or get_param('title_lat'),
                title_es=title_es or get_param('title_es'),
                title_param=target_title
            )
            if _res_meta_url.get('plot'):
                plot = _res_meta_url['plot']
            if _res_meta_url.get('tagline') is not None:
                tagline = _res_meta_url['tagline']
            if _res_meta_url.get('title') and _res_meta_url.get('has_spanish'):
                if not title_es:
                    title_es = _res_meta_url['title']
            all_names = [t for t in [target_title, title or get_param('title'), title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_en or get_param('title_en'), title_orig or get_param('title_orig'), showname or get_param('showname')] if t]
            alt_terms = [t for t in [title_es or get_param('title_es'), title_lat or get_param('title_lat'), title_orig or get_param('title_orig'), title_en or get_param('title_en'), showname or get_param('showname'), title or get_param('title')] if t and t != target_title]
            if target_channel and target_channel != 'search':
                p_dialog = xbmcgui.DialogProgress()
                p_dialog.create('Multi Bridge', 'Buscando en %s...' % target_channel.capitalize())
                if is_alfa:
                    matched_item, links = _search_channel_alfa(target_channel, target_title, target_year, is_series, season or get_param('season'), episode or get_param('episode'), all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
                else:
                    matched_item, links = _search_channel_balandro(target_channel, target_title, target_year, is_series, season or get_param('season'), episode or get_param('episode'), all_names, base_item=search_item, alt_terms=alt_terms, target_tmdb=target_tmdb, target_imdb=target_imdb)
                p_dialog.close()
            else:
                links, matched_item = run_parallel_search(engine=eng)

        if links and matched_item:
            verified_flag = (getattr(matched_item, '_pipeline_verified', False) if matched_item else False) or _PIPELINE_VERIFIED_SEARCH
            _auto_verify2 = _bridge_addon.getSetting('auto_verify_links') == 'true'
            xbmc.log(f"Multi Bridge: auto_verify_links={_auto_verify2} engine={eng} links={len(links) if links else 0} pipeline_verified={verified_flag}", xbmc.LOGINFO)
            if _auto_verify2 and not verified_flag:
                v_links = _verify_links_headless(links, engine=eng, p_dialog=None)
                if v_links:
                    links = v_links
                else:
                    _hc2 = (_bridge_addon.getSetting('hide_captcha_links') == 'true')
                    links = [l for l in links if _is_torrent_link(l) or (not _hc2 and _is_web_captcha_server(_get_link_server_name(l), l))]
                verified_flag = True

            links = _filter_and_sort_links(links)
            meta = {
                'tmdb': tmdb_id or get_param('tmdb'), 'imdb': imdb_id or get_param('imdb'), 'tvdb': tvdb_id or get_param('tvdb'), 'trakt': trakt_id or get_param('trakt'),
                'title': title or get_param('title') or get_param('title_es') or get_param('title_lat') or ((showname if (season and episode) else '') or ''),
                'year': (showyear or get_param('showyear')) if (season and episode) else (year or get_param('year')),
                'season': season or get_param('season'), 'episode': episode or get_param('episode'), 'showname': showname or get_param('showname'), 'showyear': showyear or get_param('showyear'),
                'plot': plot or get_param('plot'),
                'director': _clean_single_director(director) or _clean_single_director(get_param('director')) or (_get_directors(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode')))) or [''])[0],
                'tagline': tagline or get_param('tagline'),
                'poster': poster or get_param('poster'), 'fanart': fanart or get_param('fanart'), 'thumbnail': (_get_episode_still(tmdb_id or get_param('tmdb'), season or get_param('season'), episode or get_param('episode')) if ((season or get_param('season')) and (episode or get_param('episode'))) else '') or thumbnail or get_param('thumbnail'),
                'clearlogo': (clearlogo if clearlogo and clearlogo not in ('_', 'None') else '') or (get_param('clearlogo') if get_param('clearlogo') not in ('_', 'None', None) else '') or _get_clearlogo(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode')))),
                'genre': (genre if genre and genre not in ('_', 'None') else '') or (get_param('genre') if get_param('genre') not in ('_', 'None', None) else '') or " / ".join(_get_genres(tmdb_id or get_param('tmdb'), bool((season or get_param('season')) and (episode or get_param('episode'))))),
                'verified_only': verified_flag, 'engine': eng
            }
            if matched_item:
                _enrich_link_metadata(None, meta, matched_item)
            try:
                _store_ram_search_cache(links or [], matched_item, meta, eng)
                _save_search_cache_atomic({
                    'item': _serialize_item(matched_item),
                    'links': [_serialize_item(l) for l in (links or [])],
                    'meta': meta,
                    'engine': eng,
                    'cache_ver': 2
                })
            except Exception: pass
            try:
                _spawn_late_collector(eng, meta.get('tmdb'), meta.get('season'), meta.get('episode'))
            except: pass

            autoplay = _bridge_addon.getSetting('autoplay_enabled') == 'true'
            if autoplay:
                _enrich_link_metadata(links[0], meta, matched_item)
                media_key = _get_media_key(meta, links[0])
                is_s = bool(meta.get('season') and meta.get('episode'))
                bm = get_bookmark(media_key, tmdb_id=meta.get('tmdb'), is_series=is_s,
                                  season=meta.get('season'), episode=meta.get('episode'))
                seek_to_time = 0
                if bm:
                    r_time = float(bm.get('resume_time', 0))
                    if r_time > 10:
                        mins = int(r_time // 60); secs = int(r_time % 60)
                        hrs = mins // 60; mins = mins % 60
                        time_str = ('%d:%02d:%02d' % (hrs, mins, secs)) if hrs else ('%d:%02d' % (mins, secs))
                        t_title = meta.get('title') or getattr(matched_item, 'title', '') or 'este video'
                        ans = _ask_resume_dialog(t_title, time_str, media_key=media_key)
                        if ans == 'cancel':
                            xbmcgui.Window(10000).setProperty(bridge.autoplay_canceled, true)
                            if handle >= 0:
                                try: xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
                                except: pass
                            return
                        elif ans == 'resume':
                            seek_to_time = r_time
                        elif ans == 'restart':
                            seek_to_time = 0

                played = _autoplay_with_fallback(
                    links, handle,
                    engine       = meta.get('engine', 'alfa'),
                    matched_item = matched_item,
                    monitor_secs = 180,
                    max_attempts = 999,
                    tmdb_for_list= str(tmdb_id or meta.get('tmdb') or ''),
                    meta         = meta, seek_to_time=seek_to_time,
                    resume_media_key=media_key,
                    resume_title=meta.get('title', ''))
            else:
                _cur_tmdb = str(tmdb_id or get_param('tmdb') or meta.get('tmdb') or '')
                _ts = int(time.time())
                _win_url = 'plugin://plugin.video.bridge.multi/?view=list_links&tmdb=%s&t=%s' % (_cur_tmdb, _ts)
                if meta.get('season') and meta.get('episode'):
                    _win_url += '&season=%s&episode=%s' % (meta['season'], meta['episode'])
                _open_links_view(_win_url)
            return
        else:
            _meta_fallback = {
                'tmdb':    tmdb_id or get_param('tmdb'),
                'title':   title or get_param('title') or get_param('title_es') or get_param('title_lat') or showname or get_param('showname'),
                'season':  season or get_param('season'),
                'episode': episode or get_param('episode'),
                'showname': showname or get_param('showname'),
            }
            _offer_elementum_search(_meta_fallback)
        return




if __name__ == '__main__':
    main()
